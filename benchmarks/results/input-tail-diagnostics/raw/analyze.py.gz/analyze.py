import json,re,hashlib
from pathlib import Path
base=Path(__file__).parent
runs=[]
for label in ['A1','B1','B2','A2']:
 r=json.loads((base/(label+'.json')).read_text()); traces={};current=None
 for line in (base/(label+'.trace.log')).read_text().splitlines():
  if line.startswith('DIAGNOSTIC_BEGIN '):
   d=json.loads(line.split(' ',1)[1]);current=(d['editor'],d['size'],d['scenario'],d['index']);traces[current]=[]
  elif line.startswith('DIAGNOSTIC_END '):current=None
  elif current is not None:traces[current].append(line)
 row=r['rows'][0]; samples=[]
 for s in row['warmupSamples']+row['samples']:
  d=s['diagnostic'];start,end=d['inputStart'],d['inputEnd'];stages=[t for t in d['stages'] if t['start']>=start and t['end']<=end];events=traces[(row['editor'],row['size'],row['scenario'],s['index'])]
  gc=[e for e in r['diagnostic']['gcEvents'] if e['start']<end and e['start']+e['duration']>start]
  samples.append({'index':s['index'],'ms':s['ms'],'heapDeltaInput':d['heapPostInput']-d['heapPreInput'],'stages':[dict(t,ms=t['end']-t['start']) for t in stages],'gc':gc,'jitLines':len([e for e in events if any(w in e for w in ['optim','compiling'])]),'deopts':[e for e in events if 'bailout' in e],'traceLines':events})
 runs.append({'label':label,'result':r['result'],'rows':len(r['rows']),'node':r['node'],'target':r['target'],'distHash':r['before']['aggregate'],'samples':samples})
summary={'result':'DIAGNOSTIC_ONLY','acceptance':'NOT_RUN; original INVESTIGATE guards remain unchanged','runs':runs,'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(base.glob('*')) if p.is_file() and p.name not in ['summary.json','report.md']}}
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Slate 10k input tail diagnostic','','Fixed A1-B1-B2-A2 sequence. All 16 cells and original operation/model/history oracles are retained per capture. Instrumented times do not qualify acceptance. Original results and guards remain unchanged.','','| Capture | Index | Total ms | Sync change ms | Flush ms | Driver clone ms | Runtime commit ms | Input GC ms | JIT trace lines |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for r in runs:
 for s in r['samples']:
  if s['index']<0:continue
  def total(label):return sum(t['ms'] for t in s['stages'] if t['label']==label)
  lines.append(f"| {r['label']} | {s['index']} | {s['ms']:.3f} | {total('input.syncChange'):.3f} | {total('input.flush'):.3f} | {total('driver.commitClone'):.3f} | {total('runtime.commit'):.3f} | {sum(e['duration'] for e in s['gc']):.3f} | {s['jitLines']} |")
(base/'report.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
