# Slate 10k input tail diagnostic

Fixed A1-B1-B2-A2 sequence. All 16 cells and original operation/model/history oracles are retained per capture. Instrumented times do not qualify acceptance. Original results and guards remain unchanged.

| Capture | Index | Total ms | Sync change ms | Flush ms | Driver clone ms | Runtime commit ms | Input GC ms | JIT trace lines |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| A1 | 0 | 2.200 | 0.141 | 2.052 | 0.007 | 0.019 | 0.000 | 6 |
| A1 | 1 | 1.397 | 0.096 | 1.299 | 0.006 | 0.014 | 0.000 | 6 |
| A1 | 2 | 1.461 | 0.087 | 1.372 | 0.005 | 0.025 | 0.000 | 11 |
| A1 | 3 | 1.608 | 0.079 | 1.526 | 0.009 | 0.012 | 0.000 | 6 |
| A1 | 4 | 1.515 | 0.077 | 1.435 | 0.006 | 0.009 | 0.000 | 6 |
| A1 | 5 | 1.125 | 0.074 | 1.049 | 0.006 | 0.007 | 0.000 | 0 |
| A1 | 6 | 1.248 | 0.075 | 1.171 | 0.006 | 0.009 | 0.000 | 0 |
| A1 | 7 | 1.249 | 0.078 | 1.153 | 0.006 | 0.009 | 0.000 | 2 |
| B1 | 0 | 1.611 | 0.118 | 1.491 | 0.006 | 0.019 | 0.000 | 2 |
| B1 | 1 | 0.956 | 0.092 | 0.862 | 0.006 | 0.013 | 0.000 | 4 |
| B1 | 2 | 0.936 | 0.113 | 0.820 | 0.009 | 0.011 | 0.000 | 0 |
| B1 | 3 | 0.929 | 0.093 | 0.834 | 0.006 | 0.009 | 0.000 | 0 |
| B1 | 4 | 1.105 | 0.082 | 1.020 | 0.010 | 0.040 | 0.000 | 4 |
| B1 | 5 | 0.770 | 0.081 | 0.687 | 0.006 | 0.010 | 0.000 | 0 |
| B1 | 6 | 0.879 | 0.100 | 0.776 | 0.007 | 0.012 | 0.000 | 0 |
| B1 | 7 | 0.931 | 0.089 | 0.824 | 0.010 | 0.010 | 0.000 | 2 |
| B2 | 0 | 1.828 | 0.200 | 1.626 | 0.007 | 0.020 | 0.000 | 4 |
| B2 | 1 | 0.896 | 0.089 | 0.805 | 0.008 | 0.012 | 0.000 | 2 |
| B2 | 2 | 0.883 | 0.092 | 0.789 | 0.005 | 0.039 | 0.000 | 1 |
| B2 | 3 | 0.961 | 0.100 | 0.859 | 0.008 | 0.013 | 0.000 | 0 |
| B2 | 4 | 0.853 | 0.077 | 0.774 | 0.007 | 0.007 | 0.000 | 1 |
| B2 | 5 | 0.918 | 0.100 | 0.816 | 0.006 | 0.013 | 0.000 | 0 |
| B2 | 6 | 0.903 | 0.090 | 0.811 | 0.006 | 0.014 | 0.000 | 0 |
| B2 | 7 | 0.942 | 0.089 | 0.835 | 0.006 | 0.015 | 0.000 | 2 |
| A2 | 0 | 1.833 | 0.104 | 1.727 | 0.007 | 0.038 | 0.000 | 8 |
| A2 | 1 | 2.595 | 0.104 | 2.488 | 0.009 | 0.013 | 1.050 | 9 |
| A2 | 2 | 1.530 | 0.112 | 1.414 | 0.007 | 0.011 | 0.000 | 10 |
| A2 | 3 | 1.221 | 0.065 | 1.154 | 0.006 | 0.023 | 0.000 | 4 |
| A2 | 4 | 1.552 | 0.086 | 1.464 | 0.006 | 0.011 | 0.000 | 7 |
| A2 | 5 | 1.291 | 0.077 | 1.211 | 0.006 | 0.010 | 0.000 | 0 |
| A2 | 6 | 1.252 | 0.081 | 1.168 | 0.005 | 0.008 | 0.000 | 0 |
| A2 | 7 | 1.293 | 0.096 | 1.169 | 0.006 | 0.011 | 0.000 | 3 |

## Findings

- All four captures complete all 16 original oracle/count/history cells without failure. Distribution fingerprints remain unchanged within each capture.
- The retained original candidate spike (4.481–4.962 ms) does not recur in these instrumented captures. This does not invalidate the original flag.
- Candidate first measured input takes 1.611/1.828 ms. Its sync native Transform takes 0.118/0.200 ms; callback microtask flush takes 1.491/1.626 ms. This isolates the larger share to callback work, not synchronous native Transform work. Flush includes binding work and cannot be interpreted as idle delay.
- Candidate measured input has no overlapping GC event. Baseline A2 index 1 takes 2.595 ms and overlaps a 1.050 ms minor GC event. This confirms GC can create a tail sample in this fixture/driver, but does not establish GC as the cause of the original candidate spike.
- Every first measured input overlaps JIT trace activity. Candidate B1 has two compilation lines and B2 has four; neither contains a deoptimization event. Later samples also have some JIT activity. This establishes cold compilation activity, not its wall-time contribution or causality for the original tail.
- Driver operation clone costs 0.005–0.010 ms in the candidate measured samples. Runtime commit itself costs 0.007–0.040 ms. Neither explains a several-millisecond tail in these captures. The operation clone proof remains intact.
- No runtime change is justified by these traces. Original performance status remains INVESTIGATE. No acceptance rerun, threshold adjustment, warmup change, forced GC, sample exclusion, CPU profile, or Chrome profile was performed.

## Next bounded option

If further diagnosis is authorized, use one baseline/candidate CPU-profile pair over the same full fixture order to locate callback-flush work. CPU-profile times are diagnostic only. A separate Chrome trace pair is needed to attribute browser tails; Node traces cannot establish browser causality.

## Reproduction

The manifest contains the exact commands, order, timestamps and SHA-256 of both source and diagnostic harnesses. Each raw JSON retains all warmup/measured samples, per-stage CPU usage, heap data and global GC entries. Each trace log has begin/end markers for each native-input interval. summary.json joins those intervals with GC entries and JIT lines. No tests/builds overlapped this exclusive measurement interval.
