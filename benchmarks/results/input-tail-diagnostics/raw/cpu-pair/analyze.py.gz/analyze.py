import json,collections
from pathlib import Path
out=Path(__file__).parent;cal=json.loads((out/'clock-calibration.json').read_text());results=[]
for side in ['A','B']:
 r=json.loads((out/(side+'.json')).read_text());p=json.loads((out/(side+'.json.cpuprofile')).read_text());nodes={n['id']:n for n in p['nodes']};parents={c:n['id'] for n in p['nodes'] for c in n.get('children',[])};t=p['startTime'];points=[]
 for sid,dt in zip(p['samples'],p['timeDeltas']):t+=dt;points.append((t,sid,dt))
 rows=[]
 for s in r['rows'][0]['warmupSamples']+r['rows'][0]['samples']:
  d=s['diagnostic'];lo=int(d['hrtimeInputStart'])/1000;hi=int(d['hrtimeInputEnd'])/1000;hits=[x for x in points if lo<=x[0]+cal['lower'] and x[0]+cal['upper']<=hi];possible=[x for x in points if x[0]+cal['upper']>=lo and x[0]+cal['lower']<=hi];selfs=collections.Counter();inclusive=collections.Counter()
  for t,nid,dt in hits:
   def key(i):
    f=nodes[i]['callFrame'];return f"{f['functionName'] or '(anonymous)'} {f['url']}:{f['lineNumber']+1}"
   selfs[key(nid)]+=1
   while nid in nodes:
    inclusive[key(nid)]+=1
    if nid not in parents:break
    nid=parents[nid]
  gc=[e for e in r['diagnostic']['gcEvents'] if e['start']<d['inputEnd'] and e['start']+e['duration']>d['inputStart']]
  rows.append({'index':s['index'],'ms':s['ms'],'guaranteedHits':len(hits),'possibleHits':len(possible),'selfSamples':selfs.most_common(15),'inclusiveSamples':inclusive.most_common(30),'gc':gc,'hrtimeInputStartUs':lo,'hrtimeInputEndUs':hi})
 results.append({'side':side,'result':r['result'],'rows':len(r['rows']),'samples':rows})
 print(side,[(x['index'],round(x['ms'],3),x['guaranteedHits'],x['selfSamples'][:4]) for x in rows])
(out/'attribution.json').write_text(json.dumps({'purpose':'Diagnostic only. Conservative samples inside input for every clock offset in calibration bracket. Not exact duration.','calibration':cal,'results':results},indent=2)+'\n')
