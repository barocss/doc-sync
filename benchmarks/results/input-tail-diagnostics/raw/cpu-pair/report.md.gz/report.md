# Node CPU profile pair

One baseline A / candidate B pair completed. Each capture retained all 16 fixture/scenario cells, warmups, operation clones and fixed model/count/history oracles. Each capture passes those 16 cells. CPU sampling at 100 microseconds covers only the first Slate 10k insertion cell, including its fixture, warmups and measured inputs. These are diagnostic times, not performance acceptance.

The candidate first measured input takes **5.395 ms**. A **3.788 ms major GC** begins at performance time 305.403 ms inside input 304.852–310.248 ms. Its synchronous native Transform takes 0.155 ms; callback flush takes 5.234 ms. This directly attributes most of this reproduced spike to GC. Candidate sample 1 takes 2.309 ms and overlaps a 1.053 ms minor GC; sample 5 takes 2.343 ms and overlaps a 1.447 ms minor GC. Samples 2–4 and 6–7 take 0.818–1.090 ms without overlapping GC.

Candidate sample 0 enters fixture preparation at 57.45 MB heap and starts input at 91.61 MB, then drops to 40.64 MB after its major GC. Non-GC candidate input samples increase net heap by about 1.5–1.6 MB. The fresh-fixture/oracle setup can therefore leave substantial collectible data and heap pressure before the timed action. This diagnostic does not distinguish which allocation originally scheduled the GC. A future steady-state editor benchmark could answer a different question, but must not replace or rewrite the retained fixed fixture result.

The original B2/B3 receipts did not capture GC. This pair demonstrates a matching first-sample GC failure mode; it cannot prove the original spikes had the same cause. The earlier four trace captures did not reproduce a candidate GC tail. This variability must remain visible.

Candidate driver operation clone is 0.006–0.016 ms and runtime commit is 0.010–0.047 ms in this capture. There is no evidence that either is the several-millisecond cause. The callback profile includes schema/model conversion and equality work, but this small sample does not establish an unnecessary runtime path or justify a code change.

macOS inspector profile timestamps and process.hrtime use different monotonic domains. clock-calibration.json retains five empty inspector start/stop captures used only to bracket the clock offset; these are not additional benchmark samples. The common offset bracket is 0.790 ms wide. attribution.json counts a CPU sample as guaranteed only when its timestamp falls inside the input for every offset in that bracket. The candidate first input has 35 such samples, 31 labelled garbage collector. Boundary samples are excluded from this statistic. Exact pause duration comes from PerformanceObserver, whose timestamps share performance.now with the input windows.

Raw A/B JSON, CPU profiles, logs, exact commands, calibration and conservative attribution are retained beside this report. The original guards remain INVESTIGATE. No forced GC, extra warmups, sample exclusion, runtime edit or acceptance rerun was performed.
