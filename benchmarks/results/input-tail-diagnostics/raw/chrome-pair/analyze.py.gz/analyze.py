import json,collections,bisect
from pathlib import Path
base=Path(__file__).parent;receipt=json.loads((base/'receipt.json').read_text());reports=[]
for api in ['legacy','unified']:
 trace=json.loads((base/(api+'.trace.json')).read_text());events=trace['traceEvents'];marks={};profiles={}
 for e in events:
  if e['name'].startswith(('tail-input:','tail-dom:')):marks.setdefault(e['name'],e)
  if e['name']=='Profile':
   key=(e['pid'],e.get('id'));profiles[key]={'time':e['args']['data']['startTime'],'nodes':{},'points':[]}
  elif e['name']=='ProfileChunk':
   key=(e['pid'],e.get('id'));d=e['args']['data'];p=profiles.get(key)
   if p is None:continue
   cpu=d.get('cpuProfile',{});p['nodes'].update({n['id']:n for n in cpu.get('nodes',[])})
   for sid,dt in zip(cpu.get('samples',[]),d.get('timeDeltas',[])):p['time']+=dt;p['points'].append((p['time'],sid))
 for p in profiles.values():p['timestamps']=[t for t,_ in p['points']]
 obs=[]
 for o in [o for o in receipt['observations'] if o['api']==api]:
  label=f"{api}:{o['source']}:{o['index']}";start=marks['tail-input:'+label];doms=[marks['tail-dom:'+label+':'+p['name']]['ts'] for p in o['peers']];lo,hi=start['ts'],max(doms);selfs=collections.Counter();inclusive=collections.Counter();samples=0
  for (pid,pidProfile),p in profiles.items():
   if pid!=start['pid']:continue
   ix,jx=bisect.bisect_left(p['timestamps'],lo),bisect.bisect_right(p['timestamps'],hi)
   for t,nid in p['points'][ix:jx]:
    samples+=1
    def key(i):
     f=p['nodes'].get(i,{}).get('callFrame',{});return f"{f.get('functionName') or '(anonymous)'} {f.get('url','')}:{f.get('lineNumber',-1)+1}"
    selfs[key(nid)]+=1;seen=set();seenLabels=set()
    while nid in p['nodes'] and nid not in seen:
     seen.add(nid);labelKey=key(nid)
     if labelKey not in seenLabels:inclusive[labelKey]+=1;seenLabels.add(labelKey)
     nid=p['nodes'][nid].get('parent')
  relevant=[e for e in events if e.get('ph')=='X' and e.get('pid')==start['pid'] and e.get('tid')==start['tid'] and e['ts']<hi and e['ts']+e.get('dur',0)>lo];timelines=collections.Counter()
  for e in relevant:timelines[e['name']]+=max(0,min(hi,e['ts']+e.get('dur',0))-max(lo,e['ts']))/1000
  obs.append({'source':o['source'],'index':o['index'],'warmup':o['warmup'],'maxDOMMs':max(p['inputToDOM'] for p in o['peers']),'traceWindowMs':(hi-lo)/1000,'samples':samples,'selfSamples':selfs.most_common(15),'inclusiveSamples':inclusive.most_common(25),'timelineMs':dict(timelines.most_common(20)),'gcEvents':[e for e in relevant if e['name'] in ['MajorGC','MinorGC']]})
 reports.append({'api':api,'eventCount':len(events),'profileCount':len(profiles),'inputMarks':len([k for k in marks if k.startswith('tail-input:')]),'domMarks':len([k for k in marks if k.startswith('tail-dom:')]),'observations':obs})
 print(api,'events',len(events),'profiles',len(profiles),'top tails',[(o['source'],o['index'],round(o['maxDOMMs'],3),o['samples'],o['selfSamples'][:4],[(e['name'],e['dur']/1000) for e in o['gcEvents']]) for o in sorted([o for o in obs if not o['warmup']],key=lambda o:o['maxDOMMs'],reverse=True)[:5]])
(base/'attribution.json').write_text(json.dumps({'purpose':'Diagnostic only; default browser CPU samples and timeline overlap, inclusive event durations cannot be summed.','reports':reports},indent=2)+'\n')
