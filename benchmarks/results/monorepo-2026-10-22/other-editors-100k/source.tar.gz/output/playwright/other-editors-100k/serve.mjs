import {spawn} from 'node:child_process';
import {createServer,request} from 'node:http';
import {readFileSync} from 'node:fs';
const root=process.cwd(), folder=root+'/output/playwright/other-editors-100k';
const child=spawn(process.execPath,[folder+'/server-launch.mjs'],{env:{...process.env,PORT:'0'},stdio:['ignore','pipe','inherit']});
let output='';const backend=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',code=>reject(Error('backend exit '+code)));child.stdout.on('data',chunk=>{output+=chunk;const match=output.match(/http:\/\/localhost:(\d+)/);if(match)resolve(match[0]);});});
const server=createServer((req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname;
 if(['/','/bundle.js','/bundle.js.map'].includes(path)){res.writeHead(200,{'content-type':path==='/'?'text/html; charset=utf-8':'text/javascript','cache-control':'no-store'});res.end(readFileSync(folder+(path==='/'?'/index.html':path)));return;}
 if(path==='/favicon.ico'){res.writeHead(204);res.end();return;}
 const proxy=request(backend+req.url,{method:req.method,headers:{...req.headers,host:new URL(backend).host}},up=>{res.writeHead(up.statusCode,up.headers);up.pipe(res);});
 proxy.on('error',error=>{if(!res.headersSent)res.writeHead(502);res.end(error.message);});res.on('close',()=>proxy.destroy());req.pipe(proxy);
});
server.listen(0,'127.0.0.1',()=>console.log(JSON.stringify({url:'http://127.0.0.1:'+server.address().port,backend,dataDir:process.env.DATA_DIR})));
const stop=()=>{child.kill();server.closeAllConnections();server.close(()=>process.exit());};process.on('SIGTERM',stop);process.on('SIGINT',stop);child.on('exit',()=>{server.closeAllConnections();server.close();});
