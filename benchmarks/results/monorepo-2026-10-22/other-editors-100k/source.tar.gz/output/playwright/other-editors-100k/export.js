async page=>{
 const state=await page.evaluate(async()=>({samples:__latency.samples,longTasks:__latency.longTasks,snapshot:compat.snapshot(),server:await(await fetch('/api/docs/'+new URLSearchParams(location.search).get('doc')+'/state')).json(),timeOrigin:performance.timeOrigin,userAgent:navigator.userAgent,visibility:document.visibilityState,devicePixelRatio,browserTime:new Date().toISOString()}));
 const [download]=await Promise.all([page.waitForEvent('download'),page.evaluate(state=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(state)],{type:'application/json'}));a.download='browser-raw.json';a.click();URL.revokeObjectURL(a.href);},state)]);
 await download.saveAs(OUTPUT);return{samples:state.samples.length,failures:state.snapshot.failures,clients:state.snapshot.peers.map(p=>({name:p.name,pending:p.pending,seq:p.seq,fallbacks:p.fallbacks})),serverSeq:state.server.serverSeq};
}
