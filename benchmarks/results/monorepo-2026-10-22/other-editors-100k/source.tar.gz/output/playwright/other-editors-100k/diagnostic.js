async (page) => {
  const direction = await page.evaluate(() => __latency.currentDirection);
  const session = await page.context().newCDPSession(page);
  const prefix = RESULT_PREFIX + direction;
  await session.send('Profiler.enable');
  await session.send('Profiler.setSamplingInterval', {interval: 1000});
  await session.send('Tracing.start', {categories: 'devtools.timeline,blink.user_timing,disabled-by-default-devtools.timeline,disabled-by-default-devtools.screenshot', transferMode: 'ReturnAsStream'});
  await session.send('Profiler.start');
  const id = await page.evaluate(() => __latency.begin(__latency.currentDirection, 'z', 'diagnostic', 0));
  await page.keyboard.press('z');
  await page.waitForFunction(id => __latency.samples.some(s => s.id === id && s.done), id.id, {timeout: 60000});
  const {profile} = await session.send('Profiler.stop');
  const tracingComplete = new Promise(resolve => session.once('Tracing.tracingComplete', resolve));
  await session.send('Tracing.end');
  const event = await tracingComplete;
  let trace = '';
  for (;;) {
    const piece = await session.send('IO.read', {handle: event.stream});
    trace += piece.data;
    if (piece.eof) break;
  }
  await session.send('IO.close', {handle: event.stream});
  for (const [suffix, text] of [['trace.json', trace], ['cpuprofile', JSON.stringify(profile)]]) {
    const [download] = await Promise.all([
      page.waitForEvent('download'),
      page.evaluate(({text, name}) => {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([text], {type: 'application/json'}));
        a.download = name; a.click(); URL.revokeObjectURL(a.href);
      }, {text, name: direction + '.' + suffix}),
    ]);
    await download.saveAs(prefix + '.' + suffix);
  }
  await page.screenshot({path: SCREEN_PREFIX + direction + '.png'});
  await session.detach();
  return await page.evaluate(id => {
    const s = __latency.samples.find(s => s.id === id);
    return {id, domMs:s.inputToRemoteDomMs,frameMs:s.inputToRenderOpportunityMs,correct:s.correct && s.sourceCorrect};
  }, id.id);
}
