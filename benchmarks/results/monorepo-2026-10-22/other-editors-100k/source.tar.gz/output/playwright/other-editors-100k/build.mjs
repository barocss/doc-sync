import {readFileSync,writeFileSync} from 'node:fs';
import {build} from '../../../apps/demo/compat/node_modules/esbuild/lib/main.js';
const root=process.cwd(), out=root+'/output/playwright/other-editors-100k';
let source=readFileSync(root+'/apps/demo/compat/main.jsx','utf8');
source=source.replace("import React,", "import {Doc} from '@barocss/doc-sync';\nimport React,");
source=source.replaceAll('const editor=withReact(createSlateEditor());','const editor=withReact(createSlateEditor());peer.editor=editor;');
source=source.replace('editor.setRootElement(element);','peer.editor=editor;editor.setRootElement(element);');
source=source.replace('binding.view=view;','peer.binding=binding;peer.view=view;binding.view=view;');
const mounts="mountSlate('slate-a');mountSlate('slate-b');mountLexical('lexical-a');mountLexical('lexical-b');mountProseMirror('pm-a');";
if(!source.includes(mounts))throw Error('Mount list changed');
source=source.replace(mounts, `const chosen=new URLSearchParams(location.search).get('peers').split(',');
for(const name of chosen){if(name.startsWith('slate-'))mountSlate(name);else if(name.startsWith('lexical-'))mountLexical(name);else mountProseMirror(name);}
window.__benchmarkAPI={peers,Doc,SyncClient,HttpTransport,PmBinding,EditorView,InputSession,Transforms,TextSelection,$getRoot,$getSelection,$createRangeSelection,$setSelection};`);
writeFileSync(out+'/instrumented-main.jsx',source);
await build({stdin:{contents:source,resolveDir:root+'/apps/demo/compat',sourcefile:'compat-benchmark-main.jsx',loader:'jsx'},outfile:out+'/bundle.js',bundle:true,format:'esm',platform:'browser',sourcemap:true,jsx:'automatic',define:{'process.env.NODE_ENV':'"development"'}});
let html=readFileSync(root+'/apps/demo/compat/index.html','utf8');
html=html.replace('</style>', '#panes{grid-template-columns:1fr 1fr}.editor{height:460px;overflow:auto}section{min-width:0}</style>');
html=html.replace('참여자 5명','비교 시험 · 참여자 2명');
writeFileSync(out+'/index.html',html);
