import pathlib,subprocess,os,json,time,re,datetime,hashlib,shutil,tarfile
root=pathlib.Path('/Users/user/github/doc-sync');folder=root/'output/playwright/other-editors-100k';base=root/'benchmarks/results/monorepo-2026-10-22/other-editors-100k'
env={**os.environ,'PATH':'/Users/user/.nvm/versions/node/v22.19.0/bin:'+os.environ['PATH']}
wrapper='/Users/user/.codex/skills/playwright/scripts/playwright_cli.sh'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=sorted({*root.glob('packages/doc-sync/src/**/*.ts'),*root.glob('fixtures/*.ts'),root/'apps/demo/server.ts',*root.glob('apps/demo/compat/*.mjs'),*root.glob('apps/demo/compat/*.jsx'),*root.glob('apps/demo/compat/*.html'),*root.glob('apps/demo/compat/package*.json'),root/'package-lock.json'})
manifest={'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p)} for p in files],'harnessFiles':[{'path':str(p.relative_to(root)),'sha256':sha(p)} for p in folder.iterdir() if p.is_file() and p.suffix in ['.py','.js','.mjs','.jsx','.html'] and p.name!='bundle.js'],'bundleSha256':sha(folder/'bundle.js')}
(base/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(base/'source.tar.gz','x:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)))
 for p in folder.iterdir():
  if p.is_file() and p.suffix in ['.py','.js','.mjs','.jsx','.html'] and p.name!='bundle.js':tar.add(p,arcname=str(p.relative_to(root)))
(base/'source.diff').write_text(subprocess.check_output(['git','diff','--','packages/doc-sync/src/crdt/doc.ts','apps/demo/ui/editor.ts'],cwd=root,text=True))
data=pathlib.Path('/tmp/doc-sync-other-editors-100k-20261022');data.mkdir(exist_ok=False)
pairs=[('slate-a','lexical-a'),('slate-a','pm-a'),('lexical-a','pm-a')]
seed="""import {Doc} from './packages/doc-sync/src/index.ts';import {DEMO_SCHEMA} from './fixtures/demo-schema.ts';import {writeFileSync} from 'node:fs';const doc=new Doc('latency-seed',DEMO_SCHEMA);const content=Array.from({length:625},()=>({type:'paragraph',runs:[{text:'x'.repeat(160),marks:{}}]}));const {ops}=doc.edit([{op:'delete',at:[0],count:1},{op:'insert',at:[0],content}]);for(const name of NAMES)writeFileSync(DIR+'/'+name+'.jsonl',JSON.stringify({change:{actor:'latency-seed',seq:1,ops}})+'\\n',{flag:'wx'});""".replace('NAMES',json.dumps(['-'.join(pair) for pair in pairs])).replace('DIR',json.dumps(str(data)))
subprocess.run(['node','--input-type=module','-'],input=seed,cwd=root,env=env,text=True,capture_output=True,check=True)
seed_hash=sha(data/('-'.join(pairs[0])+'.jsonl'))
assert seed_hash==hashlib.sha256(pathlib.Path('/tmp/doc-sync-editor-latency-20261022/latency100k.jsonl').read_bytes().splitlines(keepends=True)[0]).hexdigest()
observe=lambda:{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':os.getloadavg(),'topProcesses':subprocess.check_output(['ps','-Ao','pid,ppid,pcpu,pmem,etime,comm','-r'],text=True).splitlines()[:10]}
state={'work_id':'other-editors-100k-20261022','status':'running','pairs':pairs,'seedSha256':seed_hash,'seedMatchesPrior100k':True,'before':observe(),'dataDir':str(data)}
log=(base/'server.log').open('x');server=subprocess.Popen(['node',str(folder/'serve.mjs')],cwd=root,env={**env,'DATA_DIR':str(data),'SERVER_EVENTS':str(base/'server-events.jsonl')},stdout=log,stderr=subprocess.STDOUT)
for _ in range(400):
 match=re.search(r'\{"url":.*\}',(base/'server.log').read_text())
 if match:break
 if server.poll() is not None:raise RuntimeError((base/'server.log').read_text())
 time.sleep(.05)
assert match;state['server']=json.loads(match[0]);origin=state['server']['url'];session=None

def cli(label,*args):
 path=screens/(label+'-cli.txt')
 with path.open('x') as f:p=subprocess.run([wrapper,'--session',session,*args],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 txt=path.read_text()
 if p.returncode or '### Error' in txt:raise RuntimeError(label+': '+txt[:6000])
 if '### Result\n' in txt:
  payload=txt.split('### Result\n',1)[1].split('\n### ',1)[0].strip()
  try:value=json.loads(payload)
  except json.JSONDecodeError:value=payload
  (screens/(label+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');return value
 return txt

def code(label,file,**replace):
 source=(folder/file).read_text()
 for key,value in replace.items():source=source.replace(key,json.dumps(value))
 return cli(label,'run-code',source)

try:
 for pair in pairs:
  name='-'.join(pair);results=base/name;results.mkdir(exist_ok=False);screens=folder/name;screens.mkdir(exist_ok=False);session='other-editors-100k-'+name
  assert shutil.disk_usage(root).free>150*1024*1024
  cli('open','open',origin+'/?doc='+name+'&peers='+','.join(pair),'--headed')
  installed=code('install','install.js');assert all(p['chars']==100000 and p['paragraphs']==625 for p in installed['initial']);assert not installed['traceEnabled']
  cli('version','run-code','async page=>{const c=await page.context().newCDPSession(page);const v=await c.send("Browser.getVersion");await c.detach();return v;}')
  for source,target in [pair,tuple(reversed(pair))]:
   direction=source+'-to-'+target
   prepared=cli(direction+'-prepare','run-code','async page=>{const r=await page.evaluate(([s,t])=>__latency.prepare(s,t),'+json.dumps([source,target])+');await page.waitForTimeout(1800);return r;}')
   assert prepared['range']['focus']==[0,50]
   code(direction+'-warmup','batch.js',CONFIG={'phase':'warmup','start':0,'count':5})
   for start in range(0,30,5):
    assert shutil.disk_usage(root).free>30*1024*1024
    rows=code(direction+'-'+str(start),'batch.js',CONFIG={'phase':'measured','start':start,'count':5})
    assert isinstance(rows,list) and len(rows)==5
    print(json.dumps({'pair':name,'direction':direction,'completed':start+5,'frameCaptureRangeMs':[min(r['frameMs'] for r in rows),max(r['frameMs'] for r in rows)]}),flush=True)
   code(direction+'-diagnostic','diagnostic.js',RESULT_PREFIX=str(results)+'/',SCREEN_PREFIX=str(screens)+'/')
  exported=code('export','export.js',OUTPUT=str(results/'browser-raw.json'));assert exported['samples']==72 and not exported['failures'];assert all(p['pending']==0 and p['fallbacks']==0 for p in exported['clients'])
  cli('console','console');cli('close','close');session=None
  print(json.dumps({'pairComplete':name,'export':exported}),flush=True)
 state['sourceUnchanged']=all(sha(root/e['path'])==e['sha256'] for e in manifest['files']);assert state['sourceUnchanged'];state['status']='complete'
except Exception as error:
 state['error']=str(error)
 if session:
  try:code('partial-export','export.js',OUTPUT=str(results/'partial-browser-raw.json'))
  except Exception as export_error:state['exportError']=str(export_error)
 raise
finally:
 if session:
  try:cli('cleanup-close','close')
  except Exception as close_error:state['closeError']=str(close_error)
 server.terminate();server.wait(timeout=15);log.close();state['after']=observe();state['serverStopped']=True;(base/'run.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
