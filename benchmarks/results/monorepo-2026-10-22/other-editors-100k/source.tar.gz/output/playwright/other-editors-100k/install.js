async page=>{
 await page.setViewportSize({width:1440,height:1000});
 await page.waitForFunction(()=>window.compat&&window.__benchmarkAPI?.peers.length===2&&__benchmarkAPI.peers.every(p=>p.section.querySelectorAll('.editor > p').length===625&&p.client.online&&!p.client.pending.length),null,{timeout:120000});
 return await page.evaluate(()=>{
  const A=__benchmarkAPI;
  const B=window.__latency={samples:[],active:null,stack:[],longTasks:[],clients:Object.fromEntries(A.peers.map(p=>[p.client.actor,p.client]))};
  B.wrap=(object,name,title,actor,capture)=>{
   const original=object[name];if(typeof original!=='function')throw Error(title+' missing');
   object[name]=function(...args){capture?.(this,args);const s=B.active;if(!s)return original.apply(this,args);
    const span={id:s.spans.length,parent:B.stack.at(-1)??null,name:title,actor:actor??this.client?.actor??this.actor??null,start:performance.now()};
    s.spans.push(span);B.stack.push(span.id);
    try{return original.apply(this,args);}finally{span.end=performance.now();span.ms=span.end-span.start;B.stack.pop();}
   };
  };
  for(const name of ['edit','apply','toJSON'])B.wrap(A.Doc.prototype,name,'Doc.'+name);
  for(const name of ['commit','withEvents','receiveEnvelope'])B.wrap(A.SyncClient.prototype,name,'SyncClient.'+name);
  B.wrap(A.SyncClient.prototype,'receive','SyncClient.receive',null,(client,args)=>{
   const s=B.active,event=args[0];if(s&&event.type==='change'&&event.envelope.change?.actor===s.sourceActor&&event.envelope.change.ops.some(op=>op.t==='text'&&op.text===s.char)){
    const row={actor:client.actor,sender:event.envelope.change.actor,seq:event.envelope.change.seq,time:performance.now()};s.receives.push(row);
    if(client.actor===s.targetActor){s.remoteReceive=row.time;performance.mark('latency:'+s.id+':remote-receive');}
   }
  });
  for(const p of A.peers){
   for(const name of ['send','pull','read','readRange'])if(typeof p[name]==='function')B.wrap(p,name,p.kind+'.'+name,p.client.actor);
   if(p.kind==='Slate')B.wrap(p.editor,'apply','Slate.apply',p.client.actor);
   if(p.kind==='Lexical')B.wrap(p.editor,'update','Lexical.update',p.client.actor);
   if(p.binding)B.wrap(p.binding,'dispatch','PmBinding.dispatch',p.client.actor);
  }
  for(const name of ['pull','reconcile','anchorOfPm','afterChange'])B.wrap(A.PmBinding.prototype,name,'PmBinding.'+name);
  B.wrap(A.EditorView.prototype,'updateState','EditorView.updateState');
  B.wrap(A.InputSession.prototype,'commit','InputSession.commit');
  const send=A.HttpTransport.prototype.send;
  A.HttpTransport.prototype.send=async function(message){const s=B.active,row=s?{kind:message.kind,actor:message.change?.actor??message.ack?.actor,seq:message.change?.seq,start:performance.now()}:null;if(row)s.sends.push(row);try{return await send.call(this,message);}finally{if(row){row.end=performance.now();row.ms=row.end-row.start;}}};
  const raf=requestAnimationFrame.bind(window);B.nativeRaf=raf;
  new PerformanceObserver(list=>{for(const e of list.getEntries())B.longTasks.push({start:e.startTime,ms:e.duration});}).observe({type:'longtask',buffered:true});
  for(const type of ['keydown','beforeinput','input'])document.addEventListener(type,e=>{
   const s=B.active;if(!s||!document.querySelector(s.sourceSelector)?.contains(e.target)||(type==='keydown'&&e.key!==s.char))return;
   s.inputEvents.push({type,time:performance.now(),eventTimeStamp:e.timeStamp,trusted:e.isTrusted,inputType:e.inputType??null,data:e.data??null});
   if(type==='keydown'&&s.inputStart===null){s.inputStart=performance.now();s.inputEventTime=e.timeStamp;performance.mark('latency:'+s.id+':input');}
  },true);
  for(const p of A.peers)new MutationObserver(records=>{
   const s=B.active;if(!s||s.targetActor!==p.client.actor||s.inputStart===null)return;
   for(const r of records){s.domMutations.records++;s.domMutations.added+=r.addedNodes.length;s.domMutations.removed+=r.removedNodes.length;if(r.type==='characterData')s.domMutations.text++;}
   if(s.remoteDom!=null||document.querySelector(s.targetParagraph)?.textContent!==s.expected)return;
   s.remoteDom=performance.now();s.targetFirstParagraphPreserved=document.querySelector(s.targetParagraph)===B.targetBefore;s.targetLastParagraphPreserved=document.querySelector(s.targetSelector+' > p:last-child')===B.targetLastBefore;
   performance.mark('latency:'+s.id+':remote-dom');
   raf(()=>{s.firstRafAfterDom=performance.now();performance.mark('latency:'+s.id+':raf1');raf(()=>{
    s.renderOpportunity=performance.now();s.correct=document.querySelector(s.targetParagraph)?.textContent===s.expected;s.sourceCorrect=document.querySelector(s.sourceParagraph)?.textContent===s.expected;
    s.inputToRemoteDomMs=s.remoteDom-s.inputStart;s.inputToRenderOpportunityMs=s.renderOpportunity-s.inputStart;s.queuedInputToRenderOpportunityMs=s.renderOpportunity-s.inputEventTime;
    s.longTasks=B.longTasks.filter(t=>t.start>=s.inputStart&&t.start<=s.renderOpportunity);
    performance.mark('latency:'+s.id+':render-opportunity');s.done=true;B.samples.push(s);B.active=null;
   });});
  }).observe(p.section.querySelector('.editor'),{childList:true,subtree:true,characterData:true});
  B.prepare=(source,target)=>{
   const p=A.peers.find(p=>p.name===source);B.currentDirection=source+'-to-'+target;B.source=source;B.target=target;
   const el=p.section.querySelector('.editor');el.scrollTop=0;el.focus();
   if(p.kind==='Slate')A.Transforms.select(p.editor,{anchor:{path:[0,0],offset:50},focus:{path:[0,0],offset:50}});
   else if(p.kind==='Lexical')p.editor.update(()=>{const text=A.$getRoot().getFirstChild().getFirstChild();const range=A.$createRangeSelection();range.anchor.set(text.getKey(),50,'text');range.focus.set(text.getKey(),50,'text');A.$setSelection(range);},{discrete:true});
   else{p.view.dispatch(p.view.state.tr.setSelection(A.TextSelection.create(p.view.state.doc,51)));p.view.focus();}
   window.scrollTo(0,0);return{source,target,range:p.readRange()};
  };
  B.begin=(direction,char,phase,index)=>{
   if(B.active)throw Error('Sample still active');const p=A.peers.find(p=>p.name===B.source),t=A.peers.find(p=>p.name===B.target);
   const sourceSelector='#'+p.name+' .editor',targetSelector='#'+t.name+' .editor',sourceParagraph=sourceSelector+' > p:first-child',targetParagraph=targetSelector+' > p:first-child';
   const text=document.querySelector(sourceParagraph).textContent,range=p.readRange();if(text!==document.querySelector(targetParagraph).textContent)throw Error('Not converged');
   if(range?.anchor?.[0]!==0||JSON.stringify(range.anchor)!==JSON.stringify(range.focus))throw Error('Invalid caret '+JSON.stringify(range));const offset=range.focus.at(-1);
   const expected=text.slice(0,offset)+char+text.slice(offset);B.targetBefore=document.querySelector(targetParagraph);B.targetLastBefore=document.querySelector(targetSelector+' > p:last-child');
   B.active={id:direction+':'+phase+':'+index,direction,phase,index,char,offset,sourceActor:p.client.actor,targetActor:t.client.actor,sourceSelector,targetSelector,sourceParagraph,targetParagraph,expected,spans:[],receives:[],sends:[],inputEvents:[],inputStart:null,domMutations:{records:0,added:0,removed:0,text:0}};B.stack=[];return{id:B.active.id};
  };
  return{installed:true,initial:A.peers.map(p=>({name:p.name,chars:p.section.querySelector('.editor').textContent.length,paragraphs:p.section.querySelectorAll('.editor > p').length})),traceEnabled:new URLSearchParams(location.search).has('trace'),userAgent:navigator.userAgent,visibility:document.visibilityState,devicePixelRatio,timeOrigin:performance.timeOrigin};
 });
}
