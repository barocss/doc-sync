# Independent security / CRDT equivalence review

Date: 2026-11-04. Checkout: `/Users/user/github/doc-sync`.

## Verdict

- **Body code: APPROVE** for the exact `validJSON` candidate hash below, against the frozen **post-refactor** source. No blocking behavior, security, or CRDT regression was found. Architectural status: **CLEAR** for this body-only delta.
- **Tests: APPROVE** for this slice. H1 now requires legacy rejection. No test blocker remains at the final hashes. Coverage limits are separate below.
- **Performance: NOT_RUN by this reviewer.** This review does not issue the performance-ready gate. Root must freeze and verify source hashes before enabling the benchmark worker.
- **Whole product / release: NOT_QUALIFIED.** Full regression, process/server restart, desktop Chrome, performance acceptance and publication are outside this review. No mobile tests.

Actual actionable findings: **CRITICAL 0 / HIGH 0 / MEDIUM 0 / LOW 0**. No failing counterexample was found within the stated intrinsic/observable boundary. There is no request to change production code.

Only this report was written. No production/test edit, build, dist write, commit, push, sub-agent or benchmark was run. Other workers' files and inherited WIP were preserved.

## Comparator and source integrity

The comparator is `output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src/crdt/annotations.ts`, SHA-256 `cc2257ad38afdb18a803eedda7968af05ab2be434b8ccfd064b0b04c64f0cac3`. HEAD `ec9622571a04a7d7ea3f967bb3e6423b17ce5194` was identified only as checkout context; it was **not** the equivalence oracle.

Direct byte checks establish:

1. Current annotations differ from that comparator only inside `function validJSON`. The prefix and suffix outside that function are identical.
2. The legacy fixture's `poisoned`, `plain`, original callback-based `validJSON`, and wrapper are byte-identical to the frozen block after only renaming the exported wrapper. It retains `filter` and `every`; it is not a copy of the candidate loop.
3. All **69** current core source paths have archived counterparts. There are no added or removed core source files. Only `crdt/annotations.ts` differs. This scan covers `packages/doc-sync/src`, not unrelated workspace packages.
4. `Doc.ts`, its loader, Graphic staging, History, compiler, Data admission, server and engine sources remain equal to their archived versions. The rejected private-certificate proposal is not present. No trust flag, unchecked loader, private certificate or retained-payload bypass was added.

The target annotations and Doc hashes were stable from the initial review sample through the final checks. The JSON test changed while its owner finished writing: initial `042fc556ea0fda616ee33fc3156d423747cb72bc019af3e4ff71fd564353aded`, then final `e38faa84961ddf1f21af94e2a94f176c3a7659fce8ca921d96f5f7b6a34d3d54`. Both independently executed test runs used the final version. The legacy fixture and Graphic test were stable across review samples. Ancillary production files were rehashed after inspection and at the end, with no sampled drift. Approval binds the listed bytes, not future worktree state.

## Behavior-equivalence reasoning

References below are current paths under `packages/doc-sync/`.

### Guards, recursive state and prototypes

`src/crdt/annotations.ts:41-48,69-74` preserves primitive/null handling before depth checks, finite numbers, object admission, `depth > maxDepth`, cycle detection, and the exact prototype policy. Plain objects allow Object.prototype or null. Arrays intentionally do not use the plain-object prototype restriction. This is existing behavior, not a newly broadened allowance.

`seen.add` still precedes descriptor capture. A normal false/true return still reaches `seen.delete`. An exception still propagates before deletion; no catch/finally or shared validation context was added. Shared noncyclic objects remain valid because the path membership is removed after normal recursion. Cycles remain invalid. Scalar leaves still precede the depth guard; object depth limits are inclusive. Public snapshot validation still uses its existing 128 envelope limit.

### Reflection, enumeration and exception order

`src/crdt/annotations.ts:47-49` still completes **bulk** `Object.getOwnPropertyDescriptors(value)` before the separate `Reflect.ownKeys(value)`. The second key list is not substituted with descriptor keys. Thus later descriptor traps can still throw before recursion into an earlier child. Stateful Proxy additions, omissions, duplicate-key invariant errors and revocation preserve their old ordering and outcomes.

`Reflect.ownKeys` returns a fresh ordinary dense key array when standard intrinsics are intact. The old array-only filter has a pure predicate (`key !== "length"`). The new cached `array` query occurs at that same selection point. Skipping `length` in the loop therefore selects the same ordered entries. A skipped key does not query the descriptor, read input length or recurse.

`src/crdt/annotations.ts:55-64` keeps this per-entry order:

1. Reject a non-string key or a poisoned key.
2. Run the original per-key `Array.isArray(value)`; it was **not** replaced with the cached choice.
3. For arrays, apply the original canonical-index regex. Read and compare `value.length` only if the regex succeeds.
4. Read `descriptors[key]`, then `enumerable`, then own data-descriptor membership, then `descriptor.value`, then recurse.

Keeping the per-key query matters when a child trap revokes its parent. A later poisoned/symbol key must reject before querying that revoked parent; a later valid index can still throw. Supplemental probes exercise both branches. Input property accessors are not invoked by this traversal. Proxy descriptor-conversion effects from the reflection builtin remain possible and retain their order.

The count includes exactly the selected entries on a successful walk. Its increment for a failing entry is local and cannot escape. Both versions stop validation on the same first false predicate. The final query/comparison runs only after complete success: `Array.isArray(value)`, then count/entries length equality against a fresh `value.length` read. No final length read occurs after a failed child, key, descriptor or index. Sparse arrays, holes, extra own attributes, symbols, poison names, nonenumerable properties and accessors retain rejection. Empty and dense arrays retain admission. Changing, coercive and throwing length traps retain read/exception order.

### Admission, retained state and CRDT effects

- `src/crdt/doc.ts:2243-2252`: Graphic edit still stages through the public `Doc.fromSnapshot(this.actor, this.snapshot(), this.schema)` and compiles the complete batch before live compilation. Instance/subclass/getter overrides remain observable. There is no certificate fast path.
- `src/crdt/doc.ts:2559-2576`: snapshot capture still visits stored lines/items, not only visible model content. The public loader still validates the complete image before structural admission. Extra trust/skip/certified properties do not opt out.
- `src/data/admission.ts:17-20,65-105`: whole-payload JSON checks remain before cloning; authored losing/hidden values and retained candidate contents still undergo semantic admission.
- `src/server/hub.ts:139-169`: payload checks still precede sequence handling, ownership clone, retained op checks, semantic checks, persistence and live application. No reservation, retry or broadcast guard was removed.

A direct supplemental probe placed Infinity in a deleted, model-invisible Graphic token. The frozen validator rejected the complete image. Both the current public loader and staged Graphic edit rejected it before clock, version or token-identity changes. This is a retained-payload check, not merely a visible-model comparison.

## Independent executions

Runtime: `/Users/user/.nvm/versions/node/v24.22.1/bin/node` (**v24.22.1**). The default shell `node` is v18.10.0 and was **not** used for these source tests.

| Check executed by this reviewer | Result |
| --- | --- |
| Two new/corrected test files, direct current source imports, no source hook | **241 PASS / 0 FAIL / 0 CANCEL / 0 SKIP** |
| Same final test files, separate process with archived core load hook | **241 PASS / 0 FAIL / 0 CANCEL / 0 SKIP** |
| Fixture exactness, outside-body identity and full 69-file core path/hash comparison | **PASS** |
| Additional fresh-factory result / complete trap trace / sentinel comparisons | **108 PASS** |
| Primed live storage/cache graph atomicity scenarios | **6 PASS**, 384 reachable-object observations across cases |
| Hidden retained Infinity rejection | **PASS** |

Commands for the two suite runs:

```sh
NODE=/Users/user/.nvm/versions/node/v24.22.1/bin/node
$NODE --test --test-reporter=spec --test-concurrency=1 \
  packages/doc-sync/test/json-validation-refactor.test.ts \
  packages/doc-sync/test/graphic-proof-copy.test.ts
$NODE --import ./output/json-validation-2026-11-04/tests-frozen-hook.mjs \
  --test --test-reporter=spec --test-concurrency=1 \
  packages/doc-sync/test/json-validation-refactor.test.ts \
  packages/doc-sync/test/graphic-proof-copy.test.ts
```

The archived load hook was inspected before use. It changes the loaded source of current core URLs to archived core bytes; tests and their independent fixture stay current. All 69 core paths have counterparts, so this comparison has no missing-core-source fallback. This is not an independent full CRDT engine.

Supplemental probes ran as bounded one-shot Node stdin scripts, in memory. They wrote no test or receipt files. Their results are recorded here, not represented as new committed tests:

- **108 comparisons:** all key permutations for two-index arrays with valid values, an invalid child, poison/symbol/extra keys or a nonenumerable index; parent-array revocation during nested child validation followed by a valid index, final check, poison key or symbol; object-valued/coercive/throwing length; a throwing final length read; a huge sparse array without scanning holes; second enumeration adding missing or inherited descriptor names; and an accessor-bearing descriptor object returned by a Proxy trap. Each lane received a fresh factory instance. Explicit sentinels had to propagate by identity within that lane.
- **6 atomicity cases:** instance/subclass/getter/throwing snapshot overrides, a late invalid batch and late clock exhaustion. A valid Graphic Doc first seeded nonempty History and primed model, block, projection and token-location reads. A read-only graph observer captured own descriptors/values/identities and Map/Set entry identities/contents reachable from the live Doc. Both the old public composition and live edit had to reject without changing that graph or History and without notifying. Override reads/calls and sentinel identity were checked separately. Weak collections were checked only by identity; their contents cannot be enumerated. The observer did not invoke accessors.

Other workers' implementation/test reports were read for context. Their broader focused-test and scoped-typecheck receipts are **not** counted as reviewer-executed checks. No typecheck, global regression, HTTP process restart or browser run was executed in this lane.

## Tests: H1, independence and remaining limits

### H1 correction: accepted

`test/graphic-proof-copy.test.ts:125-158` no longer allows either success or failure. Instance, subclass and getter overrides produce a snapshot with NaN Lamport and must fail with the exact legacy JSON-admission error. The throwing override must propagate its exact sentinel. Both public composition and real edit must call the override once, with the original receiver and one property-getter read where applicable. The test checks clock/version/snapshot, nonempty History, line/item identities and zero notifications. The benign getter case at lines 159-170 preserves the old call/receiver/side-effect behavior.

These corrected cases pass on both frozen and current source. The exposed-state corruption table also pins rejection, rather than merely accepting agreement between two possibly weakened current paths.

### Independent fixture and normal-checkout portability: accepted

`test/json-validation-legacy.fixture.ts:5-30` contains the exact original algorithm and helpers. `test/json-validation-refactor.test.ts:16-30,83-164` uses fresh stateful inputs and compares complete ordered traces and outcomes, with explicit thrown-sentinel identity checks. The fixed cases cover primitives, depth, cycles/DAGs, prototypes, descriptors and malformed arrays; actual snapshot and Data/server paths also have fixed rejection expectations.

All imports in these three files are Node builtins or relative checkout source/fixture imports. There is no runtime git lookup, ignored-output baseline import or dist dependency in those test files. The direct no-hook test run confirms this source path. The frozen archive/hook is needed only for this separate review comparison, not normal committed test execution. The three files are currently untracked; later commit inclusion remains root-owned.

### Non-blocking proof limits, not production findings

1. `legacyProof` in the Graphic test uses the current public loader/compiler. Its label now says this accurately. Separate frozen execution and the exact validator fixture reduce shared-path risk; they do not constitute an independent decoder or exhaustive convergence proof.
2. The committed H1 checks do not enumerate every private cache. The additional read-only graph probe supplies stronger primed-cache evidence for the six tested failures. It does not prove arbitrary WeakMap contents, all schema/callback behavior, or all possible failure points. An unattached History snapshot check is not an engine-owned History integration proof.
3. Proxy tests compare native error name/message and ordered effects, not native error-object identity across separate fresh runs. Such cross-run identity is not meaningful. Caller-provided thrown values are not caught or replaced by the implementation, and explicit sentinels are checked by identity. Diagnostic stack formatting is not pinned.
4. Input Proxy side effects, revocation, descriptor mutation and length coercion are in scope. Replacing realm-global validation/iteration builtins or prototype hooks is a separate contract. The old `filter/every` and new `for-of` intentionally call different global machinery. For example, a deliberately replaced Array iterator can suppress candidate traversal while the old `every` still visits entries. That is not an input-only regression with intact intrinsics, and it is **not** used as a blocker. This review makes no equivalence claim under hostile global monkeypatching, altered diagnostic stacks, allocation/GC observation or timing.

## Final gate boundary

There is **no security/equivalence blocker** to root issuing a performance-ready gate for candidate annotations `8883fdc4e488b3c3599788f361b841bf780d2ba941aab3ead7ee766cb78b1542`, while retaining frozen Doc `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` and the final tests below. Root must recheck those hashes and retain its own source freeze. This reviewer did not enable measurement. Allocation reduction is not a measured speedup or whole-product PASS.

## Final per-file SHA-256

Paths in this table are relative to `packages/doc-sync/`. Equal ancillary hashes were checked at their first hashed review sample and again at the end; target and test sampling is described above.

| File | SHA-256 | Drift during sampled review window |
| --- | --- | --- |
| `src/crdt/annotations.ts` | `8883fdc4e488b3c3599788f361b841bf780d2ba941aab3ead7ee766cb78b1542` | No sampled change |
| `src/crdt/doc.ts` | `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` | No sampled change |
| `src/crdt/history.ts` | `d6e4efe3aa54bde4212f12b46e394aac2b898a690ccf95f7b85b806d4a08273b` | No sampled change |
| `src/crdt/edit.ts` | `243365d1edf36d2de8d450143743db4e59b52fa0a9f8d2a92a0ca99dae608553` | No sampled change |
| `src/server/hub.ts` | `ddc433711fe89f8cb159009effaf40686f367da8dc9553de3d4f0d52d9a76a09` | No sampled change |
| `src/data/admission.ts` | `89d63936734140972e67581a13e638cd8a9f3709e3e93cdddae18c94cbc3066c` | No sampled change |
| `src/engine/typescript-client.ts` | `dbfedab406844f1e79c4d77656787ae0c438e09212c84f30efc06ad109b0d421` | No sampled change |
| `src/local/client.ts` | `44dea53c95da539adcf52fba406d42d8d1ef41b702d035d5f27ad46eab1e5964` | No sampled change |
| `test/json-validation-legacy.fixture.ts` | `0202163cdf6653fbc4d6c4752231967857e077a0cd3b52a536681e6fc123f295` | No sampled change |
| `test/json-validation-refactor.test.ts` | `e38faa84961ddf1f21af94e2a94f176c3a7659fce8ca921d96f5f7b6a34d3d54` | Changed by test owner before final runs; stable afterward |
| `test/graphic-proof-copy.test.ts` | `1a8a1722588e6d7658bf7471dd57687142024a6be68be49c32fa4c0c8880affa` | No sampled change |
