# JSON validation benchmark — PREPARED; final timings NOT_RUN

Owned source: `benchmarks/json-validation.mjs` only. Production source and tests were not edited. No build/dist, commit, push, mobile, or browser work.

- Frozen baseline manifest: **PASS**, all 71 archived files match. Baseline is the post-refactor working tree, not HEAD/ec962.
- Initial 40-record whole-source smoke: **PASS** before/current. Same driver and seed hashes. Only `crdt/annotations.ts` differs across selected source files; no additional source files. These initial smoke files precede a driver counter-reporting refinement and are not timing proof.
- New driver: explicit `--source-root`, `--label`, `--output`; Node 24; source and driver SHA256; fixed linear List/Map checkpoint; explicit noHistory edits; fixed warmup and sample counts; primitive/atomic/nested JSON micro matrix; all final collection IDs and values checked outside timed intervals with a Node JSON reference; counters run separately.
- Count mode reports inclusive Doc/History method counts and descriptor/own-key counts. Descriptor counts include all callers, not only `validJSON`. Micro counts are separate from end-to-end counts.
- Existing O(N) cloning, JSON validation, and projection remain. This is not unchecked admission or a trust capability.
- Final paired timing is **NOT_RUN**. Waiting for source writer final report/terminal evidence and root-owned `performance-ready.json`. Absence of that gate is not approval. Other CPU-heavy jobs were observed, so no final samples have been taken.

Planned final protocol after explicit readiness: 2k resource check; 20k records (10k List + 10k Map); 3 pairs ordered A/B, B/A, A/B, each process 2 warmups and 7 samples; same final driver hash, schema, actor, metadata, checkpoint seed; all raw JSON retained. Primitive micro controls and full edit+read medians reported separately. A useful result requires at least 5% median edit+read improvement and no consistent control regression. Otherwise report inconclusive/regression. No 100k probe requested.

Preparation attempts: `omx explore` positional form failed (syntax); corrected `--prompt` failed with permission denied in installed package temp path. Direct read-only inspection followed. Initial smoke before/current both exit 0; no timeouts. No source imports from ignored output are needed for CURRENT; BEFORE is selected only by explicit CLI archive root.

## Final-driver preparation update

- Driver SHA256: `82b3d81bde13848adfaf87690ab9c18e6efd931df980e18405ae25990e0a4b0b`. No more driver changes planned.
- 40-record and 2k-record source smoke: **PASS** on both whole-source roots. `*-smoke-*-v2.json` retain raw non-qualification measurements.
- Separate 2k counter run: **PASS**, identical before/after counters and micro descriptor counts. Two measured edits, one excluded warmup. E2E inclusive counts: `{"Reflect.ownKeys": 78136, "Doc.edit": 4, "Doc.snapshot": 6, "Doc.fromSnapshot": 6, "Object.getOwnPropertyDescriptors": 78126, "Doc.check": 8, "Doc.toJSON": 6}`. Counts are not additive costs and do not prove speedup.
- Fixed 2k seed SHA256: `d03d823bc8c51a68ff03cf2030f021d4ec0612560fb3aa9f6e8e9ae8849b1230`. Both full collection oracles PASS.
- Frozen/current source difference remains annotations.ts only; frozen Doc hash retained.
- Source-writer report now says finished. Root performance gate is still absent. Final timing remains **NOT_RUN** until explicit gate and quiet conditions.
- Preparation runner uses a 60-second watchdog per owned process group. All six final-driver preparation processes exit 0; no timeout. Full commands/stderr in `benchmark-preparation-v2.json`.

## Handoff state (2026-11-03T15:45:14.734694+00:00)

Source writer terminal `turn.completed` was observed. Root gate remained absent through three waits (30s, 60s, 60s). CPU-heavy CAD test processes and background indexing/security activity remained present. No final timing process was started. Do not treat smoke raw milliseconds as qualification. Nothing was killed except the runner would stop its own group on timeout (none occurred).

Full closure identity:

- BEFORE: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`.
- AFTER: `02e706eecc822087a9ef5e838b5e1244c5da143e25acc8c46491c56e64af6260`.
- AFTER annotations: `8883fdc4e488b3c3599788f361b841bf780d2ba941aab3ead7ee766cb78b1542`.
- Doc (both): `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d`.

Ready-to-run single-process form (only after explicit root gate and quiet CPU):

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node --expose-gc benchmarks/json-validation.mjs \
  --source-root output/refactor-2026-11-03/post-refactor-baseline \
  --label post-refactor-before --output output/json-validation-2026-11-04/pair1-before.json \
  --mode timing --records 20000 --samples 7 --warmup 2 --iterations 10000
```

For AFTER use `--source-root .` and a new output path/label. Run ordered pair1 A/B, pair2 B/A, pair3 A/B under an owned-process-group watchdog; retain start/end CPU conditions. The same final driver byte hash must apply to all six. Before evaluating ≥5%, compare all six source/seed hashes and ensure no changed file except annotations.ts. Primitive micro controls must not show consistent regression. Use medians per process and per-pair edit+read deltas, retain raw samples and all failures. No measured result is asserted in this handoff. Root owns performance gate, High review, global tests/browser, and final acceptance.
