# Final JSON-validation timing report

Status: **INCONCLUSIVE**. The predeclared threshold is not consistently met. Do not approve a performance claim from these runs.

**Observed control failure:** string is slower in all six pairs. Cycle-level increases are 0.14183, 0.13513, and 0.13075 ms per 10000 calls (tolerance: 0.1 ms). This is not a clean no-regression result. Null and boolean also trend slower, but remain within the declared absolute tolerance. Background load and very short micro samples prevent causal attribution.

## Protocol and identity

- Sequential 3 ABBA cycles, 12 separate Node 24.22.1 processes. Records=20000, samples=7, warmup=2, micro iterations=10000. `--expose-gc`. Each group has a 120s watchdog; no timeout or kill occurred.
- Frozen gate: 69 source files. Exact cross-root delta: `crdt/annotations.ts` only. Before is the post-refactor archive, not HEAD/ec962.
- Driver SHA256: `82b3d81bde13848adfaf87690ab9c18e6efd931df980e18405ae25990e0a4b0b`. The same absolute driver path and hash were used for both roots.
- Seed SHA256 (all 12): `15f1c21f649d8632a3ed50c1663ffc295cce27d0da0fa480c6a9d422ca327c4d`. Same schema/actor from unchanged driver. Full collection and per-sample oracles: PASS 12/12.
- Both full source manifests and driver were checked before/after every run. All unchanged. Per-run receipts retain UTC start/end, host CPU/load, owned PID/group, command, raw file and manifests.
- Host: 14 logical CPUs; 1-minute load range [5.66162109375, 11.306640625]. Background CPU included security/indexing/application work. Nothing unrelated was paused or killed. No idle-host claim. Host snapshots store comm basenames only, not arguments. `ps` aggregate is a lifetime estimate; `top` CPU usage is stored separately.

## E2E paired process medians

Ratio = AFTER/BEFORE. Lower is better. Pairs preserve AB and BA order. Each cycle uses the median of its two paired ratios.

| Cycle | Order | Before median ms | After median ms | Ratio | Reduction % |
|---|---|---:|---:|---:|---:|
| 1 | AB | 882.0698 | 893.1258 | 1.01253 | -1.25 |
| 1 | BA | 906.7380 | 898.5105 | 0.99093 | 0.91 |
| 2 | AB | 874.6088 | 886.3393 | 1.01341 | -1.34 |
| 2 | BA | 897.2413 | 880.6570 | 0.98152 | 1.85 |
| 3 | AB | 898.6266 | 878.5008 | 0.97760 | 2.24 |
| 3 | BA | 884.8533 | 865.8038 | 0.97847 | 2.15 |

Six-pair ratio min/median: 0.97760 / 0.98622. Reduction min/median: -1.34% / 1.38%.
- Cycle 1: ratio 1.00173, reduction -0.17%; >=5%: False.
- Cycle 2: ratio 0.99746, reduction 0.25%; >=5%: False.
- Cycle 3: ratio 0.97804, reduction 2.20%; >=5%: False.

## Per-run E2E median/p95

Seven raw samples each; nearest-rank p95 is sample maximum. Edit/read splits and all raw samples are in timing-comparison.json and original raw files.

| Run | Median ms | p95 ms |
|---|---:|---:|
| before-run1-cycle1 | 882.0698 | 912.7414 |
| after-run1-cycle1 | 893.1258 | 902.1719 |
| after-run2-cycle1 | 898.5105 | 928.4880 |
| before-run2-cycle1 | 906.7380 | 924.9811 |
| before-run3-cycle2 | 874.6088 | 912.6711 |
| after-run3-cycle2 | 886.3393 | 894.9153 |
| after-run4-cycle2 | 880.6570 | 919.2576 |
| before-run4-cycle2 | 897.2413 | 926.2805 |
| before-run5-cycle3 | 898.6266 | 922.7463 |
| after-run5-cycle3 | 878.5008 | 912.8526 |
| after-run6-cycle3 | 865.8038 | 902.1573 |
| before-run6-cycle3 | 884.8533 | 909.3844 |

## Primitive controls (not pooled with E2E)

Tolerance per 10000 calls: max(10% of BEFORE, 0.1 ms). Consistent regression means the cycle-level AFTER minus BEFORE exceeds that tolerance in all three cycles. Every pair and cycle flag is retained in JSON; failures are not hidden.

| Control | Pairs beyond tolerance / 6 | Consistent across 3 cycles |
|---|---:|---|
| null | 0 | False |
| boolean | 0 | False |
| finite-number | 0 | False |
| string | 6 | True |

## Atomic/nested micro results (separate from E2E)

Each entry is the six paired AFTER/BEFORE ratios of per-process micro medians. These short samples do not qualify application latency.
- atomic-object: 1.00290, 1.07025, 1.04043, 0.92928, 0.94867, 1.00740
- atomic-array: 0.90533, 0.87595, 0.94058, 0.82159, 0.96052, 0.89670
- nested-json: 0.97861, 0.94978, 0.96671, 0.98650, 0.94284, 0.95162

## Host conditions per run

CPU strings are the recorded top host snapshots. Load is the 1-minute average. No argument strings were collected.

| Run | Load start/end | CPU start | CPU end |
|---|---|---|---|
| before-run1-cycle1 | 5.66 / 6.24 | CPU usage: 21.77% user, 16.44% sys, 61.77% idle  | CPU usage: 20.72% user, 17.60% sys, 61.66% idle  |
| after-run1-cycle1 | 6.30 / 6.47 | CPU usage: 28.67% user, 16.59% sys, 54.72% idle  | CPU usage: 31.21% user, 18.9% sys, 50.69% idle  |
| after-run2-cycle1 | 6.67 / 11.31 | CPU usage: 30.44% user, 16.83% sys, 52.71% idle  | CPU usage: 34.78% user, 26.20% sys, 39.1% idle  |
| before-run2-cycle1 | 10.96 / 10.72 | CPU usage: 31.32% user, 28.85% sys, 39.81% idle  | CPU usage: 30.80% user, 19.80% sys, 49.39% idle  |
| before-run3-cycle2 | 10.43 / 9.14 | CPU usage: 17.32% user, 15.65% sys, 67.1% idle  | CPU usage: 21.87% user, 17.6% sys, 61.5% idle  |
| after-run3-cycle2 | 9.53 / 8.14 | CPU usage: 16.99% user, 14.77% sys, 68.22% idle  | CPU usage: 21.50% user, 17.54% sys, 60.95% idle  |
| after-run4-cycle2 | 7.65 / 7.13 | CPU usage: 16.81% user, 14.67% sys, 68.51% idle  | CPU usage: 17.48% user, 13.68% sys, 68.82% idle  |
| before-run4-cycle2 | 7.13 / 6.75 | CPU usage: 16.22% user, 14.59% sys, 69.17% idle  | CPU usage: 20.68% user, 17.21% sys, 62.9% idle  |
| before-run5-cycle3 | 6.77 / 6.86 | CPU usage: 34.22% user, 18.65% sys, 47.11% idle  | CPU usage: 25.12% user, 16.3% sys, 58.84% idle  |
| after-run5-cycle3 | 6.71 / 6.56 | CPU usage: 25.29% user, 14.79% sys, 59.90% idle  | CPU usage: 24.89% user, 14.65% sys, 60.44% idle  |
| after-run6-cycle3 | 6.68 / 6.80 | CPU usage: 21.75% user, 15.35% sys, 62.89% idle  | CPU usage: 17.23% user, 16.37% sys, 66.39% idle  |
| before-run6-cycle3 | 6.57 / 6.92 | CPU usage: 16.38% user, 15.19% sys, 68.42% idle  | CPU usage: 16.22% user, 13.80% sys, 69.96% idle  |

## Reused counter proof

Final-driver 2k counters were not rerun. Both raw receipts match the measured source manifests and driver SHA. Both oracles PASS; seed, inclusive counters, and all micro descriptor counts match. SHA receipts are in timing-comparison.json. Counts include nested callers and are not additive costs.

## Limits

- Observed background load; no idle-host or causal isolation claim.
- Seven samples per process; nearest-rank p95 is the maximum, not a stable tail estimate.
- Timings exclude imports/seed/warmup/GC/oracles. Micro precedes E2E identically.
- No quantitative heap/allocation measurement; static filtered-array/callback removal only.
- Existing O(N) document cloning, JSON validation and projection remain.
- No build, npm tests, browser/mobile, 100k probe, commit, push, or release. Independent review/root acceptance remain separate.

## Evidence

- `timing-comparison.json`: all run medians/p95/raw samples, six paired ratios, three cycles, all control checks, proof hashes.
- `timing-run-index-20261103T155104Z.json`: sequential process receipts.
- `timing-20261103T155104Z-*.json` and `*.log`: original raw results, before/after host/source receipts, stdout/stderr.
- `timing-preflight-20261103T155104Z.json`: first host snapshot, frozen manifest and source delta.
- `timing-run.py`, `timing-analyze.py`: reproducible output-only operator scripts.
