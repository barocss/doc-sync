# validJSON allocation reduction — implementation

Status: SOURCE READY; focused tests PASS; scoped TypeScript PASS. Performance acceptance and independent High review remain pending.

Owned edit: `packages/doc-sync/src/crdt/annotations.ts`, `validJSON` body only. No other production functions or module constants changed. Existing refactor WIP preserved. `Doc.fromSnapshot` remains unchanged.

Before source copy: `implementation.annotations.before.ts` in this directory.
Before annotations SHA-256: cc2257ad38afdb18a803eedda7968af05ab2be434b8ccfd064b0b04c64f0cac3.
Frozen Doc SHA-256: dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d.

Benchmark agent: source edit is ready for measurement. Compare the full fixed `output/refactor-2026-11-03/post-refactor-baseline/` archive, not HEAD. This report does not claim performance acceptance. Root owns global tests and final acceptance.

## Semantic preservation

- Keep primitive checks before depth and all original finite, prototype, cycle and depth checks.
- Capture all descriptors before the second `Reflect.ownKeys` call, exactly as before.
- Cache `Array.isArray` only at the old filter-selection point.
- Loop through second-enumeration keys, skipping `length` only for that cached array choice.
- Preserve key type, poisoned key, per-key `Array.isArray`, index, length, descriptor and recursive check order.
- Count non-skipped keys. Only a fully valid traversal reaches the old final `Array.isArray` and `value.length` comparison. Failed traversal cannot add a final length read.
- Keep `seen.delete` after the final check. Exceptions still bypass deletion; no catch/finally added.
- Remove the filtered array and two callback closures per array; remove the every closure per non-array object. No new per-object context or closure.

No new trust capability, unchecked path, public API, or reduced retained-payload checks. No global build, dist writes, commit, push, or mobile tests.

## Acceptance boundary

Independent differential oracle and High security review are owned by other workers. Performance acceptance is pending. Structural callback reduction is not a latency speedup claim. No frame-budget assertion.

## Verification receipts

Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node` (v24.22.1).

| Check | Result | Receipt |
| --- | --- | --- |
| Live source-hook focused tests, 10 files | 111 PASS, 0 FAIL, 0 SKIP, 0 CANCEL | `implementation.live-focused.log` |
| Same tests with full fixed archive core source | 111 PASS, 0 FAIL, 0 SKIP, 0 CANCEL | `implementation.reference-focused.log` |
| Scoped TypeScript, annotations root and transitive dependencies, no emit | PASS, zero diagnostics | `implementation.typecheck.json` |
| Only validJSON changed from inherited source | PASS | `implementation.identity.json` |
| Inherited validJSON equals fixed archive validJSON | PASS | `implementation.identity.json` |
| Frozen Doc unchanged | PASS, dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d | `implementation.identity.json` |

Focused tests: annotations, data-admission, data-admission-review, data-admission-http, snapshot, history-recovery, live-recovery, browser-recovery, recovery-receipt, recovery-reservation. `browser-recovery.test.ts` is a Node source test, not a browser or mobile session.

Source-hook command: Node `--import ./output/refactor-2026-11-03/api-client-source-hook.mjs --test --test-reporter=spec` and the ten test file paths. Reference environment: `DOC_SYNC_SOURCE_ROOT=file:///Users/user/github/doc-sync/output/refactor-2026-11-03/post-refactor-baseline/packages`. Current test harness/fixtures are reused; imported core source is switched to the full fixed archive. This is not an independent engine oracle or global qualification.

Reproducible runner: `python3 output/json-validation-2026-11-04/implementation.run.py`. Each command uses a dedicated owned process group and a 120-second timeout. No timeout or process termination occurred in these runs. Full commands and exits: `implementation.commands.json`.

An initial reference run used a filesystem path instead of the hook-required file URL and failed before test execution with `ERR_INVALID_URL`. Failure receipts are preserved as `implementation.reference-focused.invalid-url.log` and `implementation.commands.invalid-url.json`. Corrected reference run passed. Initial live receipt remains in `implementation.focused.log`.

Candidate annotations SHA-256: `8883fdc4e488b3c3599788f361b841bf780d2ba941aab3ead7ee766cb78b1542`.

## Handoff

Production source writer is finished. Benchmark and differential workers can consume this source/hash now. No source changes are planned without a reproduced issue. Benchmark results and High security review must be assessed by root before acceptance. No speedup, no-consistent-regression, whole-workspace PASS, or final acceptance is asserted here. Root retains docs/HANDOFF/final acceptance ownership.
