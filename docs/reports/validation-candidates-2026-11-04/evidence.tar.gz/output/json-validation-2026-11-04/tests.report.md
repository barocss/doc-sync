# JSON validation and Graphic override tests

## Result and scope

**FOCUSED PASS.** Frozen original source: **241 PASS / 0 FAIL / 0 SKIP**. Current allocation-only validator source: **241 PASS / 0 FAIL / 0 SKIP**. The same two files run in separate Node processes. They contain 198 JSON tests and 43 Graphic tests. Current related existing tests: **119 PASS / 0 FAIL / 0 SKIP**, 12 files. No cancelled or todo tests in any run.

**Scoped TypeScript PASS:** all three owned test/fixture files and their import closure, zero diagnostics, `noEmit`. This is not a global typecheck or build. Independent High security review, performance acceptance, global tests, docs/HANDOFF and final acceptance belong to root. No latency or performance claim is made by this lane.

The Graphic fast path remains OFF. Live Doc is byte-identical to the frozen original. This is NOT an optimized private-certificate PASS.

## Owned files

- `packages/doc-sync/test/graphic-proof-copy.test.ts`: H1 correction and baseline-weakening audit.
- `packages/doc-sync/test/json-validation-refactor.test.ts`: new independent differential and admission tests.
- `packages/doc-sync/test/json-validation-legacy.fixture.ts`: small TEST ONLY original validator, helpers and export. No Doc copy.

No production source, existing unrelated test, global build, dist, docs or HANDOFF was written by this lane. All inherited refactor WIP was preserved. No commit, push, browser, mobile or sub-agent was used. Tests were published after observing the frozen Phase 1 PASS gate.

## H1 correction and audit

The success alternative is removed. Malicious instance, subclass and property-getter overrides MUST produce the exact old `Error: Snapshot must contain finite plain JSON data without accessors`. A throwing method MUST propagate its same sentinel object. Each case verifies one method call, the original receiver, exactly one getter read where applicable, unchanged snapshot/version/clock, original line/item identities, zero edit notifications and unchanged nonempty History. The benign getter case verifies one property read/call, receiver and existing side effect, then the exact resulting snapshot.

The exposed-state corruption table now pins rejection explicitly, rather than only comparing two current public routes. The frozen run confirms all nine corruptions reject, including undefined origin. The previous origin comment was misleading and is corrected. Existing finite-JSON failure cases retain explicit rejection checks. No newly permitted behavior is used to make these tests pass. Public trust/skip/certified properties remain rejection probes, not production capabilities.

The Graphic composition oracle is now accurately labeled: it uses the public current loader and compiler, not an independent frozen structural decoder. Separate frozen-source execution and the independent JSON fixture provide their narrower proof. They do not prove every possible shared decoder bug absent.

## Independent JSON oracle

The fixture is extracted from the fixed post-refactor archive, NOT HEAD/ec962. Apart from renaming the public test export, its source from `const poisoned` through `annotationJsonOk` is exact. This was checked byte-for-byte. Its original descriptor capture, second `Reflect.ownKeys(value)`, array `filter`, `every`, recursive seen-set and exception behavior are unchanged. It does not mirror the new loop.

- 45 fixed value cases each run as direct oracle comparison, real public `Doc.fromSnapshot` admission, and real Data payload admission.
- Finite scalars and Unicode; object/array, dense/sparse/hole/extra-index properties; own symbols, nonenumerable entries, three poison keys and accessors without getter execution.
- Functions, symbols, bigint, undefined, Date, Map, Set, typed arrays, boxed numbers, NaN and both infinities reject. Cycles reject. Shared DAGs accept.
- Custom object prototypes reject; custom array prototypes retain old acceptance. Null prototypes, sealed/frozen data and reordered/nonwritable descriptors retain old acceptance.
- Object depth limits 0/64/121/122/128 are inclusive. Primitive-before-depth behavior is checked at each limit. Actual snapshot payload depths 121/122 and primitive 122/123 boundaries are separately pinned.
- 23 fresh-factory Proxy cases compare result or thrown name/message AND the complete ordered trap trace. Sentinel cases assert the exact thrown object within each lane, including a non-Error sentinel. No Proxy, trap counter or revoked target is reused between lanes.
- Traces record prototype queries, both own-key enumerations, every descriptor trap and every length read. Cases include reordered keys, a second enumeration that adds/omits/duplicates keys, descriptor mutation, changing length, revocation and throws at prototype, first keys, descriptor, second keys or length. No final length read is allowed after a failed child.
- A separate descriptor-order probe proves all bulk descriptor work completes before child recursion. A later descriptor sentinel must win over a child prototype failure.
- Deterministic xorshift seed `0x51a7c0de`: 400 small depth-4 JSON trees with arrays and Unicode, each checked as valid and with a nonfinite sibling (800 generated comparisons). No timing assertions.
- Public snapshot copy getter probes preserve first/later getter effects and the exact late sentinel before finite-JSON validation. Loader/Data accessor probes verify zero getter reads.
- Guarded Data server admission rejects malformed payloads before append, broadcast, storage/clock change or sequence consumption. The unchanged valid sequence-1 request then succeeds once.

A plain-object Proxy must trace `getPrototypeOf, ownKeys:1, descriptor:a, descriptor:b, ownKeys:2`. A dense single-element array Proxy must trace `ownKeys:1, descriptor:0, descriptor:length, ownKeys:2, get:length, get:length`. Comparisons use full arrays, not just these examples or the resulting model.

## Source identity

All **71** archived manifest entries were rehashed and match. Fixture identity and source/test hashes are recorded in `tests-provenance.json`.

| Artifact | SHA-256 |
| --- | --- |
| Frozen annotations | `cc2257ad38afdb18a803eedda7968af05ab2be434b8ccfd064b0b04c64f0cac3` |
| Current annotations candidate | `8883fdc4e488b3c3599788f361b841bf780d2ba941aab3ead7ee766cb78b1542` |
| Frozen and current Doc | `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` |
| Frozen test fixture | `0202163cdf6653fbc4d6c4752231967857e077a0cd3b52a536681e6fc123f295` |
| JSON test | `e38faa84961ddf1f21af94e2a94f176c3a7659fce8ca921d96f5f7b6a34d3d54` |
| Corrected Graphic test | `1a8a1722588e6d7658bf7471dd57687142024a6be68be49c32fa4c0c8880affa` |

The source writer applied the loop while this test lane was working. The before receipt is therefore a separate frozen-source process run, not a claim that the before process ran chronologically before that edit. The frozen hook loads exact archived core files at their normal URLs; unarchived dependencies remain current. It avoids mixed old/new Doc identities. The independent JSON function is permanently in the test fixture and does not require the ignored archive at normal test runtime.

## Reproduction and receipts

Runtime: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`.

Each test or diagnostics command ran through `tests-bounded-check.py`: a dedicated new owned process group, 240-second watchdog, SIGINT/SIGKILL only for that group on timeout. No watchdog fired. Full commands, exits and elapsed times are in the matching JSON receipts; logs are retained.

- `tests-frozen.json` / `.log`: exact archived core hook plus the two owned test files, 241/241.
- `tests-live.json` / `.log`: existing `api-client-source-hook.mjs` plus the same files, 241/241.
- `tests-related-live.json` / `.log`: existing source hook; annotations, data-admission, data-admission-review, data-admission-http, snapshot, history-recovery, live-recovery, browser-recovery, recovery-receipt, recovery-reservation, graphic-custom-schema and core-performance-helpers; 119/119. The browser-recovery file is a Node source test, not a live browser run.
- `tests-typecheck.json`, `tests-typecheck-diagnostics.json` and `.log`: scoped complete diagnostics, no emit, zero diagnostics.
- `tests-provenance.json`: archive and fixture verification, source/test hashes and counts.

Initial harness failures were corrected in tests only: public snapshot setup had omitted a default-valued register; the primitive 123-wrapper expectation was incorrect. Those first/second live logs are retained as `tests-live-initial.log` and `tests-live-second.log`. The original fixed oracle rejects the latter value, and the final test explicitly requires that rejection. A frozen probe also corrected the misleading undefined-origin assumption. No production change or compatibility relaxation was made for these failures.

## Handoff boundary

H1 test fix and independent JSON test slice are ready for root/High review. Root must consume the exact hashes and assess its own final global results. This report grants no private certificate, trust flag, unchecked route, performance acceptance, global PASS or release approval.
