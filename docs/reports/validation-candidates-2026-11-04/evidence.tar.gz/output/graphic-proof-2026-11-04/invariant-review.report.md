# Private Graphic proof snapshot: invariant review

## Decision

**Keep the optimization OFF. Do not enable the current certificate prototype.**

- **Step A source review: CLEAR. The publication gate appeared during this review.** The output candidate only extracts the existing decoder into a runtime-private static method. It does not optimize capture or validation.
- **Step B architecture: BLOCK.** There is no reviewed optimized production candidate. Wrapper ownership and exact observation order are not proved. The reflected-wrapper prototype also failed its local cost screen.
- **New test contract: REQUEST CHANGES.** The snapshot-override test permits a success that the frozen legacy route rejects. This contradicts the required compatibility contract.
- **Optimization correctness: NOT_PROVED. End-to-end performance: NOT_RUN.** Worker test receipts do not change these labels.
- The implementation lane independently chose **FAST_PATH_OFF**. This is the correct fail-closed result for the current candidate.

This report reviews the conditional plan before optimization is enabled. It does not approve a broad trusted-Doc clone, a source trust flag, a direct-state fork, or proof-result installation. Root must request review of the exact later diff before enabling another candidate.

## Scope and evidence boundary

Review points: initial source inspection at 2026-11-03T15:31Z; final status refresh at 15:35Z, 2026-11-04 KST. Workspace: `/Users/user/github/doc-sync`. HEAD: `ec9622571a04a7d7ea3f967bb3e6423b17ce5194`. The workspace has inherited uncommitted changes. HEAD is not the baseline source identity.

Read:

- `output/refactor-2026-11-03/trusted-fork-design.report.md`.
- Frozen `post-refactor-baseline/` source and its manifest.
- Live `packages/doc-sync/src/crdt/doc.ts` and the finite-JSON policy in `annotations.ts`.
- Output-only Step A source, exact diff, differential harness receipts, certifier source and raw microbenchmark samples.
- `implementation.report.md`, `implementation.status.json`, `tests.prototype.ts`, `tests-ownership.md`, and `tests.report.md` under `output/graphic-proof-2026-11-04/`.

Direct checks by this reviewer:

1. All **71 frozen manifest entries matched** their archived file bytes. No missing entry was found.
2. Live `doc.ts` equaled the frozen `doc.ts` bytes at inspection.
3. Step A equaled the frozen Doc plus one exact insertion before the former structural decoder body. No other candidate bytes changed.
4. `phase1-ready.json` was absent at initial inspection. It appeared at `2026-11-03T15:33:35.544351+00:00`. At the final refresh, live Doc still equaled the frozen bytes. No live optimization existed. No source edit was needed to review the contract.
5. Another worker published `packages/doc-sync/test/graphic-proof-copy.test.ts` after that gate. Its lines 123-132 still contain H1. The published file hash at 15:35Z was `dc2c0cdc1651a9526bee18d95fdf14cc4968aaa3829320a5e1a50ae0bcd01201`. Its runtime results were not inspected or rerun in this review.

Only this report is written by this reviewer. No production, test, benchmark, dist, docs, or HANDOFF file is changed. No tests, build, browser, mobile, commit, push, or release are run by this reviewer. No other agent is spawned. Other workers own their files and their runtime receipts.

### Source identity

| Artifact | SHA-256 at inspection |
| --- | --- |
| Frozen and live `packages/doc-sync/src/crdt/doc.ts` | `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` |
| `implementation/doc.step-a.ts` | `68a5390a04103941efb20a2ab41f664d4dcb57267cfed1c8938478aa2fe7007f` |
| `implementation/certifier-prototype.mjs` | `727095907a6c4e0883d773b6ccc2d2f8d95a15c406594469b4e3c9d1750dd4aa` |
| `tests.prototype.ts` | `895ab5c9561d502205b490e1c1c4cccb538ca1d8ed99d8704f1ef7c6e79adeb9` |
| `post-refactor-baseline-manifest.json` | `0efe5221333ee1f645f28bc0ea1b50fd742cdbe26a48daa35eb7cf2e068a7412` |

These hashes bind this review. Later worker changes require a new diff review. The inherited HEAD diff is not the proposed optimization diff.

## Ranked findings and required action

### H1 — HIGH: snapshot-override test permits a behavior regression

**Evidence:** `tests.prototype.ts:123-132`, also published in `packages/doc-sync/test/graphic-proof-copy.test.ts:123-132`, accepts either a rejection or a successful edit after `doc.snapshot` returns a snapshot with `lamport = NaN`. `tests.report.md`, case 7, states the same weakened contract. Frozen `doc.ts:2250` always calls the public `this.snapshot()` and then the full public loader. Its full preflight at `doc.ts:2576` rejects that image. Ignoring the override and accepting the edit is not equivalent.

**Required action for the test owner:** remove the success alternative. Compare with the frozen legacy outcome. Add instance override, subclass override, and throwing override cases. Count calls and preserve the receiver. A throwing override must propagate the same sentinel error object. A benign override must still run once and retain its existing side effects. Include a snapshot property getter so an identity check cannot silently double the property reads.

**Required action for a later implementation:** compare the effective snapshot method with the originally captured base method. If it differs, use the legacy public snapshot plus full `Doc.fromSnapshot` route. Do not certify an arbitrary public result, even if its fields look valid. Do not read a getter once for the identity check and again for the call. Do not use a current mutable `Doc.prototype.snapshot` value as the definition of the original method.

**Current production resolution:** unchanged legacy call; no regression is installed. **Test finding remains OPEN in the published test file at final refresh.**

### H2 — HIGH: private capture does not establish private wrapper ownership

**Evidence:** frozen `doc.ts:2566-2570` calls `lineMap.values()` and the overridable `line.items.map`. `doc.ts:2705-2707` uses external Map/Set iteration and array mapping. The implementation report identifies a concrete item-array map probe that returns modified wrappers. The private location of the call does not prove that those wrappers are fresh, plain, or unescaped.

A custom map can call the supplied encoder callback, retain its returned item object, and return a foreign array. A foreign `constructor` or species can affect array allocation. A later getter can mutate a retained wrapper during capture. Verifying that a callback ran is therefore insufficient.

**Required action:** provide an ownership entry for every wrapper and every nonprimitive metadata field. Do not infer ownership from TypeScript types, `Array.isArray`, `instanceof`, a Doc version, or private call-stack position. Do not replace user-controlled map/iterator calls with manual loops without proving unchanged read, call, copy, and throw behavior. Any unproved wrapper must use full validation on the **same captured image**.

**Current resolution:** implementation keeps the shortcut off. This is sufficient to avoid a production defect. It is not a proof for a future fast encoder.

### H3 — HIGH: descriptor inspection can change fallback observations

**Evidence:** `certifier-prototype.mjs:4-20` reflects the candidate wrappers. It uses `Reflect.ownKeys` on the newly created descriptor object. The legacy `annotations.ts:47-55` obtains descriptors and then separately obtains keys from the original object. These operations are equivalent for owned inert wrappers, but not necessarily for foreign Proxies. A Proxy can count, throw from, or vary its `ownKeys`, descriptor, and prototype traps.

**Risk:** running this checker on a foreign wrapper and then falling back to full validation can add traps, change the first error, or change the image before the legacy walk. Catching the new error and returning false does not undo those observations. Using the same image is necessary, but not sufficient, for exact behavior.

**Required action:** the fast checker must run only on wrappers whose inert ownership is already proved without extra foreign observations. Otherwise take the legacy walk directly. Do not treat speculative reflection plus a later full walk as exact fallback. Add a foreign Proxy wrapper case with a trap trace and a sentinel error. This is a contract requirement, not a test run by this reviewer.

**Current resolution:** output-only experiment; not enabled. The implementation report's reflected-shell checks must not be read as a complete runtime-ownership certificate.

### M1 — MEDIUM: the public composition oracle alone cannot detect shared decoder regressions

**Evidence:** `tests.prototype.ts:30-35` uses current `Doc.fromSnapshot` as the legacy composition oracle. The test lane correctly discloses that the new public and private paths can share the same decoder. Its frozen-Doc before run is useful, but a before success does not independently verify the after decoder.

**Required action:** retain separate frozen and candidate processes for boundary probes, compare explicit expected storage/ops/errors, and preserve the exact structural-body byte comparison for Step A. A public-composition oracle can remain a focused permanent test. Do not call it a fully independent old decoder. Do not add a public test bypass or copy an entire production Doc merely to satisfy a label.

**Current evidence:** Step A has a separate frozen-source differential receipt for 17 cases and an exact insertion check. That supports the extraction only. It does not qualify Step B.

## Explicit resolution of the six parent constraints

| Parent constraint | Contract / required resolution | Current status |
| --- | --- | --- |
| 1. Public snapshot can be overridden; source state is mutable | Preserve the override through the legacy full route whenever the effective method differs from the captured original. Never brand the public result or the Doc. Never trust `lineMap`, exposed Items, registers, tickets, Maps, clock, or an unchanged revision. | Production remains legacy. H1 test fix is required. |
| 2. Dynamic arrays, iterators, and constructors can return foreign wrappers | Prove fresh inert ownership per wrapper. No callback-visited shortcut. If proof fails, full preflight on the same image, with no speculative foreign walk that changes observations. | Ownership shortcut NOT_PROVED. H2/H3 block enablement. |
| 3. Preserve copy/read/failure order | Complete all legacy capture work before a finite-JSON error can be thrown. A certifier may record invalidity only through inert operations; it must not preempt a later clone error or getter effect. Full fallback cannot recapture. Preserve the original error object when an existing operation throws. | Legacy route preserved. One late-getter test exists; broader traces are required for Step B. |
| 4. Preserve exact JSON policy and depth | Unknown attr root is depth 7, so budget is 121. Moves root is depth 1, so budget is 127. Preserve primitive-before-object-depth checks and all captured-image descriptor rules. | Prototype has correct budget constants. Complete optimized route NOT_PROVED. |
| 5. Prove useful performance, not renamed counters | Require at least 5% improvement in 20k-entry edit + first-read total in three ordered A/B + B/A pairs, with fixed source/runtime/workload and raw samples. Count private work and allocations. | Product acceptance NOT_RUN. Current microbenchmark candidate rejected. |
| 6. Keep the slice private and bounded | Preserve structural decoder checks, public loaders, state/server/recovery admission, schema/fingerprint, exact ops, History, priors, movement and recovery behavior. | Step A exact source extraction is CLEAR. No Step B caller change exists. No broad clone is approved. |

The prior observer-fallback fix and two pure annotations are not reopened. The parent's earlier full-suite receipt remains a separate checkpoint. It is not reused as optimization evidence.

## Actionable encoder proof table

This table is a gate for a later candidate. No row grants permanent trust to source state.

| Component / step | Depth | Required proof and decoder boundary | Required failure or differential probe | Status |
| --- | --- | --- | --- | --- |
| Entry dispatch | before capture | Original public snapshot identity is privately retained; override uses legacy full route; method lookup/call occurs with legacy observations | Instance, subclass, getter, throwing override; exact calls/receiver/sentinel | OPEN; H1 |
| Envelope | 0 | Fresh owned data record; no escape, symbol, accessor or foreign prototype | Foreign shell cannot reach unchecked decoder | OPEN |
| Format / Lamport | 1 | Finite JSON values only; safe integer, format and clock-floor checks remain in decoder | NaN, bigint, negative/fractional/out-of-range Lamport; exact error order | Decoder retained; certificate OPEN |
| Capabilities shell / members | 1 / 2 | Dense owned array and finite primitive members; supported/required-feature checks remain | Missing/unknown capability; poison/extra/symbol properties on foreign array | OPEN |
| Moves | 1 | Existing copy order; finite-JSON budget 127; no foreign copied result; replay/check/order unchanged | Deep move payload; late move failure; move prior and floor | Budget correct; route OPEN |
| Lines shell / line records | 1 / 2 | Dense owned array and inert owned records; key/owner/slot are finite primitives, or direct full fallback | Custom `values`, borrowed line metadata, nonprimitive key/owner/slot | OPEN; H2/H3 |
| Items shell / item records | 3 / 4 | Dense owned output; map/species/callback cannot supply or retain trusted wrappers | Custom map returns sparse/extra/accessor/Proxy output; retained callback object mutated later | OPEN; H2/H3 |
| Item scalar metadata | 5 | All emitted `i,o,k,c,b,y,z,s` values finite; omission behavior unchanged | Corrupt id/origin/birth/span/boundary; omitted origin must keep old behavior | Structural checks retained; certificate OPEN |
| Attrs shell / tuple | 5 / 6 | Owned dense array and owned 3-field tuple; finite name/stamp fields | Tuple hole, extra own key, symbol, accessor, invalid stamp; same error | OPEN |
| Unknown copied attr value | 7 | `annotationJsonOk(value, 121)` equivalent on the copied subtree; no source pointer certificate | Exact depth boundary; nested arrays; all value-policy cases below | Constants correct; complete route OPEN |
| Delete / cancel shells and members | 5 / 6 | Owned dense arrays; finite values; no new Set iteration behavior | Undefined/nonfinite/object members, custom iterator and throwing iterator | OPEN |
| Lifetime / escape | full call | One image, synchronous consumption, no yield/callback escape/cache/brand/global mutable scratch | Source aliases and returned public snapshot cannot alter certified image | OPEN |
| Structural decode | after finite check | Duplicate IDs/lines, canonical head, spans, reserved/derived storage, capabilities, fields, annotation references and move checks remain | Frozen/candidate exact storage plus malformed structural images | Step A source CLEAR; after-live NOT_RUN |
| Compile / live effects | after proof copy | Proof stays detached; live compile/normalize and guard/listener order unchanged; prior maps stay target-specific | Late invalid batch, MAX_SAFE_INTEGER exhaustion, exact ops/priors, History undo/redo and hidden storage | Worker focused receipts only |
| External admission | unchanged | Public fromSnapshot and checkpoint/state/server/recovery still run full finite preflight | Mutated public image with trust-looking flags; malformed state/restore | No current source change; final candidate review required |

### Exact captured-image JSON policy

Use the legacy policy, not JSON.stringify success and not a source-type approximation.

- Null, strings, booleans and finite numbers are accepted before the object-depth guard. Preserve negative zero.
- Undefined, bigint, symbol, function and nonfinite numbers are not finite JSON. Copying may retain some primitives until preflight. Do not throw early while copying.
- Objects must be ordinary or null-prototype records. Arrays must be dense. Extra array own properties, non-index keys, symbol keys, non-enumerable data and accessor descriptors follow the same rejection rules as the legacy captured-image validator.
- Poisoned own names are `__proto__`, `prototype`, and `constructor`.
- Cycles reject. Shared acyclic subgraphs do not reject merely because they are shared; the legacy seen set is path-local.
- Date, Map, Set and typed-array output does not become finite plain JSON merely because structuredClone accepts it.
- Apply this policy **after legacy copying**. A source getter can run during structuredClone, and a source non-enumerable or symbol property can be omitted by that copy. Do not reject the original source graph in place of checking the captured image.
- An object at total depth 128 is allowed. An object at 129 rejects. A finite primitive at 129 still accepts because primitive checks occur first. The current attr probes encode 121 next edges to an empty object as accepted and 122 as rejected; they also accept a primitive leaf after 122 object wrappers.

## Failure and side-effect order gate

Frozen `snapshot()` builds capability information, copies moves if present, reads the clock, then captures all lines/items and copied attrs. Only after that complete public snapshot returns does `fromSnapshot` run the full finite-JSON walk. Its structural checks run after finite validation. The Graphic guard and optional preflight run before proof creation. Normalization reads and live compile run after proof compile succeeds (`doc.ts:2243-2268`).

A future inline certifier must not turn an early NaN, bigint, depth overflow or metadata uncertainty into an early throw. A later throwing getter or structuredClone failure must still win if it won before. Accumulating a boolean is safe only when the accumulation itself cannot observe foreign objects, run traps, mutate the source, or throw. Otherwise defer the check and use legacy validation.

Minimum new probes:

1. Early bad primitive and early over-deep payload, each followed by a later getter throwing a sentinel object.
2. Early invalid metadata followed by a later copy failure and a successful later getter with an observable trace.
3. Custom item map that retains callback results and changes an earlier item during a later item's capture.
4. Foreign Proxy output with traced prototype/keys/descriptor traps. No extra certification pass may precede the legacy fallback on this path.
5. Public snapshot getter/override with exact lookup and call counts, plus a throwing override.
6. One captured-image identity across failure fallback. No second snapshot/clone of mutable source state.

Compare ordered traces and error object identity, not just `throws`, name, or message. Name/message equality remains useful for newly allocated policy errors. Separate processes cannot compare object identity directly; each process must assert its own thrown object equals its own sentinel.

## Step A extraction review

The exact insertion is:

```ts
return Doc.#decodeSnapshot(actor, snapshot, schema);
}

static #decodeSnapshot(actor: string, snapshot: Snapshot, schema: Schema | null): Doc {
```

It follows the unchanged public `annotationJsonOk(snapshot, 128)` check. All former structural decoder code is byte-identical. The private method is not a string-named public entry. The existing Graphic proof call at line 2250 is unchanged. No trust parameter or validation bypass is exposed.

**Conclusion:** no source-level invariant blocker was found for this extraction. The gate now exists; this does not authorize this reviewer to apply source edits. Check the live before hash before any later application. Step A alone does not eliminate validation, copying, reconstruction or allocation. It has no qualified performance benefit.

Worker receipts, read but not rerun:

| Receipt | Recorded result | Review limit |
| --- | --- | --- |
| `implementation/step-a-focused.json` and `.log` | 62 PASS, 0 FAIL, 0 SKIP | Output candidate through a source hook; not live/global acceptance |
| `implementation/step-a-differential-results.json` | 17 PASS | Separate frozen/candidate Doc; shared compiler/History dependencies |
| `tests.report.md` | Frozen before: 38 PASS; prototype typecheck: zero diagnostics | AFTER NOT_RUN; override assertion is too weak |
| Certificate experiment | 21 probe cases recorded by implementation | Output-only; no ownership or product PASS inferred |

## Performance decision and acceptance gate

The actual certifier is a second full wrapper traversal. It allocates descriptor maps and key arrays for wrappers, then uses generic validation for arbitrary attr values and moves. Removing a public `fromSnapshot` counter does not remove this work.

`implementation/certifier-samples.json` records:

- Generic full validation median: **69.352 ms**.
- Specialized reflected-wrapper median: **77.846 ms**.
- Ratio: **1.1225**, or about 12.25% slower in this local check.
- Eight samples per route, one alternating sequence, a synthetic 20,000-item image, Node v24.22.1.

This is a local certification-only cost screen. It is not a 20k edit/read experiment, a statistically isolated regression result, or proof that every future encoder is slower. It gives no basis to enable this particular candidate. The implementation correctly rejected it.

Before accepting a different candidate, root must collect at least **three ordered A/B + B/A pairs** at 20k total entries: 10k List and 10k Map entries. Use the frozen post-refactor WIP as A, not HEAD or the earlier primitive-copy baseline. Require at least **5% lower edit + first-read total** for the candidate in each paired round; otherwise retain OFF or report INCONCLUSIVE. Keep the runtime, source closure, schema, seed, warmups, sample count, GC, observers and History setting fixed. Avoid concurrent tests/builds/browser work. Record raw samples, order and source hashes.

Count private capture, certification, generic fallback and decode work, not only public calls. Check allocation/heap/GC separately if claiming an allocation benefit. Keep control-path regressions and remaining reconstruction/normalization/first-projection cost visible. Do not claim improvement from scan counts, an extraction, or the old primitive-copy receipts.

## Parent handoff

1. Keep the Graphic proof path unchanged. Do not install `certifier-prototype.mjs` or a relaxed variant.
2. Send H1 to the test owner before treating the 38-case suite as the compatibility gate. The frozen-before PASS does not settle this finding.
3. Step A can be considered independently; the file gate now exists. Its source review is clear, but it is not a speed improvement.
4. A later Step B requires the completed ownership table, exact fallback/observation proof, focused frozen differential results, and an exact source diff review before enablement.
5. Root retains global suite, desktop product checks, publication and end-to-end performance ownership. Mobile remains NOT_RUN. Existing R1 observer/pure fixes stay closed unless new evidence directly touches them.

**Final verdict: safe to retain legacy behavior; not approved to enable optimization.**
