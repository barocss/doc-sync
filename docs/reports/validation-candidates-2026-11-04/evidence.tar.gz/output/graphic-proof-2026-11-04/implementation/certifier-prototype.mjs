// OUTPUT-ONLY experiment. No production caller. Failure means full preflight on SAME image.
import {annotationJsonOk} from '../../../packages/doc-sync/src/crdt/annotations.ts';
const scalar = value => value === null || typeof value === 'string' || typeof value === 'boolean' || typeof value === 'number' && Number.isFinite(value);
const descriptors = (value, array) => {
    if (!value || typeof value !== 'object' || Array.isArray(value) !== array) return null;
    if (!array && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) return null;
    const d = Object.getOwnPropertyDescriptors(value);
    for (const key of Reflect.ownKeys(d)) {
        if (array && key === 'length') continue;
        if (typeof key !== 'string' || key === '__proto__' || key === 'prototype' || key === 'constructor') return null;
        if (!d[key].enumerable || !Object.hasOwn(d[key], 'value')) return null;
        if (array && (!/^(0|[1-9]\d*)$/.test(key) || Number(key) >= d.length.value)) return null;
    }
    if (array && Reflect.ownKeys(d).length - 1 !== d.length.value) return null;
    return d;
};
const arrayEvery = (value, check) => {
    const d = descriptors(value, true);
    if (!d) return false;
    for (let i = 0; i < d.length.value; i++) if (!check(d[i].value)) return false;
    return true;
};
const attribute = value => {
    const d = descriptors(value, true);
    return !!d && d.length.value === 3 && scalar(d[0].value) && annotationJsonOk(d[1].value, 121) && scalar(d[2].value);
};
const item = value => {
    const d = descriptors(value, false);
    if (!d) return false;
    for (const key of Reflect.ownKeys(d)) {
        const value = d[key].value;
        if (key === 'a') { if (!arrayEvery(value, attribute)) return false; }
        else if (key === 'd' || key === 'x') { if (!arrayEvery(value, scalar)) return false; }
        else if (!['i','o','k','c','b','y','z','s'].includes(key) || !scalar(value)) return false;
    }
    return true;
};
const line = value => {
    const d = descriptors(value, false);
    if (!d) return false;
    for (const key of Reflect.ownKeys(d)) {
        if (key === 'items') { if (!arrayEvery(d[key].value, item)) return false; }
        else if (!['key','owner','slot'].includes(key) || !scalar(d[key].value)) return false;
    }
    return true;
};
export function certifyImage(value) {
    const d = descriptors(value, false);
    if (!d) return false;
    for (const key of Reflect.ownKeys(d)) {
        if (key === 'lines') { if (!arrayEvery(d[key].value, line)) return false; }
        else if (key === 'moves') { if (!annotationJsonOk(d[key].value, 127)) return false; }
        else if (key === 'capabilities') { if (!arrayEvery(d[key].value, scalar)) return false; }
        else if (!['format','lamport'].includes(key) || !scalar(d[key].value)) return false;
    }
    return true;
}
