# Graphic proof copy: test lane

## Status

- **BEFORE PASS:** 38 tests, 38 PASS, 0 FAIL, 0 SKIP. Frozen post-refactor Doc; same current dependencies. No HEAD archive used.
- **PROTOTYPE TYPECHECK PASS:** complete TypeScript diagnostic closure, zero diagnostics, no emit/build.
- **LIVE TEST PASS:** published new test file: 38 PASS, 0 FAIL, 0 SKIP. Live Doc remains identical to frozen baseline. This is not an optimized-implementation PASS.
- **STEP A OUTPUT CANDIDATE PASS:** same 38 tests pass with the implementation lane’s output-only private-decoder extraction. No fast path is enabled.
- **PUBLISHED TYPECHECK PASS:** complete diagnostic closure of the package test, zero diagnostics.
- **GATE OBSERVED / PUBLISHED:** phase1-ready.json reports PASS at 2026-11-03T15:33:35.544351+00:00. Publication occurred only after reading it. New file: `packages/doc-sync/test/graphic-proof-copy.test.ts` (253 lines).
- No production, dist, docs, HANDOFF, existing tests, commit, push, Chrome or mobile changes by this lane. Only the assigned NEW test was added outside output. No sub-agents.

## Reference agreement / limits

Root proposal is recorded in `tests-ownership.md`; no feedback artifact received yet. The permanent proposed test uses an independent legacy composition oracle: public `snapshot()` -> fully validated public `Doc.fromSnapshot()` -> `compileEdits()` on that detached Doc. It never calls a new private certifier/decoder or asks production to expose a test bypass. Explicit assertions check storage inventory, exact wire ops/normalization, live prior values/placement, write tickets, History graph/undo/redo, deletion pins, clock and failure atomicity.

The prototype was run in a separate Node process with `tests-frozen-hook.mjs`. Every Doc import is redirected to the exact frozen post-refactor Doc. Its relative dependencies are redirected to current sources; those source bytes were verified equal to the manifest at this run (`tests-provenance.json`). No old/new Doc class identity mixing. The permanent test will require no ignored output file, fixture archive, repository metadata, git command or external child loader.

**Limit:** this is a frozen-Doc before/after runtime receipt plus an independent public legacy-copy composition oracle, not a permanent fully frozen structural decoder. A future bug shared by the public loader and private decoder could escape this oracle. Full old Doc duplication was avoided; the production structural decoder remains reviewed separately by the High lane. Root agreement is not inferred from silence.

## Cases

1. Unknown payload depth: root at envelope depth 7; 121 object edges to an empty-object leaf ends at 128 and accepts; 122 edges rejects. A primitive after 122 object wrappers accepts because primitive checks precede object-depth checks.
2. Raw retained undefined, bigint, nonfinite numbers, Date, Map, Set, typed array, cyclic graph, sparse array and poisoned key reject before mutation, with the same error name/message as public legacy copy.
3. Shared acyclic graph accepts. Input, detached copy and emitted snapshot values do not mutate retained source objects.
4. Exposed clock/line key/origin/birth/span/attribute key/register ticket/deletion/cancel state matches legacy acceptance or rejection. Undefined origin intentionally retains the legacy omitted-origin meaning; not every malformed-looking mutation is rejected by the old decoder.
5. Early nonfinite value followed by later throwing getter preserves full capture ordering and exact thrown error identity.
6. Late invalid batch leaves storage identity, snapshot, version, clock, listener count and live read-projection count unchanged. Late clock exhaustion leaves all captured state unchanged.
7. Overridden public snapshot cannot install an invalid private image. Either legacy full rejection or private capture of real storage is allowed; NaN is never installed. Public trust-looking flags do not bypass validation. No named runtime-private entry is exposed.
8. Mutated public snapshots, missing feature capability, duplicate line, invalid token span, engine checkpoint, local state and server-origin snapshot retain full external validation.
9. Exact staged/live wire ops, normalization, prior maps, field stamps, restored History graph, foreign same-value ownership, undo/redo carets, retained deletion pins and clocks agree.
10. Nested Graphic parent move/delete/undo/redo retains hidden storage, placement priors, exact ticket inventory and snapshot round trip.

No wall-time assertion or performance claim. Annotation/cardinality/GC/convergence/lifecycle coverage remains with existing focused/root suites; this is a bounded new boundary-threat suite, not whole-product qualification.

## Commands / receipts

All checks use `root-check.py`, which sets Node v24.22.1 PATH and a 240-second process-group watchdog.

```sh
python3 output/refactor-2026-11-03/root-check.py graphic-proof-tests-before \
  node --import ./output/graphic-proof-2026-11-04/tests-frozen-hook.mjs \
  --test output/graphic-proof-2026-11-04/tests.prototype.ts
python3 output/refactor-2026-11-03/root-check.py graphic-proof-tests-typecheck \
  node output/graphic-proof-2026-11-04/tests-typecheck.mjs
```

Raw before results: `graphic-proof-tests-before.log` / `.json` in this directory. Typecheck diagnostics: `tests-typecheck.json`. Watchdog receipts also exist under the root runner's fixed output directory. No global build was used.

Initial fixture draft had two assertion failures: an off-by-one depth convention and a JS default argument replacing explicit undefined with null. Both were corrected against frozen behavior before the final 38-case baseline run; no production assertion was weakened.

## Final source-focused publication receipts

```sh
python3 output/refactor-2026-11-03/root-check.py graphic-proof-tests-published \
  node --test packages/doc-sync/test/graphic-proof-copy.test.ts
GRAPHIC_PROOF_TEST=packages/doc-sync/test/graphic-proof-copy.test.ts \
  python3 output/refactor-2026-11-03/root-check.py graphic-proof-tests-published-typecheck \
  node output/graphic-proof-2026-11-04/tests-typecheck.mjs
```

Published test SHA-256: `dc2c0cdc1651a9526bee18d95fdf14cc4968aaa3829320a5e1a50ae0bcd01201`. Live Doc at run: `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` (unchanged baseline). Receipts: `graphic-proof-tests-published.log/json`, `graphic-proof-tests-published-typecheck.log/json`. Output Step A receipt: `graphic-proof-tests-step-a.log/json`; this source replacement was not applied by this lane.

Parent full-suite / desktop Chrome / final performance acceptance remain NOT_RUN by this worker. Root reference-proposal acknowledgement has not been observed; the oracle boundary and limitation above are explicit, not implied approval. Implementation lane reports FAST_PATH_OFF; therefore no certified-copy correctness or performance PASS is claimed.
