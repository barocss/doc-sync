# Private Graphic proof implementation lane

## Decision

**FAST_PATH_OFF.** Do not enable the output-only certificate prototype. It still reflects every envelope wrapper. The local microbenchmark is slower than the existing full finite-JSON check. No speedup is claimed.

**GATE_WAIT:** `output/refactor-2026-11-03/phase1-ready.json` was absent through this receipt. No live production, test, benchmark, dist, docs or HANDOFF file was edited. Existing broad-refactor WIP is preserved. No helper production module was created. No subagents, build, Chrome, mobile, commit or push was used.

Step A is prepared and tested as an output-only source replacement. It is not applied to live `doc.ts`. Step B is rejected for this implementation candidate. The parent can review/apply Step A after the gate. Applying it has no expected performance benefit by itself.

## Source identity and patch

Owned production path: `packages/doc-sync/src/crdt/doc.ts` only.

- Frozen post-refactor baseline and live source both have SHA-256 `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d`.
- Output Step A candidate: `68a5390a04103941efb20a2ab41f664d4dcb57267cfed1c8938478aa2fe7007f`.
- Before is frozen WIP source, not HEAD/ec962.
- Manifest: `implementation/source-manifest.json`.
- Exact patch: `implementation/step-a.diff`.
- Candidate bytes: `implementation/doc.step-a.ts`.
- Preserved before bytes: `implementation/doc.before.ts`.

Step A leaves the public signature and `annotationJsonOk(snapshot, 128)` first statement unchanged. It then calls runtime-private static `#decodeSnapshot`. All bytes after the previous public preflight are moved unchanged. `decoderBodyExact: true` verifies suffix byte equality. The existing Graphic `Doc.edit` snapshot/fromSnapshot line is unchanged.

## Focused checks

All commands use Node v24.22.1 from `/Users/user/.nvm/versions/node/v24.22.1/bin`. A private copy of root-check.py changes only its artifact output directory. It retains the 240-second watchdog and process-group timeout handling. No global build or dist write is involved.

| Check | Result | Exact scope |
| --- | --- | --- |
| Step A focused source tests | PASS 62 / FAIL 0 / SKIP 0 | snapshot, typescript-client-engine, annotations, graphic-custom-schema, history-recovery, core-performance-helpers; 1.944 seconds wrapper elapsed |
| Step A frozen-source differential | PASS 17 cases | Exact token storage, snapshot/model, ops, priors, clock/version; controlled-time History undo/redo; late unknown-attribute failure; public malformed/deep payload decode |
| Certificate prototype | PASS 21 focused cases | Sound positive acceptance probes, negative malformed wrappers, hostile public item-array map output; not a complete certificate proof |
| Owned live diff whitespace | PASS | `git diff --check -- packages/doc-sync/src/crdt/doc.ts`; inherited diff only |
| Live source unchanged | PASS | Same SHA as before |
| Full suite / build / Chrome / final product performance | NOT_RUN | Parent ownership |
| Mobile / commit / push | NOT_RUN | Prohibited |

Raw receipts and logs are under `implementation/`. Step A imports use the existing source hook plus a load hook for only the owned source URL. Frozen reference uses the exact before bytes under a separate module URL. The candidate and reference do not share the decoder implementation. They still share compiler/History dependencies, so these probes are not an independent whole-engine qualification.

The differential harness initially used `{t: 'bogus'}` as an invalid semantic edit. The compiler ignores that out-of-contract shape, so the harness's expected atomic rejection was wrong. The first failed log is retained as `step-a-differential.initial-harness-failure.log`. It was corrected to a real `op: 'update'` with an unknown attribute. No production or existing test was changed.

## Encoder proof table for High review

This table describes required proof and the rejected output-only checker. It does not certify an optimized production encoder.

| Image component | Envelope depth | Required proof | Prototype / decision |
| --- | --- | --- | --- |
| Root | 0 | Fresh plain wrapper, only data descriptors, finite lamport and optional format | Descriptor reflection; no skipped public admission |
| capabilities | 1; elements 2 | Dense array, finite primitive contents; structural supported-capability checks remain | Reflected shell plus scalar checks |
| moves | 1 | Exact old JSON property with object budget 127; all move structure stays in decoder | Existing `annotationJsonOk(moves, 127)` |
| lines array / line record | 1 / 2 | Dense shell; key, owner, slot must be finite primitive data; no accessors, extras or symbols | Descriptor reflection on every wrapper |
| items array / item record | 3 / 4 | Dense shell; identity/origin/kind/ch/born/boundary/span/compact primitive fields covered | Descriptor reflection on every wrapper |
| attrs array / attribute tuple | 5 / 6 | Dense shells, tuple arity 3, primitive name/stamp; unknown payload checked separately | Descriptor reflection on every wrapper |
| attribute value | 7 | Old JSON rules with budget 121, primitive-before-depth-check retained | Existing `annotationJsonOk(value, 121)` |
| dels / cancels | 5; elements 6 | Dense shells and finite primitive contents | Reflected shells plus scalar checks |
| malformed metadata / foreign wrapper | any | No unchecked decoder; full preflight of the SAME already captured image | Prototype returns false; no production caller exists |
| public snapshot override | before capture | Preserve legacy override behavior; never certify arbitrary public result | No new capture path installed; legacy route remains |
| image lifetime | entire synchronous copy | No source cache, escaped image, mutable global buffers or brand | No production certificate; prototype uses fresh local descriptors |

The probe includes object payload depth 121/122 and the primitive leaf at the old boundary. Public-loader differential includes Date, Map, undefined, bigint, nonfinite values, sparse arrays, accessors and cycles. Those probes do not replace the test lane's broader independent cases.

## Actual blockers and rejected shortcuts

1. `line.items.map` is callable external state. An overridden map can call the expected callback, then mutate the produced wrappers or return a foreign array. The probe does this and inserts NaN into a returned attribute tuple. The existing full preflight rejects it. Merely recording that a private capture callback ran is not an ownership proof.
2. Attribute tuple mapping also uses public Array methods. Map/Set iteration and copied metadata can be corrupt. TypeScript types, a revision number, or a WeakSet of source Docs cannot establish finite JSON.
3. Replacing those callbacks with manual loops changes legacy callback/throw/read behavior. Selecting a fast route by a captured native-method identity needs an explicit intrinsic/prototype assumption and review. No such assumption is made here.
4. Reflecting all possibly foreign wrappers can restore the finite-JSON proof without an ownership assumption. However, that route is still a complete envelope walk. The measured candidate is slower. It is not a valid optimization merely because it uses a private method.
5. Public snapshot override compatibility is stricter than simply calling an unoverridable capture. No private encoder is installed that would bypass a rejecting/throwing public override. A future candidate must preserve the legacy route for such overrides without branding its output.

There is no public skip flag, no trusted-Doc marker, no proof-result installation, and no change to engine, History, schema or server paths. The optimization remains off rather than weakening admission or accepting a new global-intrinsic assumption.

## Local certificate cost experiment

Artifact: `implementation/certifier-samples.json`. Synthetic 20,000-item captured image, two attributes per item including a scalar-tag object; three warmups; eight samples per route; alternating full/specialized order; explicit GC. This is a certification-only microbenchmark. It is not the parent's end-to-end performance acceptance.

- Existing generic full check median: **69.352 ms**.
- Specialized reflected-wrapper check median: **77.846 ms**.
- Specialized/full median ratio: **1.1225**.
- Full range: 67.006–106.647 ms; specialized range: 74.761–82.825 ms.

One sequence, no isolation guarantee from other workers, no confidence interval, no p95 claim. This is enough to reject this particular expensive candidate; it does not prove that every future private encoder would be slower. Source/certifier checks ran sequentially within this lane.

## Parent handoff

1. Do not apply anything before phase1-ready.json exists.
2. If Step A is useful independently, compare live source with the recorded hash, inspect `step-a.diff`, and apply only that extraction. Re-run affected source checks at final live bytes.
3. Keep the Graphic call unchanged. Do not install the output-only checker.
4. A later Step B needs a cheaper ownership/capture proof that preserves custom method behavior and failure order. High review must approve the exact diff and proof before enabling it.
5. Root owns global tests, build, docs/HANDOFF, Chrome and final performance acceptance. No parent receipt is replaced by these local probes.
