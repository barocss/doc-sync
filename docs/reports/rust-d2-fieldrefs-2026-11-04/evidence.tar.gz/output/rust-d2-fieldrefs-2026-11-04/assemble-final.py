from pathlib import Path
import json,hashlib,re
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-fieldrefs-2026-11-04';report=r/'docs/reports/rust-d2-fieldrefs-2026-11-04'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
s=read(t/'compare-final-summary.json');assert s['status']=='PASS' and len(s['cases'])==23
for item in s['cases'].values():assert sha(t/item['receipt'])==item['sha256']
a=read(t/s['gzipAudit']);assert a['status']=='PASS'
for row in a['entries']:assert sha(t/row['path'])==row['gzipSha256']
s.update({'core':'core/core-receipt-01.json','coreSources':'core/source-current-01.json','sdk':'sdk/receipt-final.json','sourceVerification':'final-source-verification.json'})
(t/'final-comparison-summary.json').write_text(json.dumps(s,indent=2)+'\n')
checks={'status':'PASS','nativeCoreTests':171,'nativeSdkTests':109,'main':{'schemas':2,'commands':352,'actorStates':704,'actualDocEditChecks':184},'scopeCases':28,'actualTsHubCases':32,'comparisonStages':23,'frozenHashes':219,'inheritedRuntimeSourcesUnchanged':44,'workspace':{**read(t/'workspace-test-01.json'),**read(t/'workspace-test-totals.json')},'typecheck':read(t/'typecheck-01.json'),'documentation':{'build':read(t/'docs-build-02.json'),'check':read(t/'docs-check-02.json'),'pages':55,'internalLinks':2630,'english':True,'localPathsExcluded':True},'sourceVerification':read(t/'final-source-verification.json'),'compressedEvidence':{'gzipIntegrityChecks':76,'traceRawHashChecks':32,'audit':s['gzipAudit']},'comparisonSummary':'final-comparison-summary.json','heapIdentity':'NOT_REPRESENTED','liveObjectBridge':'NOT_QUALIFIED','chrome':'NOT_RUN','mobile':'NOT_RUN','performance':'NOT_RUN','publication':'NOT_REQUESTED'}
(report/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
paragraph='''Final verification: **171 native core tests / 109 SDK tests PASS**. The fresh
comparison wrapper passes **23/23** drivers with **219 fixed source/binary hashes**.
The new two-schema corpus compares **352 commands / 704 actor states** and
**184 actual staged TS Doc.edit checks**. New input checks pass 28 cases and
actual TypeScript/DocHub checks pass 32 rows. All 44 inherited runtime source
files are unchanged. All nine inherited corpora pass, including the previous
296-command nested-payload corpus. Eight earlier report seals remain unchanged.

Workspace tests: **2,114 total / 2,112 PASS / two expected platform SKIPs /
zero FAIL / zero cancelled**. Typecheck and documentation build pass. Documentation
checks pass **55 pages / 2,630 internal links**, with English content and local
paths excluded. Final source bindings match core34, SDK6, wrapper219, main163,
inherited TS/integration31 and next-product evidence32 maps. The compressed
integrity audit checks 76 gzip artifacts; 32 trace artifacts also match their
recorded original raw hashes. Compiled documentation bodies match both fences.
'''
p=report/'README.md';text=p.read_text();needle='## Remaining boundaries\n';assert text.count(needle)==1;assert paragraph not in text;text=text.replace(needle,paragraph+'\n'+needle);p.write_text(text)
p=r/'HANDOFF.md';text=p.read_text();assert '### 5.149 D2 references from declared field leaves' not in text
intro='''Latest **§5.149** adds v3 sources from declared field leaves. Field destinations
retain structural JSON validation and independent writers; atomic targets keep
reference-group admission. Core171/SDK109 PASS; TS/native352 commands/704 states,
23 drivers and 219 fixed hashes PASS. Whole npm: 2,112 PASS, two expected SKIPs,
zero failures. Full D2 and Rust/WASM Client delivery remain open. See
`docs/reports/rust-d2-fieldrefs-2026-11-04/`. No commit/push/publication included.

'''
text=text.replace('# Handoff — @barocss/doc-sync\n\n','# Handoff — @barocss/doc-sync\n\n'+intro,1)
section=(t/'handoff-section.md').read_text().rstrip()+'\n';needle='[Source-bound field-reference report]';section=section.replace(needle,paragraph+'\n'+needle,1);text=text.rstrip()+'\n\n'+section;p.write_text(text)
print(json.dumps({'status':'PASS','stages':23,'core':171,'sdk':109,'workspace':checks['workspace']['pass'],'gzip':76,'originalTraceHashes':32}))
