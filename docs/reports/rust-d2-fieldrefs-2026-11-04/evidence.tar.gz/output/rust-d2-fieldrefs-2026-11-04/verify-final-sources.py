from pathlib import Path
import hashlib,json,re,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-fieldrefs-2026-11-04';reg=t/'compare-regressions/run-2026-11-04T07-07-06.074Z-60037'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
s=read(reg/'receipt.json');assert s['status']=='PASS' and len(s['results'])==23
main=read(reg/'fieldrefs/run-2026-11-04T07-07-24.251Z-60989/receipt.json');counts={}
maps={'core':read(t/'core/source-current-01.json'),'sdk':read(t/'sdk/source-hashes.json'),'wrapper':s['frozenHashes'],'main':main['sourceHashes'],'inheritedRuntime':s['positiveHashesUnchanged'],'inheritedTsIntegration':read(t/'inherited-ts-integration-source.json')['files'],'nextD2Evidence':read(t/'core/next-d2-sha256.json')}
for label,files in maps.items():
 bad=[n for n,h in files.items() if sha(r/n)!=h];assert not bad,(label,bad);counts[label]=len(files)
code=(r/'experiments/rust-sdk/examples/runtime_field_refs.rs').read_text();comment,body=code.split('\n',1);assert comment.startswith('//! ')
for n in ['apps/docs/src/guide/rust.md','experiments/rust-sdk/README.md']:
 text=(r/n).read_text().split('<!-- runtime-field-refs-rust-example -->',1)[1];fence=re.search(r'```rust\n(.*?)```',text,re.S).group(1);assert fence==body,n
for n in ['sdk/consumer-readme/src/main.rs','sdk/consumer-guide/src/main.rs']:assert (t/n).read_text()==body,n
for old in read(t/'earlier-seals.json'):
 p=r/old['report'];assert sha(p/'seal.json')==old['sealSha256']
 for n,h in read(p/'seal.json')['files'].items():assert sha(p/n)==h,(p,n)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head==read(t/'baseline.json')['head']
d={'status':'PASS','sourceMaps':counts,'documentationProgramSha256':hashlib.sha256(body.encode()).hexdigest(),'exampleDifference':'One module documentation comment precedes the exact fenced/compiled body.','priorReportSeals':8,'head':head,'publication':'NOT_REQUESTED'}
(t/'final-source-verification.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
