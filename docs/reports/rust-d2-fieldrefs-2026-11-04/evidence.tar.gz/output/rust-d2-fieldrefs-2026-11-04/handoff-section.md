### 5.149 D2 references from declared field leaves

Three agents implemented the native core, SDK/docs and independent TS/native
comparison. The baseline is main `1cfb7a2` plus 131 captured source files from
inherited uncommitted work. All eight earlier report seals are preserved.
Production TypeScript CRDT code and 14 inherited integration repairs are unchanged.

The v3 schema descriptor can select composite defaults and enum entries from a
writable field leaf. Its `at` path follows explicit `fields` edges; `valuePath`
selects inside that leaf payload. The operation binding path remains separate.
Whole branches, computed fields, unsafe or missing paths, invalid key/index types
and excessive depth reject. Existing bare/v1/v2 selectors do not acquire this
feature. A pinned before/after CLI witness verifies a previously supported v3
schema's identity, DTO and own checkpoint replay remain identical.

The SDK adds `field_default_value`, `field_enum_value` and
`set_runtime_field_path`. The last method validates provenance against the active
schema before copying plain JSON into an independent field register. Field enum
admission retains TypeScript structural equality. An equal JSON copy can pass;
it does not create a symbolic link. Atomic attribute/mark targets retain their
existing reference-group admission and source metadata. Foreign handles and
same-manifest changed-group handles reject before clock, History or pending
changes mutate. Field paths have a 64-segment ceiling, subject also to the
existing whole-schema JSON depth ceiling of 128.

Native core: 171 PASS. SDK: 109 PASS in one final full run. Both documentation
examples compile and run in independent Cargo consumers, with fenced programs
byte-identical to the runnable example body. New TS/native authoring: two schemas,
352 commands, 704 actor states and 184 actual staged Doc.edit checks. Exact
operation tickets, source/target paths, material state, full History, pending,
carets, undo/redo and own JSON checkpoint restore match. New scope checks cover
28 cases; 32 actual TypeScript/DocHub rows distinguish structural field admission
from atomic enum identity and clone rejection. Other leaf and same-value foreign
writers survive local undo/redo.

The initial comparison used a branch-patch API against a direct leaf API and
observed different ticket allocation. The final harness uses matching direct
leaf APIs without normalizing tickets; existing branch/compiler clock behavior
is unchanged. Initial fixture/source-drift failures and the first mismatch remain
diagnostics. A large trace took about four minutes with an RSS sample of about
1.82GiB. Source inspection finds inherited schema compilation/journal replay in
per-edit staging and full trace retention. This is not a controlled performance
benchmark or production latency qualification.

The next product-schema gates are the existing optional URL and cell hex-color
patterns, then `image-block.text: false`, then valid unused declarations.
A separate source-bound read-only probe confirms all three original product
fixtures pass TS schema validation and fail native compilation first at the URL
pattern. Transformed diagnostic variants are not full product editing evidence.
TypeScript itself rejects markValues.fields, so that is an invalid-schema
boundary rather than a native feature backlog item.

Whole branch sources, mutable object links, full D2/D3 compiler coverage,
production Rust/WASM Client and editor binding, native Map/List, protected GC,
a TS/native object codec and native production crash recovery remain separate.
Native own checkpoint replay is not server/process durability qualification.
No Chrome, mobile or performance benchmark was run. No commit, push, deployment
or registry publication is included.

[Source-bound field-reference report](docs/reports/rust-d2-fieldrefs-2026-11-04/README.md).
