// Read-only product admission diagnostics. Transformed variants are not product parity proof.
import {PRODUCT_SCHEMAS} from '../../../fixtures/product-schemas.ts';
import {checkSchema} from '../../../packages/doc-sync/dist/crdt/schema.js';
import {schemaVersion} from '../../../packages/doc-sync/dist/crdt/schema-version.js';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
const root=new URL('../../../',import.meta.url),out=new URL('./',import.meta.url);
const binary='output/rust-d2-fieldrefs-2026-11-04/core/current-cli-01';
const paths=['fixtures/product-schemas.ts','packages/doc-sync/src/crdt/schema.ts','packages/doc-sync/src/crdt/fields.ts','packages/doc-sync/dist/crdt/schema.js','packages/doc-sync/dist/crdt/schema-version.js','experiments/rust-shadow/src/runtime_schema.rs',binary];
const hashes=()=>Object.fromEntries(paths.map(p=>[p,createHash('sha256').update(readFileSync(new URL(p,root))).digest('hex')]));
const before=hashes(),results=[];
for(const[name,schema]of Object.entries(PRODUCT_SCHEMAS)){
 const patterns=structuredClone(schema);delete patterns.markValues.link.pattern;delete patterns.nodes.cell.attrs.backgroundColor.pattern;
 const textFalse=structuredClone(patterns);delete textFalse.nodes['image-block'].text;
 for(const[variant,m]of [['original',schema],['diagnostic-remove-two-patterns',patterns],['diagnostic-remove-patterns-and-text-false',textFalse]]){
  const request={cmd:'new',replica:'a',actor:'A',schema:schemaVersion(m),runtimeSchema:m};
  const input=JSON.stringify(request)+'\n';
  const result=spawnSync(new URL(binary,root).pathname,[],{input,encoding:'utf8'});
  const stem=`next-d2-${name}-${variant}`;
  writeFileSync(new URL(stem+'-request.jsonl',out),input);writeFileSync(new URL(stem+'-response.jsonl',out),result.stdout);writeFileSync(new URL(stem+'-stderr.log',out),result.stderr);
  const response=JSON.parse(result.stdout);
  results.push({name,variant,typescriptProblems:checkSchema(m),nativeExit:result.status,native:response.ok?'COMPILE_PASS':response.error,inputFile:stem+'-request.jsonl',responseFile:stem+'-response.jsonl',inputSha256:createHash('sha256').update(input).digest('hex'),responseSha256:createHash('sha256').update(result.stdout).digest('hex')});
 }
}
const invalid=structuredClone(PRODUCT_SCHEMAS.notion);invalid.markValues.link={default:{label:''},fields:{label:{default:''}}};
const invalidProblems=checkSchema(invalid);writeFileSync(new URL('next-d2-mark-fields-invalid-input.json',out),JSON.stringify(invalid,null,2)+'\n');
const after=hashes();if(JSON.stringify(before)!==JSON.stringify(after))throw new Error('probe inputs changed');
const report={status:'PASS',command:'node output/rust-d2-fieldrefs-2026-11-04/core/next-d2-probe.mjs',binary,sourcesBefore:before,sourcesAfter:after,results,invalidSchemaDiagnostic:{variant:'diagnostic-markValues-fields',typescriptProblems:invalidProblems,expectedInvalid:true},nextPriority:['Qualify only existing public link and optional hex patterns against JavaScript RegExp','Qualify text:false image-block behavior','Assess TS-valid unused node declarations rejected by native reachability'],proofBoundary:'Read-only compilation admission probes using frozen core executable. Transformed schemas are diagnostic variants only. No product behavior, collaboration, undo, browser, performance, or full-profile support claim. No source edits or builds.'};
writeFileSync(new URL('next-d2-results.json',out),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,results:results.map(({name,variant,native,typescriptProblems})=>({name,variant,native,typescriptProblems})),invalidProblems}));
