from pathlib import Path
import json,hashlib,subprocess,shutil
root=Path('/Users/user/github/doc-sync');out=root/'output/rust-d2-fieldrefs-2026-11-04/core';old=root/'output/rust-d2-payload-2026-11-04/core/current-cli-02'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def save(name,v):(out/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert sha(old)=='35a3566428e6fdc8eb0c2500a31ef0879f6648f96ca0138d3aaf8f771b1f9ae7'
baseline=json.loads((out.parent/'baseline.json').read_text());prior=json.loads((root/'output/rust-d2-payload-2026-11-04/core/source-current-02.json').read_text());assert all(baseline['files'][k]==v for k,v in prior.items())
new=out/'current-cli-01';shutil.copy2(out.parent/'native-target/debug/doc-sync-rust-shadow',new)
manifest={'root':'doc','marks':[],'markValues':{'source':{'default':{'x':1}}},'nodes':{'doc':{'shape':'flow','children':['p'],'default':'p'},'p':{'shape':'text','attrs':{'data':{'default':{'leaf':{'box':{'x':1}}},'fields':{'leaf':{'default':{'box':{'x':1}},'values':[{'box':{'x':1}}]}}},'target':{'default':None,'values':[{'x':1}]}}}}}
leaf={'at':['nodes','p','attrs','data','fields','leaf'],'source':'default','valuePath':['box']};mark={'at':['markValues','source'],'source':'default'};target={'at':['nodes','p','attrs','target'],'source':'enum','index':0}
def dto(a):return {'format':'doc-sync-runtime-schema-payload-v3','manifest':manifest,'referenceGroups':[{'representative':target,'slots':sorted([a,target],key=canon)}]}
def run(binary,requests):
 wire=''.join(json.dumps(r,separators=(',',':'))+'\n' for r in requests);result=subprocess.run([str(binary)],input=wire,text=True,capture_output=True,timeout=30);assert result.returncode==0;return wire,[json.loads(x) for x in result.stdout.splitlines()]
runs={}
for case,source in [('new-leaf',leaf),('old-v3-fields',mark)]:
 descriptor=dto(source);identity='sha256:'+hashlib.sha256(canon(descriptor).encode()).hexdigest();ref={'schema':identity,**source,'path':['value']};op={'t':'reference','format':'doc-sync-runtime-reference-op-v1','op':{'t':'set','at':{'lamport':1,'actor':'A'},'ids':[{'lamport':0,'actor':'~root'}],'key':'target','value':{'x':1}},'references':[ref]}
 requests=[{'cmd':'new','actor':'A','runtimeSchema':descriptor},{'cmd':'apply','ops':[op]},{'cmd':'snapshot'}];requests=[dict(r,replica='a',schema=identity) for r in requests]
 outcomes={}
 for name,binary in [('before',old),('after',new)]:
  wire,responses=run(binary,requests);(out/f'{case}-{name}-requests.jsonl').write_text(wire)
  if responses[0]['ok']:
   restore=dict(cmd='restore',replica='b',actor='B',schema=identity,snapshot=responses[2]['snapshot']);wire,responses=run(binary,requests+[restore,dict(cmd='snapshot',replica='b')]);(out/f'{case}-{name}-requests.jsonl').write_text(wire)
  save(f'{case}-{name}-responses.json',responses);outcomes[name]=responses
 if case=='new-leaf':
  assert outcomes['before'][0]['ok']==False and outcomes['after'][0]['ok']==True
  assert all(r['ok'] for r in outcomes['after'])
 else:
  assert outcomes['before']==outcomes['after'];assert all(r['ok'] for r in outcomes['after']);assert outcomes['after'][2]['snapshot']==outcomes['after'][4]['snapshot']
 runs[case]={'schema':identity,'beforeOk':[r['ok'] for r in outcomes['before']],'afterOk':[r['ok'] for r in outcomes['after']],'beforeFirst':outcomes['before'][0]}
source={str(p.relative_to(root)):sha(p) for p in sorted((root/'experiments/rust-shadow').rglob('*')) if p.is_file() and (p.suffix=='.rs' and any(a in ['src','tests'] for a in p.parts) or p.name in ['Cargo.toml','Cargo.lock']) and 'target' not in p.parts}
save('source-current-01.json',source);save('witness-01.json',{'status':'PASS','oldSourceFilesMatched':len(prior),'beforeBinarySha256':sha(old),'afterBinarySha256':sha(new),'cases':runs,'sourceFiles':len(source)})
print(json.dumps({'status':'PASS','cases':runs},ensure_ascii=False))
