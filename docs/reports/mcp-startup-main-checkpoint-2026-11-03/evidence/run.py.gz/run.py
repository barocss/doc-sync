from pathlib import Path
import os,sys,json,subprocess,time,signal
root=Path('/Users/user/github/doc-sync');out=root/'output/mcp-startup-push-proof';stage=sys.argv[1]
commands={'full':['npm','test'],'types':['npx','tsc','--noEmit'],'docs-build':['npm','run','build','--workspace','@doc-sync/docs'],'docs-check':['npm','run','docs:check']}
cmd=commands[stage];env=dict(os.environ);env['PATH']='/Users/user/.nvm/versions/node/v24.22.1/bin:'+env.get('PATH','')
start=time.monotonic();expired=False;limit=360 if stage=='full' else 120
with (out/(stage+'.log')).open('wb') as log:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=limit)
 except subprocess.TimeoutExpired:
  expired=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
d={'stage':stage,'command':cmd,'pid':p.pid,'group':p.pid,'exit':code,'watchdogSeconds':limit,'watchdogTriggered':expired,'seconds':round(time.monotonic()-start,3),'status':'PASS' if code==0 and not expired else 'FAIL'}
(out/(stage+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(0 if d['status']=='PASS' else 1)
