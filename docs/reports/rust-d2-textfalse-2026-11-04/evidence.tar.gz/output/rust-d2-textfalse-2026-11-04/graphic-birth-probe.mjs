import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {Doc} from '../../packages/doc-sync/dist/crdt/doc.js';
const schema={domain:'graphic',root:'canvas',marks:[],nodes:{canvas:{shape:'container',children:['off','on']},off:{shape:'text',text:false},on:{shape:'text'}}};
const ticket=(lamport,actor='A')=>({lamport,actor});
const cases=[];
for(const [born,current,want] of [['off','off',false],['off','on',false],['on','on',true],['on','off',true]]){
 const d=new Doc('A',schema), seed={t:'node',id:ticket(1),origin:ticket(0,'~root'),type:born,boundary:'',attrs:{}};
 assert.equal(d.check([seed]),null);d.apply(seed);
 const typeOp={t:'set',at:ticket(2),ids:[ticket(1)],key:'$type',value:current};
 const typeCheck=d.check([typeOp]);assert.equal(typeCheck,null);d.apply(typeOp);
 const text={t:'text',id:ticket(3),origin:ticket(1),text:'x',marks:{}};
 const check=d.check([text]);assert.equal(check===null,want);
 if(check===null)d.apply(text);
 const continuation={t:'text',id:ticket(4),origin:ticket(3),text:'y',marks:{}};
 const continuationCheck=check===null?d.check([continuation]):null;
 if(check===null){assert.equal(continuationCheck,null);d.apply(continuation);}
 cases.push({born,current,want,typeCheck,textCheck:check,continuationCheck,lines:d.lines().map(l=>({key:l.key,slot:l.slot,items:l.items.map(i=>({key:i.key,born:i.born,kind:i.kind,origin:i.origin}))})),model:d.toJSON()});
}
const authored=new Doc('A',schema);const ops=authored.edit([{op:'insert',at:[0],content:[{type:'on',runs:[{text:'z',marks:{}}]}]}]).ops;
const receipt={status:'PASS',scope:'Real TS container text marker and char origins; immutable born spec across current $type; source-aligned raw admission only, no wire parity claim',cases,productAuthoring:{ops,lines:authored.lines().map(l=>({key:l.key,slot:l.slot})),model:authored.toJSON()}};
writeFileSync(new URL('./graphic-birth-probe.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({status:receipt.status,cases:cases.length,authoringOps:ops.length}));
