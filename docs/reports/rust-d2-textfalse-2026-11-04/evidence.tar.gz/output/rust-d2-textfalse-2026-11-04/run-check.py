from pathlib import Path
import os,sys,subprocess,json,time,signal
root=Path('/Users/user/github/doc-sync');out=root/'output/rust-d2-textfalse-2026-11-04';name=sys.argv[1];cmd=sys.argv[2:]
assert not (out/(name+'.json')).exists(), 'Use a new evidence name'
env=dict(os.environ);env.update({'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(out/'native-target')});env['PATH']='/Users/user/.nvm/versions/node/v24.22.1/bin:'+env.get('PATH','');start=time.monotonic();timeout=False;limit=240
with (out/(name+'.log')).open('xb') as log:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=limit)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
d={'command':cmd,'pid':p.pid,'group':p.pid,'exit':code,'externalWatchdogSeconds':limit,'watchdogTriggered':timeout,'seconds':round(time.monotonic()-start,3),'status':'PASS' if code==0 and not timeout else 'FAIL'};(out/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(0 if d['status']=='PASS' else 1)
