from pathlib import Path
import json,hashlib,gzip,re,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-textfalse-2026-11-04'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
s=read(t/'compare-final-summary-v2.json');receipts={n:read(Path(s[n]['receipt'])) for n in ['new','oracle','product','inherited']}
for n,d in receipts.items():assert d['status']=='PASS' and sha(Path(s[n]['receipt']))==s[n]['receiptSha256']
maps={'main':receipts['new']['sourceHashes'],'oracle':receipts['oracle']['hashesBefore'],'product':receipts['product']['hashesBefore'],'inheritedPatterns':receipts['inherited']['sourceHashes'],'summary':s['sourceBinaryHashes'],'sdkAfterRestore':read(t/'sdk-after-format-restore/source-hashes-after.json'),'inheritedTsIntegration':read(t/'inherited-ts-integration-source.json')['files']};counts={}
assert read(t/'sdk-after-format-restore/source-hashes-before.json')==maps['sdkAfterRestore']
for label,files in maps.items():
 bad=[n for n,h in files.items() if sha(Path(n) if Path(n).is_absolute() else r/n)!=h];assert not bad,(label,bad);counts[label]=len(files)
for n in ['oracle','product']:assert receipts[n]['hashesBefore']==receipts[n]['hashesAfter']
for n in ['new','inherited']:assert all(a['status']=='PASS' and a['hashesBefore']==a['hashesAfter'] for a in receipts[n]['attempts'])
base=read(t/'baseline.json');allowed={'HANDOFF.md','README.md','docs/rust-roadmap.md','apps/docs/src/roadmap.md','apps/docs/src/guide/rust.md','apps/docs/src/guide/document-rules.md','apps/docs/src/schemas/custom.md','apps/docs/src/schemas/document.md','experiments/rust-sdk/README.md',*[f'experiments/rust-shadow/src/{n}' for n in ['runtime_schema.rs','nested.rs','graphic.rs','lib.rs']]};changed=[n for n,h in base['files'].items() if sha(r/n)!=h];assert set(changed)<=allowed,changed
for row in read(t/'format-recovery/receipt.json')['files']:assert sha(r/row['path'])==row['baselineSha256']
for old in read(t/'earlier-seals.json'):
 p=r/old['report'];assert sha(p/'seal.json')==old['sealSha256']
 for n,h in read(p/'seal.json')['files'].items():assert sha(p/n)==h
previous=read(r/'output/rust-d2-fieldrefs-2026-11-04/compare-regressions/run-2026-11-04T07-07-06.074Z-60037/receipt.json')
oldbins={n:h for n,h in previous['frozenHashes'].items() if n.startswith('output/')}
for n,h in oldbins.items():assert sha(r/n)==h,n
body=(r/'experiments/rust-sdk/examples/runtime_textfalse.rs').read_text()
for n in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
 text=(r/n).read_text().split('<!-- runtime-textfalse-rust-example -->',1)[1];assert re.search(r'```rust\n(.*?)```',text,re.S).group(1)==body,n
for n in ['sdk/readme-consumer/src/main.rs','sdk/guide-consumer/src/main.rs']:assert (t/n).read_text()==body,n
compression=[]
for row in read(t/'compare-compression.json'):
 p=t/row['compressed'];h=hashlib.sha256();size=0
 with gzip.open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 assert h.hexdigest()==row['sha256'] and size==row['bytes'];compression.append({**row,'compressedSha256':sha(p)})
(t/'compression-current.json').write_text(json.dumps({'status':'PASS','files':compression},indent=2)+'\n')
for n,total in [('core-tests-full.log',183),('sdk-after-format-restore/full-sdk-tests.log',116)]:
 nums=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',(t/n).read_text());assert sum(int(x) for x,y in nums)==total and all(y=='0' for x,y in nums),(n,nums)
trace=json.load(gzip.open(Path(s['new']['receipt']).parent/'typescript-trace.json.gz','rt'));rows=[x for d in trace['documents'] for x in d['trace']];assert len(rows)==90 and all('A' in x and 'B' in x for x in rows)
raw=sum(bool(x['editAdmission'] and x['editAdmission'].get('route','').startswith('Doc.emit')) for x in rows);actual=sum(x['editAdmission'] is not None for x in rows)-raw;assert (actual,raw)==(38,4)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head==base['head']
d={'status':'PASS','sourceMaps':counts,'baselineChangesWithinOwnedScope':changed,'oldReportSeals':10,'oldTargetBinariesUnchanged':len(oldbins),'restoredSdkFiles':6,'documentedBodySha256':hashlib.sha256(body.encode()).hexdigest(),'exampleDifference':'None; fenced code and both compiled consumers equal the entire runnable source','mainRows':90,'actorStates':180,'actualDocEdits':38,'rawWireAuthorings':4,'compressionRoundTrips':len(compression),'originalCompressedBytes':sum(x['bytes'] for x in compression),'graphicProbeSha256':sha(t/'graphic-birth-probe.json'),'head':head}
(t/'final-source-verification.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
