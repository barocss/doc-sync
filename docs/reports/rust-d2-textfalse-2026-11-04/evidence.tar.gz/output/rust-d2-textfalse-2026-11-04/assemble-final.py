from pathlib import Path
import json,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-textfalse-2026-11-04';report=r/'docs/reports/rust-d2-textfalse-2026-11-04'
def read(p):return json.loads(p.read_text())
s=read(t/'compare-final-summary-v2.json');cases={n:{'status':s[n]['status'],'receipt':str(Path(s[n]['receipt']).relative_to(t))} for n in ['new','oracle','product','inherited']}
summary={'status':'PASS','scope':'Document text:false admission, exact two-actor operations/History/checkpoint comparison; graphic policy separately bounded','main':cases['new'],'cases':cases,'sdk':'sdk-after-format-restore/sdk-receipt.json','coreLog':'core-tests-full.log','comparison':'compare-final-summary-v2.json','compression':'compression-current.json'}
(t/'final-comparison-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paragraph='''Final verification: native core **183 PASS**, restored-source SDK **116 PASS**.
The final Document comparison passes **two schemas / 90 actions / 180 actor
states**, including **38 actual staged Doc.edit authorings** and **four raw
Doc.emit authorings**. Raw routes are labeled separately. Exact operations,
tickets, full History, material state, pending/carets, selection, own JSON
checkpoint restore and retry match. The focused oracle covers 24 raw admission
cases, five TS logical observations and six malformed-flag boundaries. Actual
TS Graphic origin/birth observations cover four cases separately from native
focused tests; graphic state/type-change parity is unqualified.

The complete inherited patterns corpus is freshly rerun: **two schemas /
84 actions PASS**. This does not rerun the historical 23-driver suite. Final
source/binary maps match main143, oracle4, product7 and inherited143 entries;
restored SDK source/docs52 and TS/integration31 maps also match. Ten prior report
seals and 14 prior target binaries remain unchanged. All 20 compressed trace
artifacts restore 172,473,757 original bytes with matching SHA256 checks.

Whole npm: **2,114 tests / 2,112 PASS / two expected platform SKIPs / zero FAIL /
zero cancelled**, 123.277 seconds. Typecheck and docs build pass. Documentation
checks pass **55 pages / 2,640 internal links**, with English content and local
paths excluded. Both fenced Rust programs and both compiled consumers are
byte-identical to the entire runnable example source.
'''
p=report/'README.md';text=p.read_text();assert paragraph not in text;text=text.replace('## Remaining boundaries\n',paragraph+'\n## Remaining boundaries\n',1);p.write_text(text)
section='''### 5.151 D2 text-disabled blocks

Three agents implemented the core, SDK tests/docs and independent comparison.
Baseline: main `1cfb7a2` plus 153 captured inherited files. Native production
changes are limited to runtime_schema.rs, lib.rs, nested.rs and graphic.rs.
SDK production source, TypeScript rules and inherited fixtures are unchanged.

The compiler accepts boolean text flags. Text-disabled nodes retain the text
shape, defaults, inline children, selection offsets and stored projection.
Raw flow admission scans all stored text types, including group members. A
false-only flow rejects characters; a mixed flow may accept characters after
a disabled marker. Characters remain stored and visible through type changes.
Container birth policy uses immutable owner birth type. TS actual origins differ
from native graphic dedicated text lines; only their admission policy is
observed, not exact graphic state or graphic type-change parity. Malformed
untyped flag values stay a stricter native validation boundary.

'''+paragraph+'''
The first main comparison exposed an inherited logical compiler difference:
Doc.edit omits same-current-$type updates while the native explicit setter
emits Set. The initial FAIL is retained. Separate explicit raw same-value A/B
writers and selective undo pass. This does not close the D3 compiler difference.
Earlier metadata counted raw emits as Doc.edit; final metadata counts38/4
separately and narrows the main scope to Document. Earlier receipts remain.

An unintended cargo fmt command changed six pre-existing SDK files. Archived
formatted copies and canonical-rustfmt equality prove formatting only. Those
six files were restored to the exact opening baseline, preserving inherited
WIP. New textfalse tests/examples/docs were untouched. Full SDK116, example and
both independent consumers were rerun after restoration. Failed fixtures and
the initial formatting command/error are documented; no semantic SDK fix was
introduced. A root verifier also corrected its optional-comment assumption;
this example has no module header and matches fences as a complete source file.

Original Demo and Notion schemas now compile. Word remains blocked at unused
divider; presentation at unused heading1. The 16 product probes separate
original admission from pruned diagnostic variants. Full-profile authoring is
unqualified. The next D2 gate is valid unused node declarations.

A fresh compact target uses dev/test debug info0 and incremental0 because free
disk started at1.4GiB. Optimization and overflow settings retain dev defaults.
Old targets/binaries are preserved; no performance result is inferred. Full
D2/D3, native graphic type changes, production Rust/WASM Client/editor delivery,
native Map/List, protected GC and production native process/server recovery
remain separate. Own checkpoint replay is not cross-runtime wire/durability
qualification. No Chrome, mobile or performance benchmark was run. No commit,
push, deployment or registry publication is included.

[Source-bound text-disabled block report](docs/reports/rust-d2-textfalse-2026-11-04/README.md).
'''
(t/'handoff-section.md').write_text(section)
p=r/'HANDOFF.md';text=p.read_text();assert '### 5.151 D2 text-disabled blocks' not in text
intro='''Latest **§5.151** supports boolean text-disabled block flags with existing
flow/birth admission and retained projection. Core183/SDK116 PASS; two-schema
TS/native90 actions/180 states, inherited patterns84 actions PASS. Whole npm
2,112 PASS/two expected SKIPs/zero failures; docs55 pages/2,640 links PASS.
Demo/Notion compile; Word/presentation unused declarations remain next. Full
product editing and production Rust/WASM delivery remain open. See
`docs/reports/rust-d2-textfalse-2026-11-04/`. No commit/push/publication included.

'''
text=text.replace('# Handoff — @barocss/doc-sync\n\n','# Handoff — @barocss/doc-sync\n\n'+intro,1);p.write_text(text.rstrip()+'\n\n'+section)
subprocess.run(['python3',str(t/'verify-final.py')],cwd=r,check=True)
checks={'status':'PASS','nativeCore':{'passed':183,'log':'core-tests-full.log'},'nativeSdk':{'passed':116,'receipt':'sdk-after-format-restore/sdk-receipt.json'},'comparison':s,'main':{'schemas':2,'actions':90,'actorStates':180,'actualDocEdits':38,'rawWireAuthorings':4},'oracle':{'rawAdmissionCases':24,'tsLogicalObservations':5,'malformedFlagBoundaries':6},'graphic':{'tsPolicyObservations':4,'native':'focused tests only','stateParity':'NOT_QUALIFIED'},'productCompileProbes':16,'workspace':{**read(t/'workspace-test-01.json'),**read(t/'workspace-test-totals.json')},'typecheck':read(t/'typecheck-01.json'),'documentation':{'build':read(t/'docs-build-01.json'),'check':read(t/'docs-check-01.json'),'pages':55,'internalLinks':2640,'english':True,'localPathsExcluded':True},'sourceVerification':read(t/'final-source-verification.json'),'legacyFull23Drivers':'NOT_RERUN_THIS_TASK','chrome':'NOT_RUN','mobile':'NOT_RUN','performance':'NOT_RUN','publication':'NOT_REQUESTED'}
(report/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n');print('Final metadata assembled')
