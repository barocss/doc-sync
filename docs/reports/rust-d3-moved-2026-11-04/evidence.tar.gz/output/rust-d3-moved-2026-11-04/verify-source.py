from pathlib import Path
import json,hashlib,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d3-moved-2026-11-04'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
b=json.loads((t/'baseline.json').read_text());changed=[];unchanged=[]
allowed={'HANDOFF.md','README.md','docs/rust-roadmap.md','experiments/rust-sdk/README.md','experiments/rust-sdk/src/runtime_paragraph.rs','experiments/rust-sdk/tests/runtime_paragraph.rs','experiments/rust-shadow/src/lib.rs','experiments/rust-shadow/src/nested.rs','packages/doc-sync/src/crdt/doc.ts','packages/doc-sync/src/crdt/edit.ts','packages/doc-sync/dist/crdt/doc.d.ts','packages/doc-sync/dist/crdt/doc.js','packages/doc-sync/dist/crdt/edit.js',*[f'apps/docs/src/{p}.md' for p in ['guide/rust','guide/document-rules','guide/editing','guide/blocks','schemas/document','schemas/custom','roadmap']]}
for p,h in b['files'].items():
 current=sha(r/p)
 if current!=h:
  assert p in allowed,p;changed.append({'path':p,'before':h,'after':current})
 else:unchanged.append(p)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head==b['head']
for row in json.loads((t/'earlier-seals.json').read_text()):
 p=r/row['report'];assert sha(p/'seal.json')==row['sealSha256']
 for n,h in json.loads((p/'seal.json').read_text())['files'].items():assert sha(p/n)==h,(p,n)
pins=json.loads((t/'before-pins.json').read_text());assert sha(r/pins['binary'])==pins['sha256']
review=json.loads((t/'design-review/moved-boundary-fence-source-review.json').read_text());assert review['decision']=='APPROVE_SOURCE_ONLY'
for p,h in review['sourceHashesAfter'].items():
 if '/test/' not in p:assert sha(r/p)==h,p
compat=json.loads((t/'ts-fix/source-freeze-v5.json').read_text());assert compat['status']=='SOURCE_FROZEN_V5_HIGH_APPROVED'
for p,h in compat['files'].items():assert sha(r/p)==h,p
program=(r/'experiments/rust-sdk/examples/runtime_moved.rs').read_text()
for p in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:assert '```rust\n'+program.rstrip()+'\n```' in (r/p).read_text(),p
for n in ['readme','guide']:assert (t/f'consumer-{n}/src/main.rs').read_text()==program
result={'status':'PASS','head':head,'baselineFiles':len(b['files']),'unchangedBaselineFiles':len(unchanged),'changedAllowed':changed,'priorSealedReportsUnchanged':13,'beforeNativeBinaryUnchanged':True,'reviewedTsSourcesCurrent':True,'exactFullMovedExampleFencesAndConsumers':True,'unchangedPaths':unchanged}
(t/'source-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in {'unchangedPaths','changedAllowed'}}))
