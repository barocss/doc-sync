from pathlib import Path
r=Path('/Users/user/github/doc-sync')
program=(r/'experiments/rust-sdk/examples/runtime_moved.rs').read_text().rstrip()
section='''### Insert at current model positions after moves

Use `insert_paragraph_at` or `insert_model_at` after a block has moved. Pass its
current model child path. The compiler resolves the current accepted placement,
including moves that were undone or suppressed by cycle rules. Block IDs remain
stable; a physical source token and a current model child index are different
addresses. The existing physical `after`/`right` APIs keep their contract.

A text node or a supported recursive flow/text model is inserted as one History
transaction. The compiler prepares only the needed target and ancestor flows.
If the canonical model needs an empty leading default, it creates a fresh default
identity before inserting. It does not move or overwrite an existing sibling to
repair the index. Stored text and foreign placement writers remain retained even
when child maximum rules hide them from the model.

The program below receives Bob's movement before Alice inserts. It then checks
foreign text and field edits, selection, undo, redo, own JSON checkpoint restore,
exact pending retries and acknowledgement. A pending insertion also remains
valid if its predecessor is concurrently moved or deleted before receipt.
These are native SDK checks; they do not connect a network transport or editor.

The bounded input remains text or flow/text trees. Grid/group construction,
text-offset paths, mixed structured attribute maps, trailing reserved-only
transactions and schema reference handles in model JSON remain unsupported.
Invalid native inputs reject before changing the original checkpoint. TypeScript
can normalize malformed model attributes that the native API rejects; this is
not a claim of identical malformed-input admission. A checkpoint restores the
same runtime, schema and actor; it is not a cross-runtime checkpoint format.

Run `cargo run --offline --locked --manifest-path experiments/rust-sdk/Cargo.toml
--example runtime_moved` from the repository root. The complete program is:

```rust
'''+program+'\n```\n'
for name in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
 p=r/name;s=p.read_text();s=s.replace('paths, documents with movement operations, and a supplied attribute map that','paths and a supplied attribute map that')
 s=s.replace('It\ndoes not close this D3 compiler\ngap.', 'The physical helper retains that source-token contract.')
 s=s.replace('It does not close this D3 compiler\ngap. A full `EditOp` compiler', 'Use the model-path API below for bounded insertion after moves. A full `EditOp` compiler')
 s=s.replace('creates future sibling flows before moves and checks the source-anchor contract. It does not close this D3 compiler\ngap.', 'creates future sibling flows before moves and checks the source-anchor contract.\nThe model-path API below now supports bounded insertion after existing moves.')
 assert '### Insert at current model positions after moves' not in s
 p.write_text(s.rstrip()+'\n\n'+section)
for name in ['apps/docs/src/guide/editing.md','apps/docs/src/guide/blocks.md','apps/docs/src/guide/document-rules.md','apps/docs/src/schemas/document.md']:
 p=r/name;s=p.read_text();s+='''

Native model paths can also be used after existing block movement. Resolve the
child index from the current model, while retaining object IDs for identity.
See [insertion after moves](../guide/rust#insert-at-current-model-positions-after-moves)
for the complete two-peer Rust program and the remaining input boundaries.
''';p.write_text(s)
p=r/'docs/rust-roadmap.md';s=p.read_text();s=s.replace('movement records, mixed structured attribute maps and trailing reserved-only','mixed structured attribute maps and trailing reserved-only');s=s.replace('This bounded API rejects unsupported groups/grids, offset paths, pre-existing\nmixed', 'This bounded API rejects unsupported groups/grids, offset paths,\nmixed');s=s.replace('Full post-move/model-position compilation remains separate.','Bounded insertion after existing moves is supported; general model command\ncompilation remains separate.')
needle='Provide the public EditOp/command path in Rust'
addition='''**Moved-document extension:** current model child paths now resolve through
accepted placement winners, including undone movement and suppressed cycles.
Only newly inserted identities receive compiler placement writes. A fresh empty
default preserves canonical leading slots without overwriting an old head.
Source virtual text promotion uses a deterministic candidate order; boundary
anchors retain their meaning across concurrent predecessor relocation/deletion.
Original Word/presentation comparisons check the full independent model-edit
result, exact operations/History and own checkpoint recovery. See the
[moved insertion report](reports/rust-d3-moved-2026-11-04/README.md).

'''
assert needle in s;s=s.replace(needle,addition+needle,1);p.write_text(s)
p=r/'apps/docs/src/roadmap.md';s=p.read_text();s+='''

The native D3 model-path compiler now supports bounded paragraph and recursive
flow/text insertion after existing moves. Word and Presentation checks include
accepted placement winners, canonical leading defaults, foreign writers and own
checkpoint/undo/redo recovery. General D3 command equivalence and production
Rust/WASM Client integration remain open. See the
[Rust SDK example](./guide/rust#insert-at-current-model-positions-after-moves).
''';p.write_text(s)
p=r/'apps/docs/src/schemas/custom.md';s=p.read_text();s=s.replace('bounded model-path paragraph insertion, deterministic', 'bounded model-path paragraph insertion before and after movement, deterministic');p.write_text(s)
p=r/'README.md';s=p.read_text();s+='''

The experimental native Rust SDK supports bounded model-path paragraph and
flow/text insertion after existing moves. It preserves foreign placement writers
and supports selective History and own checkpoint recovery. See the
[complete native example](experiments/rust-sdk/examples/runtime_moved.rs) and
[SDK guide](https://barocss.github.io/doc-sync/guide/rust.html#insert-at-current-model-positions-after-moves).
This does not select a production Rust/WASM backend in `Client`.
''';p.write_text(s)
# Independent consumers use exact complete program bytes.
for label in ['readme','guide']:
 folder=r/f'output/rust-d3-moved-2026-11-04/consumer-{label}';(folder/'src').mkdir(parents=True,exist_ok=True)
 (folder/'src/main.rs').write_text(program+'\n')
 (folder/'Cargo.toml').write_text(f'''[package]\nname="moved-{label}-consumer"\nversion="0.0.0"\nedition="2021"\n\n[dependencies]\ndoc-sync-native-sdk={{path="../../../experiments/rust-sdk"}}\nserde_json="1"\n\n[workspace]\n''')
print('Updated docs and two independent example consumers')
