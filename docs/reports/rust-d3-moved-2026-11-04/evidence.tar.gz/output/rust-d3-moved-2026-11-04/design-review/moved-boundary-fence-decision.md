# Moved paragraph boundary collision

Decision: use the first retained physical text marker after the birth origin as a right fence when the ordinary requested boundary would collide with a source text class now placed at another logical gap. Keep the physical birth origin, new paragraph existence and logical Move. Do not alter source grouping, rewrite existing boundaries, or write existing paragraph placements.

The preserved failure has TWO born at `10@A|end`, later moved before ROOT. Appending after ONE reuses the same physical origin 10@A and requested right end. The new marker becomes primary for that boundary and absorbs TWO's chars. TWO's moved identity then has no separate source block. The failure is source-boundary aliasing, not a losing Move.

Before emitting an ordinary unconstrained text birth:

1. Build the proposed ordinary boundary from physical origin and requested logical right.
2. Find its retained physical source text class. Compare that class primary marker's authoritative placement `(parent, after)` with the requested destination parent and cached predecessor placement stamp. Do not scan the last retained Move, and do not compare aliases as separate text classes.
3. If that exact boundary belongs to a different logical gap, use the first physical text marker after the origin in the retained source line as the right fence. Include dead but retained markers. The collision marker is a known retained reference.
4. Keep the original right when there is no such moved-away collision. Continue the ordinary constrained-child suffix rule where applicable.

For the preserved case the new boundary is `10@A|11@A`. Source grouping keeps TWO separate. Existing known-right parsing accepts this format. The new paragraph is still moved after ONE's placement; the right fence does not relocate TWO.

Repeated recreate/move-away cycles advance the fence to the next physical marker. A parent-plus-predecessor suffix alone would reuse a generation and is not sufficient. A blanket birth-ID suffix would break same-gap concurrent Enter coalescence and is rejected.

Two peers that observe the same logical gap and source fence produce the same boundary. `moved-boundary-fence-pair-results.jsonl` proves this with the exact preserved pre-failure snapshot: concurrent NEW😀 and PEER coalesce into one appended paragraph. The model is `[TWO, ROOT😀, ONE, PEERNEW😀]`; both replicas converge. A undo leaves PEER, and A redo restores both texts. TWO's exact placement remains unchanged at every step. Only newly created IDs are moved. Source hashes are recorded.

This is a manual TS wire diagnostic and a design approval. It is not a production compiler fix, native test result, or the main exact comparison receipt. The implementation owners must test ordinary same-gap Enter, moved identities, retained deletion, aliases, successive generations, and exact undo/redo. No engine source was edited or built by this reviewer.
