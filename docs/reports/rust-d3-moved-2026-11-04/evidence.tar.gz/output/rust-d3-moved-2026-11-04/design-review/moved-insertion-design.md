# Moved model-position insertion design

All diagnostics in this folder run TS source only. No engine source edits or builds were performed by this reviewer.

## Existing movement compiler rules

- Projection is active when any Move remains in the ledger. Undo or cycle suppression does not turn it off.
- Resolve model entries through `entriesOf` / `Doc.blocks`, not physical source lines or the last retained Move.
- At a nonzero gap, use the projected predecessor's last physical token as the Node origin. This token can remain in an old source flow after the block moved.
- Cache the predecessor's `movementTarget` and authoritative `placementOf(...).at` before emitting the birth. Emit the new Node and its full contents, then Move only that new Node to the destination parent after that cached placement stamp.
- For projection index zero, reserve a detached fragment nonce, birth a real Node in it with right `end`, then Move the new Node after null.
- A required predecessor also uses a detached fragment birth, but keeps the requested right marker and anchors the Move after the required owner's authoritative placement stamp.
- Rest children of a newly inserted flow need normal `chainBlocks` Move emission when global projection is already active.
- The compile prepass promotes every physical source virtual paragraph that has chars before resolving paths. The approved narrow `source_projections` bridge is for this prepass only. It must not replace logical projections in the path resolver.

`moved-insertion-probes.jsonl` stores concrete product vectors for a cycle-suppressed anchor, a paragraph moved across flows, and insertion after undo of one's own Move. All three observed TS insertions have empty normalization deltas. In the cycle vector the retained last Move for B is 15@A, but B's winning placement is its 8@A birth. New insertion uses 8@A.

## Canonical leading placeholder bug and correction

`moved-default-slot-results.jsonl` preserves a source TS failure. Move a Presentation slide's original title after notes. Logical `Doc.blocks` is `[notes, oldTitle]`, while the canonical model is `[syntheticTitle, notes]`. Paragraph insertion at canonical child 0 or 1 currently reaches the wrong raw gap. The requested-model oracle fails. Child 2 passes.

Do not move or retype the original title. Do not reorder public raw projections to match a rendered model.

Before resolving a needed flow's local canonical child index, materialize the synthetic leading default as a fresh empty default-text Node in detached fragment storage, then Move only that new identity after null. Use the existing `insertBlocksAt(line, 0, [defaultNode])` projection route. Include these operations and the requested edit in one compiler output and History transaction.

The fresh default must have default attrs and empty runs. Its boundary must include the ordinary constrained-child suffix when applicable. Do this only when the canonical model really has a leading synthetic default: first canonicalized underlying node is absent or nontext, normal flow semantics apply, and default child max is not zero. A grouped first text item already satisfies the condition and must not trigger another head. Prepare only target/traversed flows that need this identity, not every flow in the document.

The path resolver must account for canonical entries while it traverses parent flows. A parent canonical index can refer to notes even when raw pre-preparation index refers to the moved title. Validate the canonical path and child bounds before writing incidental placeholder operations. Prepare the needed flow before ordinary `ref` / `entriesOf` resolution, then resolve again from current state. A compiler-private helper or preparation callback is appropriate; changing public `Doc.blocks` is not needed.

The fresh default wins the existing child maximum before the old title. The old title remains in placement order and source storage, with its original foreign writer and text. Existing `Doc.blocks -> applyChildRules` filters that max-hidden title from its returned logical list. Therefore ordinary `entriesOf` subsequently sees `[newTitle, notes, laterParagraphOrFlow]`, without the hidden old-title index. Native `state.projections` likewise uses `blocks_nested -> apply_child_rules`. Keep resolving paths through those filtered logical entries; `source_projections` remains promotion-only.

`moved-default-materialization-results.jsonl` proves the manual single-batch route for canonical child 0, 1, and 2. All match `applyEdits(originalCanonicalModel, requestedEdit)`, exact undo/redo pass, and the exact B placement writer remains. The file records both post-edit logical blocks and retained placement order to distinguish max filtering from deletion. Source hashes before and after both default-head diagnostics are included.

## Required implementation review

- Use authoritative placement winners for suppressed cycles and ownership restoration after History undo.
- Preserve physical birth origins, requested right boundaries, Ticket spans, and field-reservation order.
- Do not emit same-position writes for existing nodes.
- Confirm new flow child chaining and source-virtual promotion before path resolution.
- Ensure canonical placeholder preparation and requested insertion are one atomic native record, with no live document changes on rejection.
- Keep actual requested-slot checks separate from exact TS/native operation parity. Both must pass.
