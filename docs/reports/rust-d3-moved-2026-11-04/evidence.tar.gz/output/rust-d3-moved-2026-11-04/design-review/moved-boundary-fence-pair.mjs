import {Doc,History} from '../../../packages/doc-sync/src/index.ts';
import {WORD_SCHEMA} from '../../../fixtures/product-schemas.ts';
import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';import {isDeepStrictEqual as equal} from 'node:util';
const paths=['packages/doc-sync/src/crdt/edit.ts','packages/doc-sync/src/crdt/doc.ts'];
const hashes=()=>Object.fromEntries(paths.map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')]));
console.log(JSON.stringify({kind:'source-hashes-before',hashes:hashes()}));
const preserved='output/rust-d3-moved-2026-11-04/compare-diagnostic-current17/run-2026-11-04T10-51-39.465Z-14015/typescript-partial-word-root-3-redone.json';
const data=JSON.parse(readFileSync(preserved)),snapshot=data.trace.at(-1).A.checkpoint.document;
const a=Doc.fromSnapshot('A',snapshot,WORD_SCHEMA),b=Doc.fromSnapshot('B',snapshot,WORD_SCHEMA),history=new History();
const old=a.blocks()[0].marker.id,writer=a.placementOf(old),origin=a.blocks()[2].chars.at(-1);
const fence=origin.line.items.slice(origin.line.items.indexOf(origin)+1).find(item=>item.kind==='node'&&a.specOf(a.typeOf(item))?.shape==='text');
const after=a.placementOf(a.blocks()[2].marker.id).at;
function insert(doc,text){
 const id=doc.clock.next(),ops=[];
 const emit=op=>{doc.apply(op);ops.push(op);};
 emit({t:'node',id,origin:origin.id,type:'paragraph',boundary:`${origin.key}|${fence.key}`});
 emit({t:'text',id:doc.clock.next(),origin:id,text});
 emit({t:'move',at:doc.clock.next(),target:id,parent:doc.items[0].id,after});
 return ops;
}
const own=insert(a,'NEW😀'),foreign=insert(b,'PEER');history.record(own,a,{caretBefore:'',caretAfter:''});
for(const op of foreign)a.apply(op);for(const op of own)b.apply(op);
const texts=doc=>doc.toJSON().children.map(node=>node.runs?.map(run=>run.text).join(''));
console.log(JSON.stringify({kind:'same-gap-pair',preserved,fence:fence.key,own,foreign,converged:equal(a.toJSON(),b.toJSON()),texts:texts(a),paragraphs:a.toJSON().children.length,oldWriterRetained:equal(a.placementOf(old),writer)}));
const undo=history.undo(a).ops;for(const op of undo)b.apply(op);
console.log(JSON.stringify({kind:'own-undo',undo,converged:equal(a.toJSON(),b.toJSON()),texts:texts(a),oldWriterRetained:equal(a.placementOf(old),writer)}));
const redo=history.redo(a).ops;for(const op of redo)b.apply(op);
console.log(JSON.stringify({kind:'own-redo',redo,converged:equal(a.toJSON(),b.toJSON()),texts:texts(a),oldWriterRetained:equal(a.placementOf(old),writer)}));
console.log(JSON.stringify({kind:'source-hashes-after',hashes:hashes()}));
