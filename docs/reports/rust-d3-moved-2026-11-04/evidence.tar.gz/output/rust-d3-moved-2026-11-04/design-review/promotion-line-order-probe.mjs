import {Doc} from '../../../packages/doc-sync/src/index.ts';
import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const paths=['packages/doc-sync/src/crdt/edit.ts','experiments/rust-sdk/src/runtime_paragraph.rs','experiments/rust-shadow/src/nested.rs','experiments/rust-shadow/src/lib.rs'];
const hashes=()=>Object.fromEntries(paths.map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')]));
console.log(JSON.stringify({kind:'source-hashes-before',hashes:hashes()}));
const schema={root:'body',marks:[],nodes:{body:{shape:'flow',children:['p','box'],default:'p'},p:{shape:'text'},box:{shape:'flow',children:['p','divider'],default:'p'},divider:{shape:'atom'}}};
const doc=new Doc('A',schema),emit=op=>doc.emit([op]);
const first=doc.clock.next();emit({t:'node',id:first,origin:doc.items[0].id,type:'box'});
const second=doc.clock.next();emit({t:'node',id:second,origin:first,type:'box'});
for(const box of [second,first]){
 const head=doc.get(`0@${box.lamport}@${box.actor}/body`),atom=doc.clock.next();emit({t:'node',id:atom,origin:head.id,type:'divider'});emit({t:'text',id:doc.clock.next(),origin:atom,text:box===first?'A':'B'});
}
emit({t:'move',at:doc.clock.next(),target:first,parent:doc.items[0].id,after:second});
const snapshot=doc.snapshot(), reordered=structuredClone(snapshot);reordered.lines.sort((a,b)=>a.key==='0@~root'?-1:b.key==='0@~root'?1:a.key.localeCompare(b.key));
const natural=Doc.fromSnapshot('A',snapshot,schema),ordered=Doc.fromSnapshot('A',reordered,schema);
console.log(JSON.stringify({kind:'equivalent-models',naturalLines:snapshot.lines.map(l=>l.key),reorderedLines:reordered.lines.map(l=>l.key),sameModel:JSON.stringify(natural.toJSON())===JSON.stringify(ordered.toJSON())}));
for(const [label,d]of [['lazy-map-order',natural],['eager-creation-order',ordered]]){
 const ops=d.edit([{op:'insert',at:[d.toJSON().children.length],content:[{type:'p',runs:[{text:'NEW',marks:{}}]}]}]).ops;
 console.log(JSON.stringify({kind:'promotion-order',label,promotions:ops.filter(op=>op.t==='node'&&op.boundary?.startsWith('virtual:')),ops}));
}
console.log(JSON.stringify({kind:'source-hashes-after',hashes:hashes()}));
