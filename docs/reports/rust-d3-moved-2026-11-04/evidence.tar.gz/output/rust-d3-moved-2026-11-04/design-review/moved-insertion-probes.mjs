import {Doc,History} from '../../../packages/doc-sync/src/index.ts';
import {PRESENTATION_SCHEMA,WORD_SCHEMA} from '../../../fixtures/product-schemas.ts';
const p=text=>({type:'paragraph',runs:[{text,marks:{}}]});
function insert(doc,path,label){const before=doc.toJSON(), result=doc.edit([{op:'insert',at:path,content:[p('NEW😀')]}],{normalize:true});console.log(JSON.stringify({kind:'insert',label,path,before,ops:result.ops,normalize:result.normalize,after:doc.toJSON()}));}
{
 const d=new Doc('A',PRESENTATION_SCHEMA);d.edit([{op:'insert',at:[1],content:[{type:'slide',children:[{type:'title',runs:[]},{type:'object-group',children:[p('A')]},{type:'object-group',children:[p('B')]}]}]}]);
 const line=d.blocks()[1].body,groups=d.blocks(line).filter(b=>b.type==='object-group'),[a,b]=groups;
 const m1={t:'move',at:d.clock.next(),target:a.marker.id,parent:d.get(b.body).id,after:d.blocks(b.body)[0].marker.id};d.emit([m1]);
 const m2={t:'move',at:d.clock.next(),target:b.marker.id,parent:d.get(a.body).id,after:d.blocks(a.body)[0].marker.id};d.emit([m2]);
 console.log(JSON.stringify({kind:'suppressed-cycle',moves:[m1,m2],aWinner:d.placementOf(a.marker.id),bWinner:d.placementOf(b.marker.id),sourceGroupMarkers:groups.map(b=>b.marker.key),bodyLine:line,before:d.toJSON()}));
 insert(d,[1,2],'after cycle-suppressed B winner uses birth stamp');
}
{
 const d=new Doc('A',WORD_SCHEMA),h=new History();d.edit([{op:'insert',at:[0],content:[p('a'),p('b'),{type:'section',children:[p('inside')]}]}]);
 const move=d.edit([{op:'move',from:[1],at:[2,1]}]).ops;h.record(move,d,{caretBefore:'',caretAfter:''});
 console.log(JSON.stringify({kind:'moved-crossflow',move,before:d.toJSON()}));insert(d,[1,2],'after moved paragraph uses old physical text origin');
}
{
 const d=new Doc('A',WORD_SCHEMA),h=new History();d.edit([{op:'insert',at:[0],content:[p('a'),p('b')]}]);const moves=d.edit([{op:'move',from:[1],at:[0]}]).ops;h.record(moves,d,{caretBefore:'',caretAfter:''});const undo=h.undo(d).ops;
 console.log(JSON.stringify({kind:'own-move-undone',moves,undo,hasMoves:d.hasMoves,before:d.toJSON()}));insert(d,[0],'indexzero after own move undo still fragment+move');
}
