import {Doc,History} from '../../../packages/doc-sync/src/index.ts';
import {WORD_SCHEMA} from '../../../fixtures/product-schemas.ts';
import {isDeepStrictEqual} from 'node:util';import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const paths=['packages/doc-sync/src/crdt/edit.ts','packages/doc-sync/src/crdt/doc.ts','experiments/rust-shadow/src/nested.rs','experiments/rust-shadow/src/lib.rs'];
const hashes=()=>Object.fromEntries(paths.map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')]));
const p=text=>({type:'paragraph',runs:[{text,marks:{}}]});
console.log(JSON.stringify({kind:'source-hashes-before',hashes:hashes()}));
for(const mode of ['relocate','delete']){
 const a=new Doc('A',WORD_SCHEMA);a.edit([{op:'insert',at:[0],content:[p('rootA'),p('moveB'),{type:'section',children:[p('inside')]}]}]);a.edit([{op:'move',from:[1],at:[2,1]}]);
 const b=Doc.fromSnapshot('B',a.snapshot(),WORD_SCHEMA),history=new History(),line=a.blocks()[1].body,target=a.blocks(line)[1].marker.id;
 const before=a.snapshot(),insert=a.edit([{op:'insert',at:[1,2],content:[p('NEW😀')]}]).ops;history.record(insert,a,{caretBefore:'',caretAfter:''});
 const foreign=b.edit(mode==='relocate'?[{op:'move',from:[1,1],at:[2]}]:[{op:'delete',at:[1,1],count:1}]).ops;
 const foreignAdmission=a.check(foreign),staleInsertAdmission=b.check(insert);for(const op of foreign)a.apply(op);for(const op of insert)b.apply(op);
 const mergedA=a.toJSON(),mergedB=b.toJSON(),winner=a.placementOf(target),undo=history.undo(a).ops;for(const op of undo)b.apply(op);
 console.log(JSON.stringify({kind:'arrival-order',mode,before,insert,foreign,foreignAdmission,staleInsertAdmission,mergedA,mergedB,converged:isDeepStrictEqual(mergedA,mergedB),winnerAfterMerge:winner,undo,convergedAfterUndo:isDeepStrictEqual(a.toJSON(),b.toJSON()),foreignWriterRetainedAfterUndo:isDeepStrictEqual(winner,a.placementOf(target)),afterUndo:a.toJSON()}));
}
console.log(JSON.stringify({kind:'source-hashes-after',hashes:hashes()}));
