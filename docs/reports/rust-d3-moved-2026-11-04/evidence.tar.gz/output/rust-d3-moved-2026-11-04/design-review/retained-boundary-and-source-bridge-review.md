# Retained boundary and source bridge review

Approved source design: movement-enabled native boundaries use a known retained right anchor as opaque boundary metadata, consistent with the existing TS compiler and admission behavior. Keep parsing, the origin prefix, known-right lookup, right-not-new-self, schema/type, and constrained-child suffix checks. Only the old physical same-line test is disabled when `self.movement` is true. Legacy non-movement behavior keeps that test. This is the root's explicit scope decision.

Do not instead compare current logical parents or require visibility. Both depend on later concurrent edits. An insertion compiled while a predecessor is in one flow remains valid after another actor moves or deletes that predecessor before delivery. Retained markers and chars must remain valid references. Known cross-line boundaries are now intentionally admitted in the movement-enabled path; the previous native-only negative is not part of the retained contract.

The reviewed patch is the single conditional `!self.movement && oldPhysicalLineCheck` inside the existing known-right lookup. It changes no raw state DTO, placement, history, type validation, or source storage.

`boundary-arrival-orders.jsonl` stores TS source vectors for both later predecessor relocation and deletion. Stale insertion admission is null, merge converges, A undo converges, and the foreign placement writer remains. These are saved input/oracle vectors for the native owner's focused tests. This reviewer did not run native code or Cargo.

Required native negatives: unknown right, self right, incorrect origin prefix, malformed boundary, and invalid constrained-child suffix must still reject. Wrong node type and attributes remain governed by their original independent schema checks. Movement mode by itself must not bypass these checks.

The narrow `source_projections` bridge is approved at source level. The Server dispatch borrows the replica immutably and calls an immutable method. That method reads original Storage line order, calls existing `source_blocks` and `block_json`, and returns a separate response. Existing `state`, checkpoint and snapshot DTOs remain unchanged. Source projections serve the compiler promotion prepass only; logical path resolution must continue to use normal filtered projections.

TS used lazy line-map order before the fix, while native flow heads are materialized eagerly. Compiler promotion therefore needs a canonical candidate line order. The current TS and SDK collect virtual-with-char candidates and sort source line keys in UTF-16 lexical order, preserving physical block order within each line. This changes compiler allocation order only; it does not reorder stored lines, blocks, or ledger records.

`promotion-line-order-results.jsonl` records two equivalent TS snapshots with opposite materialized body-line orders. The current compiler produces the same promotion operations and Tickets for both. Source hashes before and after the diagnostic are recorded. The bridge itself keeps original Storage order; only the compiler's candidate list is sorted.

Final evidence limits: this is read-only source review plus TS diagnostics. The native owner must verify the exact modified source, negative tests, arrival-order tests, and full assigned exact comparison. No engine files were edited or built by this reviewer.
