import {Doc} from '../../../packages/doc-sync/src/index.ts';
import {applyEdits} from '../../../packages/doc-sync/src/crdt/model.ts';
import {PRESENTATION_SCHEMA} from '../../../fixtures/product-schemas.ts';
import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';import {isDeepStrictEqual} from 'node:util';
const paths=['packages/doc-sync/src/crdt/edit.ts','packages/doc-sync/src/crdt/doc.ts','packages/doc-sync/src/crdt/model.ts'];
const hashes=()=>Object.fromEntries(paths.map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')]));
console.log(JSON.stringify({kind:'source-hashes-before',hashes:hashes()}));
for(const index of [0,1,2]){
 const doc=new Doc('A',PRESENTATION_SCHEMA);doc.edit([{op:'insert',at:[1],content:[{type:'slide'}]}]);
 const line=doc.blocks()[1].body,head=doc.blocks(line)[0].marker.id,notes=doc.blocks(line)[1].marker.id;
 const move={t:'move',at:{lamport:doc.clock.next().lamport,actor:'B'},target:head,parent:doc.get(line).id,after:notes};
 const admission=doc.check([move]);doc.apply(move);const before=doc.toJSON(),rawBefore=doc.blocks(line).map(b=>({type:b.type,id:b.marker.key}));
 const edits=[{op:'insert',at:[1,index],content:[{type:'paragraph',runs:[{text:'NEW',marks:{}}]}]}],expected=applyEdits(PRESENTATION_SCHEMA,before,edits);
 const result=doc.edit(edits,{normalize:true}),after=doc.toJSON();
 console.log(JSON.stringify({kind:'moved-constrained-default',index,admission,move,rawBefore,before,expected,ops:result.ops,normalize:result.normalize,after,requestedSlotPass:isDeepStrictEqual(expected,after),originalWriterRetained:isDeepStrictEqual(doc.placementOf(head)?.at,move.at)}));
}
console.log(JSON.stringify({kind:'source-hashes-after',hashes:hashes()}));
