import {registerHooks} from 'node:module';
import {pathToFileURL} from 'node:url';
const root = pathToFileURL(process.cwd() + '/packages/doc-sync/').href;
registerHooks({resolve(specifier, context, nextResolve) {
    const result = nextResolve(specifier, context);
    if (result.url === root + 'dist/index.js') return nextResolve(root + 'src/index.ts', context);
    if (result.url.startsWith(root + 'dist/editor/')) return nextResolve(result.url.replace('/dist/editor/', '/src/editor/').replace(/\.js$/, '.ts'), context);
    return result;
}});
