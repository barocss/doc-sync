from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d3-moved-2026-11-04';report=r/'docs/reports/rust-d3-moved-2026-11-04'
def read(n):return json.loads((t/n).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
n=read('moved-final-v2-receipt.json');c=read('compare-final-summary.json');s=read('source-verification.json');ts=read('ts-fix/source-freeze-v5.json')
assert n['status']=='PASS' and s['status']=='PASS' and c['status'] in {'PASS','TRACE_RECOMPARISON_PASS'}
for p,h in ts['files'].items():assert sha(r/p)==h,p
assert ts['typecheck']['status']=='PASS'
for name in ['workspace-test-final-v5','docs-build-final-schema-bound','docs-check-final-schema-bound']:assert read(name+'.json')['status']=='PASS'
main=json.loads((r/c['main']['receipt']).read_text());assert main['status'] in {'PASS','TRACE_RECOMPARISON_PASS'}
for p,h in main['sourceHashes'].items():assert sha(r/p)==h,p
counts=n['testCounts'];m=c['main'];totals=read('workspace-test-final-v5-totals.json')
assert totals['pass']==2160 and totals['fail']==0 and totals['skipped']==2
for name,count in counts.items():
 if name not in ['core','sdk']:continue
 log=(t/f'moved-final-v2-{name}.log').read_text();assert sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed;',log))==count
checks={'status':'BOUNDED_PASS_D3_MOVED','head':s['head'],'scope':'Original Word23 and Presentation27 text/flow model insertion after existing movement; full model oracle plus exact operations/history/state; not all D3 or production Rust/WASM','comparison':c,'native':n,'typescriptSource':ts,'workspace':{**read('workspace-test-final-v5.json'),'totals':totals},'docs':{'build':read('docs-build-final-schema-bound.json'),'check':read('docs-check-final-schema-bound.json'),'pages':55,'internalLinks':2660,'english':True,'localPathsExcluded':True},'sourceVerification':s,'notRun':['Chrome','mobile','performance benchmark','WASM integration','network/mixed-runtime checkpoint interoperability','protected native GC','production native process/server crash recovery'],'publication':{'commit':False,'push':False,'deployment':False,'registry':False}}
report.mkdir(exist_ok=True,parents=True)
result=f'''- Original Word/Presentation: **{m['profiles']} profiles / {m['semanticActions']} actions /
  {m['stateComparisons']} actor states**, with the complete model-edit oracle.
  **{m['actualTypescriptDocEditAuthorings']} logical Doc.edit authorings /
  {m['rawTypescriptDocEmitAuthorings']} raw Doc.emit authorings** are separate;
  **{m['fullIndependentInsertionModelOracles']} complete independent insertion model oracles** pass.
- Native core **{counts['core']} PASS**, SDK **{counts['sdk']} PASS**. The complete example and
  both independent locked documentation consumers pass, with frozen source maps.
- Current TypeScript source regressions: **119 PASS**; actual typecheck **PASS**.
- Fresh complete `npm test`: **{totals['tests']} tests / {totals['pass']} PASS / two expected
  platform SKIPs / zero FAIL / zero cancelled**.
- Documentation build and checks pass: **55 pages / 2,660 internal links**, English
  and local-path checks pass. Both full program fences match their consumers.
- Inherited paragraph466, unused84 and textfalse90 traces, schema export and
  admission/product oracles have separate fresh receipts in the summary. Historical
  probes that expect already-fixed failures are explicitly excluded.
'''
(report/'README.md').write_text((t/'report-body.md').read_text().replace('{{RESULTS}}',result))
p=r/'HANDOFF.md';h=p.read_text();assert '### 5.154 ' not in h
latest=f'''Latest **§5.154** supports bounded D3 model-path insertion after existing moves.
Original Word/Presentation {m['profiles']} profiles/{m['semanticActions']} actions/{m['stateComparisons']} states PASS;
core{counts['core']}/SDK{counts['sdk']}, source119 and whole npm{totals['pass']} PASS/two expected SKIPs.
Current placement winners, canonical defaults, deterministic promotions and
physical source fences preserve foreign text/writers and same-gap coalescence.
Docs55 pages/2,660 links PASS. Full D3 and production Rust/WASM remain open.
See `docs/reports/rust-d3-moved-2026-11-04/`. No commit/push/publication included.

'''
h=h.replace('# Handoff — @barocss/doc-sync\n\n','# Handoff — @barocss/doc-sync\n\n'+latest,1)
h+='''

### 5.154 D3 model positions after existing movement

The native model-path compiler no longer rejects every retained Move ledger.
`insert_paragraph_at` and recursive flow/text `insert_model_at` resolve accepted
placement winners, including undone or cycle-suppressed movement. Physical birth
origins remain physical; new identities receive their own logical placement.
Existing sibling Move writers are not overwritten. The candidate compiles on a
native checkpoint clone and records once, preserving the live document, clock,
History and pending queue on rejection. Physical helper semantics stay separate.

The full independent model oracle exposed TS bugs beyond operation parity.
Fresh default identities preserve canonical leading title/paragraph slots and
unwritten automatic gaps. Preparation reads only target/ancestor flows and
respects grouped defaults, max0, authored siblings and existing head writers.
Eligible populated source virtuals sort by UTF-16 line key before promotion;
read-only native source introspection keeps original storage order and DTOs.

Move undo/redo also exposed an ordinary boundary collision: appending at ONE's
old gap absorbed moved TWO into NEW. A source-class collision in another accepted
logical gap now uses the next retained physical primary as right fence. No new
wire grammar, ticket or blanket unique suffix is added. Both peers at the same
observed gap keep one coalesced new paragraph; selective undo retains peer text.
Known opaque right anchors remain valid when a peer relocates/deletes the
predecessor before receipt. Parser, origin, known/nonself and schema checks stay;
legacy non-movement physical admission is unchanged.

'''+result+'''
Initial old-binary rejection, TS position/text-merge failures, native prototype
fresh-fragment metadata failure and input/preparation boundaries remain separate
from final qualification. Promotion seeds use explicit raw nodes/text after an
initial pre-Move staged snapshot capability failure; that is fixture preparation,
not a production snapshot fix. Malformed model attrs can normalize in TS while
native rejects atomically. Negative TS compilation is staged on a clone; no new
general direct Doc.edit transaction guarantee is claimed. Initial test-only
ES2023 methods failed typecheck; compatible copies and current type/source runs
pass. Later product boundary changes received a fresh whole npm run.

Final main status is TRACE_RECOMPARISON_PASS. The completed TS/native authoring
traces retain their original successful source/binary guards. A verifier-only
correction finds the exact retained B Move by stamp and independently checks
its current winning placement; searching the first target record selected an
older retained Move. Reviewed assertion/executor diffs and all trace/corpus
hashes bind the recheck. No authoring replay or product change is claimed for
that test fix. Original failures remain and compact error pointers avoid large
trace duplication. Raw atom preparation uses an empty nontext boundary.

Thirteen prior seals, the before executable, old adapters, original schema source
and complete product snapshots remain unchanged. Opening195-file state preserves
inherited WIP. Final source maps, compressed full traces, restoration hashes and
selected archive readback are bound by the report seal. Checkpoint restoration
is same-runtime/schema/actor pending/History recovery, not server durability.

Remaining: general D3 command compilation, grid/group model construction and
parents, flows with grouped child projections, text offsets, mixed structured attrs, JSON reference handles, trailing
reserved-only cases, protected native GC and production Rust/WASM Client/editor
integration. No Chrome, mobile, performance benchmark, mixed-runtime wire or
production process/server crash qualification is included. No commit, push,
deployment or registry publication is included.

[Source-bound moved insertion report](docs/reports/rust-d3-moved-2026-11-04/README.md).
'''
p.write_text(h)
subprocess.check_call(['python3',str(t/'verify-source.py')],cwd=r)
checks['sourceVerification']=read('source-verification.json')
(report/'final-checks.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':checks['status'],'profiles':m['profiles'],'actions':m['semanticActions'],'states':m['stateComparisons'],'native':counts,'workspace':totals}))
