---
work_id: rust-d3-batch-2026-11-04-reservation-review
artifact_type: source_review
status: done
owner_role: reservation-review
source_request: Q1.2 insert_models_batch clock reservation canonicality
last_updated: 2026-11-04
---

# Native runtime reservation source review

Status: APPROVED_BOUNDED_SOURCE. The implementation owner confirmed final source freeze. The final changed reservation code and SDK metadata assertions were read again after that notice. No blocking source finding was found. Native execution by this lane: NOT_RUN.

Scope: read-only product source inspection. This lane owns only this artifact directory. No Cargo, npm, browser, mobile, benchmark, deployment, release or product mutation was performed by this lane.

## Invariant and source evidence

Let J be the maximum actual operation ticket in canonical replay, C the sender clock, and R the optional reservation marker. The permitted stable states are:

- R absent: C = J.
- R present: J < R = C <= MAX.

`Replica` derives Clone and stores `runtime_reserved_clock: Option<u64>` initialized to None (`rust-shadow/src/lib.rs:157-196`). It is native runtime metadata. It does not add wire operations or History steps.

`runtime_schema.rs:1684-1694` adds `Saved.reserved_clock` with JSON name `reservedClock`, serde default and `skip_serializing_if = Option::is_none`. Ordinary runtime snapshots omit it. `runtime_snapshot` exports the current marker with the existing journal (`:1857-1865`).

`restore_runtime` rejects a present non-u64 field, including explicit null, before decoding (`:1867-1871`). It compiles the manifest and checks the schema identity, replays every operation into a fresh replica with marker None, and checks both exact canonical journal equality and the clock relation (`:1872-1885`). Only then does it set the saved clock and marker (`:1887-1891`). Absence therefore rejects an old snapshot whose only corruption is an increased clock. A present marker equal to replay is rejected as redundant. Overflow, mismatch and malformed numeric fields are rejected.

`history_record` clones both replica and History before recording (`lib.rs:1046-1056`). It records operations first, validates the optional integer against MAX and the resulting clock, and publishes both only after success (`:1062-1080`). A larger requested clock sets the runtime marker. An equal requested clock preserves the current marker. If actual operations already consumed the old marker, an equal request does not recreate it. A lower clock fails before publication.

`Replica::observe` uses the actual observed ticket rather than the already-raised sender clock (`lib.rs:212-216`). An operation below R retains the marker. A ticket at or above R makes the gap inferable from replay and clears the marker. Text observes its final ticket in the flat path (`lib.rs:320`) and each ticket in the nested path (`nested.rs:554`); movement and graphic paths also call observe. Duplicate valid operations use the same observation path and journal de-duplication. Reference wrappers call `apply_inner` before recording their reference provenance (`composite.rs:360-415`), so they observe the underlying actual ticket too.

`History::next` increments the document clock before returning a ticket (`history.rs:411-421`). Each allocation in the inspected travel branches is applied through `doc.apply` before publication (`:439-539`). Testing the actual ticket in observe is therefore necessary. A branch that emits no operation does not allocate a ticket and does not consume the marker. Any application failure discards the cloned request candidate.

`RuntimeDocument::insert_models_batch` compiles on a restored detached document and sends all operations plus final compiler clock to one `history_record` (`rust-sdk/src/runtime_batch.rs:44-70`). `stage_change` commits its detached server only after the command and response decoding succeed, and adds pending work only for nonempty operations (`runtime_schema.rs:362-383`). Empty reserved changes preserve pending changes, History and redo. SDK restore replays each exact pending operation and compares the complete native document+History checkpoint (`:1291-1335`). Lower pending tickets leave an active reservation intact; retry does not allocate new tickets. `restore_checkpoint` assigns only after complete successful restore (`:1337-1343`).

## Regression sources inspected

- Existing `rust-shadow/tests/runtime_nested.rs:197-218` still changes only `document.clock` to 999 and requires rejection with exact live checkpoint preservation. Its complete SHA-256, `89d8dc6ce3abe0e6efe6aaceb8f5147eca9c05db7086c42e4af264f2b0242f4f`, equals the phase baseline in `../baseline.json`. It was not weakened.
- `history_reserved_clock.rs:13`: empty recording preserves redo and clock across restore.
- `history_reserved_clock.rs:45`: invalid request clocks and post-text-span regression preserve the exact checkpoint.
- `history_reserved_clock.rs:100`: lower/equal/above remote tickets, text range end, and equal re-reservation.
- `history_reserved_clock.rs:128`: own operations and undo/redo consume the marker, then restore exactly.
- `history_reserved_clock.rs:167`: clock-only and trailing gap restore, null/fraction/string/mismatch/overflow/missing/redundant metadata, invalid saved clocks, duplicate or altered journal, and exact checkpoint preservation after failed restore.
- `rust-sdk/tests/runtime_batch.rs:88`: failure after valid preparation preserves the complete serialized checkpoint, including a prepared redo branch.
- `rust-sdk/tests/runtime_batch.rs:132`: trailing compiler reservation survives SDK restore with pending operations and next ticket allocation; clock-only insertion preserves pending and redo.

These are inspections of test bodies. Execution is owned by implementation and comparison lanes and is not inferred here.

## Bounded conclusion

The inspected transitions preserve the stated invariant. No blocking source finding was found in this scope. Metadata validates consistent counter state; it does not authenticate history or prove server acceptance. A party that changes both clock and matching metadata can create a structurally valid reserved snapshot. Reservation-bearing snapshots require the updated native reader; older readers are not qualified. No broader D3, production Rust/WASM, browser or performance acceptance follows.

`source-seal.json` records SHA-256 hashes for the 13 reviewed source, regression-test and SDK documentation files after final source freeze. The old forged-clock regression file matches the phase baseline. Source inspection supports the reservation design; fresh native and differential execution remain separate receipts owned by other lanes.
