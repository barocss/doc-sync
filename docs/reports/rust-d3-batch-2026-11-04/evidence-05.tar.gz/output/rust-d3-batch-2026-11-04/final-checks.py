from pathlib import Path
import hashlib,json,re,subprocess

root=Path('/Users/user/github/doc-sync');task=root/'output/rust-d3-batch-2026-11-04'
report=root/'docs/reports/rust-d3-batch-2026-11-04'
def read(path):return json.loads(path.read_text())
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def ref(path):return {'path':str(path.relative_to(root)),'sha256':sha(path)}
baseline=read(task/'baseline.json')
allowed={
    'HANDOFF.md','README.md','apps/docs/src/guide/blocks.md','apps/docs/src/guide/editing.md',
    'apps/docs/src/guide/rust.md','apps/docs/src/roadmap.md','apps/docs/src/schemas/custom.md',
    'apps/docs/src/schemas/document.md','apps/docs/src/schemas/editing-contract.md',
    'docs/rust-roadmap.md','docs/schema-editing-roadmap.md','experiments/rust-sdk/README.md',
    'experiments/rust-sdk/src/lib.rs','experiments/rust-sdk/src/runtime_paragraph.rs',
    'experiments/rust-sdk/src/runtime_schema.rs','experiments/rust-sdk/src/runtime_structure.rs',
    'experiments/rust-shadow/src/lib.rs','experiments/rust-shadow/src/runtime_schema.rs',
}
changes=[]
for name,old in baseline['files'].items():
    current=sha(root/name)
    if current!=old:
        assert name in allowed,name
        changes.append({'path':name,'before':old,'after':current})
for row in changes:
    assert not row['path'].startswith(('packages/doc-sync/src/crdt/','packages/doc-sync/dist/crdt/','experiments/runtime-document-'))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==baseline['head']
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='main'
for name,expected in read(task/'before-pins.json').items():assert sha(root/name)==expected,name
seals=read(task/'earlier-seals.json')
for row in seals:
    prior=root/row['report'];assert sha(prior/'seal.json')==row['sealSha256']
    for name,expected in read(prior/'seal.json')['files'].items():assert sha(prior/name)==expected
native=read(task/'native-final-v2-receipt.json');assert native['status']=='PASS'
native_map=read(root/native['sourcesAfter'])
for name,expected in native_map.items():assert sha(root/name)==expected,name
summary=read(task/'compare-summary.json');assert summary['status']=='PASS' and summary['currentCandidateQualified']
main=read(root/summary['receipt']);assert main['status']=='PASS'
for name,expected in main['sourceHashes'].items():assert sha(root/name)==expected,name
inherited=read(task/'compare-inherited-summary.json');assert inherited['status']=='PASS'
aggregate=read(root/inherited['aggregateReceipt']);assert aggregate['hashesBefore']==aggregate['hashesAfter']
for name,expected in aggregate['hashesAfter'].items():assert sha(root/name)==expected,name
program=(root/'experiments/rust-sdk/examples/runtime_batch.rs').read_text().strip()
for name in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
    assert program in re.findall(r'```rust\n(.*?)\n```',(root/name).read_text(),re.S),name
for which in ['readme','guide']:
    assert (task/('consumer-'+which)/'src/main.rs').read_text().strip()==program
totals={}
for key,n in re.findall(r'^[ℹ#] (tests|pass|fail|cancelled|skipped) (\d+)$',(task/'workspace-test.log').read_text(),re.M):
    totals[key]=totals.get(key,0)+int(n)
assert totals=={'tests':2162,'pass':2160,'fail':0,'cancelled':0,'skipped':2},totals
for name in ['workspace-test','typecheck','docs-build','docs-check','whitespace']:assert read(task/(name+'.json'))['status']=='PASS'
docs=json.loads(next(line for line in (task/'docs-check.log').read_text().splitlines() if line.startswith('{"pages"')))
preservation={'status':'PASS','baselineFiles':len(baseline['files']),'changedPaths':changes,
              'priorSealsUnchanged':len(seals),'oldBinariesUnchanged':read(task/'before-pins.json'),
              'typescriptProductionAndDistUnchanged':True,'nativeMapCurrent':len(native_map),
              'mainMapCurrent':len(main['sourceHashes']),'inheritedMapCurrent':len(aggregate['hashesAfter']),
              'oldTestsExamplesUnchanged':native['inheritedTestsExamples'],
              'fullExampleFencesAndConsumersExact':True,'head':baseline['head'],'branch':'main'}
(task/'preservation-final.json').write_text(json.dumps(preservation,indent=2)+'\n')
result={'status':'BOUNDED_PASS_Q1_2_INSERT_BATCH','head':baseline['head'],
        'scope':'Native insert-only model batches and explicit reservation metadata; not general D3/WASM or durable server recovery',
        'main':{**summary['counts'],'receipt':ref(root/summary['receipt']),'currentCandidateQualified':True,
                'sourceBinaryFreeze':summary['sourceBinaryFreeze']},
        'native':{'receipt':ref(task/'native-final-v2-receipt.json'),'corePass':native['checks']['core']['passed'],
                  'sdkPass':native['checks']['sdk']['passed'],'independentConsumers':2,'fullExample':True,
                  'sourceFiles':native['sourceFiles'],'inheritedTestsExamplesUnchanged':native['inheritedTestsExamples']},
        'comparisonSummary':ref(task/'compare-summary.json'),'inheritedSummary':ref(task/'compare-inherited-summary.json'),
        'inheritedActions':inherited['fullInheritedMainActions'],'sourceReview':ref(task/'reservation-review/source-seal.json'),
        'workspace':{'receipt':ref(task/'workspace-test.json'),**totals,'packagePrebuild':'REUSED'},
        'typecheck':ref(task/'typecheck.json'),'docs':{**docs,'build':ref(task/'docs-build.json'),'check':ref(task/'docs-check.json')},
        'preservation':ref(task/'preservation-final.json'),'whitespace':ref(task/'whitespace.json'),
        'failures':{'initialPrototypeStdout':'NOT_RETAINED; summaries retained in implementation-attempts.json',
                    'broadClockRegression':'FAIL_PRIOR_CANDIDATE; final explicit-marker source rerun PASS',
                    'comparisonCorrections':'Separate fixture/oracle/helper changes retained; final authoring is fresh'},
        'notRun':['Chrome','mobile','performance measurement','WASM/production editor integration','native durable process/server recovery','mixed-runtime checkpoint exchange'],
        'publication':{'commit':False,'push':False,'deployment':False,'registry':False}}
destination=report/'final-checks.json';assert not destination.exists()
destination.write_text(json.dumps(result,indent=2)+'\n')
(task/'final-status.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=root,text=True))
print(json.dumps({'status':result['status'],'baseline':len(baseline['files']),'changed':len(changes),'native':[result['native']['corePass'],result['native']['sdkPass']],'docs':docs}))
