import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {Doc} from '../../../packages/doc-sync/src/crdt/doc.ts';
import {History} from '../../../packages/doc-sync/src/crdt/history.ts';
import {WORD_SCHEMA, PRESENTATION_SCHEMA} from '../../../fixtures/product-schemas.ts';
import {PRODUCT_MODELS} from '../../../fixtures/product-documents.ts';

const p = text => ({type:'paragraph',runs:text?[{text,marks:{}}]:[]});
const cell = text => ({type:'cell',children:[{type:'cell-body',children:[p(text)]}]});
const table = {type:'table',children:[0,1].map(()=>({type:'row',children:[cell('')]}))};
const custom = {root:'doc',marks:[],nodes:{doc:{shape:'flow',children:['paragraph','list','table'],default:'paragraph',childRules:{paragraph:{min:0}}},paragraph:{shape:'text'},list:{shape:'group',children:['item'],by:[]},item:{shape:'text'},table:{shape:'grid',children:['row']},row:{shape:'row',children:['cell']},cell:{shape:'cell',children:['cell-body']},'cell-body':{shape:'flow',children:['paragraph'],default:'paragraph'}}};
const results=[];
const run=(name,fn)=>{const detail=fn();results.push({name,...detail});console.log(JSON.stringify(results.at(-1)));};
const maxTicket=ops=>Math.max(0,...ops.map(op=>op.t==='text'?op.id.lamport+op.text.length-1:(op.id??op.at).lamport));
const track=(doc,edits)=>{const before=doc.clock.lamport;const {ops,normalize}=doc.edit(edits,{normalize:true});return {before,after:doc.clock.lamport,observed:maxTicket(ops),ops,normalize,model:doc.toJSON()};};
const insert=(at,model)=>({op:'insert',at,content:[model]});
for(const [name,schema] of [['word',WORD_SCHEMA],['presentation',PRESENTATION_SCHEMA],['custom',custom]]){
 run(name+': multirow batch sees evolving model',()=>{
  const doc=new Doc('alice',schema);
  if(name!=='custom') doc.edit([{op:'delete',at:[0],count:doc.toJSON().children.length},{op:'insert',at:[0],content:PRODUCT_MODELS[name].children}]);
  const parent=name==='custom'?[]:[1];
  if(name==='presentation') assert.equal(doc.toJSON().children[1].type,'slide');
  const index=parent.length?1:1;
  const at=[...parent,index];
  const edits=[insert(at,table),insert([...at,0,1],cell('A')),insert([...at,1,1],cell('B')),insert([...at,0,1,0,1],p('C'))];
  const out=track(doc,edits);
  const grid=at.reduce((node,i)=>node.children[i],out.model);
  assert.deepEqual(grid.children.map(row=>row.children.length),[2,2]);
  assert.equal(out.ops.filter(op=>op.t==='node'&&op.type==='col').length,2);
  const h=new History();h.record(out.ops,doc,{caretBefore:'',caretAfter:'',typing:false});
  const groupCount=h.snapshot().undo.length; assert.equal(groupCount,1);
  const undone=h.undo(doc); assert.ok(undone.ops.length); assert.equal(h.canUndo,false);
  const redone=h.redo(doc); assert.ok(redone.ops.length); assert.deepEqual(doc.toJSON(),out.model);
  return {before:out.before,after:out.after,observed:out.observed,columnBirths:2,normalize:out.normalize,historyGroups:groupCount,ops:out.ops,model:out.model};
 });
}
for(const [name,model] of [['empty group',{type:'list',children:[]}],['zero-row grid',{type:'table',children:[]}],['zero-column grid',{type:'table',children:[{type:'row',children:[]}]}]]){
 for(const projected of [false,true])for(const at of [[0],[1]])run(name+' at '+JSON.stringify(at)+' projected='+projected,()=>{const doc=new Doc('alice',custom);if(projected)doc.edit([{op:'move',from:[0],at:[0]}]);const h=new History();const beforeModel=doc.toJSON();const out=track(doc,[insert(at,model)]);h.record(out.ops,doc,{caretBefore:'',caretAfter:''});return {...out,modelUnchanged:JSON.stringify(doc.toJSON())===JSON.stringify(beforeModel),canUndo:h.canUndo};});
}
run('trailing reserved-only and subsequent ticket',()=>{const doc=new Doc('alice',custom);doc.edit([{op:'move',from:[0],at:[0]}]);const out=track(doc,[insert([1],p('X')),insert([0],{type:'table',children:[]})]);assert.ok(out.after>out.observed);const restore=Doc.fromSnapshot('alice',doc.snapshot(),custom);assert.equal(restore.clock.lamport,out.after);const next=track(restore,[insert([1],p('Y'))]);assert.ok(next.ops[0].id.lamport>out.after);return {batch:out,next};});
run('invalid late command on detached document',()=>{const live=new Doc('alice',custom);const original=live.snapshot();const detached=Doc.fromSnapshot('alice',original,custom);let error;try{detached.edit([insert([1],p('A')),insert([999,0],p('B'))]);}catch(e){error=e.message;}assert.ok(error);assert.deepEqual(live.snapshot(),original);assert.notDeepEqual(detached.snapshot(),original);return {error,liveUntouched:true,detachedClock:detached.clock.lamport,detachedModel:detached.toJSON(),directDocEditAtomic:false};});
run('empty batch and clock-only preserve redo',()=>{const doc=new Doc('alice',custom);doc.edit([{op:'move',from:[0],at:[0]}]);const h=new History();let out=track(doc,[insert([1],p('A'))]);h.record(out.ops,doc,{caretBefore:'',caretAfter:''});h.undo(doc);assert.equal(h.canRedo,true);const before=h.snapshot();out=track(doc,[insert([0],{type:'table',children:[]})]);h.record(out.ops,doc,{caretBefore:'',caretAfter:''});assert.deepEqual(h.snapshot(),before);const empty=track(doc,[]);assert.equal(empty.before,empty.after);assert.deepEqual(empty.ops,[]);return {clockOnly:out,historyUnchanged:true,empty};});
for(const mode of ['different-row','same-row','intervening-insert','intervening-update'])run('column memo '+mode,()=>{
 const doc=new Doc('alice',custom);doc.edit([insert([1],table)]);
 const commands=[insert([1,0,1],cell('A'))];
 if(mode==='intervening-insert')commands.push(insert([2],p('M')));
 if(mode==='intervening-update')commands.push({op:'update',at:[0],attrs:{}});
 commands.push(insert([1,mode==='same-row'?0:1,1],cell('B')));
 const out=track(doc,commands);const count=out.ops.filter(op=>op.t==='node'&&op.type==='col').length;
 assert.equal(count,['same-row','intervening-update'].includes(mode)?2:1);
 return {columnBirths:count,...out};
});
run('foreign peer survives one undo redo',()=>{
 const doc=new Doc('alice',custom);const out=track(doc,[insert([1],table),insert([1,0,1],cell('A')),insert([1,1,1],cell('B'))]);
 const history=new History();history.record(out.ops,doc,{caretBefore:'',caretAfter:''});
 const peer=Doc.fromSnapshot('bob',doc.snapshot(),custom);const foreign=peer.edit([{op:'insert',at:[0,0],content:'FOREIGN'}]).ops;foreign.forEach(op=>doc.apply(op));
 const withForeign=doc.toJSON();const firstUndo=history.undo(doc);assert.ok(JSON.stringify(doc.toJSON()).includes('FOREIGN'));assert.equal(history.canUndo,false);
 const undoClock=doc.clock.lamport;history.redo(doc);assert.deepEqual(doc.toJSON(),withForeign);
 return {foreignOps:foreign,undoOps:firstUndo.ops,undoClock,redoClock:doc.clock.lamport,oneHistory:true,foreignPreserved:true};
});
for(const model of [{type:'list',children:[]},{type:'table',children:[]}])run('known but unadmitted root '+model.type,()=>{
 const doc=new Doc('alice',WORD_SCHEMA);const before=doc.snapshot();const out=track(doc,[insert([1],model)]);assert.deepEqual(doc.snapshot(),before);assert.deepEqual(out.ops,[]);return out;
});
run('unprojected emptygroup bad index TS accepts',()=>{const doc=new Doc('alice',WORD_SCHEMA);let error;try{doc.edit([insert([999],{type:'list',children:[]})]);}catch(e){error=e.message;}assert.equal(error,undefined);return {directTSAccepted:true};});
writeFileSync(new URL('./probe-results.json',import.meta.url),JSON.stringify({runtime:process.version,results},null,2)+'\n');
