# Q1.2 batch contract: source review and TS probes

REOPENED: the broad native suite found that generalized clock restore accepted an old forged-clock snapshot. The preceding source review did not establish old-suite compatibility. The reservation-metadata design below replaces unconditional `saved.clock >= replay.clock`; a new source seal is required after implementation.

Date: 2026-11-04. Scope: read-only product source review; output-only probe artifacts. No cargo, browser, mobile, performance, publication or release verification.

## Evidence

`probes.mjs` imports the authoritative TypeScript source modules. It imports the original Word and Presentation schemas and models from `fixtures/`. `probe-results.json` contains the complete observed models and operations. `probe-run.log` contains the run output. Node v24.22.1: all 26 cases pass. These results establish TS behavior. They do not establish native parity.

Run from repository root:

```
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/rust-d3-batch-2026-11-04/contract-review/probes.mjs
```

## Ranked findings

1. P1 review item, fixed in reviewed source: promotion must run once when projection first becomes active. TS `edit.ts:353-366` keeps a `promoted` flag and tests projection before each command. An initially unprojected document can acquire its first Move during insertion after a required sibling. A batch-wide call only before the loop misses this transition. The implementation owner moved the gate inside the command loop and keeps the flag false until projection is active. Source inspection confirms this correction in `runtime_batch.rs:53-59`; native execution remains owned by the test agents.
2. Required contract: an empty requested grid can create an unrelated paragraph tail. With a fresh nonprojected custom document, insert empty grid at `[0]`: one paragraph Node, clock 0→1, model gains an empty paragraph, normalize inserts at `[1]`. The requested grid still has no key. A first-born-operation heuristic would invent a grid key.
3. Required contract: operation clocks do not encode all local reservations. With projection active, empty grid at `[0]` reserves one fragment ticket, emits zero operations, and leaves the model unchanged. A real paragraph followed by this command leaves final clock greater than every operation ticket. Snapshot restore retains the final clock. The next command allocates above it.
4. Required contract: the column memo belongs to the complete compiler. Different rows at one grid/index reuse one new column. A repeated row allocates a new column. Intervening INSERT preserves the memo; UPDATE clears it even with empty attrs. The insert-only native API needs no update reset branch. It must preserve the memo through every supported insert.
5. Required evidence boundary: direct TS `Doc.edit` on a document-domain Doc is not globally atomic. A valid first command followed by an invalid parent path partly mutates the detached Doc before throwing. Our comparison stages the entire batch on a detached document; the original live document stays unchanged. `doc.ts:2266-2269` provides full preflight staging specifically for the graphic domain.

## Exact result semantics

`keys` has one entry per requested model, in input order. `None` means that the requested model has no stored identity. A group returns its first member; a row returns its new row axis; a cell insertion returns its new column axis or the shared column axis reused for that row. Reused keys are valid and intentional.

The aggregate `Change` contains the complete batch operations in order, including preparation, promotion, text UTF-16 ranges, field writes and placement operations. It is present even with zero operations. Empty change operations add no pending queue entry. Nonempty operations add exactly one pending change.

`clockBefore` is the pre-batch sender clock. `clockAfter` includes consumed and reserved tickets. It must survive checkpoint export/restore. Do not derive it from the final operation, the number of operations, or History steps.

No-op classification:

| Request | Projection | Operations | Clock delta | Model |
|---|---|---:|---:|---|
| Empty command array | either | 0 | 0 | same |
| Empty group `[0]` or `[1]` | either | 0 | 0 | same |
| Empty grid `[1]` | either | 0 | 0 | same |
| Empty grid `[0]` | active | 0 | 1 | same |
| Empty grid `[0]` | inactive | 1 paragraph Node | 1 | extra paragraph |

Both zero rows and rows with zero cells have the empty-grid behavior above. These classifications describe the simple custom document after its stated setup. Preparation or promotion in other documents can add operations even when the requested structure has no identity.

History records operations, not clock reservations. `history.ts:423-454` skips empty steps before redo clearing. Clock-only and empty batches preserve undo/redo, including an existing redo branch. Nonempty batches produce one History record; typing options can merge that record with a prior group. Promotion-only Nodes with virtual boundaries are excluded from History existence steps. A peer text edit in a preexisting paragraph survives one undo, and one redo restores the complete model with that peer edit.

## Minimum native clock commit

The native `history_record` request can accept an optional bounded exact integer `reservedClock`. Apply operations and History on the candidate first. Reject a reservation below the resulting candidate clock. Assign the candidate clock after successful History recording. Publish document and History together only after all checks succeed. This needs no wire operation, field-reference encoding change, or History/checkpoint format change. Existing snapshot clock storage carries the reservation.

`stage_change` already exports document+History into a detached candidate and publishes its server only after a successful command. Its nonempty-ops condition preserves the pending queue for clock-only results. A failed later compiler command must never reach this publish step.

Retry is a separate existing transport operation. Re-running `insert_models_batch` is a new edit and can create new identities. Retry must use the captured pending Change with `apply_remote`; checkpoints must preserve that pending Change and the reservation clock. A model-only comparison cannot prove retry or History preservation.

## Authoritative source references

- `packages/doc-sync/src/crdt/edit.ts:293`: shared compiler batch state.
- `packages/doc-sync/src/crdt/edit.ts:353`: promotion and memo reset.
- `packages/doc-sync/src/crdt/edit.ts:490`: insertion preparation against evolving model.
- `packages/doc-sync/src/crdt/edit.ts:584`: empty-group flattening.
- `packages/doc-sync/src/crdt/edit.ts:689`: insertBlocksAt preparation, projected fragment reservation, legacy paragraph tail.
- `packages/doc-sync/src/crdt/edit.ts:848`: empty-grid skip before node allocation.
- `packages/doc-sync/src/crdt/edit.ts:997`: row-aware column memo reuse.
- `packages/doc-sync/src/crdt/edit.ts:1360`: one compiler per edit array.
- `packages/doc-sync/src/crdt/doc.ts:2261`: document edit and graphic-only preflight.
- `packages/doc-sync/src/crdt/doc.ts:2583`, `:2689`: snapshot clock export and restore.
- `packages/doc-sync/src/crdt/history.ts:423`, `:452`: operation-only History steps and empty return.
- `experiments/rust-sdk/src/runtime_schema.rs:362`: detached commit and pending enqueue boundary.
- `experiments/rust-shadow/src/lib.rs:1037`: native candidate History request branch.

## Initial implementation source review

Reviewed the in-progress `runtime_batch.rs`, `runtime_paragraph.rs`, `runtime_structure.rs`, and native `history_record` branch after initial implementation edits. Optional requested keys, empty-grid skip before allocation, legacy tail inclusion, shared row memo and detached commit align with the TS requirements above. The native reservation branch clones document and History before recording, rejects a clock below the resulting candidate clock, then commits both. Its scope does not alter field-reference or protocol payload formats.

Native tests and differential comparisons are owned by other agents. Their result is not inferred from this review.

## Final source review after empty-group and clock-restore fixes

No source blockers found in the assigned scope. This review inspected the final edits rather than reusing the initial seal.

- `runtime_structure.rs:379` now flattens the requested group before stored-child admission and bypasses admission only for an empty flattened array in batch mode. Parent resolution, materialization, index bounds, model type and attribute validation remain active. Strict single insertion retains its rejection.
- `runtime_batch.rs:53` gates promotion before each command and promotes at most once after projection becomes active.
- `rust-shadow/src/lib.rs:854` limits `reservedClock` to `history_record`; the candidate branch validates and assigns it only after History recording succeeds.
- `rust-shadow/src/runtime_schema.rs:1864` replays the saved journal, requires the replayed canonical journal to equal the saved journal, requires saved clock to be between replayed clock and MAX, then assigns saved clock. It retains schema identity validation.
- `rust-shadow/tests/history_reserved_clock.rs` contains three focused tests. Source inspection confirms clock-only and trailing-clock restore coverage, unchanged History after empty recording, below-clock and MAX-overflow rejection, negative/fraction/null rejection, duplicate journal rejection, altered journal rejection, and exact live checkpoint preservation after each failed request.
- `rust-sdk/tests/runtime_batch.rs:88` compares the complete serialized checkpoint after a successful first command and each invalid later command, including a prepared redo branch. The new Presentation regression checks normalized empty group, out-of-range rejection, strict single rejection, and exact checkpoint equality.

Explicit bounded policy differences: direct TS drops a known empty grid even when its type is not admitted by the parent, such as table at Word root `[1]`. Native still requires grid parent admission. Direct TS on a fresh nonprojected Doc can silently accept an out-of-range empty-group index because insertion preparation skips nonprojection; native always checks the child index. These are not universal TS API parity claims. The approved group fix does not broaden grid or path admission.

The final `source-seal.json` includes the reviewed core restore source and regression test sources. Test bodies were inspected; their execution results belong to the implementation and comparison agents.

## Reopened clock-restore design

The existing `runtime_nested.rs` corruption regression must remain unchanged. An old snapshot with only a raised clock must fail. Legitimate reservations therefore need an explicit optional native runtime snapshot field, separate from wire operations and History.

Recommended state: `Replica.runtime_reserved_clock: Option<u64>`, initialized to None and cloned with the replica. Runtime `Saved` adds optional `reservedClock`, omitted when None. Old snapshots without this field still require saved clock to equal the replayed journal clock exactly. A present integer reservation is valid only when it equals saved clock and strictly exceeds replay clock, while staying at or below MAX. The journal must still equal its canonical replay exactly. Reject redundant metadata, mismatches, invalid numeric types and explicit null if omission is the canonical None representation.

After `history_record` successfully records operations on its candidate, a requested reservation above the candidate clock sets both clock and marker. Equal requested clock preserves any prior marker. A lower request rejects. Apply no metadata to pending Change or wire operations.

At the common `Replica::observe(ticket)` function, clear the marker only when the actual observed ticket reaches or exceeds the reservation floor. A remote operation below that floor must preserve it. Text spans already observe their final ticket through the normal application path. Undo/redo allocate above the sender clock, then their applied operation clears the marker. Do not clear based only on the current sender clock, since History allocation increments it before operation application.

Restore replays with marker None, validates the metadata and clock relation, then assigns both. Snapshot export naturally omits consumed metadata. Clone and checkpoint restore retain an active marker; checkpoint retry of lower operation IDs retains it. Existing pending checkpoint validation still replays exact pending operations and compares complete native document+History. A later observed operation at or above the floor makes the old gap inferable from journal max and removes the marker.

This is canonical metadata validation, not cryptographic authenticity. A party able to alter both clock and metadata can construct an otherwise valid reserved snapshot; no authenticity claim follows.

Required verification: unchanged old forged-clock rejection; legitimate clock-only/trailing-gap restore; marker mismatch, redundant marker, overflow and invalid numeric rejection; lower remote observation retains marker; observation at/above floor removes it; failed restore keeps the exact live checkpoint; pending retry and one History action remain intact.
