# Proposed public guide section

Place a short section beside the D3 editing compiler summary in `guide/rust.md`.
The main lane owns that file. Update the Q1 sentence only after its final seal.

## What remains after schema-valid editing?

A schema-valid document can still have the wrong content, lost peer edits or
incorrect undo ownership. Native delivery therefore has additional gates:

1. Extend `insert_model_at` for supported group/grid model insertion and record
   exact accepted and blocked shapes. Then add an atomic batch-edit API with
   one History action and shared column identity across row operations.
2. Generate schemas and causal command histories with saved failure seeds,
   reduced reproducers and independent expected-model checks.
3. Complete flow/container commands that contain text-list groups and tables,
   including lists in cell bodies, concurrent moves, merged cells, axis changes
   and actor-owned undo. A schema `group` is a derived text-only wrapper; it
   cannot contain a table and has no separate stored identity.
4. Complete required/overflow children, hidden state, field resets and reference
   semantics without discarding retained foreign content.
5. Preserve offline pending edits and selection during compatible schema changes.
6. Qualify durable recovery, duplicate submission and protected garbage collection.
7. Qualify desktop binding normalization, selection and composition. Actual OS
   IME needs separate evidence.
8. Measure long-session latency, memory and retained-state growth against agreed
   budgets.

The TypeScript engine already has bounded tests for many of these features.
The remaining work includes broader native commands and new combinations of
existing features. More fuzz coverage does not itself deliver a missing command.
Native checkpoint restore does not establish durable server recovery. A native
SDK result does not establish a production Rust/WASM editor backend. D4, D6 and
D7 keep their separate exit gates.

# Review notes

The repository roadmap is `docs/schema-editing-roadmap.md`. Its evidence baseline
is HANDOFF 5.154. No new production code, dependencies, browser/mobile tests,
commits or publication are included. Local roadmap link targets were checked;
this is not a docs build or product test result.
