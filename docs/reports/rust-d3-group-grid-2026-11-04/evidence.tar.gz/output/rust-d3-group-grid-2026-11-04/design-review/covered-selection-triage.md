# Covered-cell selection diagnosis

Source diagnosis, no product edit or native execution by reviewer.

## Cause

SDK RuntimeDocument capture_selection/resolve_selection forward their values correctly to the native selection commands. The loss occurs in nested.rs:

1. capture_nested_path reaches the correct text block, but its text branch rejects `!line_visible(line)`. Full-grid covered cells are intentionally not visually visible, although the model contains their bodies.
2. resolve_nested_path rejects invisible movement locations, or invisible physical lines without moves, before raw_position runs.
3. raw_position already implements covered-cell escape: it verifies the owner grid, locates current axes, finds the covering top-left cell, and returns its body at block/offset zero.

The early selection guards prevent the existing escape code from handling the case.

## Minimal scoped correction

Add a small helper that recognizes a retained full-model covered cell only for runtime Document schemas. It must verify a real cell slot, retained owner grid projected under a visible parent, current live row and column IDs, and membership in that grid's covered map. It must not admit deleted axes, missing owners, superseded required slots, or generic hidden/private storage.

- Capture: keep numeric/path/text guards. Allow the final text capture when line_visible OR the covered-cell helper succeeds. Capture the actual requested block marker/character IDs, without changing to the covering cell.
- Resolve: derive the effective line from movement_location when movements exist, otherwise from the physical line. A visually visible effective line follows the existing path. A helper-confirmed covered effective line may bypass the old hidden early return.
- For a covered effective line, resolve via raw_position of that cell line's retained head, not necessarily the original token's physical line. This is the same existing escape implementation and correctly handles a block moved into the covered cell from another physical line. It also avoids redirecting a block moved out of a covered cell: use its current effective line first.
- Keep all original rejection behavior when the helper does not succeed. Continue to check the returned projected line visibility and build its complete model path through the existing block_model_path logic.

Do not remove visibility guards globally. Pinned legacy `experiments/rust-shadow/tests/shapes.rs:431` expressly expects covered capture and resolution to be null. Runtime required-slot tests also expect superseded slots to stay null. Gate the new admission to runtime Document selection so these contracts remain intact.

## Focused native vectors for implementer

1. Runtime full-grid 1x2 merge, retained hidden body, newly inserted paragraph with UTF-16 text. Capture offset0 and offset2 as that paragraph's own marker/character keys; resolve both to the visible merged top-left body start. Reverse anchor/focus and repeat.
2. Capture visible cell before merge, then merge and resolve retained anchors to covering start; split and resolve original offsets again. Own checkpoint restore must retain the same anchors and result.
3. Existing moved block into a covered cell: capture returns its source token IDs, resolution follows the current covered destination to top-left; move out and resolution follows visible destination normally.
4. Preserve legacy pinned hidden null, runtime missing/invalid path null, deleted axis policy, superseded required slot null, visible Unicode/range behavior.

The saved expanded comparison already proves all preceding authoring/model states match and identifies the first selection-only difference. Keep that exact case in the corpus; do not weaken its expected capture/resolve result.
