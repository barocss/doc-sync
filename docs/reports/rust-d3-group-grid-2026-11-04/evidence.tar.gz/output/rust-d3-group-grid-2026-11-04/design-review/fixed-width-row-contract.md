# Existing-grid row insertion contract

Confirmed by source `packages/doc-sync/src/crdt/edit.ts:973-995`. The method comment says to create one cell per current column and discard excess cells. It creates row nodes only, refreshes the current grid axes, then passes each existing column ID to fillCell. `fillCell` at line 933 returns before writing any body or attributes when no column exists.

For an independent full model oracle, clip ONLY the supplied inserted row payload to the existing current column count. Canonical normalization supplies missing cells and the declared default body. Keep all existing rows and their cell payloads unchanged. New grid construction remains a distinct contract: `fillGrid` uses the widest supplied row to create the columns.

`fixed-width-row-probe.mjs` directly imports current TS source. Three cases PASS with a current two-column table and inserted payload widths 0, 1 and 3. Each checks the full actual model against independently clipped/padded expected model, validates requested-model plus returned normalization, verifies unchanged existing row payloads and column IDs, verifies no column birth operations, and verifies the clipped third-cell text creates no operation. Execution is saved in `fixed-width-row-result.json`.

The request-only pure applyEdits helper can grow width for the overfull row. This is a proposed-model difference reconciled by Doc.edit normalization. No product bug or source change follows from that difference.
