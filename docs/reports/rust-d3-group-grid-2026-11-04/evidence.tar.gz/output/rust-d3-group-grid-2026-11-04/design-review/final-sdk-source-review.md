# Bounded SDK source review

Result: no remaining actionable defect found within the assigned group/grid insertion scope. This is source review, not a native test or corpus execution receipt. Source identities are saved separately in final-sdk-source-hashes.json.

Reviewed fixes are present:

- Derived group entries use the core pure `model_group_key` helper, preserving existing JS object key semantics. The facade forwards directly to the established pure helper and changes no grouping implementation.
- Group ownership comes from the local flow's children. Flow/cell body context uses owner birth type; the cell slot resolves through grid/row/cell/body schema.
- Group-target insertions admit valid parent-flow blocks, so an ordinary paragraph can split a group. Unsupported inherited by attributes are filtered per leaf; explicit attributes remain validated.
- Canonical leading preparation checks max0 on both the stored default and its local group owner. Preparation and virtual promotion retain their prior bounded behavior.
- Cell body index 0 is checked; all projected row/column cells remain selectable, including covered cells. Grid axes and cell attrs use the grid birth descriptor where required.
- Grid fill order is rows, columns, then supplied cells. Cell fill precedes span and custom attrs. Structured cell attrs reserve coarse tickets before emitting leaf writes. Covered payload and ragged defaults remain stored.
- Existing-grid row insertion fills only current columns. Column insertion refreshes axes and fills only the selected row while other cell bodies stay automatic. Return keys match the new row/column identity.
- The private recorder keeps wire emission order and separately validates fresh own, nonoverlapping, capacity-bounded operation stamp ranges and finite time. Public record still requires increasing stamps. Existing staged History commit preserves the live state on rejection and appends pending once.

Execution done by this reviewer: source TS group-split 1 case, anchored span normalization 6 cases, fixed-width row insertion 3 cases; all PASS. Native test counts and exact TS/native corpus results must come from their own final source-bound receipts.

Bounds retained: empty group/grid strict rejection, body selector zero, trailing reserved-only ticket rejection, no multi-command column-folding promise, no text-offset insertion, no production Rust/WASM integration qualification. No broad core solver or full-document preparation change is reviewed or requested.
