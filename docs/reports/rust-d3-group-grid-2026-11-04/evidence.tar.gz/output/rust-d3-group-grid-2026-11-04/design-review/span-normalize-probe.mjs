import assert from 'node:assert/strict';
import {Doc} from '../../../packages/doc-sync/src/crdt/doc.ts';
import {applyEdits} from '../../../packages/doc-sync/src/crdt/model.ts';

const schema={root:'doc',marks:[],nodes:{
    doc:{shape:'flow',children:['p','grid'],default:'p'},p:{shape:'text'},
    grid:{shape:'grid',children:['row']},row:{shape:'row',children:['cell']},
    cell:{shape:'cell',children:['body'],attrs:{
        rowspan:{default:1,computed:true},colspan:{default:1,computed:true},spanned:{default:false,computed:true},
    }},body:{shape:'flow',children:['p'],default:'p'},
}};
const cell=text=>({type:'cell',children:[{type:'body',children:[{type:'p',runs:[{text}]}]}]});
const merged={type:'grid',children:[
    {type:'row',children:[{...cell('A'),attrs:{rowspan:2,colspan:2}},cell('B')]},
    {type:'row',children:[cell('C'),cell('D')]},
]};
const cases=[];
for(const axis of ['rows','cols']) for(const index of [0,1,2]){
    const doc=new Doc(`span-${axis}-${index}`,schema);
    doc.edit([{op:'insert',at:[1],content:[merged]}]);
    const before=doc.toJSON();
    const request=axis==='rows'
        ? [{op:'insert',at:[1,index],content:[{type:'row',children:[cell('R0'),cell('R1')]}]}]
        : [{op:'insert',at:[1,0,index],content:[cell('COL')]}];
    const pure=applyEdits(schema,before,request);
    // Independent numeric model of stable endpoint behavior. At index 0 the
    // old anchor moves to index 1. Only index 1 lies inside this 2-axis span.
    const anchor=axis==='rows'?[index===0?1:0,0]:[0,index===0?1:0];
    const span=2+(index===1?1:0);
    const independentEdits=[...request];
    // One cell insert authors a whole column. Other rows receive empty bodies.
    if(axis==='cols') independentEdits.push({op:'insert',at:[1,1,index],content:[cell('')]});
    independentEdits.push({op:'update',at:[1,...anchor],attrs:{
        rowspan:axis==='rows'?span:2,colspan:axis==='cols'?span:2,
    }});
    const expected=applyEdits(schema,before,independentEdits);
    const change=doc.edit(request,{normalize:true});
    const actual=doc.toJSON();
    assert.deepEqual(actual,expected);
    assert.deepEqual(applyEdits(schema,pure,change.normalize),actual);
    assert(!change.ops.some(op=>op.t==='set' && op.key.startsWith('$span:')));
    cases.push({axis,index,status:'PASS',needsNormalize:JSON.stringify(pure)!==JSON.stringify(actual),
        normalize:change.normalize,expected,actual});
}
console.log(JSON.stringify({status:'PASS',cases},null,2));
