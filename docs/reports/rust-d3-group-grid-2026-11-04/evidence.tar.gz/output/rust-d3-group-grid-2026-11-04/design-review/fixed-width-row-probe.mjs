import assert from 'node:assert/strict';
import {Doc} from '../../../packages/doc-sync/src/crdt/doc.ts';
import {applyEdits} from '../../../packages/doc-sync/src/crdt/model.ts';
const schema={root:'doc',marks:[],nodes:{doc:{shape:'flow',children:['p','grid'],default:'p'},
    p:{shape:'text'},grid:{shape:'grid',children:['row']},row:{shape:'row',children:['cell']},
    cell:{shape:'cell',children:['body']},body:{shape:'flow',children:['p'],default:'p'}}};
const cell=text=>({type:'cell',children:[{type:'body',children:[{type:'p',runs:[{text}]}]}]});
const cases=[];
for(const width of [0,1,3]){
    const doc=new Doc(`row-${width}`,schema);
    doc.edit([{op:'insert',at:[1],content:[{type:'grid',children:[
        {type:'row',children:[cell('A'),cell('B')]},{type:'row',children:[cell('C'),cell('D')]},
    ]}]}]);
    const before=doc.toJSON();
    const oldCols=doc.blocks()[1].cols.map(col=>col.key);
    const row={type:'row',children:Array.from({length:width},(_,index)=>cell(`NEW${index}`))};
    const request={op:'insert',at:[1,1],content:[row]};
    const independent={...request,content:[{...row,children:row.children.slice(0,2)}]};
    const expected=applyEdits(schema,before,[independent]);
    const proposed=applyEdits(schema,before,[request]);
    const change=doc.edit([request],{normalize:true});
    const actual=doc.toJSON();
    assert.deepEqual(actual,expected);
    assert.deepEqual(applyEdits(schema,proposed,change.normalize),actual);
    assert.deepEqual(doc.blocks()[1].cols.map(col=>col.key),oldCols);
    assert(!change.ops.some(op=>op.t==='node' && op.type==='col'));
    assert(!change.ops.some(op=>op.t==='text' && op.text.includes('NEW2')));
    assert.deepEqual(actual.children[1].children[0],before.children[1].children[0]);
    assert.deepEqual(actual.children[1].children[2],before.children[1].children[1]);
    cases.push({width,status:'PASS',normalize:change.normalize,expected,actual});
}
console.log(JSON.stringify({status:'PASS',cases},null,2));
