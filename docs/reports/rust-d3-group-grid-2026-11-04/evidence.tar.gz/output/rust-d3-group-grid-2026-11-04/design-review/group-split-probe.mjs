import assert from 'node:assert/strict';
import {Doc} from '../../../packages/doc-sync/src/crdt/doc.ts';
import {applyEdits} from '../../../packages/doc-sync/src/crdt/model.ts';
import {WORD_SCHEMA} from '../../../fixtures/product-schemas.ts';

const doc = new Doc('design-probe', WORD_SCHEMA);
doc.edit([{op:'insert', at:[1], content:[{type:'section',children:[
    {type:'paragraph',runs:[]},
    {type:'list',attrs:{listType:'numbered'},children:[
        {type:'list-item',runs:[{text:'A'}]},
        {type:'list-item',runs:[{text:'B'}]},
    ]},
]}]}]);
const before = doc.toJSON();
const edit = {op:'insert',at:[1,1,1],content:[{type:'paragraph',runs:[{text:'X'}]}]};
const expected = applyEdits(WORD_SCHEMA,before,[edit]);
const change = doc.edit([edit]);
const actual = doc.toJSON();
assert.deepEqual(actual,expected);
assert.deepEqual(actual.children[1].children.map(node=>node.type),
    ['paragraph','list','paragraph','list','header','footer']);
assert.equal(actual.children[1].children[2].runs[0].text,'X');
assert(!change.ops.some(op=>op.attrs && 'listType' in op.attrs));
console.log(JSON.stringify({status:'PASS',check:'source TS paragraph at group member path splits group',before,edit,change,expected,actual},null,2));
