# Targeted implementation inspection

Source inspection of current runtime_paragraph.rs and runtime_structure.rs. No builds or native tests were run by this reviewer. The first four comparison PASS results were reported by other agents and are not reviewer execution evidence.

## Required correction proved with source TS

`group-split-probe.mjs` directly imports current TypeScript source. In Word section `paragraph,list(numbered:[A,B])`, inserting ordinary paragraph X at `[1,1,1]` yields `paragraph,list(A),paragraph(X),list(B),header,footer`. Both independent `applyEdits` and real `Doc.edit` agree. Generated paragraph birth has no inherited listType attribute. Thus restricting insertion at a Group reference to group-member kinds incorrectly rejects a valid group split. Use the enclosing flow's admission rules, filter unsupported compiler-inherited by attributes, and keep explicit user attribute validation strict. This was sent to the owner and root before further corpus work.

Saved probe execution: PASS in `group-split-result.json`. The first saved script run failed module loading because its relative import had one excess parent segment; corrected imports then passed. The earlier direct source stdin probe also passed. No product-source error was involved.

## Private compiled recording

The private method checks finite time, actor equality, freshness against the document's observed clock, text UTF-16 range capacity, and disjoint operation ticket intervals. Sorting a separate interval list does not alter emission order. The public monotonic `record` method remains unchanged. Commit uses the existing staged History checkpoint clone and swaps live server state only after a successful response. Existing pending entries stay on self and the new change is appended once. No guard or atomicity defect was found by this bounded source review. Undo/redo execution and typed checkpoint proof remain the implementation owner's verification responsibility.

## Additional narrow correction

`materialize_model_head` must check max0 on both the default stored type and its local group owner, matching TS `insertionEntries`. Checking only the stored default misses grouped-default max0 and can reserve unwanted preparation tickets. Sent to owner/root.

Cell schema ownership now uses the body shape. Covered cells are kept in grid model references. Cell field writes reserve all coarse tickets before expansion and retain supplied attribute order. Grid row and column updates use the refreshed stable-axis projection. Nontext insertion after a required predecessor is also explicitly rejected by TS, so that existing boundary does not need widening for this task.

Known object by-value property-order discrepancy in grouped entries was already identified by root; the approved resolution is reuse of the core pure grouping key helper. It is not newly qualified here.
