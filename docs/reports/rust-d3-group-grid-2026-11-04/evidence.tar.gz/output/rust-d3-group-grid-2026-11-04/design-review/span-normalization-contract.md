# Anchored span insertion contract

## Decision

The request-only `applyEdits` mismatch is expected for this case. It does not establish a production bug in model.ts or Doc.edit. Keep the stored inclusive endpoint IDs and the CRDT projection unchanged. No product source change is required by this evidence.

## Direct contract evidence

- `docs/edit-api.md:118`: spans use end-row/end-column IDs; covered cells remain in the full-grid model and retain content.
- `docs/edit-api.md:177-179`: a single-row cell insertion inserts a whole column and creates empty cells for the other rows.
- `docs/edit-api.md:202-204`: request normalization through `{normalize:true}` or an edit listener. Normalization reconciles a proposed model with the actual CRDT result. The documented examples expressly include merges that cover newly inserted axes.
- `packages/doc-sync/src/crdt/doc.ts:2270-2282`: the before/proposed/actual comparison is conditional; returned normalization is `diffModels(expected,after)`.
- `packages/doc-sync/test/fuzz-core.ts:179-181`: the model mirror applies requested edits, then the returned normalization.

## Independent complete-model oracle

For an existing merge on one axis, let its anchor index be `a` and its inclusive endpoint be `b = a + extent - 1`. Insert `n` axes at prior coordinate `i`:

- `i <= a`: shift the anchor by `n`; retain the extent.
- `a < i <= b`: retain the anchor; increase the extent by `n`.
- `i > b`: retain anchor and extent.

For a column insertion requested on just one row, independently insert an empty cell at the same coordinate in every other row. Preserve every old cell body. Then adjust affected old merge extents and run canonical model normalization. This constructs a full expected model from the pre-model, request coordinate and endpoint rule; it does not read actual projected span output. It is distinct from simply accepting production normalization as the independent oracle.

Separately verify the adapter contract: applying the request and then returned `normalize` must produce the actual complete model. This contract check uses the production delta intentionally; it cannot replace the independent model comparison.

## Executed source proof

`span-normalize-probe.mjs` directly imports current TypeScript source. Six cases PASS: row/column insertion before the old anchor, inside the inclusive old endpoint, and after the old endpoint. Each compares the entire actual model to the independently derived model and also checks request-plus-returned-normalize. None emits a `$span:` writer during the axis insertion. Saved execution: `span-normalize-result.json`.

Scope: one existing 2x2 merge, one inserted axis, retained source-cell text. This proves the assigned contract and boundary rule. It does not qualify arbitrary overlapping new merge payloads or all grid mutation combinations.
