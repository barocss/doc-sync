# D3 group/grid compiler design inspection

Source inspection only. No product edits or executions. Opening HANDOFF §5.154 is historical context, not current qualification.

## Required behavior

- `edit.ts:53` groups only adjacent text blocks. The owner must occur in the local flow's declared children. Compare canonical by-values, then the required-group source-line boundary. An unrelated schema group does not own a child.
- `edit.ts:582` flattens one group level. Attribute precedence is enclosing group target values, explicit wrapper by-values, then child attributes. Missing wrapper by-values do not override enclosing values. Child null remains an override before normalization.
- Group by attributes belong to the member text schema. Product `list` has no own attribute schema. Ordinary group `validate_attrs` must not reject valid `listType`.
- `edit.ts:902` births all row axes, then all column axes, then fills supplied cells in row-major order. Ragged cells retain automatic empty/default flow content. Row attributes are not authored by this method.
- `edit.ts:932` fills `cell.children[0].children`, then writes span metadata, then custom cell attrs in supplied order. No body node is born. `spanned` is computed and causes no attribute write.
- `edit.ts:951` reserves span/custom coarse-write tickets before `emit` expands structured attributes into later leaf-write tickets. Preserve reserved gaps and leaf order.
- `doc.ts:2180` emits every row/column cell in the full model, including covered cells. Covered-cell bodies remain model-addressable and retain content. A cover does not remove its source line.
- Row insertion authors every requested row before cell fills. Supplied excess cells past existing width are ignored. Column insertion is one column at a time; new columns use the current stable axis identities.

## First SDK gap

Opening `runtime_paragraph.rs:420` maps a non-root line to `node_kind(line.owner)`. This produces grid type for a cell body. Local-flow helpers must inspect line slot: `body` uses owner flow, `cell:*` uses grid -> row -> cell -> body schema. Existing `runtime_schema.rs:1523` has that schema traversal. Group owner, defaults, max0 and childRules all depend on it. No native-core change is established by this finding.

## Minimal discriminating cases

1. Insert a numbered group wrapper; one member supplies `listType:null`, another omits it. Confirm wrapper precedence, canonical defaults and split grouping.
2. Two distinct required groups with equal by-values must remain two model entries. A same-valued ordinary group should coalesce only when adjacent.
3. Create 1x2 grid: first cell colspan2, second cell text `HIDDEN`. Insert at `[tableIndex,0,1,0,1]`. Preserve `HIDDEN` plus the new block in the covered body, with computed `spanned` true.
4. Cell-body schema default belongs to a group, or default/group max0. Preparation must use body schema and touch only target/ancestor lines.
5. Cell structured attr plus later scalar attr: compare exact operation stamps, leaf order, History, undo/redo, own checkpoint restore.
6. New row after a foreign column receipt uses all current columns. Foreign grid row/column identities cannot form an admitted cell owner address.

## Explicit bounded policies

- Canonical body index is 0. TS currently consumes any body index; strict malformed-index rejection is a disclosed boundary.
- Empty group/grid insertion can be an atomic SDK rejection because the API promises a concrete returned Key; TS can no-op. Do not count that case as exact parity.
- Preserve existing fresh-head, virtual promotion and physical-fence rules. Do not add unique boundary suffixes or whole-model preparation walks.
