# Covered-cell selection patch review

Source SHA reviewed: nested.rs `41da63a70b7069cb8a9655aa47ec2253f15adfced236ac93fac6ad068727cc54`.

Result: no actionable defect found in the approved direct covered-cell selection correction. This is a read-only source verdict. Focused native execution PASS results were supplied by the implementation owner and were not rerun by this reviewer.

- runtime_covered_cell rejects non-runtime state and requires a direct cell slot with an existing owner, live owner grid projected under a visible parent, current row and column membership, and an actual covered-map entry.
- capture_nested_path keeps the old path/text/offset checks and captures the requested block marker or UTF-16 character key. It permits the covered runtime cell without replacing these raw anchors.
- resolve_nested_path selects the current effective movement line first. Visible destinations retain the old token path. A covered effective cell uses its retained line head through existing raw_position, reaching the merged top-left escape. This handles moved-in source tokens and avoids clamping moved-out tokens to their old covered physical source.
- The old missing/hidden rejection remains for all cases outside this helper, including deleted axes and deleted grids. Pinned legacy shapes continue to fail the helper and keep their previous hidden-null behavior. Superseded required slots do not qualify.
- New test source checks a backward UTF-16 range, stable raw anchors during merge, merged start resolution, own checkpoint, split restoration, moved-out and moved-in positions, deleted column and deleted grid. The earlier direct covered-cell test was updated to check capture and projected clamp.

Bound: helper handles direct cell bodies. Descendant flows beneath a covered cell are not admitted by this narrow correction. No general hidden-line selection behavior or legacy selection contract has been changed.
