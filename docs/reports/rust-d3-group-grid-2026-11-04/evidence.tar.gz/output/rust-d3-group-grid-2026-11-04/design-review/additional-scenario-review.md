# Additional schema-editing scenarios

Read-only source review against the current Q1–Q8 queue. No tests were run. The items below refine missing acceptance cases; they do not reopen completed TS work or claim native product readiness.

## 1. Authority must survive the read/prepare/commit boundary

**Rank: high. Missing acceptance coverage, not a missing TS authorization feature.** Q1.2/Q1.3 cover atomicity and stale versions. They do not state how a valid command behaves when its principal loses authority after preparation, while offline, or before undo/redo/retry. Schema validity and actor-owned History do not grant permission.

**Existing:** hosted tool authorization runs before session access (`apps/mcp/test/hosted.test.ts:29`); the tool map includes retry/undo/redo (`apps/mcp/src/hosted-auth.ts:14`). Proposal restart tests revoke the owner and preserve every recovery byte (`apps/mcp/test/proposal-process.test.ts:179`). HubOptions also has trusted payload and semantic policy hooks (`packages/doc-sync/src/server/hub.ts:57`).

**Add:** carry those existing host guarantees into the future native/session acceptance matrix. Revoke write or schema permission between preview and commit, then attempt direct edit, retry, undo, redo and schema transition. Require denial before mutation or persistence, while preserving pending evidence. Separate permission denial from stale-base rejection and unknown acceptance. Do not put a new ACL engine in the CRDT by assumption.

## 2. Persistent annotations need a separate endpoint oracle

**Rank: high. Existing TS feature; missing native command API and combined evidence.** Q7 names selection, but persistent annotations are not selections. A cursor may escape a covered cell; an annotation must report `hidden` with no range. Reusing the cursor resolver would attach a comment to unrelated visible text.

**Existing:** `docs/spec.md:97` states explicit missing/hidden/cross-slot/compacted statuses and GC pins. `packages/doc-sync/test/annotations.test.ts:103` checks hidden merged-cell endpoints and restoration; later cases cover backward affinity, independent metadata, snapshots and foreign undo. D3 already lists annotations (`docs/rust-roadmap.md:366`). Current runtime SDK source has selection helpers but no public annotation authoring API.

**Add:** a named annotation slice under Q3/Q4, then a Q6 pin/recovery fixture: annotate a cell paragraph, move/split it, merge the cell, insert axes, edit peer metadata, undo in both orders, restore and run protected GC. Check complete content plus annotation status/data/writer IDs. Content-only model equality cannot prove metadata preservation. Define whether combined content-and-annotation commands share the future batch transaction.

## 3. Model commands need an explicit schema-value handle contract

**Rank: medium. Actual bounded command-API gap.** Q4 distinguishes schema-source handles from document references, but it does not say how model commands preserve those handles.

**Existing:** `insert_runtime_block_in` accepts `SchemaAttributes` and binds schema-owned reference descriptors (`experiments/rust-sdk/src/runtime_schema.rs:714`). `insert_model_at` accepts plain `serde_json::Value` (`experiments/rust-sdk/src/runtime_paragraph.rs:36`). A JSON payload alone does not carry a SchemaValue's source descriptor identity. Existing D2 reference behavior must not be credited to this D3 entry point.

**Add:** define a typed model value or explicit companion binding input before claiming reference-aware model editing. Compare equal JSON from distinct default/enum sources, shared reference groups, field leaves, clone fallback, undo and checkpoint. Check writer/reference descriptors as well as the model. Keep the current plain-JSON boundary explicit until implemented.

## 4. Accepted state must stay accepted when observers fail or reenter

**Rank: medium. Existing TS behavior; missing cross-backend acceptance case.** Q6 injects transport/storage failure and Q7 checks listener cleanup. Neither explicitly covers a callback exception after acceptance or a listener that starts a second edit. Treating a callback error as edit failure can resend accepted work or lose History.

**Existing:** `apps/mcp/test/session.test.ts:247` checks confirmed edits with throwing local/event/update callbacks and retained undo. `packages/doc-sync/test/durable-staging.test.ts:59` checks a reentrant durable change after staged commit.

**Add:** reuse those cases for the future native host/editor boundary. Verify one accepted change and History action, recorded observer errors, no automatic resend, correct ordering for the reentrant edit, and exact recovery after checkpoint. This is an observable completion contract, not a request to make all listeners transactional.

## Do not duplicate existing queue items

Q1.2 already covers native atomic batches and column memo. Q1.3 already covers ID-relative/stale-path targeting. Q4 already covers atomic JSON arrays, common Map/List references, missing/null/default fields and target-kind rules. Q7 already covers paste/import/export and desktop composition. These need concrete receipts, not new claims that the TypeScript features are absent.
