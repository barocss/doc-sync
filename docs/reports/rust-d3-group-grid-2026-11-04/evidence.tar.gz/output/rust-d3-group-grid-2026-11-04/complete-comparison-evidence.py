from pathlib import Path
import gzip,hashlib,json,shutil

root=Path('/Users/user/github/doc-sync');task=root/'output/rust-d3-group-grid-2026-11-04'
def read(path):return json.loads(path.read_text())
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def receipt(folder):
    return sorted((task/folder).glob('*/receipt.json'))[-1]
def relative(path):return str(path.relative_to(root))
main_path=receipt('compare');main=read(main_path);assert main['status']=='PASS'
inherited_path=receipt('compare-regressions');inherited=read(inherited_path)
assert inherited['status']=='PASS' and inherited['hashesBefore']==inherited['hashesAfter']
for name,expected in inherited['hashesAfter'].items():assert sha(root/name)==expected,name
ts=read(main_path.parent/'typescript-trace.json')
oracles=sum(step.get('logicalOracle') is not None for doc in ts['documents'] for step in doc['trace'])
generated=[doc for doc in ts['documents'] if doc['name'].startswith('generated-schema-contract-')]
generated_actions=sum(len(doc['trace']) for doc in generated)
assert len(generated)==6 and generated_actions==120
regressions=[]
for folder,expected in [('moved',1062),('paragraph',466),('unused',84),('textfalse',90)]:
    path=receipt('compare-regression-'+folder+'-main');value=read(path)
    assert value['status']=='PASS' and value['semanticActions']==expected
    regressions.append({'name':folder,'receipt':relative(path),'status':'PASS',
                        'semanticActions':expected,'stateComparisons':expected*2})
bound_path=receipt('compare-policy-boundaries');bound=read(bound_path)
assert bound['status']=='OBSERVED_POLICY_BOUNDARY' and bound['hashesBefore']==bound['hashesAfter']
compression=[]
for directory in sorted(task.glob('compare*')):
    if not directory.is_dir():continue
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or path.suffix not in {'.json','.jsonl'} or path.stat().st_size<=1000000:continue
        target=path.with_name(path.name+'.gz');assert not target.exists(),str(target)
        expected=sha(path)
        with path.open('rb') as source,gzip.GzipFile(filename=str(target),mode='wb',compresslevel=6,mtime=0) as dest:
            shutil.copyfileobj(source,dest,1048576)
        h=hashlib.sha256();size=0
        with gzip.open(target,'rb') as stream:
            for chunk in iter(lambda:stream.read(1048576),b''):
                h.update(chunk);size+=len(chunk)
        assert h.hexdigest()==expected and size==path.stat().st_size,str(path)
        compression.append({'original':relative(path),'compressed':relative(target),'bytes':size,
                            'compressedBytes':target.stat().st_size,'sha256':expected,
                            'gzipSha256':sha(target),'roundtrip':'PASS','originalRetained':True})
        print(json.dumps({'compressed':path.name,'bytes':size,'roundtrip':'PASS'}),flush=True)
compression_path=task/'compare-compression.json';assert not compression_path.exists()
compression_path.write_text(json.dumps(compression,indent=2)+'\n')
qualified_dirs=[main_path.parent]+[root/item['receipt'].rsplit('/',1)[0] for item in regressions]
qualified=[item for item in compression if (root/item['original']).parent in qualified_dirs and Path(item['original']).name in {'typescript-trace.json','native-trace.json'}]
assert len(qualified)==10
summary={'status':'PASS','main':{'receipt':relative(main_path),'profiles':22,'schemas':10,'semanticActions':481,'stateComparisons':962,
                               'originalProductProfiles':14,'compositionProfiles':2,'generatedProfiles':6,
                               'fullIndependentInsertionModelOracles':oracles,
                               'actualTypescriptDocEditAuthorings':main['typescriptDocumentEdits'],
                               'rawTypescriptDocEmitAuthorings':main['typescriptRawWireAuthorings'],
                               'fourGuardedStages':[{key:row[key] for key in ['name','status']} for row in main['attempts']]},
         'q2':{'generatedProfiles':6,'semanticActions':generated_actions,'stateComparisons':generated_actions*2,
                'sourceFixturePass':19,'seeds':list(range(1701,1707)),
                'causalScheduleGenerator':'NOT_RUN','validityPreservingReducer':'NOT_RUN'},
         'inherited':{'receipt':relative(inherited_path),'status':'PASS','stages':inherited['results'],
                      'corpora':regressions,'exclusions':inherited['exclusions'],
                      'protectedMapsCurrent':len(inherited['hashesAfter']),
                      'newAdapters':'New namespace wrappers and copied admission oracles target the new native binary; original harnesses and old targets retained'},
         'policyBoundary':{'receipt':relative(bound_path),'status':bound['status'],'cases':bound['cases'],
                           'scope':bound['scope'],'binary':bound['hashesBefore']},
         'before':{'receipt':relative(receipt('compare-before')),'status':'OBSERVED_OLD_REJECTION','cases':3},
         'compression':{'manifest':relative(compression_path),'records':len(compression),
                        'rawBytes':sum(row['bytes'] for row in compression),'gzipBytes':sum(row['compressedBytes'] for row in compression),
                        'qualifiedFullTraces':qualified,'rawOriginalsRetained':True},
         'limits':['No new browser/mobile/performance/WASM/process/server qualification','Fixed generated schedules; no arbitrary-schema guarantee']}
destination=task/'compare-summary.json';assert not destination.exists()
destination.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'PASS','oracles':oracles,'generatedActions':generated_actions,'compressed':len(compression),'qualifiedFullTraces':len(qualified)}))
