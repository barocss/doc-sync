from pathlib import Path
import hashlib,json,re,sys

root=Path('/Users/user/github/doc-sync')
task=root/'output/rust-d3-group-grid-2026-11-04'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
baseline=json.loads((task/'baseline.json').read_text())['files']
allowed={
    'HANDOFF.md','README.md','apps/docs/src/guide/blocks.md',
    'apps/docs/src/guide/document-rules.md','apps/docs/src/guide/editing.md',
    'apps/docs/src/guide/rust.md','apps/docs/src/roadmap.md',
    'apps/docs/src/schemas/custom.md','apps/docs/src/schemas/document.md',
    'docs/rust-roadmap.md','experiments/rust-sdk/README.md',
    'experiments/rust-sdk/src/runtime_paragraph.rs',
    'experiments/rust-shadow/src/lib.rs','experiments/rust-shadow/src/nested.rs',
}
changed=[];unchanged=[]
for name,old in baseline.items():
    new=sha(root/name)
    if new==old:unchanged.append(name)
    else:
        assert name in allowed, 'Unexpected inherited change: '+name
        changed.append({'path':name,'before':old,'after':new})
for prefix in ['packages/doc-sync/src/crdt/','packages/doc-sync/dist/crdt/',
               'experiments/runtime-document-']:
    assert all(row['path'][:len(prefix)]!=prefix for row in changed),prefix
pins=json.loads((task/'before-pins.json').read_text())
assert sha(root/pins['binary'])==pins['sha256']
seals=json.loads((task/'earlier-seals.json').read_text())
for row in seals:
    report=root/row['report'];seal=report/'seal.json'
    assert sha(seal)==row['sealSha256'],str(seal)
    for name,expected in json.loads(seal.read_text())['files'].items():
        assert sha(report/name)==expected,str(report/name)
program=(root/'experiments/rust-sdk/examples/runtime_group_grid.rs').read_text().strip()
for doc in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
    assert program in re.findall(r'```rust\n(.*?)\n```',(root/doc).read_text(),re.S),doc
for consumer in ['consumer-readme','consumer-guide']:
    assert (task/consumer/'src/main.rs').read_text().strip()==program,consumer
native_map=json.loads((task/'structural-final-v2-source-hashes-after.json').read_text())['files']
for name,expected in native_map.items():
    assert sha(root/name)==expected,'Native final map drift: '+name
main_receipt=next((task/'compare').glob('*/receipt.json'))
main=json.loads(main_receipt.read_text())
assert main['status']=='PASS'
for name,expected in main['sourceHashes'].items():
    assert sha(root/name)==expected,'Main final map drift: '+name
log=(task/'workspace-test-final-v2.log').read_text();totals={}
for key,n in re.findall(r'^[ℹ#] (tests|pass|fail|cancelled|skipped) (\d+)$',log,re.M):
    totals[key]=totals.get(key,0)+int(n)
assert totals=={'tests':2162,'pass':2160,'fail':0,'cancelled':0,'skipped':2},totals
result={'status':'PASS','baselineFiles':len(baseline),'changedPaths':changed,
        'unchangedPaths':unchanged,'priorSealedReportsUnchanged':len(seals),
        'beforeNativeBinaryUnchanged':pins,'typescriptProductionAndDistUnchanged':True,
        'wholeWorkspaceRetryTotals':totals,'fullExampleFencesAndConsumersExact':True,
        'nativeFinalSourceMapCurrent':len(native_map),
        'mainFinalSourceAndBinaryMapCurrent':len(main['sourceHashes']),
        'extraSnapshots':['baseline-extra.json','baseline-navigation-test.json']}
destination=task/(sys.argv[1] if len(sys.argv)>1 else 'preservation-final.json')
assert not destination.exists(),'Use new receipt name'
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ['status','baselineFiles','priorSealedReportsUnchanged','typescriptProductionAndDistUnchanged','wholeWorkspaceRetryTotals']}))
