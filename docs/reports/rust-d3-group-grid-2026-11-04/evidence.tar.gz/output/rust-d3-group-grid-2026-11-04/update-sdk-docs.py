from pathlib import Path
r=Path('/Users/user/github/doc-sync');program=(r/'experiments/rust-sdk/examples/runtime_group_grid.rs').read_text().rstrip()
section='''### Insert groups, grids and cell contents by model path

Use the existing `insert_model_at` for nonempty text-list groups, tables and
supported flow/text children. Paths select current model children, including
existing moved structures. The schema determines the node names and cell body
type; the compiler does not require the names in this example.

A text `group` is a derived wrapper. Its declared `by` values are inherited by
members, and explicit member values win. The returned key identifies the first
stored member. It is not a separate wrapper ID. Inserting a parent-admitted
paragraph or table at a group member gap can split the wrapper into two groups.
A stored flow/container is the right choice for an object group with its own ID
or table children.

For a table at root child index `g`, the accepted paths include:

| Path | Effect | Returned key |
| --- | --- | --- |
| `[g]` | Insert a table at the root child gap | New grid identity |
| `[g, rowGap]` | Insert a row into an existing table | New row axis identity |
| `[g, row, colGap]` | Insert a column across all rows; fill the selected row | New column axis identity |
| `[g, row, col, 0, childGap]` | Insert in the selected cell body's children | Inserted stored identity |

Nested tables use the corresponding longer parent path. The body selector is
`0`. Covered cells remain addressable and keep their content. New ragged tables
use the maximum supplied row width and implicit missing cells. In an existing
table, row insertion keeps its current width; valid excess supplied cells are
ignored by the existing command contract. Insert columns explicitly when needed.
These are dense document-table models. Use the separate Spreadsheet APIs for
sparse sheets.

Cell content is filled before spans and custom attributes. Cell field patches
retain input order, including a structured branch beside scalar attributes.
`rowspan` and `colspan` use positive integer or null input and clamp to the
available axes. `spanned` is computed and is not written as an ordinary field.
A merge hides content in the editor without deleting the retained cell data.

Each call is one atomic native History transaction. A rejected input preserves
the original state, clock, History and pending queue. Existing physical helpers
keep their source-token contracts. Multiple calls do not implement the shared
column memo of a multi-command TS batch; atomic batch editing is a later D3 gate.
Axis moves are also separate from model insertion.

Empty groups and tables with no rows or no columns reject before mutation: the
existing `(Key, Change)` result cannot identify an absent stored result. TS can
normalize these inputs to no insertion, so this is a recorded policy boundary.
Malformed values, uncompiled row/body-wrapper attributes and a nonzero body
selector also reject. General node attribute maps still retain the earlier
mixed structured-branch limits; this cell-attribute expansion is not arbitrary
node-attribute normalization or JSON reference-handle input support.

Run `cargo run --offline --locked --manifest-path experiments/rust-sdk/Cargo.toml
--example runtime_group_grid` from the repository root. This complete program
checks derived groups, row and column identities, cell paths, foreign fields,
selection, undo/redo, pending retries and own JSON checkpoint restoration:

```rust
'''+program+'\n```\n'
for n in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
 p=r/n;s=p.read_text();s=s.replace('This API is bounded. It rejects grid/group model nodes and parents, text-offset\npaths and a supplied attribute map that', 'This API is bounded. Text-offset paths and a supplied node attribute map that')
 s=s.replace('This API is bounded. It rejects grid/group model nodes and parents, text-offset\npaths, documents with movement operations, and a supplied attribute map that', 'This API is bounded. Text-offset paths and a supplied node attribute map that')
 s=s.replace('The bounded input remains text or flow/text trees. Grid/group construction,\ntext-offset paths, mixed structured attribute maps, trailing reserved-only', 'Group/grid construction and paths now use `insert_model_at` as described below.\nText-offset paths, mixed structured node attribute maps, trailing reserved-only')
 assert '### Insert groups, grids and cell contents by model path' not in s
 p.write_text(s.rstrip()+'\n\n'+section)
for label in ['readme','guide']:
 f=r/f'output/rust-d3-group-grid-2026-11-04/consumer-{label}';(f/'src').mkdir(parents=True,exist_ok=True);(f/'src/main.rs').write_text(program+'\n');(f/'Cargo.toml').write_text(f'''[package]\nname="group-grid-{label}-consumer"\nversion="0.0.0"\nedition="2021"\n\n[dependencies]\ndoc-sync-native-sdk={{path="../../../experiments/rust-sdk"}}\nserde_json="1"\n\n[workspace]\n''')
print('SDK and public guide updated; two independent consumers prepared')
