from pathlib import Path
import json,hashlib,re,subprocess

root=Path('/Users/user/github/doc-sync');task=root/'output/rust-d3-group-grid-2026-11-04'
report=root/'docs/reports/rust-d3-group-grid-2026-11-04'
def read(path):return json.loads(path.read_text())
def ref(path):return {'path':str(path.relative_to(root)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
main_path=next((task/'compare').glob('*/receipt.json'));main=read(main_path)
assert main['status']=='PASS'
native=read(task/'structural-final-receipt.json');assert native['status']=='PASS'
for name in ['workspace-test-final-v2','typecheck-final','docs-build-final','docs-check-final']:
    assert read(task/(name+'.json'))['status']=='PASS',name
summary_path=task/'compare-summary.json';summary=read(summary_path)
assert summary['status']=='PASS' and summary['inherited']['status']=='PASS'
assert len(summary['compression']['qualifiedFullTraces'])==10
preservation_path=task/'preservation-final-v2.json';preservation=read(preservation_path)
assert preservation['status']=='PASS'
doclog=(task/'docs-check-final.log').read_text()
docs=json.loads(next(line for line in doclog.splitlines() if line.startswith('{"pages"')))
status=subprocess.check_output(['git','status','--short'],cwd=root,text=True)
(task/'final-status.txt').write_text(status)
result={
    'status':'BOUNDED_PASS_D3_GROUP_GRID_AND_Q2_1',
    'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'scope':'Bounded native model group/grid/row/cell construction, direct covered-cell selections and six generated schema fixed-sequence comparisons; not complete D3 or production Rust/WASM',
    'main':{**{key:main[key] for key in ['status','profileCount','schemaCount','semanticActions','originalProductProfiles','originalProductSchemaCount','compositionProfiles','generatedProfiles','generatedSchemaCount','generatedSeeds','preexistingMoveProfiles','typescriptDocumentEdits','typescriptRawWireAuthorings','positiveCorpusSha256']},
            'stateComparisons':main['semanticActions']*2,
            'receipt':ref(main_path),
            'fourGuardedStages':[{key:stage[key] for key in ['name','status']} for stage in main['attempts']],
            'sourceAndBinaryMapCurrent':preservation['mainFinalSourceAndBinaryMapCurrent']},
    'native':{'receipt':ref(task/'structural-final-receipt.json'),'corePass':189,'sdkPass':152,
              'fullExample':True,'independentLockedConsumers':2,'sourceMapCurrent':preservation['nativeFinalSourceMapCurrent'],
              'inheritedExamplesTestsUnchanged':72,'trace':native['trace'],'cli':native['cli']},
    'comparisonSummary':ref(summary_path),
    'independentInsertionModelOracles':summary['main']['fullIndependentInsertionModelOracles'],
    'inheritedRegressions':summary['inherited']['corpora'],
    'q2SourceFixture':{'receipt':ref(task/'research/q2-receipt-v2.json'),'pass':19,'seeds':list(range(1701,1707)),
                       'nativeFixedSequenceActions':120,'nativeFixedSequenceProfiles':6,
                       'generatedCausalSchedules':'NOT_RUN','validityPreservingReducer':'NOT_RUN'},
    'workspace':{'receipt':ref(task/'workspace-test-final-v2.json'),**preservation['wholeWorkspaceRetryTotals'],
                 'command':'npm run test --workspaces --if-present',
                 'boundary':'Final whole-workspace retry used existing completed package builds; initial navigation golden failure retained separately'},
    'typecheck':ref(task/'typecheck-final.json'),
    'whitespace':ref(task/'whitespace-final-v2.json'),
    'docs':{**docs,'buildReceipt':ref(task/'docs-build-final.json'),'checkReceipt':ref(task/'docs-check-final.json'),
            'fullRustExampleFencesMatchConsumers':True},
    'preservation':ref(preservation_path),
    'notRun':['Chrome','mobile','performance benchmark','production WASM/editor integration','mixed-runtime checkpoint/wire exchange',
              'native durable process/server restart','protected native GC','general generated causal schedules and shrinking'],
    'publication':{'commit':False,'push':False,'deployment':False,'registry':False},
}
destination=report/'final-checks.json';assert not destination.exists()
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'mainActions':main['semanticActions'],'docs':docs}))
