from pathlib import Path
import os,json,hashlib,tarfile

root=Path('/Users/user/github/doc-sync')
task=root/'output/rust-d3-group-grid-2026-11-04'
report=root/'docs/reports/rust-d3-group-grid-2026-11-04'
selected=set();excluded=[]
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def reject(path,reason,hashit=True):
    excluded.append({'path':str(path.relative_to(root)),'bytes':path.stat().st_size,
                     'reason':reason,**({'sha256':sha(path)} if hashit else {})})
for base,dirs,files in os.walk(task):
    dirs[:]=[d for d in dirs if 'target' not in d and d not in {'baseline-source','before-src','before-source','baseline'}]
    for name in files:
        path=Path(base)/name
        if path.suffix=='.stdout':reject(path,'duplicate raw stdout',False);continue
        if path.suffix=='' and os.access(path,os.X_OK):reject(path,'loose executable omitted; digest and sources retained');continue
        if path.suffix not in {'.json','.jsonl','.gz','.diff','.log','.rs','.mjs','.ts','.py','.toml','.lock','.md','.stderr','.patch','.txt','.sha256'}:continue
        if name.endswith('.tar.gz'):
            with tarfile.open(path,'r:gz') as archive:
                binary=any(any('target' in part for part in Path(member.name).parts) for member in archive.getmembers())
            if binary:reject(path,'binary-containing bundle; code snapshots retained separately');continue
        if path.stat().st_size>8388608 and path.suffix in {'.json','.jsonl'}:
            reject(path,'large raw trace retained locally; verified lossless gzip selected');continue
        selected.add(path)
baseline=json.loads((task/'baseline.json').read_text())['files']
selected.update(root/name for name in baseline)
for folder in ['experiments/rust-sdk','experiments/rust-shadow']:
    for base,dirs,files in os.walk(root/folder):
        dirs[:]=[d for d in dirs if 'target' not in d]
        for name in files:
            path=Path(base)/name
            if path.suffix in {'.rs','.toml','.lock','.json'}:selected.add(path)
for folder in ['experiments/runtime-document-group-grid','experiments/runtime-document-schema-contract']:
    selected.update(path for path in (root/folder).glob('*') if path.is_file())
for name in ['docs/schema-editing-roadmap.md','apps/docs/src/schemas/editing-contract.md',
             'apps/docs/.vitepress/config.mts','apps/docs/test/navigation.test.mjs',
             'docs/reports/rust-d3-group-grid-2026-11-04/README.md',
             'docs/reports/rust-d3-group-grid-2026-11-04/final-checks.json']:
    selected.add(root/name)
assert all(path.exists() for path in selected)
files=[{'path':str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':sha(path)} for path in sorted(selected)]
destination=report/'evidence.tar.gz'
assert not destination.exists(),'Do not replace a sealed archive'
with tarfile.open(destination,'w:gz',compresslevel=6) as archive:
    for path in sorted(selected):archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
manifest={'status':'SELECTED_EVIDENCE_SEALED',
          'baseline':'main1cfb7a2 plus captured265-file opening baseline and separate config/navigation snapshots; inherited WIP preserved',
          'archive':{'path':destination.name,'bytes':destination.stat().st_size,'sha256':sha(destination)},
          'files':files,'excludedLocalArtifacts':excluded,
          'scope':'Current source, selected full compressed comparison traces, compact diagnostics, baselines and checks; no targets or executable bundles'}
(report/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(destination,'r:gz') as archive:
    for item in files:
        h=hashlib.sha256()
        stream=archive.extractfile(item['path'])
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
        assert h.hexdigest()==item['sha256'],item['path']
seal={'status':'PASS','files':{path.name:sha(path) for path in [report/'README.md',report/'final-checks.json',report/'manifest.json',destination]},'archiveMembersVerified':len(files)}
(report/'seal.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'members':len(files),'archiveBytes':destination.stat().st_size,'excluded':len(excluded),'readback':'PASS'}))
