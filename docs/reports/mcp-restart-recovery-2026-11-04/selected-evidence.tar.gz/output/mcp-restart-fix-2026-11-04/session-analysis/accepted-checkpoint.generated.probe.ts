import assert from "node:assert/strict";
import {mkdtemp, readFile, rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {test} from "node:test";
import type {Schema} from "@barocss/doc-sync";
import {DocHub} from "@barocss/doc-sync/server";
import type {Change, Outbound, Presence, ServerEvent, Transport} from "@barocss/doc-sync/sync";
import {DEMO_SCHEMA} from "/Users/user/github/doc-sync/fixtures/demo-schema.ts";
import {IntentJournal} from "/Users/user/github/doc-sync/apps/mcp/src/journal.ts";
import {DocumentSession} from "/Users/user/github/doc-sync/apps/mcp/src/session.ts";

class DurableHubTransport implements Transport {
    dropOwnEcho = false;
    receiptUnknown = false;
    loseRelease = false;
    failReserve: "before" | "after" | null = null;
    releases = 0;
    private callback: ((event: ServerEvent) => void) | null = null;
    readonly hub: DocHub;
    readonly actor: string;
    constructor(hub: DocHub, actor: string) { this.hub = hub; this.actor = actor; }
    subscribe(since: number, onEvent: (event: ServerEvent) => void, epoch?: string): () => void {
        this.callback = onEvent;
        this.hub.connect(this.actor, since);
        const stop = this.hub.listen(event => {
            if (!(this.dropOwnEcho && event.type === "change" && event.envelope.change?.actor === this.actor)) onEvent(event);
        });
        onEvent(this.hub.hello(since, epoch));
        return () => { stop(); this.hub.disconnect(this.actor); };
    }
    async send(message: Outbound): Promise<void> {
        if (message.kind === "change") this.hub.submit(message.change);
        else this.hub.ack(message.ack);
    }
    sendPresence(presence: Presence): void { this.hub.setPresence(presence); }
    async getSchema() { return {schemaVersion: this.hub.schemaVersion, schema: this.hub.getSchema()}; }
    async getRecoveryState() { return {generation: this.hub.generation, epoch: this.hub.epoch, serverSeq: this.hub.serverSeq, schemaVersion: this.hub.schemaVersion}; }
    async transitionSchema(base: {epoch: string; serverSeq: number; schemaVersion: string}, schema: Schema) {
        return {schemaVersion: this.hub.transitionSchema(schema, base)};
    }
    async submitConditional(base: {epoch: string; serverSeq: number; schemaVersion: string | null}, change: Change) {
        const envelope = this.hub.submitConditional(change, base);
        return {status: "accepted" as const, serverSeq: envelope.serverSeq};
    }
    async getRecoveryReceipt(generation: string, base: {epoch: string; serverSeq: number; schemaVersion: string | null}, change: Change) {
        return this.hub.findConditionalReceipt(generation, base, change);
    }
    async getChangeReceipt(generation: string, change: Change) {
        return this.receiptUnknown ? {status: "unknown" as const} : this.hub.findChangeReceipt(generation, change);
    }
    async reserveRecovery(generation: string, id: string, pin: number | null, requireExisting = false) {
        const fail = this.failReserve; this.failReserve = null;
        if (fail === "before") throw new Error("reservation unavailable");
        const result = this.hub.reserveRecovery(generation, this.actor, id, pin, requireExisting);
        if (fail === "after") throw new Error("reservation response lost");
        return result;
    }
    async releaseRecovery(generation: string, id: string) {
        this.releases++;
        const result = this.hub.releaseRecovery(generation, this.actor, id);
        if (result.status !== "released") throw new Error("release unsafe");
        if (this.loseRelease) { this.loseRelease = false; throw new Error("release response lost"); }
    }
    async recoverChange(generation: string, id: string, version: string, change: Change) {
        if (this.hub.submitRecovery(generation, id, version, change).status !== "accepted") throw new Error("recovery unavailable");
    }
    deliverOwnEcho() {
        for (const envelope of this.hub.since(0)) if (envelope.change?.actor === this.actor) this.callback?.({type: "change", envelope});
    }
}


test("accepted intent checkpoint survives cleanup-before-unlink failure and restart", async () => {
 const directory = await mkdtemp(join(tmpdir(), "doc-sync-accepted-cp-probe-"));
 const path = join(directory, "doc.json");
 const journal = await IntentJournal.open(path, {document: "doc", actor: "ai"});
 const hub = new DocHub({schema: DEMO_SCHEMA, generation: crypto.randomUUID()});
 hub.onRecoveryPin = () => undefined;
 const transport = new DurableHubTransport(hub, "ai");
 const original = new DocumentSession("ai", transport, DEMO_SCHEMA, 100, journal);
 let resumed: DocumentSession | undefined;
 try {
   await original.start();
   const before = await original.read(); assert.ok(before.revision);
   journal.clearAfterConfirmed = async () => {throw new Error("clear interrupted before unlink");};
   const edit = await original.edit(before.revision, [{op: "insert", at: [0, 0], content: "saved"}]);
   assert.equal(edit.status, "confirmed");
   const record = await journal.read(); const cp = await journal.readCheckpoint(); assert.ok(record); assert.ok(cp);
   assert.equal(cp.sourceIntentDigest, record.recordDigest);
   assert.equal(cp.client.pending.length, 0);
   assert.equal(cp.client.serverSeq, record.base.serverSeq + 1);
   await original.close();
   const opened = await IntentJournal.open(path, {document: "doc"});
   resumed = new DocumentSession(opened.actor, new DurableHubTransport(hub, opened.actor), DEMO_SCHEMA, 100, opened);
   await resumed.start();
   const status = await resumed.recoveryStatus();
   console.log(JSON.stringify({status, recordBase: record.base.serverSeq, checkpointServerSeq: cp.client.serverSeq, sameDigest: cp.sourceIntentDigest === record.recordDigest}));
   assert.equal(status.status, "clear");
   assert.equal(hub.serverSeq, 1);
 } finally {await resumed?.close(); await original.close(); await rm(directory, {recursive: true, force: true});}
});
