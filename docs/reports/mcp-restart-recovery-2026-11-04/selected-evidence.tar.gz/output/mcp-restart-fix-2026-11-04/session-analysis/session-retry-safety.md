# Session restore and retry safety

Workspace: `/Users/user/github/doc-sync`; reviewed inherited WIP on `ec9622571a04a7d7ea3f967bb3e6423b17ce5194`.
No product source or real test changes made by this investigator.

## Current reproduction

- Pinned Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`.
- Exact current `MCP killed during undo after-accept` case: PASS 1/1; test 1884.229416 ms, invocation 2383.623958 ms.
- Output-only generated probe repeats the same complete scenario 30 times. Original assertions retained. It adds current server state and durable checkpoint to the existing second-restart diagnostic and writes that diagnostic on failure.
- Result: PASS 30/30, 0 FAIL, 0 SKIP, 0 CANCELLED; 37549.293958 ms. No failure file generated. Each case uses its own temporary journal/data and spawned processes.
- This is **NOT_REPRODUCED**, not proof of a fix or explanation of the original second-restart failure.

## Source findings

`DocumentSession.start()` awaits `restoreCheckpoint()` and catches its failure into `recoveryError`. The stdio lifecycle waits for `session.start()` before SDK admission. A ready client with `recovery_required` has a completed failed bootstrap, not pending background restoration.

`saveCheckpoint()` captures the client synchronously. `SyncClient.checkpoint()` captures engine history, snapshot, seq, serverSeq, deletion sequences and pending in a single structured clone. Journal writes are serialized and verify restored checkpoint and digest before returning. History and conditional session operations are serialized. No session checkpoint-save race was found.

## Retry phases

| Phase | Relevant operations | Same operation can be repeated safely? | Constraint |
| --- | --- | --- | --- |
| Server identity proof | recovery-state | Yes, read only | Validate generation/schema/serverSeq against original checkpoint after every response. |
| History protection proof | recovery-lease | Yes, exact same generation/actor/reservation/pin/requireExisting | Keep original reservation ID and requireExisting. Do not turn unsafe or missing reservation into a new one. Server retains minimum floor. |
| Conditional receipt proof | exact receipt | Yes, read only | Never infer rejection from unknown or failed HTTP. |
| Pending atomic recovery | recover-change | Yes | Repeat exact generation/reservation/schema/change. Server checks full accepted receipt before append. Never ordinary-send the pending operation. |
| Local checkpoint/intent install | client.restoreCheckpoint / restoreAcceptedIntent | No whole-restore retry on same client | Pending and history can already be installed. Restore rejects clients with pending. Fresh SyncClient is necessary for retry from original checkpoint after this boundary. |
| SSE connect / snapshot / ack | connect and synchronization | Not by blindly rerunning whole restore | Client engine/pending/history/connectionError may have changed. Disconnect does not discard pending. Fresh client required before replaying original restore. Preserve original durable checkpoint until proof succeeds. |
| Durable checkpoint write | saveCheckpoint | Must remain fail-closed unless storage outcome is revalidated | Retry does not justify clearing journal or ignoring corrupt/foreign checkpoint. |
| Journal clear | clearAfterConfirmed | Must retain exact intent digest | Failed clear can leave accepted record; the exact receipt plus checkpoint source digest is the existing recovery path. |

A bounded retry at the transport operation boundary is smaller and safer than rerunning whole restore. Recovery-state, lease, receipt and atomic recover can retry only their exact idempotent requests on transport failure / selected transient HTTP status. A successful but unsafe response, mismatched generation/schema/history, invalid protocol/snapshot, corrupt checkpoint and storage failure must remain fail-closed. Ordinary `send`, conditional submission, schema transition and history creation must not inherit blanket mutation retries.

A whole-restore retry that reaches local installation must recreate SyncClient from the initial actor/schema, discard only that failed in-memory client, restore the unchanged original durable checkpoint, re-prove generation/reservation/receipts, and never carry the failed attempt's partial pending/history/connection state into the next attempt. It also needs careful handling if an accepted-intent checkpoint was durably advanced before synchronization failed. This complexity is unnecessary for the known transient pre-install HTTP cases.

## Files

- `exact-undo-after-accept.log`: exact existing case receipt.
- `repeated.generated.probe.ts`: output-only generated probe, not a package test.
- `repeated-30.log`: bounded 30-case receipt.

Original historical response body remains absent. No claim links any injected transport failure to the unknown original error.

## Deterministic accepted-intent checkpoint defect

`accepted-checkpoint.generated.probe.ts` fails on current product source; `accepted-checkpoint.log` retains the receipt. The probe uses the existing test DurableHubTransport plus a real journal. It throws in `clearAfterConfirmed` before unlink, after a real accepted conditional edit and successful settled checkpoint save. It closes/reopens the journal and starts a fresh DocumentSession.

Observed facts:

- accepted record base serverSeq = 0;
- durable checkpoint serverSeq = 1;
- checkpoint sourceIntentDigest equals the accepted recordDigest;
- checkpoint pending is empty;
- exact conditional server receipt is accepted at serverSeq 1;
- fresh start returns `recovery_required`, message `An unresolved conditional edit needs inspection`;
- desired immediate `clear` assertion fails (1 FAIL, 162.434542 ms test / 526.671333 ms invocation).

Cause: `restoreCheckpoint` rejects record.base.serverSeq < checkpoint.client.serverSeq before distinguishing an intent already installed in that checkpoint by exact sourceIntentDigest. Normal `finishConditional` saves the settled checkpoint before clearing the intent. A crash or clear error in that durable boundary therefore leaves valid paired evidence that the next start rejects.

This is a real independent restore defect. It does **not** establish the cause of the historical undo repeated-restart failure, whose earlier conditional record had already been cleared.

A fix must distinguish digest-matching already-installed intent from not-yet-installed intent before applying the base revision ordering guard. For matching digest, require exact accepted receipt, matching intent change sequence to checkpoint client sequence, empty checkpoint pending, and checkpoint serverSeq at or after the intent base. Do not require accepted receipt serverSeq to be at or before checkpoint serverSeq universally: the existing pre-SSE `restoreAcceptedIntent` save legitimately records the installed actor seq with the old server cursor; the subsequent authoritative snapshot settles that state. For differing digest, retain base serverSeq >= checkpoint serverSeq and change.seq == checkpoint.seq + 1 before installing the intent once.

## Implemented fix and final focused receipt

Parent assigned ownership of `apps/mcp/src/session.ts` and new `apps/mcp/test/accepted-checkpoint-restart.test.ts` after the deterministic failure above. No other product files changed by this investigator.

`restoreCheckpoint` now:

1. Requires the original generation, reservation, exact conditional receipt and empty pending state as before.
2. Distinguishes a digest-matching installed intent from an intent that must follow the older checkpoint. The installed path requires exact actor sequence equality and checkpoint cursor >= intent base. It does not install History again. The older-checkpoint path keeps the original base-cursor and next-sequence rules.
3. Reads fresh authoritative recovery state after remote proofs, before main local restoration. It checks generation, schema and a minimum cursor equal to max(checkpoint cursor, accepted conditional receipt cursor). This allows a same-generation hub reopen with a new epoch while rejecting lost accepted history.
4. Synchronizes a fresh snapshot and durably saves it before clearing the exact retained intent record.

Final dedicated regression file: **PASS 11/11, 0 FAIL, 0 SKIP, 0 CANCELLED**, invocation 1379.6175 ms. `accepted-checkpoint-tests.log` is the final receipt. `git diff --check` passes for both owned files.

Healthy cases cover settled accepted checkpoint, installed pre-snapshot checkpoint, older not-yet-installed checkpoint, another restart, no ordinary resend, exact server sequence, preserved human text, one undo group and redo. Safety cases cover digest mismatch, installed actor sequence mismatch, unknown receipt, missing original reservation, post-proof generation/schema changes and lost accepted history after a pre-snapshot checkpoint. They preserve checkpoint and intent bytes, do not subscribe or ordinarily resend, and block undo. The epoch case replays real DocHub log, exact conditional receipt and original recovery pins into a new same-generation hub after reserve, then verifies immediate clear and working undo.

A seven-case output-only copy of the new suite imported the unchanged pre-fix HEAD Session from `baseline-session.ts`: **3 FAIL / 4 PASS**. The settled accepted cleanup, installed sequence mismatch and same-generation reopen cases fail there and pass with the fix. `baseline-accepted-checkpoint-tests.log` preserves that discriminating baseline. This baseline is not the final 11-case file and is not a full test-suite result.

Frozen SHA-256:

- Session: `02cccd332821d608a920d42ebf4af2dff086de4e784e4a91107af43811a254ff`.
- New regression test: `456ad7ea1aa5ca44cf8636329260dfead23b250db2a3408f754ea953c4f5354d`.

The historical undo repeated-restart failure remains **NOT_REPRODUCED / exact original cause unknown**. The accepted-intent cleanup defect and same-generation epoch refresh are independently reproduced and fixed. Parent owns integration build/full focused process verification and docs. No commit, push, mobile or browser test was performed here.
