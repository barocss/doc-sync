// Output-only diagnostic transform. Product source and package artifacts stay unchanged.
import {registerHooks} from 'node:module';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const target = new URL('../../../apps/demo/server.ts', import.meta.url).href;
registerHooks({load(url, context, nextLoad) {
  if (url !== target) return nextLoad(url, context);
  const result = nextLoad(url, context);
  let source = typeof result.source === 'string' ? result.source : Buffer.from(result.source).toString('utf8');
  const replacements = [
    ['function invalidateHub(doc: string, hub: DocHub): void {', `function invalidateHub(doc: string, hub: DocHub): void {\n console.error('[server-trace]', JSON.stringify({kind:'invalidateHub', doc, epoch:hub.epoch, generation:hub.generation, serverSeq:hub.serverSeq, stack:new Error().stack}));`],
    ['    res.writeHead(status, {"content-type": type, "cache-control": "no-store"});', `    if (res.req?.url?.includes('/recovery-state') || res.req?.url?.includes('/recovery-lease') || status >= 400) console.error('[server-trace]', JSON.stringify({kind:'http', url:res.req?.url, method:res.req?.method, status, body}));\n    res.writeHead(status, {"content-type": type, "cache-control": "no-store"});`],
    ['    const hello = hub.hello(since, epoch);', `    const hello = hub.hello(since, epoch);\n console.error('[server-trace]', JSON.stringify({kind:'hello', doc, actor, epoch:hub.epoch, generation:hub.generation, serverSeq:hub.serverSeq, since, requestedEpoch:epoch}));`],
  ];
  for (const [needle, replacement] of replacements) {
    if (!source.includes(needle)) throw new Error('Diagnostic source anchor missing: '+needle);
    source = source.replace(needle, replacement);
  }
  return {...result, source};
}});
