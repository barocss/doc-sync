---
work_id: mcp-restart-fix-2026-11-04
artifact_type: code_review
status: done
owner_role: independent_high_reviewer
source_request: Parent-assigned read-only safety review of recovery retry and accepted-checkpoint fixes
last_updated: 2026-11-04
---

# Final independent source review

**No open actionable finding in the reviewed final source.** This is a source/focused-probe review, not a whole-workspace or historical-cause PASS.

Frozen files reviewed:

- `apps/mcp/src/session.ts`: SHA256 `02cccd332821d608a920d42ebf4af2dff086de4e784e4a91107af43811a254ff`.
- `packages/doc-sync/src/sync/node-http-transport.ts`: SHA256 `59a344046b3b428c5aeb594d7b07f7e9a5fc1b4f009cf59dab8f4d0d9631421b`.
- `apps/mcp/test/accepted-checkpoint-restart.test.ts`: SHA256 `456ad7ea1aa5ca44cf8636329260dfead23b250db2a3408f754ea953c4f5354d`.
- `packages/doc-sync/test/node-http-recovery-retry.test.ts`: SHA256 `a7715f5df4115c576d17f9ca798ee4c3ef3da91b71be02fe89f8989f68f90376`.

## Resolved review findings

The first transport draft retried fetch/header failures but missed recognized network errors while consuming a successful response body. The independent real-socket probe sends partial HTTP 200 JSON, then destroys the connection only after fetch receives headers. Before correction: rejected, one request, TypeError terminated / UND_ERR_SOCKET. After correction: confirmed protected reservation, two identical requests. Receipts are `review-partial-body.before.log` and `.after.log`; the same output-only probe was used for both.

The final helper consumes successful bytes inside the bounded attempt loop and the same 10-second signal. JSON/protocol validation stays outside, so complete malformed replies, unsafe reservations and generation conflicts remain blocked. HTTP retry status set is 429/502/503/504; recognized connection errors use cause codes. Four attempts maximum, with 100/200/400 ms delays. Unclassified errors, ordinary send, conditional submit and release remain unchanged. Request bodies and original reservation identity are fixed before retry.

The persistent 503 process test now expects the exact four-attempt cap while retaining recovery_required, zero ordinary sends, byte-identical checkpoint preservation, blocked edit/schema operations and successful later recovery checks.

## Session safety

A retained accepted intent with the checkpoint's exact source digest can complete cleanup without reinstalling History. It must still have the exact accepted conditional receipt, original reservation proof, empty pending, equal change/checkpoint actor sequence, and checkpoint cursor at/after intent base. A pre-SSE checkpoint may have cursor below the accepted receipt; that is a legitimate durable local installation boundary.

For a different source digest, the existing next actor sequence and base>=checkpoint cursor constraints remain. The intent is installed only once. A fresh authoritative state read occurs after remote proof and before local restore. Generation and schema must match, and current serverSeq must be at least max(checkpoint cursor, exact accepted conditional receipt sequence). Thus a pre-SSE cursor below the receipt does not permit a later rolled-back server state below that receipt. SSE epoch validation still blocks further epoch change after local installation.

The final 11 accepted-checkpoint tests were source-reviewed. They cover settled/pre-SSE/pre-install boundaries, preserved human text and one undo group, digest/sequence/unknown-receipt/missing-reservation conflicts, generation/schema changes after receipt proof, post-proof history rollback, and same-generation reopened epoch. Their owner-produced log was inspected: 11 PASS, 0 FAIL/SKIP/CANCELLED. Transport owner-produced log was inspected: 9 PASS, 0 FAIL/SKIP/CANCELLED. The independent partial-body probe is this reviewer's execution.

## Proof limits

The historical undo after-accept second-restart failure remains **NOT_REPRODUCED** and its original error body is missing. The accepted-cleanup crash defect is independently reproduced and fixed; transient transport failures are separately injected and handled. Neither establishes that the historical unknown error had the same cause.

Parent owns build, process-focused and broader suite qualification. No browser/mobile tests, Git mutation or product edit was performed by this reviewer.
