---
work_id: mcp-restart-fix-2026-11-04
artifact_type: code_review
status: draft
owner_role: independent_high_reviewer
source_request: Parent-assigned read-only safety review of recovery retry and accepted-checkpoint fixes
last_updated: 2026-11-04
---

# Independent review

## Findings requiring resolution

### P2: Network loss during a successful response body bypasses bounded retry

Reviewed transport hash: `c249fd090995944aa1181368bd8215b5f742bec008e17530847ec786c90fc16b`.

`recoveryRequest` catches `fetch()` failures but returns a successful Response before the caller reads JSON. Socket loss after 200 headers therefore throws from `reserveRecovery`'s response.json outside the loop. It is an exact safe lease request with a recognized transient cause, but it is never retried. The same gap applies to atomic recovery and read-only state/schema calls. Including UND_ERR_BODY_TIMEOUT in the cause-code set does not catch body reads outside the try block.

A deterministic output-only real HTTP probe confirms this. The server sends 200 headers and partial JSON, then destroys the response only after real fetch has resolved the headers. `review-partial-body.before.log` reports:

```
{"result":"rejected","count":1,"name":"TypeError","message":"terminated","causeCode":"UND_ERR_SOCKET","cause":"other side closed"}
```

Required resolution: consume the body within the same four-attempt/shared-deadline scope. Retry recognized network read failures with the same URL/body. A complete malformed JSON reply must remain an immediate blocked result. Do not retry protocol/unsafe/generation-conflict replies or ordinary mutations.

### Existing persistent-failure process assertion must match exact retry cap

`automatic-recovery-process.test.ts:485` expects only one recover request for permanent injected 503. The new intended cap is four attempts. Change this one count to exact cap four and retain recovery_required, zero ordinary resend, preserved checkpoint bytes, blocked edits/schema changes and later-restart recovery assertions. Sent to implementation owner; not an instruction to weaken the safety assertion.

## Reviewed Session semantics: no defect found

Reviewed Session hash: `8fee0025142124a079acb1c7d0e96431c7a6372ed3c282e39ff6cf5736ad8963`.

The same-digest cleanup path still requires the exact accepted conditional receipt, original reservation proof, empty pending, matching actor change sequence, and checkpoint cursor at or after intent base. It skips reinstalling an already-installed intent. Requiring checkpoint cursor at/after accepted receipt would incorrectly reject the existing pre-SSE durable installation boundary; that constraint is correctly absent.

The different-digest path preserves base>=checkpoint cursor and next actor sequence before installation. Fresh authoritative generation/schema/history lower-bound checks occur after the pre-install remote operations and before local installation, so a reopened same-generation epoch can be bound safely. An epoch change after that boundary remains blocked by SSE/client validation.

Seven new accepted-checkpoint tests were source-reviewed, including settled/pre-SSE/pre-install crash boundaries, digest/sequence/unknown-receipt negatives, human text preservation, one History group, and same-generation hub reopen after reservation. Their PASS receipt belongs to the implementation owner, not this reviewer. Additional targeted generation/schema/missing-reservation negative coverage was requested if no existing test provides it.

No product root cause is assigned to the original historical undo repeated-restart failure. Its error body remains missing. This review identifies an independent accepted-cleanup defect and concrete limitations in the proposed transient transport handling.
