import {createServer} from 'node:http';
import {once} from 'node:events';
import {NodeHttpTransport} from '../../../packages/doc-sync/src/sync/node-http-transport.ts';
let count=0, destroyFirst;
const server=createServer(async(req,res)=>{for await(const chunk of req){};count++;res.writeHead(200,{'content-type':'application/json'}); if(count===1){res.write('{"status":"protected",');res.flushHeaders();destroyFirst=()=>res.destroy();}else res.end(JSON.stringify({status:'protected',generation:'g',pin:1,lastGc:0,existing:true}));});
server.listen(0,'127.0.0.1');await once(server,'listening');const port=server.address().port;
const original=globalThis.fetch;
globalThis.fetch=async(...args)=>{const response=await original(...args);if(count===1)destroyFirst();return response;};
try{const value=await new NodeHttpTransport('doc','actor',`http://127.0.0.1:${port}`).reserveRecovery('g','r0~id',1,true);console.log(JSON.stringify({result:'confirmed',count,value}));}
catch(error){console.log(JSON.stringify({result:'rejected',count,name:error.name,message:error.message,causeCode:error.cause?.code,cause:error.cause?.message}));}
finally{globalThis.fetch=original;server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
