import {spawn} from 'node:child_process';
import {writeFile,mkdir} from 'node:fs/promises';
import {once} from 'node:events';
const dir = new URL('./', import.meta.url);
const child = spawn(process.execPath, ['--import', new URL('./trace-server-loader.mjs',dir).pathname, 'apps/demo/server.ts'], {cwd:new URL('../../../',dir), env:{...process.env,PORT:'0',DATA_DIR:new URL('./trace-smoke-data',dir).pathname}, stdio:['ignore','pipe','pipe']});
let out='',err=''; child.stdout.on('data',b=>out+=b); child.stderr.on('data',b=>err+=b);
const ready = new Promise((resolve,reject)=>{child.on('error',reject);child.stdout.on('data',()=>{const m=out.match(/localhost:(\d+)/);if(m)resolve('http://127.0.0.1:'+m[1]);});child.once('exit',()=>reject(new Error(err)));});
const timer=setTimeout(()=>child.kill('SIGKILL'),10000);
try { const origin=await ready; const response=await fetch(origin+'/api/docs/trace/recovery-state'); const state=await response.json(); if(response.status!==200)throw new Error(JSON.stringify(state)); console.log(JSON.stringify({status:response.status,state})); }
finally { child.kill('SIGTERM'); if(child.exitCode===null&&child.signalCode===null)await once(child,'exit');clearTimeout(timer);await writeFile(new URL('./trace-smoke.stderr.log',dir),err);console.log(err); }
