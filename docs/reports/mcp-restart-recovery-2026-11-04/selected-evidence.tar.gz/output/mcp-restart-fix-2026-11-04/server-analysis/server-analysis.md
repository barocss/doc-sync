# Server and transport audit

Workspace: `/Users/user/github/doc-sync`; baseline HEAD `ec9622571a04a7d7ea3f967bb3e6423b17ce5194`.
Scope: read-only source audit and output-only tracing. No product source, tests, docs, dist, Git refs, or other agents' files changed. The historical second-restart failure was NOT_REPRODUCED here. Its exact error body is missing; no historical cause is claimed.

## Findings

1. **No ordinary restart readiness race is established.** `apps/demo/server.ts:489-500` awaits `sharedColdLoad` before publishing one hub. `sharedColdLoad:293-309` deduplicates concurrent reads. Recovery-state, reservation mutation and SSE admission are serialized and reject a stale captured hub (`:859-907`). `stream:693-711` constructs hello, connects the peer and adds its listener without an await. These facts exclude simple healthy state/read-vs-hello reordering as an explanation.
2. **No 503 means merely 'still starting'.** Cold loading is awaited. A 503 indicates `StorageUncertainError`, captured-hub invalidation, reset/generation change during compaction, or failed retained-reservation confirmation. Storage errors can be transient when the next request reopens and durably validates an authoritative log, but can also be persistent or unsafe. Never classify every 503 as harmless, and never return clear from the first failed attempt.
3. **Actor close does not discard durable recovery pins.** Stream close only disconnects the ordinary peer and drops presence (`:716-723`); leave removes only ordinary peers (`hub.ts:539-542`). Frontier includes every recovery pin (`hub.ts:456-467`). Reacquisition retains or lowers the existing floor (`:312`), so ordinary human edit, peer lease, or SSE close cannot themselves remove history protection.
4. **The second settled restart should have no pending recovery submission.** This follows from the first restoration's awaited settled checkpoint persistence, rather than server receipt state alone. Session/journal agent owns that proof.

## Exact operation retry safety

A bounded retry of the **identical pre-install lease request** preserves the existing protection contract:

- Keep generation, actor, reservation ID, pin and requireExisting unchanged.
- `reserveRecovery` rejects a generation mismatch, released ID, absent sealed/legacy ID and absent requireExisting reservation (`hub.ts:302-311`).
- Floor is `min(requestedPin, serverSeq+1, existingPin)` (`:312`); a repeated success cannot advance it.
- A lost response after a durable append can produce a second identical pin record; it cannot create a replacement identity or move GC past the protected floor.
- Missing/unsafe reservations and valid unsafe replies remain blocked. A retry must not rekey, clear requireExisting, rebuild history, or reinterpret an unsafe reply as permission.

The identical atomic pending request is also safe to retry before local restore:

- Generation, schema and the reservation must still match (`:322-324`).
- An exact full-payload accepted receipt is returned before considering a fresh append (`:325-326`, `:267-272`).
- Otherwise only the next actor sequence may append (`:327-330`).
- Different payload, unsafe reservation, or conflict remains blocked. An accepted receipt does not replace reservation proof.

**Do not retry the whole restoreCheckpoint method.** Local installation and accepted-intent restoration have further state transitions; the Session agent audits those separately.

## Epoch interaction after retry

A first recovery-state GET can observe epoch A. An uncertain storage outcome can invalidate that hub. An identical reservation retry can safely succeed against a reopened hub with the same durable generation but epoch B. If Session retains state A, its protected-history SSE guard will correctly refuse hello B.

After confirmed pre-install remote operations, a fresh authoritative recovery-state read with the full generation/schema/history lower-bound checks can bind the first local restore to B. It does not justify skipping reservation proof or accepting arbitrary epoch change after connection. A later invalidation/churn remains a failed recovery attempt. No whole-method or indefinite retry is implied.

This is a deterministic source-level interleaving and a design requirement for a future retry patch. It is **not** evidence that this interleaving occurred in the historical healthy test.

## Output-only instrumentation

`trace-server-loader.mjs` uses Node 24 `registerHooks` to transform only `apps/demo/server.ts` in memory. It records recovery-state and lease HTTP status/body, >=400 replies, stream epoch/sequence, and `invalidateHub` stack traces. It does not modify files loaded by the product.

`trace-smoke.mjs`: PASS, owned demo process; GET recovery-state returned HTTP 200 and emitted the expected trace. The process was stopped. No scenario/root-cause reproduction is claimed. `trace-smoke.stderr.log` preserves the trace.

Use the hook through `NODE_OPTIONS=--import=/Users/user/github/doc-sync/output/mcp-restart-fix-2026-11-04/server-analysis/trace-server-loader.mjs` when running a diagnostic process scenario. Capture demo stderr after startup as well as MCP stderr; the original helper only exposes demo stderr if startup itself fails.
