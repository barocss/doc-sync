# Bounded recovery HTTP resilience

Implemented: private HTTP retry scope for getSchema, getRecoveryState, reserveRecovery and recoverChange. The retry sends identical URL/body/generation/actor/reservation ID/pin/requireExisting/change. Maximum four attempts; backoff 100/200/400 ms; one 10-second signal covers all requests, response body reads and backoff. Capture-free helpers and retry constants are module-scope; Set constructors have PURE annotations. Existing SERVER_URL_PROTOCOLS PURE marker is preserved.

Retry conditions: HTTP429/502/503/504, or explicit known network codes including ECONNREFUSED/ECONNRESET/UND_ERR_SOCKET/body/connect/header timeout. Body read occurs inside retry scope, so a socket loss after successful headers can recover. Complete malformed JSON and semantic validation stay outside retry. Unsafe, missing reservation, generation mismatch, protocol/corruption/conflict and permanent HTTP outcomes remain blocked. Ordinary send, conditional submit, schema transition, release and receipt methods have no new retry.

Failed response bodies are cancelled. Successful bodies are fully consumed under the shared fetch signal, then admitted for existing JSON/semantic validation. This preserves the public transport API. No session-wide retry or recovery-status polling was added.

## Tests and evidence

- Actual source before implementation: unit 8 tests, 6 FAIL, 2 PASS (`retry-before-fix.log`).
- Frozen reconstructed pre-retry control: real HTTP200 partial JSON then socket loss FAIL, request count1 (`partial-body-before-fix.log`). Same method wiring as before retry; helper code remains unused. This is a behavioral control, not byte-identical old source.
- Frozen reconstructed pre-retry control via child NODE_OPTIONS alias: new second-restart lease-before process regression FAIL, attempts1 vs expected2, full transcript (`process-retry-frozen-before.log`). No dist file was overwritten.
- Earlier process invocation used the parent's first rebuilt dist and passed. `process-retry-before-fix.log` is explicitly NOT_BASELINE.
- Final source units: **9 PASS, 0 FAIL** (`retry-final.log`). Includes temporary status/exact body/single signal/cancel, cap4, unsafe/permanent/malformed/generation mismatch, ordinary and conditional no-retry, known versus arbitrary network error, shared deadline abort, actual lost socket before headers, actual lost socket after successful headers.
- Final dist process focus after parent build2: **12 PASS, 0 FAIL, 0 SKIP, 0 CANCELLED**, 10.010259625 seconds (`mcp-final-focused.log`). Existing eight recovery cases and four new second-restart cases: lease503 before forwarding, lease503 after upstream protected/existing true, recovery-state503 plus authoritative refresh, persistent lease503 exhausted cap4 then healthy restart.

Command: `/Users/user/.nvm/versions/node/v24.22.1/bin/node --test --test-concurrency=2 apps/mcp/test/restart-recovery-regression.test.ts apps/mcp/test/automatic-recovery-process.test.ts`.

The process regressions preserve original pending bytes, exact accepted serverSeq, initial recovery count1 with zero ordinary resend, independent Human content, empty settled pending, immediate status, zero second recovery/resend and opposite history confirmation. Persistent failure keeps settled bytes, blocks redo, emits no stream/recover/change, and later healthy restart recovers. The existing unavailable atomic recovery case changes only its exact expected count1 to bounded cap4; all safety assertions remain.

Owned product file: packages/doc-sync/src/sync/node-http-transport.ts. New unit/process files and unique fixture are listed in implementation-receipt.json. Existing automatic-recovery-process.test.ts had substantial inherited WIP; this phase edits only the persistent recovery request count assertion. Other changes belong to the parent or other agents.

Historical intermittent failure cause remains UNKNOWN. These controlled availability faults establish a known resilience improvement and a regression boundary. They do not prove HTTP503 caused the historical failure. Parent owns package build, typecheck, full suite and overall archive verification. No mobile/browser, commit, push or release was performed here. Logs and final source SHA-256 are in implementation-receipt.json.
