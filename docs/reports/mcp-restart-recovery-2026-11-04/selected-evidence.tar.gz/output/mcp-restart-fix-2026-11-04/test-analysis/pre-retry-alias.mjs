import {registerHooks} from "node:module";
registerHooks({resolve(specifier, context, nextResolve) {
    if (specifier === "@barocss/doc-sync/node") return {url: new URL("./frozen-pre-retry-transport.ts", import.meta.url).href, shortCircuit: true};
    return nextResolve(specifier, context);
}});
