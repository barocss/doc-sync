# MCP repeated restart process probes

Result: four discriminating cases PASS. Historical intermittent failure NOT_REPRODUCED; root cause remains unknown. No product or repository test file was changed. All writes are in this output directory.

Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`, v24.22.1. Existing package dist exports were used. No build, full suite, browser/mobile, commit, push, or timing benchmark. Each process scenario owns fresh server data/journal and cleans only its direct live children in finally.

| Probe | Result | Evidence |
|---|---|---|
| Healthy second restart: hold confirmed lease reply, independent human insert advances same-epoch serverSeq 3 to 4, release | PASS, 1327.741 ms | lease-interleave.log |
| Second restart lease HTTP503 before forwarding request | PASS, 1462.873542 ms | settled-lease-fault.log |
| Second restart lease HTTP503 after upstream returned protected/existing true | PASS | fault-variants.log |
| Second restart recovery-state GET HTTP503 before forwarding | PASS, 1452.69875 ms | fault-variants.log |

The healthy lease barrier proved stdio connect remains pending, no SSE/recover/change request has occurred, and exact settled checkpoint bytes remain unchanged while another user adds `Second `. After release: immediate clear; second atomic recover count 0 and ordinary send count 0; text `Second Human `; opposite redo confirmed and `Second Human abc`. The first recovery still proves exact accepted serverSeq, atomic recover count 1, ordinary resend 0, preserved Human text, empty pending, and history survival.

Each injected failure produced immediate `recovery_required`, preserved exact settled checkpoint bytes before and after a rejected redo, and emitted no SSE/recover/change request. Lease message: `Recovery reservation outcome is unknown: HTTP 503`. State message: `Could not read server state: HTTP 503`. Next healthy MCP startup immediately cleared and opposite history succeeded with Human text preserved. The AFTER-protected variant first asserts upstream HTTP200, status protected and existing true, then replaces only proxy response with HTTP503. Raw request bodies and upstream responses, full recovery response/message, hello frame, server state, checkpoint and SHA are logged.

These injected failures establish reachable safe failure classes. They are not evidence that HTTP503 caused the original historical failure. No expectation was weakened and no recovery-status polling was added. Existing helper waits for human sync remain unchanged.

Exact same recovery-state GET is read-only and eligible for bounded transient HTTP retry. Exact same confirmed lease POST is idempotent under durable reserve semantics: same generation/actor/reservationId/pin/requireExisting true, existing pin cannot advance. Both before-request loss and after-protection response loss are eligible. Missing reservation (`unsafe` or existing false), generation/schema/history mismatch, invalid response, permanent HTTP denial, or unknown protection must retain fail-closed behavior. A retry must not create a new reservation ID or fall through to ordinary change resend. HTTP503 availability recovery would be a separately qualified fix class, not proof of historical cause.

Harness note: initial output-only probe invocation failed import resolution before any server startup. Relative import path was corrected; all four process cases above then passed. The corrected generator is reproducible. Source generators and generated files are retained. receipts.json hashes the completed logs.
