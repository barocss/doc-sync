from pathlib import Path
root=Path('/Users/user/github/doc-sync')
s=(root/'apps/mcp/test/automatic-recovery-process.test.ts').read_text()
# Only helpers + the retained exact-receipt scenario.
a=s.index('test("recovery reservation survives')
b=s.index('async function historyRecoveryScenario')
c=s.index('\ntest("unavailable atomic recovery')
s=s[:a]+s[b:c]
s=s.replace('import assert from "node:assert/strict";', 'import assert from "node:assert/strict";\nimport {createHash} from "node:crypto";')
s=s.replace('"../../../fixtures/demo-schema.ts"', '"../../../fixtures/demo-schema.ts"')
s=s.replace('new URL("../../demo/server.ts", import.meta.url)', 'new URL("../../../apps/demo/server.ts", import.meta.url)')
s=s.replace('new URL("../src/main.ts", import.meta.url)', 'new URL("../../../apps/mcp/src/main.ts", import.meta.url)')
s=s.replace('async function userInsert(origin: string)', 'async function userInsert(origin: string, content = "Human ")')
s=s.replace('content: "Human "', 'content')
s=s.replace('startupGate?: "recover-change" | "stream"', 'startupGate?: "recover-change" | "stream" | "recovery-lease"')
s=s.replace('phase: "recover-change" | "stream"', 'phase: "recover-change" | "stream" | "recovery-lease"')
s=s.replace('let armed = false, changes = 0, recoveries = 0, streams = 0;', 'let armed = false, changes = 0, recoveries = 0, streams = 0;\n    let requestId = 0;')
s=s.replace('const server = createServer((req, res) => {', '''const server = createServer((req, res) => {
        const id = ++requestId;
        let requestBody = "";
        req.on("data", chunk => { requestBody += String(chunk); });
        req.on("end", () => console.log(JSON.stringify({event: "http-request", id, method: req.method, url: req.url, body: requestBody})));
        res.on("close", () => console.log(JSON.stringify({event: "http-close", id, status: res.statusCode})));''')
s=s.replace('if (change && armed && mode === "after-accept") {', '''let responseBody = "", loggedHello = false;
            response.on("data", chunk => {
                responseBody += String(chunk);
                if (req.url?.includes("/stream")) {
                    if (!loggedHello && responseBody.includes("\\n\\n")) {
                        loggedHello = true;
                        console.log(JSON.stringify({event: "http-hello", id, status: response.statusCode, body: responseBody.split("\\n\\n")[0]}));
                        responseBody = "";
                    } else if (loggedHello) responseBody = "";
                }
            });
            response.on("end", () => { if (!req.url?.includes("/stream")) console.log(JSON.stringify({event: "http-response", id, status: response.statusCode, body: responseBody})); });
            if (change && armed && mode === "after-accept") {''')
s=s.replace('startupGate === "stream" ? req.url?.includes("/stream") : startupGate === "recover-change" && req.url?.endsWith("/recover-change")', 'startupGate === "stream" ? req.url?.includes("/stream") : startupGate === "recover-change" ? req.url?.endsWith("/recover-change") : startupGate === "recovery-lease" && req.url?.endsWith("/recovery-lease")')
s=s.replace('        } else {\n            assert.equal(proxy.streams(), 1,', '''        } else if (phase === "recovery-lease") {
            assert.equal(proxy.streams(), 0, "settled recovery reservation response precedes SSE");
            assert.equal(proxy.recoveries(), 0);
            assert.equal(proxy.changes(), 0);
            const before = await readFile(checkpointPath);
            await userInsert(demo!.origin, "Second ");
            assert.deepEqual(await readFile(checkpointPath), before, "lease barrier preserves settled checkpoint bytes");
            console.log(JSON.stringify({event: "second-lease-interleave", state: await state(demo!.origin), checkpoint: JSON.parse(before.toString()), checkpointSha256: createHash("sha256").update(before).digest("hex")}));
        } else {
            assert.equal(proxy.streams(), 1,''')
s=s.replace('resumedProxy = await historyProxy(demo.origin, "pass", "stream");\n            mcp = await connectThroughGate(resumedProxy, "stream");', 'resumedProxy = await historyProxy(demo.origin, "pass", "recovery-lease");\n            mcp = await connectThroughGate(resumedProxy, "recovery-lease");')
s=s.replace('assert.equal(settled.client.pending.length, 0, "healthy recovery persists a settled checkpoint");', '''assert.equal(settled.client.pending.length, 0, "healthy recovery persists a settled checkpoint");
            console.log(JSON.stringify({event: "first-recovery-settled", state: await state(demo.origin), checkpoint: settled, checkpointSha256: createHash("sha256").update(await readFile(checkpointPath)).digest("hex")}));''')
s=s.replace('response: repeatedResponse, stderr: mcp.diagnostics()', 'response: repeatedResponse, state: await state(demo.origin), checkpoint: JSON.parse(await readFile(checkpointPath, "utf8")), stderr: mcp.diagnostics()')
s=s.replace('assert.equal(text(await state(demo.origin)), `Human ${afterText}`, "repeated restart', 'assert.equal(text(await state(demo.origin)), `Second Human ${afterText}`, "repeated restart')
s=s.replace('assert.equal(text(await state(demo.origin)), `Human ${beforeText}`);', 'assert.equal(text(await state(demo.origin)), `Second Human ${beforeText}`);')
s+='\ntest("second restart: same-epoch human edit while confirmed lease response is held", {timeout: 45000}, () => historyRecoveryScenario("undo", "after-accept", true));\n'
(root/'output/mcp-restart-fix-2026-11-04/test-analysis/lease-interleave.probe.ts').write_text(s)
