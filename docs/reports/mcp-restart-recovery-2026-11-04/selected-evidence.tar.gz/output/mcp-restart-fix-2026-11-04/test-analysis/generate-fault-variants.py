from pathlib import Path
p=Path('output/mcp-restart-fix-2026-11-04/test-analysis')
s=(p/'settled-lease-fault.probe.ts').read_text()
after=s.replace('mode === "fail-lease" && req.url?.endsWith("/recovery-lease")', 'false && mode === "fail-lease" && req.url?.endsWith("/recovery-lease")')
after=after.replace('            if (change && armed && mode === "after-accept") {', '''            if (mode === "fail-lease" && req.url?.endsWith("/recovery-lease")) {
                let acceptedBody = "";
                response.on("data", chunk => { acceptedBody += String(chunk); });
                response.on("end", () => {
                    assert.equal(response.statusCode, 200, acceptedBody);
                    const protectedReply = JSON.parse(acceptedBody);
                    assert.equal(protectedReply.status, "protected");
                    assert.equal(protectedReply.existing, true);
                    res.writeHead(503, {"content-type": "application/json"});
                    res.end(JSON.stringify({injected: "after-protected-reply", protectedReply}));
                    console.log(JSON.stringify({event: "fault-injection-after-upstream-protected", id, status: 503, protectedReply}));
                });
                return;
            }
            if (change && armed && mode === "after-accept") {''')
after=after.replace('injected second-start lease HTTP503 preserves', 'injected second-start lease HTTP503 after upstream protected preserves')
(p/'settled-lease-after-fault.probe.ts').write_text(after)
state=s.replace('mode === "fail-lease" && req.url?.endsWith("/recovery-lease")', 'mode === "fail-lease" && req.url?.endsWith("/recovery-state")')
state=state.replace('Recovery reservation outcome is unknown: HTTP 503', 'Could not read server state: HTTP 503')
state=state.replace('injected second-start lease HTTP503 preserves', 'injected second-start recovery-state GET HTTP503 preserves')
(p/'settled-state-fault.probe.ts').write_text(state)
