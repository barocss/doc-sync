from pathlib import Path
root=Path('/Users/user/github/doc-sync')
s=(root/'apps/mcp/test/automatic-recovery-process.test.ts').read_text()
a=s.index('test("recovery reservation survives'); b=s.index('async function historyRecoveryScenario'); c=s.index('\ntest("unavailable atomic recovery')
s=s[:a]+s[b:c]
s=s.replace('import {test} from "node:test";\n','')
s=s.replace('"../../../fixtures/demo-schema.ts"','"../../../../fixtures/demo-schema.ts"').replace('new URL("../../demo/server.ts"','new URL("../../../demo/server.ts"').replace('new URL("../src/main.ts"','new URL("../../src/main.ts"')
s=s.replace('    startupGate?: "recover-change" | "stream") {','    startupGate?: "recover-change" | "stream", fault?: Fault) {\n    const transcript: Array<{url: string; method: string; body: string; status?: number; response?: string}> = [];\n    let faultRequests = 0;')
s=s.replace('    const server = createServer((req, res) => {','''    const server = createServer((req, res) => {
        const entry = {url: req.url ?? "", method: req.method ?? "", body: "", status: undefined as number | undefined, response: undefined as string | undefined};
        transcript.push(entry);
        req.on("data", chunk => { entry.body += String(chunk); });
        const target = fault && req.url?.endsWith(fault === "state" ? "/recovery-state" : "/recovery-lease");
        const inject = target && (++faultRequests === 1 || fault === "persistent");
        if (inject && fault !== "lease-after") {
            req.resume(); entry.status = 503; entry.response = "{}";
            res.writeHead(503, {"content-type": "application/json"}); res.end("{}"); return;
        }''')
s=s.replace('            if (change && armed && mode === "after-accept") {','''            entry.status = response.statusCode;
            if (!req.url?.includes("/stream")) {
                entry.response = "";
                response.on("data", chunk => { entry.response += String(chunk); });
            }
            if (inject && fault === "lease-after") {
                response.on("end", () => {
                    const reply = JSON.parse(entry.response!);
                    if (response.statusCode !== 200 || reply.status !== "protected" || reply.existing !== true) {
                        res.writeHead(502); res.end(JSON.stringify({unexpected: entry})); return;
                    }
                    res.writeHead(503, {"content-type": "application/json"}); res.end("{}");
                });
                return;
            }
            if (change && armed && mode === "after-accept") {''')
s=s.replace('return {gateSeen:', 'return {transcript, faultRequests: () => faultRequests, gateSeen:')
s=s.replace('async function historyRecoveryScenario(action: "undo" | "redo", mode: "before-send" | "after-accept", controlledStartup = false) {', '''export type Fault = "lease-before" | "lease-after" | "state" | "persistent";
export async function restartRecoveryScenario(fault: Fault) {
    const action = "undo" as const, mode = "after-accept" as const, controlledStartup = true;''')
# TS detects const redo conditional unreachable so keep variable annotations helper args instead.
s=s.replace('    const action = "undo" as const, mode = "after-accept" as const, controlledStartup = true;', '    const action: "undo" | "redo" = String("undo") as "undo" | "redo", mode: "before-send" | "after-accept" = String("after-accept") as "before-send" | "after-accept", controlledStartup = true;')
s=s.replace('''            resumedProxy = await historyProxy(demo.origin, "pass", "stream");
            mcp = await connectThroughGate(resumedProxy, "stream");''','''            const settledBytes = await readFile(checkpointPath);
            resumedProxy = await historyProxy(demo.origin, "pass", undefined, fault);
            mcp = await connectMcp(resumedProxy.origin, journal);
            const attempts = resumedProxy.transcript.filter(entry => entry.url.endsWith(fault === "state" ? "/recovery-state" : "/recovery-lease"));
            assert.equal(attempts.length, fault === "persistent" ? 4 : 2, JSON.stringify(resumedProxy.transcript));
            assert.equal(new Set(attempts.map(entry => entry.body)).size, 1, "retries preserve the exact request body");
            if (fault !== "state") {
                const requestBody = JSON.parse(attempts[0].body);
                const settled = JSON.parse(settledBytes.toString());
                assert.equal(requestBody.generation, settled.generation);
                assert.equal(requestBody.reservationId, settled.reservationId);
                assert.equal(requestBody.actor, actor);
                assert.equal(requestBody.requireExisting, true);
            }
            if (fault === "persistent") {
                const blocked = value<{status: string; message: string}>(await call(mcp.client, "recovery_status"));
                assert.equal(blocked.status, "recovery_required", JSON.stringify({blocked, transcript: resumedProxy.transcript}));
                assert.match(blocked.message, /HTTP 503/);
                assert.equal((await call(mcp.client, "redo")).isError, true);
                assert.deepEqual(await readFile(checkpointPath), settledBytes, "exhausted recovery preserves settled checkpoint bytes");
                assert.equal(resumedProxy.streams(), 0);
                assert.equal(resumedProxy.recoveries(), 0);
                assert.equal(resumedProxy.changes(), 0);
                assert.equal(text(await state(demo.origin)), `Human ${afterText}`);
                await killMcp(mcp); mcp = undefined;
                await resumedProxy.close(); resumedProxy = undefined;
                resumedProxy = await historyProxy(demo.origin, "pass");
                mcp = await connectMcp(resumedProxy.origin, journal);
            }''')
s=s.replace('response: repeatedResponse, stderr: mcp.diagnostics()', 'response: repeatedResponse, transcript: resumedProxy?.transcript, stderr: mcp.diagnostics()')
p=root/'apps/mcp/test/fixtures/restart-recovery-harness.ts'; p.parent.mkdir(exist_ok=True); p.write_text(s)
(root/'apps/mcp/test/restart-recovery-regression.test.ts').write_text('''import {test} from "node:test";
import {restartRecoveryScenario, type Fault} from "./fixtures/restart-recovery-harness.ts";

const skip = process.platform !== "darwin" && process.platform !== "linux" ? "The journal requires a macOS or Linux kernel lock" : false;
for (const fault of ["lease-before", "lease-after", "state", "persistent"] as Fault[]) {
    test(`repeated MCP restart tolerates bounded recovery HTTP failure: ${fault}`, {timeout: 45000, skip}, () => restartRecoveryScenario(fault));
}
''')
