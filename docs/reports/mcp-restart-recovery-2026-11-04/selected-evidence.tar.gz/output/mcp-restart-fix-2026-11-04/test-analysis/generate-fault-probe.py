from pathlib import Path
p=Path('output/mcp-restart-fix-2026-11-04/test-analysis')
s=(p/'lease-interleave.probe.ts').read_text()
s=s.replace('"pass" | "fail-recovery"', '"pass" | "fail-recovery" | "fail-lease"')
s=s.replace('        if (req.url?.includes("/stream")) streams++;', '''        if (mode === "fail-lease" && req.url?.endsWith("/recovery-lease")) {
            req.resume();
            res.writeHead(503, {"content-type": "application/json"});
            res.end(JSON.stringify({injected: "settled-checkpoint-second-start-lease-unavailable"}));
            console.log(JSON.stringify({event: "fault-injection", id, status: 503, route: req.url}));
            return;
        }
        if (req.url?.includes("/stream")) streams++;''')
s=s.replace('resumedProxy = await historyProxy(demo.origin, "pass", "recovery-lease");\n            mcp = await connectThroughGate(resumedProxy, "recovery-lease");', '''resumedProxy = await historyProxy(demo.origin, "fail-lease");
            const settledBeforeFault = await readFile(checkpointPath);
            mcp = await connectMcp(resumedProxy.origin, journal);
            const unavailable = await call(mcp.client, "recovery_status");
            const unavailableValue = unavailable.structuredContent as {status: string; message: string};
            assert.equal(unavailable.isError, undefined);
            assert.equal(unavailableValue.status, "recovery_required");
            assert.match(unavailableValue.message, /Recovery reservation outcome is unknown: HTTP 503/);
            assert.equal(resumedProxy.changes(), 0);
            assert.equal(resumedProxy.recoveries(), 0);
            assert.equal(resumedProxy.streams(), 0);
            assert.deepEqual(await readFile(checkpointPath), settledBeforeFault);
            assert.equal((await call(mcp.client, "redo")).isError, true);
            assert.deepEqual(await readFile(checkpointPath), settledBeforeFault);
            console.log(JSON.stringify({event: "settled-second-start-fail-closed", recovery: unavailable, state: await state(demo.origin), checkpointSha256: createHash("sha256").update(settledBeforeFault).digest("hex")}));
            await killMcp(mcp); mcp = undefined;
            await resumedProxy.close(); resumedProxy = undefined;
            resumedProxy = await historyProxy(demo.origin, "pass");
            mcp = await connectMcp(resumedProxy.origin, journal);''')
s=s.replace('`Second Human ${afterText}`', '`Human ${afterText}`').replace('`Second Human ${beforeText}`', '`Human ${beforeText}`')
s=s.replace('second restart: same-epoch human edit while confirmed lease response is held', 'injected second-start lease HTTP503 preserves settled history and healthy next startup recovers')
(p/'settled-lease-fault.probe.ts').write_text(s)
