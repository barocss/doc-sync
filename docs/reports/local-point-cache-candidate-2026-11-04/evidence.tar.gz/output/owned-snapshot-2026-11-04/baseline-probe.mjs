// Tiny source-only ownership probes. No timing and no project mutation.
import assert from 'node:assert/strict';
import {Doc} from '../../packages/doc-sync/src/crdt/doc.ts';
import {createDataSchema} from '../../packages/doc-sync/src/data/schema.ts';
const actor='owned-proof';
const t={lamport:1,actor};
function seed(){
  const doc=new Doc(actor,createDataSchema());
  doc.apply({t:'node',id:t,origin:{lamport:0,actor:'~root'},type:'entry',attrs:{id:'data:proof',key:'proof',value:{scalar:1}}});
  return doc;
}
const payload=s=>s.lines[0].items[1].a.find(([k])=>k==='value')[1];
const stored=d=>d.get('1@owned-proof').attrs.get('value').value;
const results={node:process.version,scope:'tiny baseline source probes; no candidate implementation or timing'};
{
  const d=seed(), snap=d.snapshot(), restored=Doc.fromSnapshot(actor,snap,d.schema);
  assert.notEqual(payload(snap),stored(d)); assert.notEqual(payload(snap),stored(restored));
  payload(snap).scalar=2; assert.equal(stored(d).scalar,1); assert.equal(stored(restored).scalar,1);
  results.stockPayloadDetached='PASS';
}
{
  const d=seed(), publicItems=d.snapshot().lines[0].items;
  // Public arrays from Doc.items/Doc.lines are mutable. No Doc method is replaced.
  Object.defineProperty(d.items,'map',{value(){return publicItems;},configurable:true});
  const snap=Doc.prototype.snapshot.call(d);
  assert.equal(snap.lines[0].items,publicItems);
  const restored=Doc.fromSnapshot(actor,snap,d.schema);
  assert.notEqual(stored(restored),payload(snap));
  payload(snap).scalar=3; assert.equal(stored(restored).scalar,1);
  results.originalSnapshotWithOwnMapCanReturnPublicPayload='PASS';
}
{
  const d=seed(); let escaped;
  function PublicArray(length){escaped=new Array(length);return escaped;}
  Object.defineProperty(d.items,'constructor',{value:{[Symbol.species]:PublicArray},configurable:true});
  assert.equal(d.items.map,Array.prototype.map);
  const snap=Doc.prototype.snapshot.call(d);
  assert.equal(snap.lines[0].items,escaped); assert.notEqual(payload(snap),stored(d));
  const restored=Doc.fromSnapshot(actor,snap,d.schema);
  payload(snap).scalar=4;
  assert.equal(stored(d).scalar,1); assert.equal(stored(restored).scalar,1);
  results.nativeMapWithOwnSpeciesLeaksClonedPayload='PASS';
}
{
  const d=seed(), snap=d.snapshot(), shared=payload(snap);
  snap.lines[0].items[1].a.push(['another',shared,'1@owned-proof']);
  const restored=Doc.fromSnapshot(actor,snap,d.schema);
  assert.notEqual(restored.get('1@owned-proof').attrs.get('another').value,stored(restored));
  results.publicPerRegisterAliasSplit='PASS';
}
{
  const d=seed(), trace=[], sentinel={sentinel:true};
  Object.defineProperty(d,'snapshot',{get(){trace.push('get snapshot');return function(){trace.push('call snapshot');return seed().snapshot();};}});
  Object.defineProperty(d,'schema',{get(){trace.push('get schema');throw sentinel;}});
  try { Doc.fromSnapshot(actor,d.snapshot(),d.schema); assert.fail(); } catch(e){assert.equal(e,sentinel);}
  assert.deepEqual(trace,['get snapshot','call snapshot','get schema']);
  results.snapshotSchemaReadOrder=trace;
}
{
  const d=seed(), clone=globalThis.structuredClone; let snapshotCopies=0,restoreCopies=0,phase='snapshot';
  globalThis.structuredClone=function(v,...args){if(v&&typeof v==='object'&&Object.hasOwn(v,'scalar')){phase==='snapshot'?snapshotCopies++:restoreCopies++;}return clone(v,...args);};
  try { const snap=d.snapshot(); phase='restore'; Doc.fromSnapshot(actor,snap,d.schema); }
  finally {globalThis.structuredClone=clone;}
  assert.equal(snapshotCopies,1); assert.equal(restoreCopies,1);
  results.oneEntryPayloadCopies={snapshotCopies,restoreCopies};
}
{
  const d=seed(), snap=d.snapshot(); snap.lines[0].items[1].i='01@owned-proof';
  const restored=Doc.fromSnapshot(actor,snap,d.schema);
  assert.ok(restored.get('01@owned-proof')); assert.equal(restored.get('1@owned-proof'),undefined);
  const duplicate={...snap.lines[0].items[1],i:'1@owned-proof'}; snap.lines[0].items.push(duplicate);
  assert.throws(()=>Doc.fromSnapshot(actor,snap,d.schema),/Duplicate snapshot token identity/);
  results.canonicalDuplicateSetIsNotRedundantWithKeyIndex='PASS';
}
console.log(JSON.stringify(results,null,2));
