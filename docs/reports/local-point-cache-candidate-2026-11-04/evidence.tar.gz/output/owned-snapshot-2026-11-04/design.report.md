# Owned snapshot handoff: design/proof review

## Decision: HOLD

**Do not implement the proposed transfer on the strength of original `Doc.snapshot` identity alone.** Two source-only probes show that the original method can return publicly owned attribute payloads. A native `items.map` function is not sufficient either: an array's own `constructor[Symbol.species]` can expose its result before restoration.

The payload-copy hypothesis is valid only for a default, unescaped snapshot construction. That provenance is not established in the current code. This is a concrete ownership failure, not a claim that a new private function is impossible. Sections 7 and 8 give two bounded next designs. Root must choose and authorize a change. Neither has implementation or timing approval.

### Evidence boundary

- PASS: current 69 Core source files equal `output/refactor-2026-11-03/post-refactor-baseline`, byte for byte, at initial inspection and final report capture.
- PASS: seven tiny baseline probe groups in `baseline-probe.mjs` / `baseline-probe.json`, Node **v24.22.1**, normal strip-only execution, no flags.
- NOT_RUN: candidate implementation, candidate tests, full tests, builds, dist/package checks, browser/mobile, performance timing, commit/push.
- The rejected COW/trace candidate is not the source basis. `output/data-cache-2026-11-04/rollback.json` records its restoration. Historical timing and R4 evidence were read, not rerun.
- Only this report, `final.md`, and the tiny probe artifacts are owned here. Other workers' source, tests, documentation, processes and artifacts remain untouched.

## 1. New concrete counterexamples

### C1. The original snapshot can return public attribute pointers

`Doc.items` returns the stored array (`doc.ts:361-364`). `Doc.lines` returns stored Line objects (`366-369`). Snapshot uses **the public array's method**:

```ts
items: line.items.map((item, i) => itemToJSON(item, line.items[i - 1]))
```

`doc.ts:2570`. A user can set an own `map` method on `doc.items` that returns a retained, valid `ItemJSON[]`. `Doc.prototype.snapshot.call(doc)` then returns this exact retained array. It need not call `itemToJSON` at all. The finite JSON check accepts the resulting data. Legacy `fromSnapshot` still detaches each payload at `2731`.

Probe `originalSnapshotWithOwnMapCanReturnPublicPayload` passes: mutating the retained snapshot payload does not alter the restored document. A decoder that assigns that payload directly would lose this isolation. No Doc method, global intrinsic, private field or source file is replaced in this counterexample.

### C2. Native map still permits an escaped first clone

Keep `doc.items.map === Array.prototype.map`. Give this array an own `constructor` object with a `Symbol.species` constructor that returns and retains a public array. Native map puts each `itemToJSON` result into that retained array.

Probe `nativeMapWithOwnSpeciesLeaksClonedPayload` passes:

- The snapshot `items` array equals the externally retained species array.
- The snapshot payload is detached from the live document. The first structured clone did occur.
- That first clone is nevertheless public. Legacy restoration creates a second detached payload.

This disproves both “all original snapshot outputs are private” and “a first structured clone is sufficient ownership proof.” A dense plain Array result can still be externally retained. Checking the result's prototype/descriptors after construction does not prove non-exposure.

### C3. Public restoration must split register aliases

A public snapshot can use the same object for two attribute tuples. Legacy `itemFromJSON` clones each tuple separately. Probe `publicPerRegisterAliasSplit` passes. A whole-snapshot clone or blanket adoption flag must not replace this behavior.

### C4. Do not remove the duplicate-key Set using `byKey.has`

An accepted token key `01@owned-proof` produces canonical id `1@owned-proof`, but KeyIndex stores the noncanonical original key in its `other` map. `snapshotKeys` records the canonical key. A subsequent `1@owned-proof` must fail with `Duplicate snapshot token identity`.

Probe `canonicalDuplicateSetIsNotRedundantWithKeyIndex` passes. Replacing the Set check with `doc.byKey.has(tokenKey)` would miss this duplicate. Rejecting all noncanonical keys instead would change public admission.

## 2. Attribute provenance and exact copy sites

| Stage | Current behavior | Transfer implication |
| --- | --- | --- |
| `Doc.apply`, `doc.ts:832,848,904` | Copies incoming mark/node/set values with `copyStoredValue` | Keep unchanged. Public operation payloads do not authorize adoption. |
| `copyStoredValue`, `28-32` | Returns immutable primitives directly; host-clones other values, including host rejection | Primitive shortcut already exists. Do not count it as a new saving. |
| `itemToJSON`, `2694-2711` | Allocates `j`; normally allocates `a` and a fresh `[key, copiedValue, ticketString]` for every register | Only tuple slot 1 is a candidate. Slot 0 comes from the stored Map iterator; do not assume it is a string without proof. |
| Source `line.items.map`, `2570` | Uses a public instance method and native species semantics | Can replace or expose the entire item/tuple/payload result. C1/C2 apply even when the Doc snapshot method is original. |
| `itemFromJSON`, `2714-2737` | Builds a fresh Item, Map and register object; copies each tuple's value separately; decodes fresh Tickets | A private decoder can change only the payload-copy expression. Keep register/Map/Item/Ticket creation and tuple iteration order. |
| Attribute/model reads and defaults, `1340-1359` | Further read/model value copies or scoped borrowing | Not restored-payload copies. Do not remove or relabel them. |
| Snapshot moves, `2564` | Host-clones the movement array | Not a payload transfer permission. Keep placement copies. |
| Placement restore, `2666-2669`; `placement.ts:15-18` | Checks, applies, and independently copies movement records | Keep exactly. A first revision may decline all nonempty moves to reduce its proof surface. |

In the ordinary path, an object register gets **one host clone in snapshot and one in restoration**. The one-entry probe counts exactly 1 + 1. Primitives get neither host clone. Data values are **object wrappers**, not primitive strings: `{scalar: value}` or `{reference, kind}` (`data/access.ts:21,154-161`; `data/schema.ts:5`). Thus there is a real object-copy target in the large Data fixture.

No mutable attribute pointer is returned by the normal `itemToJSON` copy itself, with standard host intrinsics. But the **public original snapshot method can return mutable/public attribute pointers**, because C1 can bypass that callback and C2 can expose its result. Separately, raw corrupted scalar fields such as `item.ch` can be returned by reference; the whole snapshot must never be assumed recursively owned.

## 3. Validation, callbacks and admission

`fromSnapshot` order (`doc.ts:2575-2673`):

1. Full `annotationJsonOk(snapshot, 128)`; exact rejection text at `2576`.
2. Clock, format, capabilities and required-feature checks, in their current order.
3. `new Doc(actor, schema)`, including conditional `checkSchema` (`335-349`).
4. Clear temporary root state. Restore lines/items, identity/span checks, canonical duplicate checks and canonical heads. Resolve owners.
5. Annotation, derived/required storage and trailing-anchor checks.
6. Register ticket checks. Dynamic `doc.check` calls for `$join`, `$field:` and cell-field registers (`2658-2663`).
7. Dynamic `doc.check` and `doc.apply` for moves, in snapshot order.
8. Final clock floor, then return.

Keep all these steps. Ordinary attributes are **not** all passed through `Doc.check` during restore. Do not describe this loader as doing that today or add such calls in a performance patch.

The JSON visitor captures descriptors, then enumerates keys (`annotations.ts:41-57`). A Proxy can observe this; schema/default/value access can also invoke user code on external/raw schemas. Frozen alone is not a proof of plain callback-free data. Do not add a second reflective visitor over unknown objects or turn a failed eligibility test into a new error.

`Schema`/`AttrSpec` has no typed custom validation callback (`schema.ts:30-44`). Still, raw schema getters and replaced array methods are possible. `attrValueOk` uses `values.includes(value)` (`289-311`): do not substitute structural equality. `ClientOptions.data.validate` (`client/index.ts:24-28`) is an application write policy, outside the private restoration copy decision; it must retain its current calls/order.

Public Doc methods are overrideable. `doc.check` can retain an operation value or the partially restored target Doc. A future private transfer token, copy-policy function or snapshot metadata must **never** be passed to these methods. A target payload becoming visible through the same legacy callback at the same stage is different from exposing its ownership authority.

## 4. Engine evaluation order and receiver contract

Original clone (`typescript-client.ts:121`):

```ts
return Doc.fromSnapshot(this.actor, doc.snapshot(), doc.schema);
```

Observable order, after the default parameter's possible `this.doc` read:

1. Get `Doc.fromSnapshot`.
2. Get `this.actor`.
3. Get and call `doc.snapshot`, with `this === doc`.
4. Get `doc.schema`.
5. Call the **previously selected** restoration function, with `this === Doc`.

The snapshot/schema getter probe preserves the exact sentinel and read order. Do not read methods twice, reread a static after snapshot side effects, or retry snapshot on fallback. Moving actor evaluation before the static Get changes this contract. Replacing all calls with `Reflect.apply` can also change non-callable TypeError text; keep the original expression for unsupported surfaces.

R4 in `output/data-cache-2026-11-04/root-review-notes.md` remains a required test: a server-exposed Doc is available before first Client import. Capture Doc originals in **Doc's defining module**, before exposure, not on first engine/client import. Capture any other protected class originals in its own defining module too. This review did not rerun the archived preload fixture.

Receiver guard rule for a future design: private WeakSet/WeakMap membership may reject a Proxy without traps. Reflect only on positively known real allocations. Do not use new ECMAScript private fields in existing public/borrowable Doc methods. A transparent Doc Proxy or `Object.create(doc)` projection must retain the original path. Engine Proxies must not acquire new property reads or private-brand errors.

## 5. Clone call graph and scope of possible savings

- Engine `compile`, `215-226`: copies/validates edits, calls `Doc.edit`, then its preflight uses `clone(doc).edit(..., {normalize:true})` when fast paths decline.
- Graphic `Doc.edit`, `2243-2270`: guard, optional engine preflight, **another** detached `Doc.fromSnapshot`, then model/compile/normalization/listener work.
- A normal Graphic Data update that misses the text/structural fast paths therefore has **three** snapshot/restore pairs by source control flow: engine detached clone, that clone's Graphic stage, and the live Graphic stage. This is a source-derived count, not a new instrumented whole-set measurement.
- Changing only engine `clone` can avoid at most **one object-payload restoration copy per existing object register** for this call graph, not all six snapshot/restore object copies across the three pairs.
- Routing the Graphic stage through the same proven private factory could avoid three restoration copies per object register. That is a distinct extra call site and proof obligation. Do not silently claim it is included in an engine-only change.
- Tickets, snapshot wrappers, duplicate-key sets, JSON validation, KeyIndex rebuilding, normalization and first-read model work remain. No asymptotic whole-edit improvement is claimed.

For the historical 20,000-entry fixture, each entry has one object-valued `value` register. The fixture has two collection nodes with primitive id attributes, not two additional reference-value wrappers (`data-point-cache.mjs:64-95`). Expected avoided host payload clones: **20,000 per one eligible pair**, or **60,000 if all three eligible pairs are explicitly covered**, for that unchanged fixture. Confirm the exact count with a later tiny/untimed counter. Do not extrapolate it to milliseconds.

## 6. History, schema transition and failure behavior

- `clone` returns a fresh Doc. Snapshot does not carry revision, caches, guards/listeners, `priors`, movement priors or History. Preserve that difference; do not copy the live object's fields wholesale.
- `run` retains prior register pointers (`doc.ts:2528-2549`); History's SetStates retains prior/op values and ticket ownership (`history.ts:140-149,175-181,423-449`). New restored register objects remain necessary. Internal payload transfer must not change live History aliasing or step grouping.
- High-clock undo/redo first restores History, then clones Doc, before the live action (`typescript-client.ts:297-306`). Preserve that order and History's full JSON copy (`history.ts:380-403,413-416`).
- Public `prepareSnapshot` copies its input and restores it (`315-318`). `prepareCheckpoint` first copies/checks the checkpoint, restores Doc, then History (`329-336`). Neither public-input path can adopt payloads or use internal-fresh metadata.
- `previewSchema`/`upgradeSchema` (`338-339`) use a different schema or the public prepared path. Keep both legacy in the first revision. Schema identity and compatibility checks must not be inferred from a document stamp.
- Ordinary failed restoration mutates only the new target Doc before throwing. No handle is installed by a failed prepare. Preserve the first error, clock, stored state, History and notifications before the live compile.
- Do not claim rollback of arbitrary user callback side effects. Legacy getters/overrides can mutate external state. Also, `createSession.begin` assigns its draft before `live.clone` (`378`); a clone failure is not automatically an all-fields session rollback today. Do not add cleanup or stronger atomicity claims in this patch.

## 7. Bounded private-factory revision worth considering, NOT approved yet

A new private function is allowed. A defensible revision must add construction provenance, not a hidden public `owned=true` argument.

### Shape

- `doc.ts`: common private restore body; public `fromSnapshot(actor,snapshot,schema)` always selects legacy payload copying. An internal fresh-clone function accepts a source Doc/actor, **never a caller-supplied snapshot/token**, and builds its own snapshot using the captured original method.
- Internal-only payload-transfer factory/closure can select tuple slot 1 without copying only after the provenance result is true. It is single-invocation, not reusable, not stored on a Doc, not a stamp, not an exported package capability.
- Capture the original full Doc method/accessor descriptors in `doc.ts` after definition and before module exposure. Do not recapture at Client import.
- Add private real-allocation registries, not Doc fields. Line/items-array allocation sites are `doc.ts:343,408,425,1567,1587,2597`.
- At the **actual original nested map evaluation point**, after earlier line field reads, identify a known real Line and its known real array by descriptor-only checks. Decline accessors, a changed prototype, own map overrides, own constructor/species routes, foreign arrays or Proxies **without probing them**. Then execute the original `line.items.map(...)` expression once, including its original element/getter behavior. A changed later line must be checked when reached, not certified from an earlier scan.
- The original snapshot builder can retain a module-private WeakMap result for its newly built snapshot. It must mark unsafe map/species routes without traversing their returned arrays. Public snapshots get no property/token; public `fromSnapshot` never consults this record. The internal factory accepts only the result of its own direct original-method call, not a snapshot returned through an override wrapper.
- Record that all non-payload wrapper slots are safe primitives or separately host-cloned values. A raw `ch`, key, owner, slot, deletion entry, register key, span or lamport object is not a recursively owned wrapper. Check only already-known fresh wrapper values; never invoke a foreign getter for eligibility.
- Callback-free schema provenance can be minted by the existing validate/copy/deep-freeze schema factory in a private helper module. Mint only after the real copy/freeze; do not export `registerTrustedSchema` or accept `Object.isFrozen` as authority. Keep `schemaVersion`, copy, freeze and errors in their original order. No need to cache schema validity or skip constructor checks.
- Recheck protected descriptors after snapshot and the one original schema read. If any eligibility is lost, pass that **same** snapshot/schema to the **originally selected** public restore function. Never rerun snapshot or silently read a replacement static.
- A first revision may decline nonempty moves and external/raw schemas. All public checkpoint/schema-transition routes remain legacy. This reduces Clock/placement and callback proof obligations; it does not waive tests for fallback.

### Guard and fallthrough table

| Observation | Required action |
| --- | --- |
| Unknown/Proxy/borrowed engine receiver | Execute the unchanged original clone expression; no added public reads. |
| Unknown/Proxy/subclass/borrowed Doc, instance getter/override, changed Doc prototype/static surface | Same untouched fallback before any eligible-only reads; defining-module originals prevent R4. |
| Original method with foreign `items.map` / custom constructor/species | Original snapshot still runs once; its private provenance is false; legacy restore copies. C1/C2 must pass. |
| Source-array Proxy or `line.items` accessor | No speculative reflective/getter probe. Preserve original trap/getter trace, then legacy restore. |
| Snapshot callback changes a later line or protected surface | Evaluate later lines in legacy order; decline ownership if proof is lost. Restore the already-built snapshot, not a second snapshot. |
| Known private construction + pure owned schema + unchanged protected surfaces | Same validation/restore algorithm; only object tuple payload copies may transfer. Fresh register wrappers and Tickets remain. |
| Public `fromSnapshot`, prepare/checkpoint/import/schema preview/upgrade | Defensive copies always, even for an original public snapshot. |
| Invalid JSON, ticket, reserved register, late move or guard error | Same first error and side effects; do not catch-and-retry or bypass checks. |

This design is larger than changing one expression: it needs six allocation registration sites and exact nested-map provenance. The prior reflected wrapper candidate was rejected; this is not permission to revive it or assume its cost is negligible. It remains **HOLD** until its implementation shape and independent review close these obligations.

## 8. Simpler no-payload-semantic alternative: canonical KeyIndex restore insertion

If root does not want the provenance work, investigate **only snapshot KeyIndex reconstruction**, leaving every payload copy, public DTO visitor and admission step unchanged. Proposed scope: `crdt/doc.ts` + `crdt/key-index.ts`; private helpers only. No `Doc.apply` changes or added Doc fields.

Current `doc.ts:2605-2609` already materializes a canonical `{lamport,actor}` to make `tokenKey`. `KeyIndex.set` (`key-index.ts:43-91`) then parses the stored key again: first-at search, number conversion, prefix slices, canonical-string check and actor suffix slice, before its actual range/sparse insertion.

A private KeyIndex insertion helper can reuse that **fresh local ticket**, only when the actual stored key equals `tokenKey` and the original index set dispatch is intact. Extract the existing insertion body into a shared private routine. Public `set(key,value)` keeps its existing parsing, errors and dynamic internal behavior. Noncanonical first keys retain the old public set path. Keep the canonical `snapshotKeys` Set and all duplicate errors (C4).

This changes no payload ownership. It avoids up to one redundant key parse per canonical restored logical token in each of the three full rebuilds. For the historical fixture, the source formula gives 20,005 tokens per pair: 20,002 non-head items across the three lines + three heads. Confirm with a small count before scheduling timing. The benefit is limited: key strings, validation passes, payload clones and index insertion still exist. It is not a demonstrated 5% whole-edit improvement.

Safety conditions before approval:

1. Reuse the exact temporary ticket already allocated for `keyOf`; do not add reads of an Item or caller's DTO. Do not remove the existing second `keyOf` on span aliases without a separate observation proof.
2. Preserve the originally selected `KeyIndex.set` receiver/call for any override/accessor. Capture originals in **key-index.ts**, not the engine. A fast helper must not create a new public trusted flag or alter the public set signature.
3. Preserve noncanonical keys, multi-`@` actors, invalid/large identities, duplicate-after-alias failures, compressed spans, sparse/range transitions, insertion order and exact final KeyIndex metadata.
4. Keep all Doc/History/wire/schema/check/normalization paths unchanged. If the extraction changes an observable callback or first error, reject it.

Reason to prefer this alternative: it removes duplicated parsing of already generated local data, not a defensive copy of possibly exposed data. Reason to stop early: even 60,015 avoided parses may be too small compared with the recorded full-clone/validation cost. If an untimed work census cannot identify this as a material stage, do not spend a performance cycle on it. No speed claim is made.

## 9. Minimal acceptance pack BEFORE timing

For an owned-transfer revision:

1. **Source isolation**: original/frozen baseline import and candidate import in separate processes; normal strip-only Node. Include server-before-Client preload, valid/invalid/throwing/getter overrides. Verify exact selected function receiver, first sentinel and trap/read order.
2. **New C1/C2 mandatory**: own `items.map`; own map getter returning native map; custom species retaining normal Array; species returning Proxy; species getter/constructor throwing; earlier item getter changing a later line. Legacy rejection is not optional when legacy rejects.
3. **Public boundaries**: public snapshot/fromSnapshot; repeated restore; public shared payload across registers; retained snapshots and live raw payloads; mutation in both directions. No extra public arguments/exports/token properties. No live value freezing.
4. **Private counts**: object/scalar/reference wrappers, nested/shared subgraphs, null-prototype objects, negative zero; primitives avoid no new host clone. For eligible single pair, avoid exactly P object-payload clones, keep Map/register/Ticket allocation/copy boundaries. Unknown routes avoid zero copies.
5. **Failure order**: JSON accessors/cycles/depth/nonfinite/unsupported host values, missing capabilities, duplicate line/token/span/canonical head, malformed last reserved register and last move. Same error identity/text where applicable and same guards/model-read order. Check clock/storage/History/listeners, not only toJSON.
6. **Core behavior**: normal local edit and late rejection, remote concurrent overwrite/deletion, undo/redo with foreign writes, high-clock proof, composition begin/publish/cancel/failure, checkpoint capture/open/recovery, schema preview/upgrade. Compare full ops, snapshot and History, with only pre-agreed wall-clock group timestamps normalized.
7. **Receivers**: real, transparent Proxy and borrowed Doc/engine projections; readonly guard sentinel before all later failures. No new private-brand error.
8. **Performance controls**: counts separate from timing; confirm exactly which clone sites are changed. Include the public fallback paths and plain text/structural paths which should not benefit.

For the simpler KeyIndex alternative, keep tests 1, 5-8 plus C4 and an exhaustive small insertion differential (canonical/noncanonical, actor/range/sparse/span cases). Payload copy counts must be unchanged, not reduced.

## 10. Prospective useful-effect gate

Proposal for root to approve **before any timing**:

- Same frozen restored baseline, deterministic valid Data fixture, actor/keys/tickets, source/driver hashes and complete state oracle. No benchmarking against ec962 HEAD or the rejected COW candidate.
- Public setter + first relevant public read is the primary endpoint. Also report setter and first read separately; do not move work eagerly into the setter or report a helper speedup as a total result.
- Require at least **5% total median reduction in each 20k root Map / nested Map / List scenario in every accepted serialized ABBA cycle**. Require the setter not to regress by more than 3%. Require **no more than 3% total regression at 2k**. These are proposed gates, not historical receipts.
- Prespecify an absolute noise tolerance for tiny controls in the driver's own units before starting. Record host load without stopping unrelated work. A noisy/failed mandatory first cycle does not authorize favorable reruns or a revised threshold.
- Plan three cycles, with early stop on a mandatory failure. All untimed full-state oracles and unchanged-source hashes must pass. Keep test/full-suite and timing jobs serialized by root.
- A stage-specific improvement with a failed total gate is **DECLINED**, as for the prior COW candidate. No new timing was run here.

## 11. Exact source identities

Current HEAD is `ec9622571a04a7d7ea3f967bb3e6423b17ce5194`, but the reviewed source is **post-refactor WIP**, not that HEAD tree. SHA-256:

| Source under `packages/doc-sync/src/` | SHA-256 |
| --- | --- |
| `crdt/doc.ts` | `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` |
| `engine/typescript-client.ts` | `dbfedab406844f1e79c4d77656787ae0c438e09212c84f30efc06ad109b0d421` |
| `crdt/history.ts` | `d6e4efe3aa54bde4212f12b46e394aac2b898a690ccf95f7b85b806d4a08273b` |
| `crdt/annotations.ts` | `cc2257ad38afdb18a803eedda7968af05ab2be434b8ccfd064b0b04c64f0cac3` |
| `crdt/schema.ts` | `8e8afb39f1b6f8f6dc64dac19bdda056f23f11b1948458f5e3eea37d984809fe` |
| `crdt/key-index.ts` | `ff447129ce1d006ae1cb24430b21d448fbb41dc043098145b07a3bcee126a1dd` |
| `crdt/placement.ts` | `ad27804d11d719f95a6e138e3eabcf904cec515df84108a3e264471d41845e1d` |
| `crdt/fields.ts` | `0faf91e07a33d840816fc56cc1f0e3b556b2738b4a01754703872239f12d2ea9` |
| `data/schema.ts` | `3462f7d365c8ab496cc1e99d8bcf6a3da05df8055d7ffd5ff08f2d675a752192` |
| `data/access.ts` | `4d1d6395b832bd6c7f264acb38973b4b245b6aa96d9a9b1108507669e6611154` |

Old review evidence was not replaced. This report supplies new baseline ownership counterexamples, a bounded repair shape, and a smaller non-payload alternative. It does not qualify new production code.
