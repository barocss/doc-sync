# Local point-cache candidate decision

## Decision and current source

**DECISION: DECLINED. The copy-on-write (COW) candidate was not landed.**
The root retained only the initial API/structure refactor. The rejected prototype
has no accepted latency claim in the current library.

This is a **draft evidence handoff, not a final source-qualification seal**.
The root must append final restored-source test receipts and reseal the report.
The first restored full-workspace run is **FAIL**, with two underlying restart
failures: Bot detached-process cleanup returned EPERM, and MCP undo after-accept
reported recovery_required instead of clear. The 1,403-file test-input manifest
was unchanged. Its failing receipt is retained; investigation is active. The
retained public-contract cleanup passes 335 focused tests, including 162 new
behavior contracts. These results do not establish a full-suite PASS.

`rollback.json` records restoration of the eight changed existing modules and
removal of `internal/point-receipt.ts`. The 69 Core sources match the frozen
post-refactor baseline exactly. This worker independently checked those 69
hashes and the helper's absence in `restored-core-identity.json`. Identity is not
a test result. The restored source has no candidate point helper, original-surface
predicates, or new runtime exports. Prior reports and seals remain unchanged.

## Proof boundaries

| Layer | Result | Boundary |
| --- | --- | --- |
| Rejected prototype source review | APPROVE_CODE | High reviewer inspected the exact 70-source candidate manifest; not package, Chrome, or performance approval. |
| Rejected prototype focused tests | 480 PASS / 0 FAIL / 0 SKIP | 478 main tests plus two ticket tests; the 16 isolated preload cases overlap and must not be added. |
| Rejected prototype bounded types | PASS | Zero diagnostics in the recorded imported dependency closure, not a full-workspace check. |
| Final-size clone counts | PASS | Four separate 2k/20k before/current receipts; functional branch proof only. |
| First-cycle timing processes and oracles | 12 PASS_ORACLE | Eight Data processes and four direct-Doc processes completed; not a performance-gate PASS. |
| Mandatory performance gates | FAIL | 2k nested Map total regression; 20k nested Map/List useful-effect misses. |
| Timing cycles 2 and 3 | NOT_RUN | Early decline after mandatory first-cycle failures; no favorable rerun. |
| Restored full suite | FAIL, investigation active | First restored run: Bot cleanup and MCP undo-recovery failures; unchanged source manifest. A corrected gate is still required. |
| New package/build, Chrome, Rust/WASM, heap qualification | NOT_RUN | No such qualification for the rejected candidate. |
| Commit, push, release | NOT_RUN | This documentation task does not publish code or evidence remotely. |

Phase-1 Chrome/package receipts do not qualify the rejected prototype. They may
be reused for restored source only after the root checks exact source hashes.
The copied `restored-phase1-identity.json` records the root's bounded historical
identity check; it does not certify newly added tests or benchmark files.
No new Rust/WASM or browser qualification is implied.

## Prospective plan and stop rule

All three plan versions precede the first timing process:

| Receipt | UTC timestamp | Change |
| --- | --- | --- |
| `timing-plan.json` | 2026-11-03 17:39:22.648518 | Initial three-cycle design and per-cycle gates. |
| `timing-plan-v2.json` | 2026-11-03 17:41:40.773171 | Added the useful 5% combined large-size gate. |
| `timing-plan-v3.json` | 2026-11-03 17:43:30.951087 | Corrected count-mode CLI bounds for large fixtures and made early-decline reporting explicit. |
| `timing-start.json` | 2026-11-03 17:47:41.662808 | First timing began with v3 and final source hashes. |

Version 2 requires at least 5% total setter-plus-read reduction in every 20k
scenario. The reason was the cross-cutting Doc/History/Clock ownership complexity
for a narrow headless local path. First-read improvement alone was insufficient.
Version 3 changes the driver guard to permit count qualification at 2k/20k;
it does not change timing oracles or effect thresholds. No gate changed after
observing timing data. The independent audit's earlier large-count blocker is
historical: the final four count receipts use the corrected driver and final
candidate closure. Its earlier pending-source statements are not final failures.

Three ABBA cycles were planned. Cycle 1 failed mandatory gates, so the root
explicitly declined the candidate and did not run cycles 2/3. This is not a
three-cycle PASS, an incomplete series reported as PASS, or a selected favorable
rerun. Historical failed probes and red tests are preserved in review reports
and selected logs; they are not hidden behind later functional passes.

## Workload and measurement limits

- Node 24.22.1, stock executable, empty execArgv and NODE_OPTIONS.
- BEFORE is the frozen uncommitted post-refactor source, **not Git HEAD**.
  CURRENT in all candidate timing receipts means the rejected prototype, not
  today's restored runtime.
- At each size, ABBA uses four separate processes, three measured samples and one
  warmup per process: six raw observations per lane/case. Doc control uses the
  same process/sample/warmup pattern. These are not six independent hosts.
- N is the total entry count across root Map, nested Map and List, not N in each.
  Splits are 666/666/668 and 6,666/6,666/6,668. Stored List keys are nonempty.
- Data timers include a complete public Map.set/List.set, normal History, then
  the first public read. No eager read moves cost outside the setter interval.
  Full expected values/IDs/order, held-entry, reference/-0 and undo/redo checks
  run outside timing. Within each lane, raw Client.edit control and public
  setter replicas compare full snapshots/History with stated normalization.
  The driver does not export exact cross-source checkpoint equality; do not
  claim that stronger equivalence from the benchmark alone.
- Separate raw-edit fallback timings remain in the raw receipts and decision
  JSON. They are not optimized-path timings and are not pooled with them.
- Unrelated CAD jobs were preserved. Per-process load and host records are saved;
  starting load averages were 9.88/10.25/10.44. There is no isolated-host claim,
  no production SLA, and no causal attribution of a result to host noise.

## First-cycle Data results

Each cell is a median in milliseconds. Change is `(candidate / before - 1) × 100`;
negative means faster. Total medians use the raw combined samples, not the sum
of component medians. Values are rounded here; exact JSON and raw samples are
in the archive. The first-read gate is >=20% reduction for every case/size;
the total guard permits at most 5% regression, and the 20k useful gate requires
>=5% reduction in every case.

| Entries | Case | Setter before → candidate | Change | First read before → candidate | Change | Total before → candidate | Change | Mandatory gates |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 2,000 | root-map-overwrite | 79.9874 → 80.6854 | +0.87% | 8.7698 → 6.0885 | -30.57% | 88.7512 → 86.6157 | -2.41% | PASS |
| 2,000 | nested-map-overwrite | 67.7849 → 74.4390 | +9.82% | 8.1510 → 5.9844 | -26.58% | 76.2012 → 80.3169 | +5.40% | >5% total regression |
| 2,000 | list-item-set | 71.6159 → 69.5780 | -2.85% | 8.2050 → 5.2342 | -36.21% | 79.8140 → 75.0104 | -6.02% | PASS |
| 20,000 | root-map-overwrite | 817.8809 → 798.3969 | -2.38% | 102.6202 → 66.4315 | -35.26% | 922.7442 → 867.3164 | -6.01% | PASS |
| 20,000 | nested-map-overwrite | 802.3650 → 808.7684 | +0.80% | 101.1539 → 64.9611 | -35.78% | 905.1104 → 872.9801 | -3.55% | <5% large total reduction |
| 20,000 | list-item-set | 797.0064 → 804.1233 | +0.89% | 97.5537 → 65.0619 | -33.31% | 897.7067 → 871.6155 | -2.91% | <5% large total reduction |

All first reads improved by 26.58–36.21%. That does not override the combined
cost gates. The 2k nested Map total increased by 5.40%, beyond its guardrail.
The 20k nested Map and List totals improved by only 3.55% and 2.91%, below the
useful-effect threshold. Strict zero-total-regression sensitivity also fails the
2k nested Map case; passing a 5% guardrail elsewhere is not a claim of zero
observed regression. Setter-only increases remain visible above.

## Direct-Doc NIL-trace control

The 100k control imports direct Doc/schema and takes no storage/owner receipt.
All six first-cycle metric effects are non-regressive, within their prospective
5% per-metric guardrails. This does not rescue the failed Data gates or prove
zero overhead for all Doc workloads.

| Metric | Before median (ms) | Candidate median (ms) | Change |
| --- | ---: | ---: | ---: |
| `localEditMs` | 46.6835 | 46.3447 | -0.73% |
| `localColdToJSONMs` | 22.5402 | 21.8653 | -2.99% |
| `remoteApplyMs` | 2.3524 | 2.2357 | -4.96% |
| `remoteColdToJSONMs` | 32.2734 | 30.0216 | -6.98% |
| `localEditAndReadMs` | 68.7547 | 68.2709 | -0.70% |
| `remoteApplyAndReadMs` | 34.7466 | 32.2073 | -7.31% |

Each sample restores the same 100,000-UTF-16 seed, applies 16 deterministic
operations and ends at 100,032 UTF-16 units. Independent operation/model/full
physical-snapshot oracles pass. Local edit plus first toJSON and remote apply
plus first toJSON are separate totals. Wire serialization, transport, restore
and oracle work are outside timing. This is not network or editor latency.
No History layer is present in this direct-Doc control; the Data workload keeps
its normal History path.

## Functional qualification before decline

The rejected prototype fixed all four demonstrated findings before final review:

| Finding | Demonstrated defect | Final prototype resolution |
| --- | --- | --- |
| R1 | Optional trace-observer exception interrupted physical apply. | Revoke optional proof and preserve original apply/clock/cache behavior. |
| R2 | Doc private-brand access broke transparent Proxy receivers. | Guard optional private access after the original guard; Proxy gets no authority. |
| R3 | Public engine compatibility methods broke Proxy receivers or failed to revoke the real owner. | Preserve receiver/error behavior and revoke through private pointer associations. |
| R4 | Server-before-Client import adopted a late public override as original, bypassing malformed unrelated data validation. | Capture original surfaces in defining modules; overridden reads take legacy validation. |

The High reviewer issued **APPROVE_CODE** for the exact candidate manifest
SHA-256 `dff44206fe088af77f1c7da8537202e92c4a4608d17684753c755ec88e824987`.
That approval applies to the archived 70-source prototype only, not restored
source, packaging, browser behavior, performance, or release. The latest 480
focused passes supersede, rather than add to, overlapping 409/371/191 receipts.
The isolated preload suite's 16 cases are included in the main receipt.

The final 2k/20k count receipts prove first-read full data-root clones of one
BEFORE and zero in the eligible prototype for all three cases. Setter clones
are zero in both lanes; raw-edit fallback retains a full root clone. This is a
specific functional count, not a heap-allocation, retained-memory or universal
eligibility claim. Count instrumentation is absent from timing runs.

The history revocation contract is model-mutating undo/redo, not every History
action. Public overrides, escape, unsupported owners and uncertain proof decline
to the original full validation. Neither full setter work nor History was removed.
Those mechanisms were rejected with the prototype, not retained as a fast path.

## Evidence archive and draft handoff

Only copied, manifest-listed files are evidence for this report. References to
ignored `output/` paths name their archived original paths; ignored originals
alone are not publishable evidence. Extract `evidence.tar.gz` to inspect them.
It contains **84 files**, including all three plans, all **12** raw first-cycle
timings, all **four** final-size count receipts, decision/rollback, source/review
hashes, selected focused/type logs, historical reproducers, both final drivers,
the timing runner, source hook and a copied post-refactor baseline archive.
It excludes massive CLI events and unneeded screenshots/binaries.

`candidate-final-core.tar.gz` contains the exact **70** rejected Core sources;
this worker verified every member hash against `candidate-final-source.json`.
`candidate-proof-tests.tar.gz` preserves the rejected candidate's proof tests.
The archive is a bounded evidence package, not a claim of a standalone installed
runtime or independent reproduction on a clean host.

`evidence-manifest.json` records each archived file's path, byte count and SHA-256,
plus the outer archive identities below. `prior-report-identity.json` inventories
prior phase-1/phase-2 report files without changing them. No final `seal.json` is
created: final restored-source qualification is not yet part of this draft.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `evidence.tar.gz` | 378,063 | `bd68ab3f56e6a6c9e9cf2b700d34380b33f700269eba0202c7d3fe0d688cd887` |
| `candidate-final-core.tar.gz` | 212,180 | `480bc202e83234c95182cd257118fc5388ce07b41cd8d70dc1fc959c2e7a772d` |
| `candidate-proof-tests.tar.gz` | 18,052 | `36cabb6a70effca6f7d673dd2c6ad210994218c604e925b340b118fcfda4779a` |
| `prior-report-identity.json` | 1,512 | `60b0f7a3f6a818d9de0c71b1a8e8c87c12d5f4b841f3183cd33b7ddc8758bd51` |
| `restored-core-identity.json` | 8,318 | `34a28b0f8102b37ee5821dc413ddea1ed6ced043faed95d090f244d71b28586f` |

The root must add exact restored-suite counts/logs and any approved source-bound
receipt reuse before the final seal. This worker ran no build, heavy test,
benchmark, browser/mobile check, commit or push, and changed no implementation,
test, benchmark or HANDOFF file.

## Next investigation, not implementation

Investigate a private owned-attribute snapshot handoff that avoids redundant
trusted internal copies without removing `Doc.check`. This is read-only design,
not an implemented optimization or accepted speed result. Public admission,
normalization, selective History, schema transitions, recovery and fail-closed
fallback remain mandatory. P2 GC/resource, S3 integration and Rust/WASM gates
remain open.
