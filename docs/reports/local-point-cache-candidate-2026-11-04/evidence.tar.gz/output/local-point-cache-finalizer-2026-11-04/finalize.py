import pathlib,json,hashlib,tarfile,io,datetime,shutil,re
R=pathlib.Path('docs/reports/local-point-cache-candidate-2026-11-04')
O=pathlib.Path('output/local-point-cache-finalizer-2026-11-04')
D=pathlib.Path('output/data-cache-2026-11-04')
def sha(b): return hashlib.sha256(b).hexdigest()
def ident(p):
 b=pathlib.Path(p).read_bytes(); return dict(bytes=len(b),sha256=sha(b))
def write(p,d): pathlib.Path(p).write_text(json.dumps(d,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Preserve the draft before changing any report byte. Never overwrite these records.
for n in ['README.md','evidence-manifest.json','documentation-checks.json','evidence.tar.gz']:
 t=O/('draft-'+n)
 if not t.exists(): shutil.copyfile(R/n,t)
for p,n in [('HANDOFF.md','handoff-before.md'),('apps/docs/src/roadmap.md','roadmap-before.md')]:
 
 if not (O/n).exists(): shutil.copyfile(p,O/n)
old=json.loads((R/'evidence-manifest.json').read_text())
assert ident(R/'evidence.tar.gz')['sha256']=='bd68ab3f56e6a6c9e9cf2b700d34380b33f700269eba0202c7d3fe0d688cd887'
write(O/'draft-provenance.json',dict(preservedAt=now,status='IMMUTABLE_PRIOR_DRAFT_NOT_FINAL_QUALIFICATION',files={n:ident(O/('draft-'+n)) for n in ['README.md','evidence-manifest.json','documentation-checks.json','evidence.tar.gz']}))
members={}
with tarfile.open(O/'draft-evidence.tar.gz') as t:
 for m in t.getmembers():
  assert m.isfile()
  members[m.name]=t.extractfile(m).read()
assert len(members)==84
for e in old['archiveEntries']:
 assert sha(members[e['path']])==e['sha256'] and len(members[e['path']])==e['bytes']
# Live source/phase-1 identity: no test/build execution.
source=json.loads((D/'final-restored-checkpoint-source.json').read_text())
result=json.loads((D/'final-restored-checkpoint-result.json').read_text())
assert sha((D/'final-restored-checkpoint-source.json').read_bytes())==result['sourceManifestSHA256']
assert len(source['files'])==1403
assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in source['files'].items())
prior=json.loads((R/'prior-report-identity.json').read_text())['files']
assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in prior.items())
core=json.loads((R/'restored-core-identity.json').read_text())['files']
assert len(core)==69 and all(sha(pathlib.Path(p).read_bytes())==h for p,h in core.items())
assert not pathlib.Path('packages/doc-sync/src/internal/point-receipt.ts').exists()
with tarfile.open('docs/reports/api-structure-refactor-2026-11-03/post-refactor-core.tar.gz') as t:
 for p,h in core.items(): assert sha(t.extractfile('post-refactor-baseline/'+p).read())==h
phase=json.loads(pathlib.Path('docs/reports/api-structure-refactor-2026-11-03/tested-source.json').read_text())
phase=phase['files']
diff=[p for p,h in phase.items() if sha(pathlib.Path(p).read_bytes())!=h]
assert sorted(diff)==['apps/bot/test/brief-runner.test.ts','apps/mcp/test/automatic-recovery-process.test.ts'],diff
write(O/'current-runtime-identity.json',dict(at=now,sourceManifestSHA256=result['sourceManifestSHA256'],currentSourceFiles=1403,currentSourceMismatches=[],restoredCoreExact=69,restoredCoreMatchesQualifiedArchive=True,phase1HistoricalFiles=1391,phase1CurrentMatches=1389,phase1CurrentDifferences=diff,productionRuntimeUnchanged=True,newBenchmarkFilesAreNotRuntimeQualification=True,priorReportFilesUnchanged=len(prior),candidateArchivesUnchanged={n:ident(R/n) for n in ['candidate-final-core.tar.gz','candidate-proof-tests.tar.gz']},receiptReuse='Unchanged phase-1 package/four editor LocalSync/custom/Graphic/Sheet/Presence Chrome receipts only; not new tests, rejected COW, or new Rust/WASM qualification.'))
selected=[]
def add(p):
 p=pathlib.Path(p); assert p.is_file(),p
 b=p.read_bytes()
 if str(p) in members: assert members[str(p)]==b
 else: members[str(p)]=b
 selected.append(str(p))
for n in ['final-restored-checkpoint-source.json','final-restored-checkpoint-result.json','restored-phase1-identity.json','restored-final-test-source.json','restored-final-test-source-result.json','restored-harness-test-source.json','restored-harness-test-source-result.json','restored-full-test-totals.json','docs-chrome-receipt.json','restore-tests.report.md','restore-tests-focused.json','restore-tests-focused.log','restore-tests-integrity.json','restore-tests-original-registration-counts.json','restore-tests-source-before.json','restore-tests-typecheck.json','restore-tests-typecheck.log','restore-tests-count.mjs','restore-tests-edit.py','restore-tests-run.py','restore-tests-typecheck.mjs']:
 add(D/n)
P=pathlib.Path('output/refactor-2026-11-03')
for stem in ['final-restored-checkpoint-tests','final-restored-checkpoint-types','final-restored-checkpoint-docs-build','final-restored-checkpoint-docs-check','restored-point-candidate-full-tests','restored-point-fixed-harness-full-tests','restored-point-final-typecheck','restored-point-final-typecheck-corrected','restored-point-bot-type-fix']:
 for ext in ['json','log']: add(P/(stem+'.'+ext))
P=pathlib.Path('output/recovery-worker-2026-11-04')
for n in ['investigation.report.md','receipt.json','group-lifetime.log','owned-tests.patch','final-focused.log','bot-live-group-1.log','mcp-diagnostic-1.log','mcp-focused-file.log','source-before.json','source-after.json']:
 add(P/n)
for p in (P/'probes').iterdir():
 if p.is_file() and p.suffix in ['.mjs','.py']: add(p)
P=pathlib.Path('output/recovery-test-failures-2026-11-04')
for n in ['mcp-high-review.report.md','barrier-tests.report.md','barrier-tests.receipts.json','barrier-tests.automatic-recovery-file.log','barrier-tests.history-cases.log','barrier-tests.new-test.log','barrier-tests.noemit.json','barrier-tests.noemit.log','barrier-tests.owned.patch','barrier-tests.run.py','barrier-tests.source-before.json','barrier-tests.source-after.json']:
 add(P/n)
for p in (P/'probes').iterdir():
 if p.is_file(): add(p)
for p in ['apps/bot/test/brief-runner.test.ts','apps/mcp/test/automatic-recovery-process.test.ts','packages/doc-sync/test/data-read-contract.test.ts','packages/doc-sync/test/engine-read-contract.test.ts','packages/doc-sync/test/data-point-preload.test.ts','packages/doc-sync/test/fixtures/data-point-preload.mjs']:
 add(p)
for p in ['output/owned-snapshot-2026-11-04/design.report.md','output/owned-snapshot-2026-11-04/baseline-probe.json','output/owned-snapshot-2026-11-04/baseline-probe.mjs','output/index-restore-2026-11-04/census.report.md','output/index-restore-2026-11-04/census-receipt.json','output/index-restore-2026-11-04/counts.json','output/index-restore-2026-11-04/profile-classification.json']:
 add(p)
for n in ['draft-README.md','draft-evidence-manifest.json','draft-documentation-checks.json','draft-provenance.json','current-runtime-identity.json','finalize.py']: add(O/n)
# The original 84 members remain byte-exact. New bounded receipts use their original paths.
with tarfile.open(R/'evidence.tar.gz','w:gz') as t:
 for p,b in sorted(members.items()):
  m=tarfile.TarInfo(p); m.size=len(b); m.mtime=0; m.mode=0o644; t.addfile(m,io.BytesIO(b))
write(O/'archive-result.json',dict(files=len(members),preservedDraftMembers=84,archive=ident(R/'evidence.tar.gz'),selectedNewReceipts=len(members)-84))
print(json.dumps(dict(files=len(members),archive=ident(R/'evidence.tar.gz'),phase1CurrentDifferences=diff),indent=2))
