# KeyIndex restore work census

## 결정: DECLINE_OPPORTUNITY

**Evidence:** 20,000개 항목에서 재구성 삽입은 60,015회다. 그러나 `KeyIndex.set` 전체 포함 비용은 관측된 edit+read 표본의 약 **1.1%**다. 중복 파싱은 이 비용의 일부다.

**Inference, 신뢰도 중간:** 이 후보가 전체 비용을 5% 줄일 근거는 없다. 구현·비교 성능 측정으로 진행하지 않는다. `PROCEED_TO_DESIGN`이 아니다. 소유권 이전 후보의 기존 **HOLD**도 유지한다.

이 결론은 한 root Map overwrite의 작업 분류다. 새 성능 개선, SLA, 통계적 보편성 또는 모든 workload의 상한을 주장하지 않는다.

## 1. 기존 기록 재사용 판단

| 기록 | 직접 확인한 내용 | 이번 판단에 사용하는 범위 |
|---|---|---|
| `core-performance.cpuprofile` + `core-performance-pre.json` | 20k List/Map, 5 edits. `fromSnapshot` 프레임은 소스 2568행이다. 현재는 2575행이다. 기존 보고서는 primitive-copy 변경 전 기록이라고 명시한다. seed 이후 method wrappers와 명시적 GC도 포함한다. | 역사적 참고만. post-refactor 전체 비용의 분모로 사용하지 않는다. 그 기록의 KeyIndex.set 포함 표본은 48개, 가중치 30.002 ms, 전체 0.528%였다. |
| `repro-core-baseline-receipt.cpuprofile` + 동일 prefix JSON | ec962 외부 archive, doc hash `ec194391...`, 40 entries, 2 samples, CPU 표본 21개. | 현재 WIP/20k와 불일치. 기각. |
| `repro-profile-collision.cpuprofile` | JSON 프로필이 아니다. 실제 내용은 `preserve this profile`이다. 충돌 보호 검사의 sentinel이다. | CPU 증거가 아니다. |
| `repro-core-current-receipt.json` | 현재 doc hash와 일치하지만 40 entries이고 profile=0이다. | 현재 20k CPU 증거가 아니다. |

각 입력의 전체 SHA-256은 `census-receipt.json`에 보존했다. 첫 프로필을 ec962 HEAD 또는 현재 WIP의 프로필로 표시하지 않았다.

## 2. 실행과 범위

- Node: `v24.22.1`. 실행 파일: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`. execArgv 없음. NODE_OPTIONS 없음.
- 현재 HEAD는 `ec9622571a04a7d7ea3f967bb3e6423b17ce5194`다. **실행한 소스는 그 HEAD tree가 아닌 post-refactor WIP**다.
- 실행 전·후 Core 69개 `.ts` 파일이 frozen `post-refactor-baseline/packages/doc-sync/src`와 byte-for-byte 일치했다. 전체 파일별 hash는 counts/profile/receipt JSON에 있다.
- `benchmarks/data-point-cache.mjs:57-145`의 선형 fixture와 oracle 논리를 out-only 모듈에 복사했다. CLI harness는 import하지 않았다. actor, IDs, tickets, values를 유지했다.
- 전체 entries 20,000개: root Map 6,666개, nested Map 6,666개, List 6,668개. collection nodes 2개, line heads 3개. 저장 토큰 합계 20,005개.
- 각 프로세스에서 `Client.fromState` 및 정상 첫 public reads로 seed/cache 준비를 마쳤다. 그 뒤 기존 root Map 중간 key에 `set(1000)` 1회와 `get` 1회를 수행했다. 정상 History를 사용했다.
- count 모드에만 `Doc.fromSnapshot` 및 `KeyIndex.prototype.set` wrapper를 설치했다. CPU 모드는 wrapper, prototype 변경, intrinsic 변경 없이 inspector만 사용했다.
- CPU seed/restore는 profile 시작 전이다. 전체 model/collection/snapshot/History oracle은 profile 종료 후다. 측정 대상과 무관한 fixture 생성은 profile에 없다.
- 측정 프로세스는 count 2.257초, profile 2.250초였다. 각각 subprocess watchdog 29초, 발동 없음. 전체 benchmark driver는 실행하지 않았다.
- 별도 최초 preflight는 압축 snapshot에서 생략된 `i`를 잘못 읽어 0.972초에 중단됐다. setter/wrapper/profile 시작 전이었다. seed의 명시적 키를 사용하도록 out-only script만 수정했다. 실패 로그를 보존했다. 실제 count 1회, profile 1회 외 추가 edit 실행은 없다.

## 3. 정확한 호출 수 — Evidence

`doc.ts:335-349` constructor는 임시 root를 1회 삽입한다. `fromSnapshot`은 이를 clear한 뒤 `2599-2609`에서 각 logical token을 삽입한다.

| restore | snapshot logical tokens | constructor set | rebuild set | canonical rebuild |
|---|---:|---:|---:|---:|
| 1 | 20,005 | 1 | 20,005 | 20,005 |
| 2 | 20,005 | 1 | 20,005 | 20,005 |
| 3 | 20,005 | 1 | 20,005 | 20,005 |
| 합계 | 60,015 | 3 | 60,015 | 60,015 |

- `fromSnapshot`: 정확히 3회. `KeyIndex.set`: 전체 60,018회. restore 밖 set은 0회.
- 각 restore의 실제 set key 배열 전체를 `[temporary root, ...seed logical keys]`와 비교했다. 단순 길이 추정이 아니다.
- 60,015회가 canonical reuse 후보의 parse 기회 수다. 60,018회가 아니다. constructor의 3회는 이번 후보 범위 밖이다.
- fixture에는 noncanonical key/span alias가 없다. 이 count가 그 admission을 변경할 권한은 아니다.
- 압축 snapshot의 생략된 `i`는 `itemFromJSON`이 previous ticket으로 복원한다 (`doc.ts:2714-2737`). source formula와 actual count가 일치했다.

## 4. CPU 분류 — Evidence

`point-edit.cpuprofile`: 1,000 μs 요청 sampling interval. 전체 706 samples, 가중치 합계 1,082.084 ms. inspector stack 2 samples / 112.959 ms를 분리하면 **704 samples / 969.125 ms**다. 아래 ms는 sample delta 가중치이며 독립 함수 timer가 아니다.

| stage | samples | weighted ms | 전체 표본 비율 | inspector 제외 비율 |
|---|---:|---:|---:|---:|
| KeyIndex.set self | 7 | 10.583 | 0.978% | 1.092% |
| KeyIndex.set inclusive | 7 | 10.583 | 0.978% | 1.092% |
| restore 아래 KeyIndex.set inclusive | 7 | 10.583 | 0.978% | 1.092% |
| set 아래 find descendants | 0 | 0 | 0% | 0% |
| set 아래 join descendants | 0 | 0 | 0% | 0% |
| Doc.fromSnapshot inclusive | 305 | 439.169 | 40.585% | 45.316% |
| KeyIndex 모든 함수 self | 19 | 25.417 | 2.349% | 2.623% |

`find`/`join`의 0 표본은 호출이 없거나 비용이 0이라는 뜻이 아니다. V8 inlining과 표본 누락을 분리할 수 없다. 문자열 parse 역시 `set` 안에서 따로 분리할 수 없다. **set inclusive 전체를 avoided parsing의 관측 상한 proxy로 사용**했다. 실제 저장, range/sparse 처리 및 dynamic find/join은 여전히 필요하므로 모두 절감할 수는 없다.

동일 profile의 큰 self buckets: `validJSON` 273.249 ms, host structuredClone 두 계열 119.002 + 56.418 ms, GC 77.871 ms. 겹치는 inclusive 시간을 더하지 않았다. GC를 KeyIndex에 귀속하거나 allocation 수를 추정하지 않았다.

## 5. 5% gate 판단 — Inference / Unknown

- 5% 전체 절감에는 inspector 제외 가중치 기준 약 48.456 ms가 필요하다. 이는 관측된 **set 전체** 10.583 ms의 약 4.58배다. 실제 회피 대상 parse는 그 일부다.
- 따라서 root workload에서조차 material stage라는 근거가 없다. root/nested/List 전부에서 5%를 요구하는 다음 단계로 갈 이유가 부족하다. nested/List 추가 profile이나 helper microbenchmark를 실행하지 않았다.
- 표본은 7개뿐이다. 단순 count의 대략적 상대 sampling noise는 `1/sqrt(7)`, 약 38% 규모다. 이는 weighted time의 공식 신뢰구간이 아니다. sampling bias, inlining, 긴 sample delta, JIT 및 host scheduling 오차도 남는다.
- loadavg(1/5/15분)는 시작과 끝 모두 10.679 / 17.820 / 17.519였다. Apple M3 Max 16 logical CPU다. host가 idle이라고 주장하지 않는다. 다른 CAD/agent 프로세스를 중단하지 않았다.
- 이 기록은 정확한 인과적 절감 상한을 증명하지 않는다. GC 간접 효과나 다른 데이터 분포는 Unknown이다. 그러나 재파싱 제거의 5% 효과를 지지하는 관측 증거도 없다. 추가 성능 cycle을 쓰지 않는 결정은 **DECLINE_OPPORTUNITY**, 전 workload 불가능 증명은 아니다.

## 6. 다음 후보의 순위와 계약

| 순위 | source-grounded 방향 | 판단 |
|---|---|---|
| 1 | 소스 변경 없이 큰 validation/clone stage의 호출별 work census. JSON 방문과 payload 복사를 각각 유지한 채 중복 work의 실제 지점을 분류한다 (`annotations.ts:41-57`, `doc.ts:2575-2673,2694-2737`). | 향후 root가 별도 승인할 read-only 조사 후보. 검증 생략·공유 캐시·속성 이전을 승인하지 않는다. |
| 2 | `doc.ts:2605`의 fresh ticket을 canonical index 삽입에 재사용. | 이번 census로 DECLINE. payload 의미는 작지만 material gate 근거가 부족하다. |
| 제외 | private attribute handoff, trusted flag, engine import 시점 prototype capture. | 기존 HOLD/거부 유지. own items.map 및 ArraySpecies payload escape를 해결하지 않는다. |

이 보고서는 새 구현 설계가 아니다. root가 나중에 canonical insertion을 다시 선택하더라도 다음 계약은 남는다.

- 모든 snapshot JSON 검사, payload별 copy, canonical duplicate Set, public admission, History 및 wire를 유지한다.
- `01@actor` 뒤 `1@actor`는 legacy처럼 canonical duplicate로 거부해야 한다. KeyIndex.other와 byKey.has로 canonical Set을 대체할 수 없다 (`owned-snapshot` C4).
- multi-@ actors, safe integer/span, sparse/range, alias와 insertion metadata를 유지한다.
- public `KeyIndex.set` override/getter/receiver 및 dynamic `find`/`join` dispatch를 유지한다. 원본 capture가 필요하면 defining module에서 해야 한다. trusted 인수나 뒤늦은 prototype capture로 우회하지 않는다.

## 7. 검증 상태와 산출물

**PASS:** 두 모드 모두 complete public model, 세 collection 전체 entries/ID/order/value, complete snapshot, complete History의 set ownership/steps/tickets/currentSets, history status, captured document oracle. History group timestamp만 finite number로 별도 검사했고 나머지 전체 객체는 seed-derived 기대값과 deepEqual했다. 실제 undo/redo 실행은 이번 범위가 아니다.

**PASS:** Core69 frozen archive 일치 및 실행 전후 소스 hash 불변. **NOT_RUN:** production candidate, candidate tests, 전체 tests/build, browser/mobile, 비교 timing/ABBA, SLA, commit/push/release. root의 기존 2081 PASS / 2 SKIP는 사용자 인계 정보이며 이 worker가 재실행하거나 새 검증으로 주장하지 않는다.

핵심 파일:
- `census-run.mjs`: out-only fixture/count/profile/oracle 모듈.
- `counts.json`, `profile.json`: 전체 source SHA, fixture SHA, Node/host 정보, 검증 결과.
- `point-edit.cpuprofile`, `classify-profile.py`, `profile-classification.json`: raw CPU와 재현 가능한 분류.
- `census-receipt.json`: 최종 source 일치, 기존 입력 hashes, 실행/실패 범위.
- `counts-preflight-failure.log`, `counts.log`, `profile.log`: 실패와 성공 로그.

SHA-256:
- doc.ts: `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d`
- key-index.ts: `ff447129ce1d006ae1cb24430b21d448fbb41dc043098145b07a3bcee126a1dd`
- Core69 sorted source-hash JSON: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`
- fixture state: `6fde989b9a0dd8a7d7c0656ace8981d268bb3e99b5512210825d36e643aaf6c8`
- out-only script: `2a21f8b6450b364345fe61596e7ab40627f576e1716504f2b069758edd7e8b97`
- raw point-edit CPU: `b268b162c420ab04f56e53ee619668ade175275e53b57eb9a6f2a21e748acae7`
