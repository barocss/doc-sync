from pathlib import Path
import subprocess,os,signal,json,datetime,hashlib
repo=Path('/Users/user/github/doc-sync')
out=repo/'output/recovery-test-failures-2026-11-04'
node='/Users/user/.nvm/versions/node/v24.22.1/bin/node'
test='apps/mcp/test/automatic-recovery-process.test.ts'
runs=[('new-test',['--test-name-pattern=MCP startup waits for atomic recovery']),('history-cases',['--test-name-pattern=MCP killed during']),('automatic-recovery-file',[])]
receipts=[]
for name,options in runs:
    command=[node,'--test','--test-reporter=tap',*options,test]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    log=out/f'barrier-tests.{name}.log'
    with log.open('w') as f:
        p=subprocess.Popen(command,cwd=repo,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        timedout=False
        try: code=p.wait(timeout=90)
        except subprocess.TimeoutExpired:
            timedout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
        finally:
            # Only this invocation's process group. Do not touch sibling workers.
            try: os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError: pass
    receipt={'name':name,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'exit':code,'watchdogTriggered':timedout,'testSha256':hashlib.sha256((repo/test).read_bytes()).hexdigest(),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    receipts.append(receipt)
    (out/'barrier-tests.receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
    print(log.read_text(),flush=True)
    if code: break
