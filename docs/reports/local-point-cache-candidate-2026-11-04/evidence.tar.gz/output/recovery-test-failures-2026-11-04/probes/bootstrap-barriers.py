"""Output-only derivation of ONE original case with two transport barriers.
Run with python3. No repository source is edited. Outer watchdog owns its child group.
"""
from pathlib import Path
import subprocess, os, signal, hashlib, json, datetime
repo = Path('/Users/user/github/doc-sync')
out = repo / 'output/recovery-test-failures-2026-11-04/probes'
src = repo / 'apps/mcp/test/automatic-recovery-process.test.ts'
s = src.read_text()
helpers = s[:s.index('test("recovery reservation survives')]
case = s[s.index('for (const action of ["undo", "redo"]'):s.index('test("unavailable atomic recovery')]
case = case.replace('["undo", "redo"] as const', '["undo"] as const').replace('["before-send", "after-accept"] as const', '["after-accept"] as const')
base = src.as_uri()
helpers = helpers.replace('"../../../fixtures/demo-schema.ts"', json.dumps((repo/'fixtures/demo-schema.ts').as_uri())).replace('import.meta.url', json.dumps(base))
helpers += '\nlet gatePhase = "recover-change";\n'
helpers = helpers.replace('let armed = false, changes = 0, recoveries = 0;', '''let armed = false, changes = 0, recoveries = 0, streams = 0;
    let releaseGate!: () => void, seeGate!: () => void;
    const held = new Promise<void>(r => {releaseGate = r;});
    const seen = new Promise<void>(r => {seeGate = r;});''')
helpers = helpers.replace('const change = req.method', 'if (req.url?.includes("/stream")) streams++;\n        const change = req.method')
needle = '            res.writeHead(response.statusCode ?? 502, response.headers);'
assert helpers.count(needle) == 1
helpers = helpers.replace(needle, '''            if (mode === "pass" && (gatePhase === "stream" ? req.url?.includes("/stream") : req.url?.endsWith("/recover-change"))) {
                response.pause(); seeGate();
                void held.then(() => {res.writeHead(response.statusCode ?? 502, response.headers); response.pipe(res);});
                return;
            }
''' + needle)
helpers = helpers.replace('return {origin: `http://127.0.0.1:${address.port}`, arm()', 'return {gateSeen: () => deadline(seen,"controlled gate"), releaseGate, streams: () => streams, origin: `http://127.0.0.1:${address.port}`, arm()')
first = '            mcp = await connectMcp(resumedProxy.origin, journal);'
assert case.count(first) == 1
case = case.replace(first, '''            let firstSettled = false;
            const firstConnect = connectMcp(resumedProxy.origin, journal).then(x => {firstSettled = true; return x;});
            await resumedProxy.gateSeen();
            assert.equal(firstSettled, false, "stdio cannot initialize before recover response");
            assert.equal(resumedProxy.streams(), 0, "recovery must precede SSE admission");
            console.log("BARRIER recover-change: stdio uninitialized, SSE requests 0");
            resumedProxy.releaseGate();
            mcp = await firstConnect;''')
second = '''            mcp = await connectMcp(demo.origin, journal);
            assert.equal(value<{status: string}>(await call(mcp.client, "recovery_status")).status, "clear");'''
assert case.count(second) == 1
case = case.replace(second, '''            gatePhase = "stream";
            resumedProxy = await historyProxy(demo.origin, "pass");
            let secondSettled = false;
            const secondConnect = connectMcp(resumedProxy.origin, journal).then(x => {secondSettled = true; return x;});
            await resumedProxy.gateSeen();
            assert.equal(secondSettled, false, "repeated restart stdio cannot initialize before compatible hello");
            assert.equal(resumedProxy.recoveries(), 0, "settled checkpoint needs no atomic resubmission");
            console.log("BARRIER repeated restart stream: stdio uninitialized, recoveries 0");
            resumedProxy.releaseGate();
            mcp = await secondConnect;
            const repeatedStatus = value<{status: string}>(await call(mcp.client, "recovery_status"));
            assert.equal(repeatedStatus.status, "clear", JSON.stringify({repeatedStatus, checkpoint: JSON.parse(await readFile(checkpointPath,"utf8")), server: await state(demo.origin), stderr:mcp.diagnostics()}));''')
file = out/'bootstrap-barriers.generated.probe.ts'
file.write_text(helpers+case)
node = '/Users/user/.nvm/versions/node/v24.22.1/bin/node'
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'bootstrap-barriers.log').open('w') as log:
    p = subprocess.Popen([node,'--test',str(file)], cwd=repo, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    timedout=False
    try: code=p.wait(timeout=30)
    except subprocess.TimeoutExpired:
        timedout=True; os.killpg(p.pid,signal.SIGKILL); code=p.wait()
receipt = {'start': start, 'exit': code,'watchdogTriggered':timedout,'node':node,'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'probeSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'logSha256':hashlib.sha256((out/'bootstrap-barriers.log').read_bytes()).hexdigest()}
(out/'bootstrap-barriers.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt)); print((out/'bootstrap-barriers.log').read_text())
