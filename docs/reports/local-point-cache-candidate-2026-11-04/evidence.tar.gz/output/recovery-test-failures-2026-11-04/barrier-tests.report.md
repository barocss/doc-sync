# Automatic recovery barrier tests

## Result and limits

- Diagnostic coverage corrected: PASS.
- Controlled startup ordering regression: PASS.
- Original MCP failure: **NOT_REPRODUCED / UNRESOLVED**. No product fix is claimed.
- No first failure occurred in this worker's three test invocations or focused noEmit check.
- Original full-run failure remains preserved in `output/refactor-2026-11-03/restored-point-candidate-full-tests.log`. Original line 358 maps to entry-source line 361, the repeated restart, not the first recovery. After this extraction, the repeated clear assertion is at line 421.

## Ownership and baseline

Only `apps/mcp/test/automatic-recovery-process.test.ts` was edited outside this output directory. No new helper file was needed. Existing WIP was retained. No product/Core/Bot/docs/benchmark file was edited. No further agent, build, global test suite, root tsc, browser, mobile, commit, push or runtime API/proof-gate change was used.

Read the High report, derivation script and generated probe in this directory. Entry test SHA-256 was `8aeca4e34ffc161f970d3a0b92aebbad6739e9d8deb24e22a69bae6d526aaebe`, exactly the High probe source hash. Final test SHA-256 is `fda60c373ff7f9b4a381ecd8be526e83ea85f29261a768e89e99f29b518d3e2e`.

The six product paths in `barrier-tests.source-before.json` and `barrier-tests.source-after.json` are unchanged and match the High report: MCP main/session/journal, sync client, server hub and demo server. This is a six-path hash audit, not a whole-workspace immutability claim. Core69 qualification is inherited context, not requalified here.

## Changes

1. Repeated restart calls `recovery_status` exactly once. Assertions retain `clear` and include `stage: repeated-restart`, action, mode, the complete tool response (including its recovery message) and captured MCP stderr. No diagnostic GET, checkpoint read, sleep or other extra I/O was added to the four healthy original sequences. The first-stage diagnostic is unchanged.
2. Extracted the existing four-case scenario into a local function. The four original names, action/mode combinations, platform guard, 45-second deadline, ordinary transport sequence and assertions remain. Controlled startup is off for them. The new named test runs the existing undo/after-accept scenario with startup barriers enabled, without duplicating the scenario or importing output artifacts.
3. First barrier holds the HTTP 200 atomic recovery response. It asserts stdio is not connected, recover count is exactly 1, and SSE request count is 0. It then releases explicitly and requires immediate `clear`, ordinary count 0, recover count 1, original human content and exact accepted receipt sequence.
4. The controlled case reads the settled checkpoint and requires zero pending changes. It kills MCP and restarts the server, as the original scenario does. A separate proxy holds the repeated startup stream response before forwarding hello. It asserts stdio is not connected, stream count 1, recover count 0 and ordinary count 0. After explicit release it requires immediate `clear`, zero resend/recovery counts, no duplicate text, the opposite history action and preserved human text.
5. Added rejection observation and gate release during cleanup for an outstanding controlled connection. Existing process/proxy cleanup and deadlines remain. Each test invocation had its own process group and a 90-second outer watchdog. The runner cleaned only its own group after exit; no watchdog fired.

No poll-until-clear, arbitrary delay, retry, force-clear, relaxed success/error alternative or new skip was added. Existing fixture synchronization polling is unchanged. Barriers exercise two selected phases; they do not prove absence of all races or identify the original recovery error.

## Gates and exact receipts

Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node` (v24.22.1). The process tests use current package dist exports, as before. No build was run.

| Gate | PASS | FAIL | SKIP | CANCELLED | Duration (runner ms) |
| --- | ---: | ---: | ---: | ---: | ---: |
| New named startup barrier test, once | 1 | 0 | 0 | 0 | 1626.132792 |
| Four original killed undo/redo history cases, once | 4 | 0 | 0 | 0 | 5147.588125 |
| Entire automatic recovery file, once | 8 | 0 | 0 | 0 | 9082.414291 |

These runs overlap. Do not sum them as independent coverage. Full file coverage is **8 PASS**, not 13 distinct tests. All commands, timestamps, exit codes and SHA-256 log/test anchors are in `barrier-tests.receipts.json`. Logs are `barrier-tests.new-test.log`, `barrier-tests.history-cases.log` and `barrier-tests.automatic-recovery-file.log`.

Focused TypeScript noEmit used the root base compiler options and only this test entry plus its imports. TypeScript 5.8.3: **0 diagnostics**, exit 0. See `barrier-tests.noemit.json` and `.log`. This is not root tsc. `git diff --check -- apps/mcp/test/automatic-recovery-process.test.ts`: PASS, no output.

`barrier-tests.owned.patch` records only the delta from this worker's entry snapshot, not inherited WIP. `barrier-tests.test-before.ts` preserves that snapshot as an output-only receipt. Normal tests depend on neither file, Git, output nor archived source.

## Handoff

Root can run full tests/types and perform its docs/seal work. Do not treat these controlled passes or the earlier parent full-suite pass as resolution of the original unknown repeated-restart failure. No product root cause was established. The next recurrence should now retain the complete repeated-stage recovery response and stderr.
