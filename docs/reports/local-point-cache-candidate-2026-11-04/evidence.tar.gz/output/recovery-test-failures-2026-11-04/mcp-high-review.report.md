# MCP recovery review — 2026-11-04

## Scope and evidence basis

- Workspace: `/Users/user/github/doc-sync`; HEAD `ec9622571a04a7d7ea3f967bb3e6423b17ce5194`.
- Start: 2026-11-03T18:12:17Z (2026-11-04 03:12:17 KST).
- Read-only product/source/test analysis. Own only this report, `mcp-high-review.final.md`, and small output-only probes. Existing WIP is not mine. No agents, builds, dist writes, workspace test run, browser/mobile, commit or push.
- Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`, v24.22.1.
- Basis: live files and original failed receipt, not older engineering memory. Investigation complete; no product fix claimed.

## Important correction: original failure is the repeated restart

**Evidence:** original full log lines 2306–2323 locates the assertion at `automatic-recovery-process.test.ts:358:20`. The saved worker patch adds exactly three lines at the FIRST recovery assertion, originally line 344, now line 346. It makes no earlier line-count change. Therefore original line 358 maps to CURRENT line 361, the SECOND/repeated restart assertion. Current first-recovery diagnostic at lines 346–347 does not cover that failure site.

The earlier first automatic recovery, ordinary-send count 0, recover count 1, local human text check and exact accepted sequence check had already passed in the original failing run. This is not a failure of the initial accepted pending recovery assertion. Root should preserve diagnostics at the second restart if it fails again; do not change expected `clear`.

Original case duration was 1143.042208 ms. The 10-second synchronization timeout is not supported as the original failure mechanism.

## Readiness hypothesis

**Evidence:** `main.ts:139–146` awaits `session.start()` before creating and connecting the stdio SDK server. `session.ts:137–150` awaits every atomic pending recovery, restores checkpoint metadata, connects, waits for synchronized + matching epoch + schema + empty pending, and awaits checkpoint persistence. `recoveryStatus()` reports stored recovery errors (`session.ts:421–433`).

**Inference, high confidence:** a normally connected stdio client cannot observe a merely unfinished automatic recovery because hello arrived early. Failure can be a completed, fail-closed bootstrap recovery error, not a reason to poll until clear. The same applies to the second restart.

EOF cleanup awaits bootstrap (`main.ts:71–80`), while input remains buffered until SDK admission (`stdio-lifetime.ts:3–17`). EOF during bootstrap closes admission rather than returning a valid recovery status before bootstrap completion.

## Final result

**NOT_REPRODUCED.** No concrete product root cause was established. No source or test fix was implemented. The supplied worker report incorrectly treats the failing line as the first recovery; this review corrects that localization from the actual log and saved patch.

The parent-owned rerun completed while this review was active:

- `restored-point-fixed-harness-full-tests.json`: PASS, exit 0, 103.332 seconds, watchdog not triggered.
- Its MCP workspace section: 193 tests, 191 PASS, 0 FAIL, 2 existing SKIP; undo after-accept PASS (1267.202458 ms).
- This is an observed receipt, not a test run started by this investigator. It does not establish the cause of the original intermittent failure or qualify a product recovery fix.

## Ranked synthesis

Confidence below concerns the stated classification, not an invented probability for an unobserved error.

| Rank | Explanation | Confidence / evidence |
| --- | --- | --- |
| 1 | A caught error inside **second** `restoreCheckpoint()` made startup complete in fail-closed `recovery_required`. | High for the failure class; exact subcause unknown. Original second assertion failed only after the first recovery, count checks, human text and accepted sequence checks passed. `start():73–83` catches restore errors and `recoveryStatus():425` returns them. |
| 2 | Second-start HTTP state/reservation failure or state mismatch. | Possible, not reproduced. `session.ts:100–125`; transport state/lease HTTP failure is immediate, not a background operation. A prior exact receipt does not prove the second server is currently available or the reservation can be confirmed. No original response body survives. |
| 3 | Second-start compatible hello/snapshot validation or checkpoint-write failure after a successful state/lease check. | Possible, not reproduced. `session.ts:143–150`, `client.ts:678–727,750–789`, `journal.ts:223–258`. These errors are retained. A checkpoint load/lock failure BEFORE the guarded restore normally prevents stdio connection, rather than returning a structured `recovery_required`; that class is less consistent with the observed assertion. |
| 4 | Ordinary lease expiry, reservation compaction, or human edit caused valid protected history to be collected. | Low support for this exact case. Active reservation pins constrain GC independently of peers; the initial reservation is at floor 1 before the first edit, and subsequent reserve calls can only retain/lower it. There is no discard. Only three inserted characters are undone, below demo AUTO_GC=12. Default compaction threshold is 128; this case has only a few reservation records. No evidence shows a missing reservation, alternate threshold, or storage fault in the failed run. |
| 5 | `recovery_status` raced an unfinished automatic recovery because stdio became ready on hello. | Refuted for the audited stdio path. Source ordering plus the controlled barriers below establish recovery/hello admission precedes stdio initialization. Do not add polling or weaken `clear`. |

A normal 10-second timeout is also poorly supported: the entire original failed case took 1.143 seconds. CPU contention alone does not reverse an awaited ordering. It could expose an unobserved HTTP/storage error or different interleaving; that remains unknown.

## Ordering, identity and protection audit

### Durable pending and History

- `session.ts:497–519`: history disconnects first, creates undo/redo locally, durably saves the pending operation and History, then reconnects. The test's after-accept barrier is reached only after this save and server acceptance. Pending bytes and the history transition remain paired.
- `journal.ts:223–258`: write input is checked by restoring a disconnected client. The checkpoint uses a private temp file, file fsync, rename, directory fsync and digest readback. `journal.ts:183–212` validates stored digest, actor/schema metadata and reconstructed history before returning it.
- `client.ts:327–365` validates monotonic actor pending sequences, delSeq bounds, identity/schema and disconnected restoration. The TypeScript engine restores a separate `History` (`typescript-client.ts:329–337`). `history.ts:311–345,380–403` serializes/restores group and shared ownership references, not visible text alone.
- A first successful restore saves an empty-pending checkpoint before `clear` can be exposed (`session.ts:149–150`). The original first `clear` and subsequent exact serverSeq assertion therefore already passed. The failing repeated startup should normally have zero pending recover submissions.

### Server generation, reservation and GC

- New process epoch is distinct from durable generation. `session.ts:100–108` checks generation, schema and serverSeq, then proves the original reservation **before joining as the actor**. It installs the new epoch only after those proofs (`:141–148`).
- `hub.ts:300–316` requires an existing confirmed reservation when requested, rejects released/sealed unsafe IDs, and uses `min(requested pin, serverSeq+1, existing floor)`. A repeated acquisition cannot advance the pin and lose older protection.
- `hub.ts:320–330` requires generation/schema/actor-reservation identity. It returns the exact accepted receipt before considering a fresh append. An accepted duplicate is not appended again. `findChangeReceipt():267–272` checks full serialized payload, not actor/sequence alone.
- GC frontier includes every active recovery pin (`hub.ts:456–467`); replay rejects GC crossing one (`:497–503`). Human `leave` removes only an ordinary peer, not recovery reservations (`:539–542`). Peer lease or delayed stream-close bookkeeping does not release the durable pin.
- `server.ts:892–907` serializes reservation mutation, waits for compaction, and rechecks live hub/generation and retained reservation before confirming. `:921–939` serializes atomic recover under `durableMutation`. `server.ts:198–245` replays stored changes/reservations in order and reestablishes storage barriers on reopen. An unsafe storage result invalidates the hub, not force-clears recovery.

### HTTP state, SSE snapshot and clocks

- `restoreCheckpoint` forces a complete snapshot (`client.ts:348–354`); connection subscribes from 0 (`:403–418`). The compatible hello must contain snapshot and actor sequences (`:678–683`). The demo constructs snapshot, actor seqs and serverSeq synchronously from one hub (`hub.ts:513–525`) under the document queue (`server.ts:860–865,691–711`). There is no await between hello construction and listener registration.
- Snapshot is prepared before pending acknowledgement (`client.ts:719–727`). Accepted actor sequence removes matching pending/outbox entries before `ready` and `flush` (`:754–789`), which explains the required zero ordinary resend after the atomic recover.
- Same-epoch snapshot installation retains the restored allocation floor (`client.ts:754,781`, `typescript-client.ts:322–326`). History is not cleared by that installation. An incompatible epoch with protected state causes explicit disconnection (`client.ts:700–703,743–746`), rather than silently dropping history.
- An independent human insertion advances serverSeq and snapshot content; it does not itself alter generation/schema or release an AI reservation. The original first recovery read already proved human content survived.

## Controlled, output-only process probe

Reproducer: `probes/bootstrap-barriers.py`. It derives only the existing undo/after-accept case and helpers into `probes/bootstrap-barriers.generated.probe.ts`. It does not modify the original test. Local subprocesses use the pinned Node. The runner owns a fresh process group and has a 30-second outer watchdog. Existing original assertions are retained, including human text, zero ordinary resend, one atomic recovery, exact accepted sequence, repeated restart and opposite history action.

Two added transport barriers are event-controlled, not sleeps or retry-until-green:

1. Hold the successful first `/recover-change` response at the proxy. Check stdio connect has not completed and no SSE request was issued. Release explicitly. The original recovery assertions then pass.
2. On the repeated restart, hold `/stream` before forwarding its hello. Check stdio connect has not completed and atomic recovery count is 0, as required for the settled checkpoint. Release explicitly. Check immediate `clear` with a full second-stage diagnostic, then retain the original opposite-undo/redo and human-preservation assertions.

**PASS: 1 case, 0 FAIL, 0 SKIP, 0 CANCELLED; test duration 1823.075625 ms, runner duration 2299.913625 ms.** Watchdog not triggered. This is one discriminating invocation, not another repetition loop. It demonstrates the enforced barriers at two specific phases; it does not prove absence of every race or reproduce the original error.

Source hash used by probe: `8aeca4e34ffc161f970d3a0b92aebbad6739e9d8deb24e22a69bae6d526aaebe`.
Generated probe hash: `bc77dd125bd50ad492a8213d91809d94d95a6a5cbf3779a7e7128e8757e007eb`.
Probe log hash: `559a1abaaad2650b1e1220004d9a3598fa76f041a90b56a5daf92a4912524dfd`.

## Concrete branch counterexamples, not claimed reproductions

These clarify the contract and the missing discriminant. They do **not** explain the old failure without its message:

- A second `GET recovery-state` can succeed; the following reservation POST can return HTTP 503. `node-http-transport.ts:181` throws `Recovery reservation outcome is unknown: HTTP 503`; `session.ts:78–82` stores that error; `recoveryStatus():425` returns `recovery_required`. The old exact accepted receipt remains valid. This is consistent with correct fail-closed behavior, not an early status/readiness bug.
- If the hub is invalidated/reopened between state proof and the later stream, it can have the same generation but a new process-local epoch. The protected-history epoch guard at `client.ts:700–703` then blocks. Ordinary human insertion alone does not create this condition; no invalidation was recorded in the original receipt.
- A missing confirmed reservation returns unsafe at `hub.ts:311`, and `session.ts:116–119` refuses to rekey or recreate it despite an accepted change receipt. A mismatched generation/schema/history is rejected even earlier (`session.ts:101–102`). These are intended safeguards, not grounds to bypass proof.

## Contract vs. assertion

`docs/recovery-plan.md:21–25` and `apps/docs/src/guide/ai.md:114–116` require generation/schema/reservation/GC proof before reconnecting. Unsafe or unavailable recovery must remain blocked. These contracts support immediate `clear` only after successful automatic restoration, not after every conceivable server fault. Current stdio startup explicitly waits for that restoration attempt. Therefore the test expectation is appropriate for its intended healthy-server scenario. The existing evidence cannot decide whether the original failure was an environmental fault handled correctly or an unintended product fault. Merely changing expected status or polling would hide that distinction.

## Minimal next diagnostic, no implementation performed

The highest-value change is diagnostic at CURRENT `automatic-recovery-process.test.ts:361`, not a product fix. Bind the repeated `recovery_status` result once and put its complete JSON in the existing assertion message. Include a stage label, the settled checkpoint saved before killing the first recovered MCP, second-server state and stderr. Preserve `clear`, pending bytes, all count/history/receipt checks and cleanup. A proxy at the second restart is optional if exact HTTP status bodies are needed later.

Do not rerun the whole workspace again solely because the parent-owned rerun is green. If that exact second-stage failure recurs, classify its message first. A production fix and its regression stage can only be specified after the missing branch is identified. No fix to implement is established by this investigation.

## Immutable receipt anchors and limits

| Artifact | SHA-256 |
| --- | --- |
| Original full log | `7a5bdc3da8a43d1a4be1e4f4dc263cc31eab218891ec6371b5d78f2513b35723` |
| Parent fixed-harness full JSON | `e9753a426293ce6ba95e69bff4f195167d56b75d65e91bd517e49439f6220288` |
| Parent fixed-harness full log | `fd61491b1d09103028208d2a22a3491d63770d43f16622759c075e042bb3f51d` |
| `apps/mcp/src/main.ts` | `2bd869bfb0e921b5fd6dbd015a66bbf67391d140afb11d226798ea1ecf1ae078` |
| `apps/mcp/src/session.ts` | `347b4a505a9c5dc57fcd25d4bd4ff2cffd501813c657a595ffe26f6b72a53280` |
| `apps/mcp/src/journal.ts` | `21e56cf83a1981e64ce1fbcdf6c17559f956f5bbfd269d9bba8bb71e33f77177` |
| `packages/doc-sync/src/sync/client.ts` | `738c490910374c8b2ab73dc808a5de7e4d66143ff4a66e717840eb4d8f900c8c` |
| `packages/doc-sync/src/server/hub.ts` | `ddc433711fe89f8cb159009effaf40686f367da8dc9553de3d4f0d52d9a76a09` |
| `apps/demo/server.ts` | `6c6b8e864f2775146ceb5b046502133e5df259b718a468cf673ba607cff189a8` |

The original temporary journal/log state was already removed before this task. No complete original recovery response exists. Core69 archive qualification is inherited task context, not independently requalified here. No rejected COW helper was introduced. The probe uses existing package dist exports, as the actual process tests do; it does not build them. Directly inspected source is separately identified above. No broader process stress, performance test, full suite, browser, mobile, commit, push, remote publication or product mutation was performed by this investigator.

Completed: 2026-11-03T18:18:32.557Z (2026-11-04 03:18:32.557 KST). All 12 explicitly audited source/test paths have the same SHA-256 at first read and completion; see `probes/source-after.json`. This is not a whole-workspace immutability claim.
