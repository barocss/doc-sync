import {registerHooks} from 'node:module';
import {existsSync, realpathSync, readFileSync} from 'node:fs';
import {fileURLToPath, pathToFileURL} from 'node:url';
const workspace = new URL('../../packages/', import.meta.url).href;
const root = pathToFileURL(realpathSync(fileURLToPath(process.env.DOC_SYNC_SOURCE_ROOT ?? workspace)) + "/").href;
function sourceURL(url) {
    if (!url.includes('/dist/') || !url.endsWith('.js')) return null;
    const prefix = [root, workspace].find(prefix => url.startsWith(prefix));
    if (!prefix) return null;
    const source = root + url.slice(prefix.length).replace('/dist/', '/src/').replace(/\.js$/, '.ts');
    if (!existsSync(fileURLToPath(source))) throw new Error('No source equivalent: ' + url);
    return source;
}
registerHooks({resolve(specifier, context, nextResolve) {
    const ownPackage = /^@barocss\/(doc-sync[^/]*)(?:\/(.*))?$/.exec(specifier);
    if (ownPackage) {
        const manifestURL = new URL(ownPackage[1] + '/package.json', root);
        if (existsSync(manifestURL)) {
            const manifest = JSON.parse(readFileSync(manifestURL, 'utf8'));
            const entry = manifest.exports?.[ownPackage[2] ? './' + ownPackage[2] : '.'];
            const target = typeof entry === 'string' ? entry : entry?.import;
            if (target) {
                const source = sourceURL(new URL(target, manifestURL).href);
                if (source) return nextResolve(source, context);
            }
        }
    }
    // Archives omit ignored dist files. Map explicit relative dist imports before
    // resolution; map package exports after resolution. Never create dist files.
    if (specifier.startsWith('.') && context.parentURL) {
        const source = sourceURL(new URL(specifier, context.parentURL).href);
        if (source) return nextResolve(source, context);
    }
    const resolved = nextResolve(specifier, context);
    const source = sourceURL(resolved.url);
    return source ? {...resolved, url: source, format: 'module-typescript'} : resolved;
}});
