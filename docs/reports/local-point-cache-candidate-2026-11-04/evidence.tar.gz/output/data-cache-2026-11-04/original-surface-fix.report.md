# Original-surface R4 fix — source candidate

## Outcome and boundary

- R4 source reproducer: **FIXED in this focused candidate**. Before: public Map.set followed by malformed unrelated toJSON scalar returned stale valid data. After: same probe rejects with `Data: invalid encoded scalar`. Both runs confirm `client-engine-preloaded false`. See `original-surface-fix.before.log` and `original-surface-fix.after.log`.
- Focused source tests: **480 PASS / 0 FAIL / 0 SKIP** across 28 files (478 in the 27-file receipt plus 2 separate ticket-boundary tests). New isolated suite: **16 PASS / 0 FAIL / 0 SKIP**, also run with no source hook.
- Bounded direct-source no-emit diagnostics: **0**, exit 0. No lifecycle, global build or dist writes.
- **No speed or performance acceptance claim.** High review, package/real-export isolation, local-bundle qualification and parent benchmark remain pending. Browser/mobile, commit/push/release: NOT_RUN.

## Exact owned scope

Five existing production modules only:

1. `crdt/doc.ts`: import descriptor factory and capture original class/static and instance-method surface immediately after Doc definition.
2. `crdt/history.ts`: same original capture in History defining module. No history algorithm, undo/redo or clearHistory changes.
3. `crdt/ticket.ts`: same original capture in Clock defining module. No clock semantics changes.
4. `internal/point-receipt.ts`: retain descriptor/own-key intrinsic references at module initialization; add closure-only `originalClassSurface` factory. Existing descriptor comparison still compares parent, key set, value/get/set and descriptor flags; it never calls replaced getters.
5. `engine/typescript-client.ts`: consume defining-module original predicates instead of taking late Doc/History/Clock snapshots in the engine module. Keep the engine's own original capture and R1/R2/R3 action/pointer/restore logic unchanged.

New files only: `test/data-point-preload.test.ts` and private `test/fixtures/data-point-preload.mjs`. No existing test, Client, Local, DataAccess, docs, package/barrel export or engine capability edits. Preserved inherited WIP. Lane-only patch: `original-surface-fix.patch`; its pre-source reconstruction is hash-verified against the starting five source hashes, not Git HEAD.

## Authority

- Original predicates are const internal-only exports from defining modules, not package/barrel exports. Their snapshots remain private in closures. No setter/registry registration, mutable per-doc trust, externalDataDoc validity flag, enginecaps, reassignment bridge, or model read was added. A fresh call to the generic snapshot factory cannot replace the predicate bound to the engine.
- Static and prototype descriptors are captured before another ordinary entry point can expose each class. Engine import order no longer establishes authority. Clock static identity is now conservatively checked too.
- No new PURE annotation was added: the factories inspect descriptors. No local-bundle guard was relaxed. Actual bundle/package checks are NOT_RUN in this lane.
- A declined proof uses the existing original full-refresh fallback. Public toJSON replacements execute at that original point, with their original receiver, exactly once per uncached engine model read. No double read was added.

## Persistent regression evidence

Each test child uses `process.execPath` and `fileURLToPath(new URL(..., import.meta.url))`, with real relative source imports. Normal tests require no output archives, Git, generated dist or historical loader. A registerHooks observer proves server/schema expose public hub.doc before typescript-client is loaded.

- Public server -> hub.doc.constructor.prototype.toJSON replacement BEFORE Client import: valid unrelated change, malformed encoded scalar, exact sentinel throw; method and accessor variants. Warm valid cache, complete public Map.set, then toggle override flag. Literal expected values/errors and a supported compatibility-escaped full-refresh control agree.
- Valid unrelated updates are visible. Malformed data throws the literal original error; neither target nor unrelated read can use partial cache. Thrown sentinel identity is preserved. Getter/call counts stay at the original full-refresh point; descriptor eligibility checks do not invoke them.
- Unmodified headless restored client remains positive: setter + first read retains zero full data-root clones. Successful overridden reads take one full data-root clone; malformed reads take one clone per rejected validation attempt; original throw takes zero clones and the exact original exception. Clone counts are a functional projection boundary, not a speed claim.
- Doc, History and Clock method/getter/static-descriptor late overrides each decline original authority and engine point authority. Checks invoke neither overridden methods nor getters. Taking a second local surface snapshot does not reclaim engine authority. Safe public effects (Doc.toJSON, History.pin, Clock.observe) preserve receiver and one-call behavior.
- clearHistory scope remains MODEL-MUTATING undo/redo only. Existing pending-COW clearHistory regression remains GREEN in the 478 focused tests.

## Commands and receipts

Additional focused Clock boundary check: `node --import ./output/refactor-2026-11-03/api-client-source-hook.mjs --test packages/doc-sync/test/ticket-boundary.test.ts`: 2 PASS / 0 FAIL / 0 SKIP; `original-surface-fix.ticket-boundary.log`.

Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node` (v24.22.1).

- `original-surface-fix.validate.mjs` runs the exact 27-file command with `--import ./output/refactor-2026-11-03/api-client-source-hook.mjs --test --test-concurrency=2`. Full argv, elapsed time and before/after hashes: `original-surface-fix.receipt.json`. Complete output: `original-surface-fix.focused.log`. Source stable=true.
- `node --test packages/doc-sync/test/data-point-preload.test.ts`: 16 PASS, zero FAIL/SKIP. `original-surface-fix.new-suite.log`.
- `original-surface-fix.typecheck.mjs`: direct source dependency closure rooted in the five owned modules plus the new TS test. `original-surface-fix.typecheck.{json,log}`: zero diagnostics. The private mjs fixture is runtime-checked in all 16 children; this is not a checkJs claim.
- Owned tracked source `git diff --check`: PASS.

## Failures and red proof

1. Before production edits, the user-provided reproducer confirmed stale accepted data (before.log).
2. Exact starting sources were reconstructed into a private output directory and verified against all five captured starting SHA-256 values. An output-only load hook replays those bytes without modifying workspace source. The same persistent fixture yields **4 expected failures**: method/getter valid changes incorrectly return old instead of visible; method/getter malformed variants omit the required exception. Stock and both original-throw cases already pass on those pre-fix bytes. Full rows/stacks: `original-surface-fix.red-proof.json`. This proves the new assertions detect R4 rather than deriving expectations from the candidate.
3. The first red-proof driver incorrectly expected all six override scenarios to fail. The observed original-throw passes were valid; the driver's expected status matrix was corrected to the actual 4 failing regression cases. No production behavior or persistent assertion was weakened.
4. New candidate suite, focused suite and bounded no-emit check have no failures or skips. Initial read-only OMX lookup used unsupported positional syntax and returned usage; no source was changed by that lookup.

## SHA-256 for exact reviewed bytes

| Path | Final SHA-256 |
| --- | --- |
| packages/doc-sync/src/crdt/doc.ts | 9aa617fff7fa8e3caeaae5d4f5edf4186c126cb9071869f06f56491408a3d6a6 |
| packages/doc-sync/src/crdt/history.ts | 4dee4664b9153afad63aa7d012ffff7b10aef97be003a925551423a5e976deb5 |
| packages/doc-sync/src/crdt/ticket.ts | 1846cd4d33aea8c6bc55bbf3b1a4e395746ed7eba564d91f575096c3223bd4eb |
| packages/doc-sync/src/internal/point-receipt.ts | afa0b6acdf3881b6ab6ea1cf3956c723a2ac3080c7a49dabfff6a96b28907428 |
| packages/doc-sync/src/engine/typescript-client.ts | 5ee2be8d07a13a751523a80fc28eb40659d5ab421ccc10b391a1989283c8a1f0 |
| packages/doc-sync/test/data-point-preload.test.ts | 4ffddcac599ad2e8280371bf0bff07d558a1c41066ba0635e3a77520080e440c |
| packages/doc-sync/test/fixtures/data-point-preload.mjs | 2d31af88067e2d31cc137de33e789fa68a5251ad602d44f505f5483d8d9134ea |
| packages/doc-sync/src/data/access.ts | 887397e007952247a2de75b506fa44b5076a9233961e4d0b10d1b176cd0e1281 |
| packages/doc-sync/src/local/client.ts | 5b894d5769b21c3e7689f304ca313e193d6422b4471f7f95512fa8ed59b1fa72 |
| packages/doc-sync/src/client/index.ts | 2835ff9e3b36e77523f8d51e3ae259bf3fd6ad6e5e4df526aad0ab35eca959b7 |
| packages/doc-sync/test/engine-point-receiver.test.ts | 340f8a566d5055a32998bbbfbc57a9a0181a83cd9a37a35a5cce3ca8db52f8ad |

The five starting hashes are retained in `original-surface-fix.before.sha256`. Guarded unowned source/test hashes match R3 receipt values. Later parent edits require fresh qualification of their changed bytes.
