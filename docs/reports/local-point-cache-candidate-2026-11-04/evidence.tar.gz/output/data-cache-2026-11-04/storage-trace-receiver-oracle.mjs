import {Doc} from '../../packages/doc-sync/src/crdt/doc.ts';
import {createDataSchema} from '../../packages/doc-sync/src/data/schema.ts';
const results=[];
for (const action of ['apply','emit','compact','readonly']) {
 const doc=new Doc('receiver',createDataSchema()), proxy=new Proxy(doc,{}), op={t:'set',ids:[],key:'value',value:1,at:{lamport:1,actor:'receiver'}};
 let error=null;try{
  if(action==='compact')proxy.compact(0,()=>undefined);
  else if(action==='emit')proxy.emit([op]);
  else if(action==='readonly')doc.withReadProjection(read=>read.apply(op));
  else proxy.apply(op);
 }catch(e){error={name:e.name,message:e.message};}
 results.push({action,error,version:doc.version,snapshot:doc.snapshot()});
}
console.log(JSON.stringify(results));
