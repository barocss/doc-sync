import {typescriptClientEngineFactory} from '../../packages/doc-sync/src/engine/typescript-client.ts';
import {createDataSchema} from '../../packages/doc-sync/src/data/schema.ts';
import {Doc} from '../../packages/doc-sync/src/crdt/doc.ts';
import {History} from '../../packages/doc-sync/src/crdt/history.ts';
const results=[];
for(const method of ['typescriptDocument','typescriptHistory','replaceTypeScriptDocument','replaceTypeScriptHistory']) {
 const engine=typescriptClientEngineFactory.create('oracle',createDataSchema());
 const doc=engine.doc,history=engine.history,proxy=new Proxy(engine,{}),arg=method.endsWith('Document')?doc:history;
 let result=Reflect.apply(engine[method],proxy,[arg]);
 results.push({method,result:result===arg?'same-pointer':result===undefined?'undefined':'other',model:engine.model()});
 engine.dispose();
 let error;try{Reflect.apply(engine[method],proxy,[arg]);}catch(e){error={name:e.name,message:e.message};}
 results.push({method,disposed:error});
 for(const throws of [false,true]) {
  const events=[],sentinel=new Error('alive'),target={alive(){events.push('alive');if(throws)throw sentinel;},get doc(){events.push('doc');return doc;},set doc(v){events.push('doc=');},get history(){events.push('history');return history;},set history(v){events.push('history=');},set generation(v){events.push('generation=');},set guardWrapper(v){events.push('guardWrapper=');},attach(){events.push('attach');}};
  const receiver=new Proxy(target,{get(t,k,r){events.push('get:'+String(k));return Reflect.get(t,k,r);},set(t,k,v,r){events.push('set:'+String(k));return Reflect.set(t,k,v,r);}});
  let error=null;try{Reflect.apply(engine[method],receiver,[arg]);}catch(e){error={name:e.name,message:e.message};}
  results.push({method,throws,events,error});
 }
}
console.log(JSON.stringify(results));
