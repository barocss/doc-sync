from pathlib import Path
import subprocess,json,hashlib,re,os,signal
root=Path.cwd(); out=root/'output/data-cache-2026-11-04'; node='/Users/user/.nvm/versions/node/v24.22.1/bin/node'
tests=root/'packages/doc-sync/test'
files=sorted(set(tests.glob('data*.test.ts'))|set(tests.glob('client*.test.ts'))|set(tests.glob('history*.test.ts'))|{tests/'engine-read-contract.test.ts'})
cmd=[node,'--import','./output/refactor-2026-11-03/api-client-source-hook.mjs','--test','--test-concurrency=4','--test-timeout=60000','--test-reporter=tap']+[str(p.relative_to(root)) for p in files]
with (out/'restore-tests-focused.log').open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try: code=p.wait(timeout=150)
 except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGTERM); p.wait(); code=124
log=(out/'restore-tests-focused.log').read_text(); counts={key:int(value) for key,value in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',log,re.M)}
perfile={}
# TAP lists tests in file argument order. New contract groups are disjoint by name.
for label,pattern in [('mapList',r'^# Subtest: point (?!preload)'),('preload',r'^# Subtest: point preload'),('engine',r'^# Subtest: (?:engine receiver|trace )')]: perfile[label]=len(re.findall(pattern,log,re.M))
receipt={'node':subprocess.check_output([node,'--version'],text=True).strip(),'command':cmd,'exitCode':code,'counts':counts,'retainedGroups':perfile,'files':[str(p.relative_to(root)) for p in files], 'environmentGates':False,'logSHA256':hashlib.sha256(log.encode()).hexdigest()}
(out/'restore-tests-focused.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
