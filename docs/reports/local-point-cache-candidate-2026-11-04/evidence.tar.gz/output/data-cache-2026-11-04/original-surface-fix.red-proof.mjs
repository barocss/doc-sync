import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const scenarios=['stock','doc-valid','doc-malformed','doc-throw','doc-getter-valid','doc-getter-malformed','doc-getter-throw'];
const rows=[];
for(const scenario of scenarios){
    const result=spawnSync(process.execPath,['--import','./output/data-cache-2026-11-04/original-surface-fix.pre-hook.mjs','packages/doc-sync/test/fixtures/data-point-preload.mjs',scenario],{encoding:'utf8',timeout:30_000});
    rows.push({scenario,status:result.status,error:result.error?.message,stdout:result.stdout,stderr:result.stderr});
}
writeFileSync('output/data-cache-2026-11-04/original-surface-fix.red-proof.json',JSON.stringify(rows,null,2)+'\n');
for(const row of rows)console.log(row.scenario,row.status,row.stderr.split('\n').filter(x=>/Assertion|actual:|expected:|Missing expected/.test(x)).join(' '));
const regressions = new Set(['doc-valid','doc-malformed','doc-getter-valid','doc-getter-malformed']);
if(rows.some(row=>row.status!==(regressions.has(row.scenario)?1:0)))process.exitCode=1;
