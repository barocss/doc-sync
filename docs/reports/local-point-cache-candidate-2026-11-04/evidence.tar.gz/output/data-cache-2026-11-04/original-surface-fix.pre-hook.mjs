import {registerHooks} from 'node:module';
import {readFileSync} from 'node:fs';
const entries = new Map(['crdt/doc.ts','crdt/history.ts','crdt/ticket.ts','internal/point-receipt.ts','engine/typescript-client.ts'].map(path=>[new URL('../../packages/doc-sync/src/'+path,import.meta.url).href,new URL('./original-surface-fix.pre/'+path.split('/').at(-1),import.meta.url)]));
registerHooks({load(url,context,next){const source=entries.get(url);return source ? {format:'module-typescript',source:readFileSync(source,'utf8'),shortCircuit:true} : next(url,context);}});
