import {registerHooks} from 'node:module';
let loadedClientEngine=false;
registerHooks({resolve(s,c,n){const r=n(s,c);if(r.url.endsWith('/engine/typescript-client.ts'))loadedClientEngine=true;return r;}});
const {DocHub}=await import('../../packages/doc-sync/src/server/index.ts');
const {createDataSchema}=await import('../../packages/doc-sync/src/data/schema.ts');
const hub=new DocHub({schema:createDataSchema()});
const D=hub.doc.constructor, original=D.prototype.toJSON;
console.log('client-engine-preloaded',loadedClientEngine);
let corrupt=false;
D.prototype.toJSON=function(...args){const m=original.apply(this,args);if(corrupt&&m.type==='data'&&m.children?.[1])return {...m,children:m.children.map((n,i)=>i===1?{...n,attrs:{...n.attrs,value:{scalar:{invalid:true}}}}:n)};return m;};
const {Client}=await import('../../packages/doc-sync/src/client/index.ts');
const client=new Client({actor:'preload-probe',schema:createDataSchema()});
const id=n=>`data:00000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
client.edit([{op:'insert',at:[0],content:[{type:'entry',attrs:{id:id(1),key:'target',value:{scalar:'old'}}},{type:'entry',attrs:{id:id(2),key:'unrelated',value:{scalar:'old'}}}]}],null);
const root=client.data.root; console.log('before',root.get('target'),root.get('unrelated'));
root.set('target','new');corrupt=true;
try{console.log('after',root.get('target'),root.get('unrelated'));}catch(e){console.log('after ERROR',e.message);}
console.log('public-model-unrelated',client.model().children[1].attrs.value);
corrupt=false;D.prototype.toJSON=original;client.dispose();
