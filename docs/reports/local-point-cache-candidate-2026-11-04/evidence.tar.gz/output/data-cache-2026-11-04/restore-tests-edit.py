from pathlib import Path
import hashlib,json
root=Path.cwd(); out=root/'output/data-cache-2026-11-04'; tests=root/'packages/doc-sync/test'
names=['data-point-cache.test.ts','private-storage-trace.test.ts','engine-point-receiver.test.ts','data-point-preload.test.ts','fixtures/data-point-preload.mjs']
for n in names:
 p=tests/n; target=out/('rejected-'+p.name); assert not target.exists(); target.write_bytes(p.read_bytes())
source={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path('packages/doc-sync/src').rglob('*')) if p.is_file()}
(out/'restore-tests-source-before.json').write_text(json.dumps(source,indent=2)+'\n')
p=tests/'data-point-cache.test.ts'; s=p.read_text(); a=s.index('function cloneCounter()'); b=s.index('for (const location',a); s=s[:a]+s[b:]
a=s.index('// RED/GREEN requirement'); b=s.index('test("point fallback',a); s=s[:a]+s[b:]
s=s.replace('point fallback raw edit and escaped owner keep a full root clone','point raw edit and escaped owner preserve the accepted value')
s=s.replace('const f = fixture({}, !raw), p = point(f, "root"), clones = cloneCounter();','const f = fixture({}, !raw), p = point(f, "root");')
s=s.replace('clones.reset(); assert.equal(p.get(), "fallback"); assert.equal(clones.roots, 1);','assert.equal(p.get(), "fallback");\n            assert.deepEqual(p.item().node.attrs!.value, {scalar: "fallback"});')
s=s.replace('} finally {clones.restore(); f.client.dispose();}','} finally {f.client.dispose();}')
(tests/'data-read-contract.test.ts').write_text(s); p.unlink()
p=tests/'engine-point-receiver.test.ts'; s=p.read_text().replace('import {enginePoints, ownStorage} from "../src/internal/point-receipt.ts";\n','')
s=s.replace('    const port = enginePoints(engine)!; assert.ok(port); assert.equal(port.check(), true);\n    return {engine, port};','    return {engine};')
a=s.index('for (const method of ["typescriptDocument"'); b=s.index('for (const method of ["apply", "emit", "compact"]',a)
s=s[:a]+'''test("engine receiver Client.fromState and clearHistory preserve the model", () => {
    const client = new Client({actor: "restore", schema: createDataSchema()});
    client.edit([{op: "insert", at: [0], content: seed()}], null);
    const restored = Client.fromState(client.captureState(), {schema: createDataSchema()});
    try {
        const root = restored.data.root;
        assert.equal(root.get("key"), "old");
        root.set("key", "new");
        const model = restored.model();
        assert.equal(restored.historyStatus().canUndo, true);
        restored.clearHistory();
        assert.equal(restored.historyStatus().canUndo, false);
        assert.equal(restored.historyStatus().canRedo, false);
        assert.equal(root.get("key"), "new");
        assert.deepEqual(restored.model(), model);
        assert.equal(client.data.root.get("key"), "old");
    } finally {restored.dispose(); client.dispose();}
});

'''+s[b:]
a=s.index('for (const method of ["replaceTypeScriptDocument", "replaceTypeScriptHistory"] as const) test(`engine receiver foreign'); s=s[:a]
s=s.replace('// Ordinary field capture is test-only; it does not call a revoking getter.','// Capture pointers through the public compatibility methods.')
s=s.replace('    const raw = engine as unknown as {doc: Doc; history: History};\n    const pointer = method.endsWith("Document") ? raw.doc : raw.history;','    const pointer = method.endsWith("Document") ? engine.typescriptDocument() : engine.typescriptHistory();')
# Salvage only standalone raw-operation contracts, with no private producer.
trace=(tests/'private-storage-trace.test.ts').read_text()
a=trace.index('function docFixture()'); b=trace.index('test("trace generic',a); helper=trace[a:b]
a=trace.index('for (const throws of [false, true]) test(`trace raw Doc guard'); b=trace.index('test("trace synchronous send',a); raw=trace[a:b]
a=trace.index('// Exact inactive raw-DTO'); b=trace.index('for (const action of ["winning", "losing", "multi-id", "missing-id", "non-value", "non-set"',a); sequence=trace[a:b]
s=s.replace('import type {NodeJSON}', 'import type {Op} from "../src/crdt/doc.ts";\nimport type {NodeJSON}')
a=trace.index('const id = (n:'); b=trace.index('function fixture(',a); seed=trace[a:b].replace('const id =','const rawId =').replace('id: id(', 'id: rawId(').replace('const seed =', 'const rawSeed =')
helper=helper.replace('content: seed()', 'content: rawSeed()')
s+='\n'+seed+helper+raw+sequence
(tests/'engine-read-contract.test.ts').write_text(s); p.unlink(); (tests/'private-storage-trace.test.ts').unlink()
p=tests/'data-point-preload.test.ts'; s=p.read_text(); a=s.index(', "authority-doc-method"'); b=s.index(']) {',a); s=s[:a]+s[b:]; p.write_text(s)
p=tests/'fixtures/data-point-preload.mjs'; s=p.read_text().replace('// Private source-graph fixture.', '// Isolated public preload fixture.')
a=s.index("if (scenario.startsWith('authority-'))"); b=s.index("const {Client, clientOwner}",a); s=s[:a]+s[b:]
a=s.index('const clone = globalThis.structuredClone;'); b=s.index('try {',a); s=s[:a]+s[b:]
s=s.replace('calls = 0; gets = 0; roots = 0;', 'calls = 0; gets = 0;')
s=s.replace(' assert.equal(roots, 0);','').replace("            assert.equal(roots, 1); assert.equal(calls, 1);", "            assert.equal(calls, 1);")
s=s.replace("            assert.equal(roots, 2, 'failed validation must not publish partial cache');\n",'')
s=s.replace("            assert.equal(roots, scenario === 'stock' && client === candidate ? 0 : 1);\n",'')
s=s.replace('    globalThis.structuredClone = clone;\n','')
s=s.replace('let flag = false, gets = 0, calls = 0;', 'let flag = false, gets = 0, calls = 0;\nconst seen = [];')
s=s.replace('    calls++;','    calls++; seen.push("call:toJSON");').replace('get() {gets++;', 'get() {gets++; seen.push("get:toJSON");')
s=s.replace('flag = true; calls = 0; gets = 0;', 'flag = true; calls = 0; gets = 0; seen.length = 0;')
s=s.replace("        }\n    }\n} finally", "        }\n        const oneRead = scenario.startsWith('doc-getter-') ? ['get:toJSON', 'call:toJSON'] : ['call:toJSON'];\n        assert.deepEqual(seen, scenario === 'stock' ? [] : scenario.endsWith('throw') ? [...oneRead, ...oneRead] : oneRead);\n    }\n} finally")
p.write_text(s)
