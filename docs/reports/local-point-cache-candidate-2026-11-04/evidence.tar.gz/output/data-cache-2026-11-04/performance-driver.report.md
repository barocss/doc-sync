# Source-only Data point cache driver

Status: PASS for bounded source-only correctness and projection-count proof. Heavy timing NOT_RUN. Exact-byte High approval is a separate root gate.

Owned files: `benchmarks/data-point-cache.mjs` and `output/data-cache-2026-11-04/performance-driver.*` only. No source/test/docs WIP changed. No agent, build, browser, mobile, commit, push, or heavy timing.

## Driver contract

- Source-only dynamic imports with a fail-closed selected-source resolver. Realpaths, loaded imports, SHA-256 for every TS source file (conservative closure), start/end equality, driver SHA, fixed checkpoint SHA.
- Linear complete valid checkpoint with total entries split across root map, nested map, list. Explicit STRING keys on every entry, including list entries. Fixed actor, IDs, tickets and finite tagged scalars. One seed build, bounded six public `Client.fromState` restores; no per-entry setter seeding.
- Three known-existing public setters. Normal History is primary. Stock methods; no raw owner escape. Warm cache. Separate complete setter, next point read and total intervals. No eager read inserted in setter.
- Separate raw `Client.edit` fallback control on the identical fixture and operation sequence; at most three recorded control samples. Remaining operations replay only to preserve exact model/snapshot/History comparison.
- Full independent arrays/IDs/order/values/public model oracle outside intervals. Complete captured History/checkpoint comparison with ONLY wall-clock group `.at` normalized; snapshot, undo, redo, repeated sets without intervening reads, frozen held entry, refs and -0 checked outside intervals.
- Counts mode changes ONLY global `structuredClone` and counts only root `NodeJSON`. Setter root clones must be zero. Canonical prescribed before source requires next-read one; other selected source roots require zero. Labels do not select expectations. Counts are never timing evidence.
- 100k-character general Doc trace-disabled control DISABLED; no general Doc no-regression claim. No heap-allocation or speed claim.

## Commands and receipts

Pinned executable: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`.

Syntax check and `--help` PASS. Production-source runs began only after `storage-trace-implementation.events.jsonl` recorded `turn.completed` (2026-11-04 ~02:28 KST). No source writer process was terminated or changed.

Final driver SHA-256: `16d37bde2ebeb70d72551a7bc41cf2569a7166bc324e2e6aee7534f825808be8`.

| Source | smoke | counts | Setter ROOT clones | Next-read ROOT clones |
| --- | --- | --- | --- | --- |
| canonical frozen before | PASS | PASS | 0 | 1 |
| current worktree | PASS | PASS | 0 | 0 |

Each row covers root map overwrite, nested map overwrite, and existing list item set at **20 total entries, one warmup, one measured count sample**. Count values apply to all three scenarios. Raw edit fallback control is one ROOT clone for both sources. Count mode overrides only global structuredClone, never Client/Doc/History methods. Smoke/timing do not instrument global structuredClone. No time numbers are reported from smoke/counts.

Both source runs use exactly the same final script, checkpoint hash, actor, deterministic IDs/tickets, record/sample/warmup options and oracle operations. Canonical paths and labels differ by design; labels never determine baseline or eligibility.

- Before conservative TS closure: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`
- Current conservative TS closure: `001e4dcab5130fb9089ffd0d4babb50bfc7bf145edebc80ef8b9fb889297bbc2`
- Shared fixture SHA: `fa341cab42e964d57ec370675b5747c14e67583442ec7eaddd7dfb9b7d99169e`
- Each result contains full per-file hashes, loaded source file list and identical start/end source hashes. Smoke/counts have identical closures within each selected source.

Commands (all run with the pinned executable):

```sh
N=/Users/user/.nvm/versions/node/v24.22.1/bin/node
D=benchmarks/data-point-cache.mjs
O=output/data-cache-2026-11-04
"$N" --check "$D"
"$N" "$D" --help
for source in before current; do
  if test "$source" = before; then
    SRC=output/refactor-2026-11-03/post-refactor-baseline
  else
    SRC=.
  fi
  for mode in smoke counts; do
    "$N" "$D" --source-root "$SRC" --label "$source-source-not-HEAD" \
      --output "$O/performance-driver.$source-$mode-final.json" \
      --records 20 --samples 1 --warmup 1 --mode "$mode"
  done
done
```

Expected failures, all nonzero exit 1 (PASS for rejection): unknown `--bogus value`; missing required options (`--mode typo` alone); invalid mode with all required options; overwrite attempt against the existing final before-smoke output. Overwrite is rejected before import/seed/measurement. No unexpected functional failures occurred. `git diff --check -- benchmarks/data-point-cache.mjs` PASS. Initial passing receipts from the earlier driver are retained with no `-final` suffix; only `*-final.json` qualifies the final SHA above. No existing output was overwritten by the driver.

Final receipts:

- `performance-driver.{before,current}-{smoke,counts}-final.json`
- `performance-driver.validation.json`: cross-source common-input equality, within-source smoke/counts closure equality, all completed oracle checks, expected rejection exits, timing NOT_RUN.
- `performance-driver.checks.log`: help output, successful runs and expected exception messages/exits.

## Remaining evidence boundary

No 2,000/20,000 timing was run. Timing mode supports these exact total entry counts and bounded samples; each sample separates complete public setter, next read and total cost. Root owns later same-driver/same-flags single-lane ABBA, exact-byte High approval and larger-fixture qualification. Retained heap is not used and there is no allocation claim. General Doc 100k-char trace-disabled no-regression evidence is NOT_RUN here. Focused source correctness and ROOT-clone proof do not imply workspace acceptance, product/browser proof, remote publication or release readiness.
