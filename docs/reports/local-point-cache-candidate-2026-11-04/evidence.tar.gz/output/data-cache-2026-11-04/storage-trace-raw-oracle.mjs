import assert from 'node:assert/strict';
import {Doc} from '../../packages/doc-sync/src/crdt/doc.ts';
import {createDataSchema} from '../../packages/doc-sync/src/data/schema.ts';
const id='data:00000000-0000-4000-8000-000000000001';
const active=process.env.TRACE_ACTIVE==='1';
const {ownStorage}=active ? await import('../../packages/doc-sync/src/internal/point-receipt.ts') : {};
const make=()=>{const d=new Doc('oracle',createDataSchema());d.edit([{op:'insert',at:[0],content:[{type:'entry',attrs:{id,key:'x',value:{scalar:0}}}]}]);return d;};
const seed=make(), set=seed.edit([{op:'update',at:[0],attrs:{value:{scalar:1}}}]).ops.find(o=>o.t==='set');
const results=[];
for(const kind of ['set','losing','multi','unknown','text','del']) {
 const d=make(), reads=[];let port,trace;
 if(active){port=ownStorage(d,{});trace=port.begin({id,value:{scalar:1}});}
 const raw=kind==='unknown'?{t:'unknown',extra:7}:kind==='text'?{t:'text',id:{actor:'peer',lamport:100},origin:{actor:'~root',lamport:0},text:'a'}:kind==='del'?{t:'del',at:{actor:'peer',lamport:100},ids:set.ids}:kind==='multi'?{...set,ids:[...set.ids,...set.ids]}:kind==='losing'?{...set,at:{actor:'old',lamport:0}}:{...set};
 const op=new Proxy(raw,{get(t,k,r){reads.push(String(k));return Reflect.get(t,k,r);}});
 let error=null;try{d.apply(op);}catch(e){error=String(e);}
 if(active)assert.equal(port.finish(trace),null,'raw ops cannot certify');
 results.push({kind,reads,error,snapshot:d.snapshot(),version:d.version});
}
console.log(JSON.stringify(results));
