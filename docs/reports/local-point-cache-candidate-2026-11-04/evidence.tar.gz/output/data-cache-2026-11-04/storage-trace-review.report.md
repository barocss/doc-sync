---
work_id: data-cache-2026-11-04
artifact_type: exact-storage-trace-review
status: done
owner_role: readonly-review
source_request: bounded actual Doc.apply/emit storage trace and lazy COW exact proof review
last_updated: 2026-11-03T17:11:25.857038+00:00
---

# Storage trace review

## Initial disposition (historical; final decision below)

IN_PROGRESS. The implementation lane is building the newly authorized actual storage trace. The old missing-API HOLD is not the disposition for this candidate. No approval is issued before actual code and exact hashes are reviewed.

## Scope and proof boundary

- Only this report and storage-trace-review.final.md may be written by this reviewer.
- No code, tests, builds, dist, benchmarks, mobile work, commits, pushes or sub-agents are run by this reviewer.
- CONTRACT, CODE, FUNCTIONAL and PERFORMANCE are separate gates. A test PASS cannot establish receipt authority.
- Private unstamped storage-map mutation and hostile replacement of global JS intrinsics are outside the stated contract. Public method overrides and normal callbacks are inside it.
- The implementation prompt widens the old receipt-contract ownership to Doc trace plus owner/access changes. The contract has not yet been updated at this checkpoint; this is an in-progress document mismatch, not a final code finding.

## Review checklist

1. Actual successful physical winning set, exactly one attempt and one target; stored register ticket, key, value and physical/Data ID binding.
2. Owner/action/Doc authority, replay and foreign rejection; no public owner.write or returned-op authority.
3. NIL trace: no extra raw Op getter/proxy reads or per-op allocation. Active raw escape revokes before pointer return. Unknown operations get no extra metadata reads.
4. Exact closed default-local action window, descriptor-only override checks, no observers/sessions/moves if needed, restore proof without revocation reset.
5. Private known-set frame after policy; complete Client.edit plus History unchanged; no setter model read.
6. One normal captured model; proof decline uses full legacy clone/walk/validation with that same capture; read attempts invalidate even on failure.
7. COW three maps, candidate and child arrays, frozen Indexed/attrs/path/root and ancestor spine; preserve refs, duplicate max-ID winner, -0 and stored list key.
8. No schema/admission/normalizer/History/GC/wire changes, no public engine capability/export, no relaxed tree-shaking guard.
9. Functional exact-source independent evidence and later performance control remain separate.

## Initial source identity

Captured 2026-11-03T17:11:25.857038+00:00. These are progress identities only; they are not approval identities.

| Path | SHA-256 |
| --- | --- |
| `output/data-cache-2026-11-04/receipt-contract.md` | `15c169c86b0060daa35411346b2dc985f026cebb15694552bf0e1efd3ec0a7c5` |
| `packages/doc-sync/src/crdt/doc.ts` | `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` |
| `packages/doc-sync/src/engine/typescript-client.ts` | `dbfedab406844f1e79c4d77656787ae0c438e09212c84f30efc06ad109b0d421` |
| `packages/doc-sync/src/local/client.ts` | `44dea53c95da539adcf52fba406d42d8d1ef41b702d035d5f27ad46eab1e5964` |
| `packages/doc-sync/src/local/editor-host.ts` | `4bf7f35451181f13a51a2c3ca02b3c6666e6522c9e1d3094c379d9cf091add92` |
| `packages/doc-sync/src/client/index.ts` | `2c1d49322f2bf56d47b650b0917da647e87004c1028ef7d5ff3393ddb1b6290d` |
| `packages/doc-sync/src/data/access.ts` | `4d1d6395b832bd6c7f264acb38973b4b245b6aa96d9a9b1108507669e6611154` |

## Progress 2026-11-03T17:15:35.426241+00:00

The contract now contains the widened executable-candidate API table. Actual `Doc.#storedSetTrace` and successful set-register observation now exist. Review continues; this is not the old missing-API HOLD.

### Early test proof gap (test lane still building)

`private-storage-trace.test.ts` currently tests raw physical winning/losing/multi-id/replay writes by comparing two normal Docs. It never calls `ownStorage`/`begin` for those cases. Thus it tests NIL-mode storage semantics, not active trace rejection or authority. Both Docs can share the same trace defect. This is not a production-code counterexample. Before claiming active-trace proof, add exact active trace checks for winning/losing/multi-id/non-value/extra/throw/compact, physical-ticket/DataId mismatch, replay and foreign capability rejection, plus an external frozen-baseline property-getter/proxy observation oracle. Generic owner.write fallback and observer tests are useful but do not close that gap.

Raw operation metadata must not be read after trace invalidation. Source currently gates `attempt` by compiler identity and gates `written` by `invalid`; this is the right boundary to test. Tests must exercise the real production helper, without a new public bypass.

## Early finding 2026-11-03T17:19:47.027672+00:00

### R1 — Optional trace exception interrupts the physical apply (P1; current code)

- Paths: `packages/doc-sync/src/crdt/doc.ts:825,929` and `packages/doc-sync/src/internal/point-receipt.ts:StoredSetTrace.attempt/written`.
- Trigger: start the real private storage port, make the production trace's `attempt` or `written` method throw, then run a normal winning `Doc.emit` value set. The attempt error aborts before revision/storage work. The written error aborts after the register is changed but before `structureChanged` and clock observation. This differs from the same operation with trace disabled.
- Independent evidence already present: `storage-trace-candidate-all.log` reports 173 PASS, 2 FAIL; the two failures are these fault-injection cases. I did not run tests. The helper is production-used, not a parallel test-only recorder.
- Minimal fix: isolate optional trace observation, mark/revoke its proof on error, and continue the unchanged physical apply/clock/cache path. Do not swallow original operation, editGuard, clone, History or clock errors. Keep the NIL branch free of operation reads/allocations. Re-run exact active/inactive error and proxy-read tests after source stabilizes.
- Scope note: this is optional-proof isolation, not a claim that arbitrary hostile global-intrinsic replacement is supported.

The early active-helper test gap is now closed in source by actual `ownStorage`/engine owner tests. Those tests still need a stable exact-source GREEN receipt after R1 is resolved. No approval is issued on 173/175.

`packages/doc-sync/src/crdt/doc.ts` SHA-256 `eac2210f25805fe2ca08ed69ca89e2582fd7816b7c9313c20b557ae11f274268`.

`packages/doc-sync/src/internal/point-receipt.ts` SHA-256 `1d7417db295b1e9164e93248394d94fd5a58f9b43d12c7f3431f8b5da18d3f5c`.

`packages/doc-sync/src/data/access.ts` SHA-256 `e68ed6302b06ece93fec758f267db286b1f7d366a6c39a45ce7e9817c787db39`.

`packages/doc-sync/test/private-storage-trace.test.ts` SHA-256 `eb57f82cc8a490ff813fcaa852cc40a8562e556f987aff6be581f16d75a2a312`.

## Root counterexample and next gate 2026-11-03T17:24:40.694384+00:00

### R2 — NIL trace brand access changes transparent-Proxy receiver semantics (P1; confirmed root counterexample)

`Doc.apply:825` unconditionally evaluates `this.#storedSetTrace`. A transparent Proxy around a real Doc previously supported a valid raw set through ordinary forwarded fields/methods; it now throws a private-brand TypeError after the guard. This violates the NIL-mode compatibility requirement independently of receipt forgery. The root recorded the frozen BEFORE/current comparison in `storage-trace-fixes.prompt.md`. I inspected the exact offending private-field expression; I did not run that reproducer.

Minimal fix: brand-test before optional private-field access (or use a suitable private WeakMap). A Proxy must never gain receipt authority. Preserve the original guard call/receiver/first exception and inactive raw Op observation sequence. `ownStorage` should decline nonbrand values safely. Add exact BEFORE/current tests for successful apply and throwing guard.

The root has sent R1/R2 to the source-fix lane. The implementation is still changing. Current 191-case test receipt is 187 PASS / 4 FAIL / 0 SKIP, not approval. The producer's narrower 9-case internal smoke receipt does not cover these failures.

### Remaining contract detail to settle

`LocalClient.clearHistory` and engine `clearHistory` do not change the Doc stamp or invalidate a pending point receipt. Therefore set -> clearHistory -> normal read can still consume COW. The historical contract says every history action discards pending proof. This does not itself show a wrong data value: clearHistory does not change the model. Either explicitly narrow the contract to model-mutating history actions, or invalidate pending receipts for clearHistory without adding model reads. Do not claim literal all-history-action revocation from current code.

### Positive source proof in progress

The actual lower trace records the winning stored register and stored DataId, not returned Ops. Generic write/direct owner.set lack the private frame. The action executes full Client.edit/Local.apply+commit/History. The normal refresh captures model once and catches optional COW proof decline before reusing that same capture for full legacy validation. Three Maps and affected candidate/child arrays are copied before one private-bundle assignment; root/parent/entry wrappers remain frozen. These observations are not final exact-byte approval while fixes are pending.

## Early finding 2026-11-03T17:25:23.271134+00:00

### R3 — The same private-brand regression exists on public TS engine compatibility (P1)

- Paths: `src/engine/typescript-client.ts:167-170`, `typescriptDocument`, `typescriptHistory`, `replaceTypeScriptDocument`, `replaceTypeScriptHistory`.
- Concrete trigger: create the exported stock engine with `typescriptClientEngineFactory.create`, wrap it with `new Proxy(engine, {})`, then call its ordinary TS compatibility getter-methods. BEFORE uses ordinary TS-private fields and returns the original Doc/History. Candidate `this.#pointPort` (and replacement's `this.#ownedRestore`) throws a brand TypeError. `alive` runs first; a disposed engine must keep its original first error.
- This follows directly from the same JS brand rule as root's actual Doc Proxy counterexample. I did not execute a new probe while the writer was unstable. It is not arbitrary hostile global-intrinsic replacement, nor manual unstamped storage mutation.
- Minimal fix: preserve supported generic receiver behavior while ensuring raw Doc/History exposure cancels the *actual* underlying active trace before returning the pointer. Merely using `enginePoints(proxy)` (which is absent) avoids the exception but is not enough to prove revocation of an underlying active owner. Use a bounded private Doc/owner association or another fail-closed receiver-safe design. Preserve one normal public read/call/receiver/error order. Cover compatibility returns, replacements, and disposed guards with exact BEFORE/current checks.
- More generally, review every newly inserted #field access in formerly generic public methods. DataAccess already had runtime-private #client before this candidate; do not treat that different baseline as a new regression.

Inspected engine SHA-256: `e87d94be04bd173df8a3ca775f9b4b2543160b886f64eb58993172bde92aac9f`.

## R3 confirmed after writer-stable delivery 2026-11-03T17:29:06.962027+00:00

The implementation lane has delivered its report/final. I ran one short read-only source probe under Node 24.22.1. It executed no tests/builds and wrote no files. Each lane imported the existing engine factory/Data schema through its existing source hook. The frozen hook is the independent test lane's archived BEFORE loader.

| Public compatibility call through `new Proxy(engine,{})` | Current | Frozen BEFORE |
| --- | --- | --- |
| typescriptDocument() | TypeError: private #pointPort | same original Doc |
| typescriptHistory() | TypeError: private #pointPort | same original History |
| replaceTypeScriptDocument(originalDoc) | TypeError: private #ownedRestore | success / undefined |
| replaceTypeScriptHistory(originalHistory) | TypeError: private #pointPort | success / undefined |

This is an actual source counterexample, not merely a pending test obligation. R1 and Doc receiver R2 were fixed in the submitted source. R3 is still open. Do NOT approve the submitted hashes based on the 371 focused PASS, 191 later PASS or 9 smoke PASS; none of those establishes compatibility for these four public calls. Exact final approval requires R3 resolution or an explicit documented scope decision from the parent, plus re-review of changed bytes.

`packages/doc-sync/src/engine/typescript-client.ts` SHA-256 `e87d94be04bd173df8a3ca775f9b4b2543160b886f64eb58993172bde92aac9f`.

`packages/doc-sync/src/crdt/doc.ts` SHA-256 `46037917fc6d399eb2f80712950f10db87216e6f8b81fd0ed9e9e1fed5e1ca91`.

`packages/doc-sync/src/data/access.ts` SHA-256 `887397e007952247a2de75b506fa44b5076a9233961e4d0b10d1b176cd0e1281`.

`packages/doc-sync/src/internal/point-receipt.ts` SHA-256 `b32fde966f8dc103e620f4877317e14c5d055385ee69efe85c62a30b7c9b0d98`.

## R3 revised source and R4 actual fail-open 2026-11-03T17:36:37.212561+00:00

R3 has a bounded fix in engine hash `30db938166a842248782a88a292509ccfd8f99b3c4e7f565eaa4f0b67ca89bb9`: original alive-first behavior and one captured public pointer; brand-safe methods; private WeakMap pointer-to-port revokes the actual owner for Proxy exposure; owned Doc/History pointer equality refuses foreign replacements. Private restore updates the captured pointers without clearing revocation. I inspected these exact paths and the 38 persistent regression bodies. The source-fix lane's 409 PASS receipt is source-stable. This closes R3's demonstrated brand/escape defect for the inspected revision. ClearHistory scope is explicitly accepted by root as MODEL-MUTATING undo/redo only; no claim of literal all-history revocation is retained.

### R4 — Late descriptor capture adopts a preloaded public override as stock (P1, actual fail-open)

- Paths: engine `stockDoc = stockPrototype(Doc.prototype)` / static-surface captures near the module end; engine point-owner `check`; access `#tryPoint` skipping unrelated full validation after that false stock proof.
- Supported trigger: import public server first; take the exposed `hub.doc.constructor`; replace public `Doc.prototype.toJSON`; only then dynamically import Client. Engine-local descriptor snapshots capture the already modified method as original. Initial full Data read is valid. A later completed point set followed by the override returning malformed unrelated entry data is incorrectly accepted by COW.
- I independently executed root's existing read-only `preload-override-probe.mjs`, once through current source hook and once through the frozen BEFORE hook, after the writer delivered stable bytes. Node 24.22.1; exit 0; no files written/tests/builds run.
- Both lanes: `client-engine-preloaded false`, initial values `old old`, public model unrelated value `{scalar:{invalid:true}}` after set.
- CURRENT: next Data read returns `new old` (silently accepts malformed unrelated data).
- BEFORE: next Data read throws `Data: invalid encoded scalar`.
- This is an ordinary public method override across package entry points. It does not require private storage mutation or replacing JS global intrinsics. It disproves the current original-default surface authority.
- Minimal fix: capture original instance/static descriptors inside the defining Doc module before public exposure; supply an internal read-only original-surface check to engine ownership. Apply the same provenance rule to independently exposed History/Clock originals. Do not recapture already exposed classes on first Client import, add a public trust flag, bypass validation, or relax tree-shaking guards. Root has explicitly authorized minimal defining-module surface capture, not algorithm changes.

R4 is an exact executable-candidate rejection reason. It supersedes the old missing-API HOLD and is independent of passing focused tests. Re-review final changed bytes and fresh preload valid/malformed/throw/getter oracles before approval.

`packages/doc-sync/src/engine/typescript-client.ts` SHA-256 `30db938166a842248782a88a292509ccfd8f99b3c4e7f565eaa4f0b67ca89bb9`.

`packages/doc-sync/src/crdt/doc.ts` SHA-256 `46037917fc6d399eb2f80712950f10db87216e6f8b81fd0ed9e9e1fed5e1ca91`.

`packages/doc-sync/src/crdt/history.ts` SHA-256 `d6e4efe3aa54bde4212f12b46e394aac2b898a690ccf95f7b85b806d4a08273b`.

`packages/doc-sync/src/crdt/ticket.ts` SHA-256 `70f8b71bac19b6f9039056570256ac41890f99fdc46da1675e91bd875aed8298`.

`packages/doc-sync/src/internal/point-receipt.ts` SHA-256 `b32fde966f8dc103e620f4877317e14c5d055385ee69efe85c62a30b7c9b0d98`.

`packages/doc-sync/src/data/access.ts` SHA-256 `887397e007952247a2de75b506fa44b5076a9233961e4d0b10d1b176cd0e1281`.

## FINAL exact-source disposition

**APPROVE_CODE — bounded executable candidate only.** No open source-correctness finding remains in the exact identities below. This is not full-workspace, package/build, browser/product, performance or release approval. It is not approval of arbitrary future bytes. Timestamp: 2026-11-03T17:45:23.279564+00:00.

The old absent-trace HOLD is superseded. Actual storage trace, owner lifecycle and lazy COW code exist. R1, R2, R3 and R4 are resolved in the inspected source; the history wording is explicitly narrowed to model-mutating undo/redo. Do not reuse earlier report paragraphs as current blockers: they preserve the discovery sequence and original counterexamples.

### Closed findings and direct checks

- R1: optional attempt/written and compiler bind/reset proof failures clear only the private trace and preserve the original apply body/clock/cache path. Setter begin/finish optional errors decline/revoke proof; original edit/History errors remain outside the optional catches.
- R2: Doc observation paths use a private-brand test after the original guard. Transparent Proxy/read-projection receivers do not acquire trace authority or new property observations. Normal raw unknown operations are invalidated before metadata capture; invalid traces do not inspect Op metadata.
- R3: exact four-method read-only source probe now returns the same original Doc/History and undefined replacement results, matching frozen BEFORE. Engine private weak pointer associations revoke actual active and pending owner proofs before raw exposure; captured current/owned Doc+History equality rejects foreign Proxy replacements. Private restore updates pointers only in its owned scope and never clears revocation.
- R4: original Doc/History/Clock instance and static surfaces are now captured in EACH defining module, not the later engine import. The predicate is a const internal-only closure, with no replacement registry. The engine consumes those original predicates. Descriptor checks do not invoke override accessors. I re-executed the existing malformed-unrelated preload source probe after writer-stable delivery: current now throws `Data: invalid encoded scalar`, exactly as frozen BEFORE. No tests/builds were run by this reviewer.
- Defining-module Local and Data handle static/prototype checks also remain in place. Raw override results are not treated as newly owned default restore objects. Genuine default restored clients have positive COW tests; the original escaped client stays revoked.

### Source proof map

| Requirement | Exact inspected mechanism | Boundary |
| --- | --- | --- |
| Real physical winner | Doc successful set branch reads the ACTUAL stored register after attrsFor.set; StoredSetTrace checks one compiler-identity apply attempt, one ID, value key, live entry birth/type, stored DataId/key, winning register at/value and detached frozen ticket/payload | Public returned Ops and numeric stamp alone are not authority. |
| Additional mutations | Additional apply attempts invalidate; direct unknown apply invalidates without Op metadata reads; compact drops trace; engine generation/revision/current Doc/current History and complete-success checks deny replacement/failed actions | Direct private storage mutation without stamps and hostile global intrinsic replacement remain outside contract. |
| Owner/action authority | One-time Doc owner claim, lower and upper private WeakMaps, identity-only opaque tokens, finish/consume single-use; raw escape revokes before return | Public owner.write, direct owner.set/update, constructed handles and returned DTO mutation cannot mint cache receipts. |
| Default closed action | Original Client/Local/host/engine/Doc/History/Clock descriptor proof; default local backend; fixed Data schema; no observers, pending batches or sessions | Existing graphic placements are allowed, not silently assumed absent. Any new placement operation invalidates one-set proof. |
| Policy and old target | Known stock held handle establishes only frame eligibility. Actual cache/target/value action capture occurs AFTER successful policy, against the SAME already-resolved entry/cache; no stale-path repair | Full existing public Client.edit and Local apply+commit+History execute once. |
| Lazy/error behavior | Setter stores pending proof only. refresh performs original schema/stamp check, captures model once at its normal miss point; optional proof catch uses SAME captured model for old full clone/walk/validation | No setter model read or eager Map copy; original model/validation exceptions are preserved. |
| Read attempts | refresh increments epoch before schema/stamp errors while in action; decode also marks attempts; successful publication checks same epoch/cache | Observer scope is disabled initially, so no newer observer cache can be overwritten. |
| COW graph | Copies index/children/key Maps and affected key Map; replaces frozen entry/parent/root spine and child/candidate arrays; one private bundle install | Held old objects are not mutated; unchanged references and ID-sort duplicate order preserved; Object.is keeps -0 and stored list keys remain exact. Object.freeze(Map) does not freeze its entries; privacy, no escape and copy discipline establish that part. |
| Format and algorithm isolation | Doc changes are observation/identity only; History and Clock changes are defining-module descriptor capture only; compiler, normalizer, schema/admission and GC algorithms remain unchanged | No new engine capability, package export or snapshot/wire format. Internal source predicates are not barrel exports. |
| NIL raw path | Brand/nil checks do not read Op properties or allocate per Op; optional trace work only on active path | New Doc-only hot-path branches are NOT assumed free. A trace-free performance control is still required. |

### CONTRACT / CODE / FUNCTIONAL / PERFORMANCE

| Gate | Disposition | Evidence and limits |
| --- | --- | --- |
| CONTRACT | REVIEWED, bounded scope explicit | Actual applied storage certificate, model-mutating-history scope, existing placements, closed default-local owner, unsupported private unstamped mutation/global intrinsics boundary. |
| CODE | APPROVE_CODE for exact hashes | Full mechanism inspection, actual R3 and R4 BEFORE/current short source probes, exact 70-source manifest verification. No forgery approval is inferred merely from test totals. |
| FUNCTIONAL | Focused receipts reviewed; not reviewer-run/full-suite approval | Latest original-surface-fix main receipt: 478 PASS / 0 FAIL / 0 SKIP, sourceStable=true, 27 files. Separate ticket-boundary receipt: 2 PASS. Do not add earlier 409/371/191 totals to this. Test bodies include independent Data/actual-trace suites and persistent receiver/preload cases. Final broad executions belong to implementation lanes, not a new independent reviewer run. |
| Types | Bounded zero-diagnostic receipt reviewed | Imported dependency closure only, not full-workspace typecheck. |
| Package/build/tree shaking | NOT_RUN by reviewer; root gate remains | Public barrels/capability definitions are unchanged in source and no guard was relaxed. Actual emitted export/package isolation and unchanged tree-shaking guard still need root evidence. Descriptor captures can affect retention; do not infer a bundle PASS from source. |
| PERFORMANCE | NOT_APPROVED / NOT_RUN by reviewer | No benchmark or timing run here; clone-count proof is functional eligibility, not speed. Default restored eligibility is functionally demonstrated, but useful latency and Doc-only NIL-branch cost require exact-source parent performance receipts. |
| Browser/mobile/remote/release | NOT_RUN / NOT_APPROVED | No browser or mobile, commit, push, release or remote proof. |

### Final immutable identity

At final capture, all 70 Core source hashes equal `candidate-final-source.json`; zero mismatches. Manifest SHA-256: `dff44206fe088af77f1c7da8537202e92c4a4608d17684753c755ec88e824987`. This covers the 69 prior Core sources plus the new internal helper; it does not certify unrelated workspace files. The latest main receipt's 11 before/after guarded source/test paths are stable and equal current bytes. Receipt SHA-256: `de77380f856bb3aa0ca96a18d6f33ad6142c09b69b3a1533a234bc99928c035f`.

| Production path | Final inspected SHA-256 |
| --- | --- |
| `packages/doc-sync/src/crdt/doc.ts` | `9aa617fff7fa8e3caeaae5d4f5edf4186c126cb9071869f06f56491408a3d6a6` |
| `packages/doc-sync/src/crdt/history.ts` | `4dee4664b9153afad63aa7d012ffff7b10aef97be003a925551423a5e976deb5` |
| `packages/doc-sync/src/crdt/ticket.ts` | `1846cd4d33aea8c6bc55bbf3b1a4e395746ed7eba564d91f575096c3223bd4eb` |
| `packages/doc-sync/src/internal/point-receipt.ts` | `afa0b6acdf3881b6ab6ea1cf3956c723a2ac3080c7a49dabfff6a96b28907428` |
| `packages/doc-sync/src/engine/typescript-client.ts` | `5ee2be8d07a13a751523a80fc28eb40659d5ab421ccc10b391a1989283c8a1f0` |
| `packages/doc-sync/src/local/client.ts` | `5b894d5769b21c3e7689f304ca313e193d6422b4471f7f95512fa8ed59b1fa72` |
| `packages/doc-sync/src/local/editor-host.ts` | `77bc65ce07223eb7e16ee8afe6c083b0a04a59b8e1b711d8f4895e704ded6ad5` |
| `packages/doc-sync/src/client/index.ts` | `2835ff9e3b36e77523f8d51e3ae259bf3fd6ad6e5e4df526aad0ab35eca959b7` |
| `packages/doc-sync/src/data/access.ts` | `887397e007952247a2de75b506fa44b5076a9233961e4d0b10d1b176cd0e1281` |

Any change to these sources, original-surface predicates, package export wiring or guard logic invalidates the corresponding approval and requires focused re-review. Root owns integration and performance disposition.

### Reviewer write/execution audit

Only `storage-trace-review.report.md` and `storage-trace-review.final.md` were written by this reviewer. No production source, test, benchmark, build/dist, mobile, Git commit/push or spawned agent. After writer-stable delivery only short read-only source probes and hash/source inspections were run. Historical memory search produced no applicable cache/trace facts; no memory-derived engineering claim is used in this decision.
