import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir = 'output/data-cache-2026-11-04/original-surface-fix.pre'; mkdirSync(dir,{recursive:true});
const expected = Object.fromEntries(readFileSync('output/data-cache-2026-11-04/original-surface-fix.before.sha256','utf8').trim().split('\n').map(line=>{const [hash,path]=line.split(/\s+/);return [path,hash];}));
for (const [path, hash] of Object.entries(expected)) {
    let text=readFileSync(path,'utf8');
    if (path.endsWith('/doc.ts')) text=text.replace('installStorageBridge, StoredSetTrace, originalClassSurface','installStorageBridge, StoredSetTrace').replace('// Internal authority. Capture here, not in a later engine import.\nexport const originalDocSurface = originalClassSurface(Doc);\n\n','');
    if (path.endsWith('/history.ts')) text=text.replace('import {originalClassSurface} from "../internal/point-receipt.ts";\n','').replace('\n// Internal authority captured before a later consumer can replace this surface.\nexport const originalHistorySurface = originalClassSurface(History);\n','');
    if (path.endsWith('/ticket.ts')) text=text.replace('import {originalClassSurface} from "../internal/point-receipt.ts";\n\n','').replace('\n// Internal authority captured before a later consumer can replace this surface.\nexport const originalClockSurface = originalClassSurface(Clock);\n','');
    if (path.endsWith('/point-receipt.ts')) {
        text=text.replace('const getOwnDescriptors = Object.getOwnPropertyDescriptors, ownDescriptorKeys = Reflect.ownKeys;\n\n','').replaceAll('getOwnDescriptors(', 'Object.getOwnPropertyDescriptors(').replaceAll('ownDescriptorKeys(', 'Reflect.ownKeys(');
        const a=text.indexOf('/** Call only in the class\'s defining module'), b=text.indexOf('export function ownValue',a); text=text.slice(0,a)+text.slice(b);
    }
    if (path.endsWith('/typescript-client.ts')) {
        text=text.replace('ownStorage, stockPrototype','ownStorage, stockSurface, stockPrototype').replace('import {originalClockSurface}', 'import {Clock}').replace('Doc, MAIN, originalDocSurface','Doc, MAIN').replace('History, originalHistorySurface','History').replace('originalDocSurface(this.doc) && originalHistorySurface(this.history) && originalClockSurface(this.doc.clock)','stockDocClass() && stockHistoryClass() && stockDoc(this.doc) && stockHistory(this.history) && stockClock(this.doc.clock)');
        text=text.replace('export const typescriptClientEngineFactory:', 'const stockDocClass = /* @__PURE__ */ stockSurface(Doc);\nconst stockHistoryClass = /* @__PURE__ */ stockSurface(History);\nconst stockDoc = /* @__PURE__ */ stockPrototype(Doc.prototype);\nconst stockHistory = /* @__PURE__ */ stockPrototype(History.prototype);\nconst stockClock = /* @__PURE__ */ stockPrototype(Clock.prototype);\nexport const typescriptClientEngineFactory:');
    }
    const actual=createHash('sha256').update(text).digest('hex');
    if(actual!==hash) throw Error('Reconstruction mismatch '+path+': '+actual+' != '+hash);
    writeFileSync(dir+'/'+path.split('/').at(-1),text); console.log('Verified pre-source',path,hash);
}
