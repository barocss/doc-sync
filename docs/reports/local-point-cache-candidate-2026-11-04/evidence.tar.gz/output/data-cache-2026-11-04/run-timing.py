from pathlib import Path
import json,hashlib,subprocess,statistics,time,datetime,os
ROOT=Path('/Users/user/github/doc-sync'); OUT=ROOT/'output/data-cache-2026-11-04'
PLAN=json.loads((OUT/'timing-plan-v3.json').read_text()); NODE=PLAN['node']
BEFORE=ROOT/'output/refactor-2026-11-03/post-refactor-baseline'
manifest=json.loads((OUT/'candidate-final-source.json').read_text())
assert (OUT/'storage-trace-review.final.md').read_text().startswith('**APPROVE_CODE**')
for s,h in manifest['coreSource'].items(): assert hashlib.sha256((ROOT/s).read_bytes()).hexdigest()==h,s
for s,h in PLAN['drivers'].items(): assert hashlib.sha256((ROOT/s).read_bytes()).hexdigest()==h,s
expected={}
for n in (2000,20000):
 a=json.loads((OUT/f'counts-{n}-before.json').read_text());b=json.loads((OUT/f'counts-{n}-current.json').read_text())
 assert a['fixtureSHA']==b['fixtureSHA'] and a['driverSHA']==b['driverSHA']==PLAN['drivers']['benchmarks/data-point-cache.mjs']
 assert all(s['counts'][0]['nextReadRootClones']==1 for s in a['scenarios'])
 assert all(s['counts'][0]['setterRootClones']==s['counts'][0]['nextReadRootClones']==0 for s in b['scenarios'])
 expected[n]={'before':a,'current':b}
start={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planSHA256':hashlib.sha256((OUT/'timing-plan-v3.json').read_bytes()).hexdigest(),'sourceManifestSHA256':hashlib.sha256((OUT/'candidate-final-source.json').read_bytes()).hexdigest(),'status':'RUNNING','loadavg':os.getloadavg()}
(OUT/'timing-start.json').write_text(json.dumps(start,indent=2)+'\n')
ledger=[];cycles=[]
def save(): (OUT/'timing-progress.json').write_text(json.dumps({'started':start,'runs':ledger,'cycles':cycles},indent=2)+'\n')
def run(kind,cycle,pos,lane,n=None):
 name=f'point-timing-c{cycle}-{n}-p{pos}-{lane}' if kind=='data' else f'doc-timing-c{cycle}-p{pos}-{lane}'
 dest=OUT/(f'{name}.json' if kind=='data' else f'doc-trace-control.{name}.json')
 root=BEFORE if lane=='before' else ROOT
 script='benchmarks/data-point-cache.mjs' if kind=='data' else 'benchmarks/doc-trace-control.mjs'
 args=[NODE,script,'--source-root',str(root),'--label',f'{lane}-post-refactor-c{cycle}-p{pos}','--output',str(dest),'--mode','timing','--samples','3','--warmup','1']
 args+=['--records',str(n)] if kind=='data' else ['--chars','100000']
 entry={'name':name,'kind':kind,'cycle':cycle,'position':pos,'lane':lane,'n':n,'output':str(dest),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':os.getloadavg(),'argv':args,'status':'RUNNING'}
 ledger.append(entry);save();print('START',name,flush=True)
 env=dict(os.environ);env.pop('NODE_OPTIONS',None)
 result=subprocess.run(['python3','output/refactor-2026-11-03/root-check.py',name,*args],cwd=ROOT,env=env,check=False)
 assert result.returncode==0,name
 data=json.loads(dest.read_text());entry['status']='PASS_ORACLE';entry['end']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if kind=='data':
  assert data['closureSHA']==expected[n][lane]['closureSHA'] and data['fixtureSHA']==expected[n][lane]['fixtureSHA']
  assert data['driverSHA']==PLAN['drivers'][script]
 else:
  assert data['sourceClosureSHA']==expected[2000][lane]['closureSHA']
  assert data['benchmarkSHA']==PLAN['drivers'][script]
 save();print('DONE',name,flush=True);return data
med=statistics.median
def compare(before,current,metrics):
 return {key:{'beforeMedianMs':med([r[key] for r in before]),'currentMedianMs':med([r[key] for r in current]),'reduction':1-med([r[key] for r in current])/med([r[key] for r in before]),'beforeRawMs':[r[key] for r in before],'currentRawMs':[r[key] for r in current]} for key in metrics}
try:
 for cycle in range(1,4):
  summary={'cycle':cycle,'data':[],'document':{},'gates':[]};laneOrder=['before','current','current','before']
  for n in (2000,20000):
   data=[run('data',cycle,pos,lane,n) for pos,lane in enumerate(laneOrder)]
   for case in range(3):
    lanes={lane:[row for i,runData in enumerate(data) if laneOrder[i]==lane for row in runData['scenarios'][case]['timing']] for lane in ('before','current')}
    metrics=compare(lanes['before'],lanes['current'],['setMs','nextReadMs','totalMs'])
    controls={lane:[row for i,runData in enumerate(data) if laneOrder[i]==lane for row in runData['scenarios'][case]['rawEditReadControlTiming']] for lane in ('before','current')}
    result={'n':n,'scenario':data[0]['scenarios'][case]['name'],'metrics':metrics,'rawFallbackControl':compare(controls['before'],controls['current'],['setMs','nextReadMs','totalMs']),'strictZeroTotalRegression':metrics['totalMs']['reduction']>=0}
    result['gates']={'readAtLeast20Percent':metrics['nextReadMs']['reduction']>=.20,'totalWithin5PercentRegression':metrics['totalMs']['reduction']>=-.05,'largeTotalAtLeast5Percent':n!=20000 or metrics['totalMs']['reduction']>=.05}
    summary['data'].append(result);summary['gates'].extend(result['gates'].values())
  docs=[run('doc',cycle,pos,lane) for pos,lane in enumerate(laneOrder)]
  for key in ['schemaSHA','fixtureSHA','seedTextSHA','workloadSHA','expectedOperationSHA','expectedModelSHA','expectedSnapshotSHA']:
   assert len({d[key] for d in docs})==1,key
  lanes={lane:[row for i,d in enumerate(docs) if laneOrder[i]==lane for row in d['runs']] for lane in ('before','current')}
  metrics=compare(lanes['before'],lanes['current'],['localEditMs','localColdToJSONMs','remoteApplyMs','remoteColdToJSONMs','localEditAndReadMs','remoteApplyAndReadMs'])
  summary['document']={'metrics':metrics,'eachMetricWithin5PercentRegression':all(m['reduction']>=-.05 for m in metrics.values())}
  summary['gates'].append(summary['document']['eachMetricWithin5PercentRegression']);summary['acceptedCycle']=all(summary['gates']);cycles.append(summary);save()
  print('CYCLE_RESULT',cycle,summary['acceptedCycle'],[(r['n'],r['scenario'],round(100*r['metrics']['totalMs']['reduction'],2)) for r in summary['data']],flush=True)
  if not summary['acceptedCycle']:break
 decision={'status':'PERFORMANCE_GATES_PASS_SUBJECT_TO_INTEGRATION' if len(cycles)==3 and all(c['acceptedCycle'] for c in cycles) else 'DECLINED_PERFORMANCE_CANDIDATE','cyclesCompleted':len(cycles),'cyclesNotRun':list(range(len(cycles)+1,4)),'reason':'Prospective per-cycle gates; no optional favorable reruns. See raw effect and control metrics, not a causal isolated-host or SLA claim.','endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cycles':cycles}
 (OUT/'performance-decision.json').write_text(json.dumps(decision,indent=2)+'\n');print('DECISION',decision['status'],flush=True)
except Exception as e:
 (OUT/'timing-failure.json').write_text(json.dumps({'status':'ERROR_NOT_ACCEPTED','error':str(e),'runs':ledger},indent=2)+'\n');raise
