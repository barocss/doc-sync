import assert from 'node:assert/strict';
import {test} from 'node:test';
import {Client,clientOwner} from '../../packages/doc-sync/src/client/index.ts';
import {LocalClient} from '../../packages/doc-sync/src/local/client.ts';
import {Doc} from '../../packages/doc-sync/src/crdt/doc.ts';
import {createDataSchema} from '../../packages/doc-sync/src/data/schema.ts';
import {ownStorage,clientPoints} from '../../packages/doc-sync/src/internal/point-receipt.ts';
const id='data:00000000-0000-4000-8000-000000000001';
const make=()=>{const c=new Client({actor:'private-proof',schema:createDataSchema()});c.data.root.set('x',0);c.data.root.get('x');return c;};
const clones=run=>{const original=globalThis.structuredClone;let n=0;globalThis.structuredClone=(v,...a)=>{if(v?.type==='data'&&v.children)n++;return original(v,...a);};try{run();return n;}finally{globalThis.structuredClone=original;}};
test('unescaped default restored owner remains eligible and uses COW',()=>{
 const c=make(), state=c.captureState(), r=Client.fromState(state,{schema:createDataSchema()});
 assert.equal(clientPoints(r).check(),true);r.data.root.get('x');r.data.root.set('x',-0);
 assert.equal(clones(()=>assert.ok(Object.is(r.data.root.get('x'),-0))),0);c.dispose();r.dispose();
});
test('user LocalClient.fromState override is called once and never adopted as owned',()=>{
 const c=make(),state=c.captureState(),original=LocalClient.fromState;let calls=0,backend;
 LocalClient.fromState=function(...args){calls++;backend=original.apply(this,args);return backend;};
 try{const r=Client.fromState(state,{schema:createDataSchema()});assert.equal(calls,1);assert.equal(clientPoints(r).check(),false);r.data.root.get('x');r.data.root.set('x',2);assert.equal(clones(()=>r.data.root.get('x')),1);r.dispose();}finally{LocalClient.fromState=original;c.dispose();}
});
test('direct public owner.set cannot issue a known-set frame',()=>{
 const c=make(),root=c.data.root;root.owner.set(root,'x',4);assert.equal(clones(()=>root.get('x')),1);c.dispose();
});
test('generic write and public write override preserve one receiver/call',()=>{
 const c=make(),root=c.data.root,owner=root.owner,original=owner.write;let calls=0;
 owner.write=function(...args){assert.equal(this,owner);calls++;return original.apply(this,args);};
 try{root.set('x',3);assert.equal(calls,1);assert.equal(clones(()=>root.get('x')),1);}finally{delete owner.write;c.dispose();}
});
test('storage owner cannot be overwritten and tokens cannot finish another action',()=>{
 const d=new Doc('private-proof',createDataSchema());d.edit([{op:'insert',at:[0],content:[{type:'entry',attrs:{id,key:'x',value:{scalar:0}}}]}]);
 const owner={},port=ownStorage(d,owner);assert.ok(port);assert.equal(ownStorage(d,{}),null);assert.equal(ownStorage(d,owner),null);
 const trace=port.begin({id,value:{scalar:1}});assert.equal(port.begin({id,value:{scalar:2}}),null);
 assert.equal(port.finish({}),null);d.edit([{op:'update',at:[0],attrs:{value:{scalar:1}}}]);
 const receipt=port.finish(trace);assert.equal(receipt.id,id);assert.equal(receipt.key,'x');assert.ok(receipt.target.actor);assert.equal(receipt.value.scalar,1);assert.equal(port.finish(trace),null);port.revoke();assert.equal(port.begin({id,value:{scalar:2}}),null);
});
test('receipt rejects foreign replay, multiple applies and direct raw apply',()=>{
 const a=make(),b=make(),pa=clientPoints(a),pb=clientPoints(b),intent={id:a.data.root.candidates('x')[0].id,value:{scalar:1}};
 let action=pa.begin(intent);a.edit([{op:'update',at:[0],attrs:{value:{scalar:1}}}]);const token=action.finish(true);
 assert.equal(pb.consume(token),null);assert.equal(pa.consume(token).id,intent.id);assert.equal(pa.consume(token),null);
 action=pa.begin(intent);a.edit([{op:'update',at:[0],attrs:{value:{scalar:2}}}]);a.edit([{op:'update',at:[0],attrs:{value:{scalar:3}}}]);assert.equal(action.finish(true),null);
 action=pa.begin(intent);const raw=clientOwner(a);assert.equal(action.finish(true),null);assert.equal(clientPoints(a).check(),false);assert.equal(raw,clientOwner(a));a.dispose();b.dispose();
});
test('stock Doc static override rejects optimization without an extra invocation',()=>{
 const c=make(),original=Doc.fromSnapshot;let calls=0;Doc.fromSnapshot=function(...args){calls++;return original.apply(this,args);};
 try{c.data.root.set('x',5);assert.ok(calls>0);const before=calls;assert.equal(clones(()=>c.data.root.get('x')),1);assert.equal(calls,before);}finally{Doc.fromSnapshot=original;c.dispose();}
});
test('list default unstored key still proves one value write',()=>{
 const c=make(),list=c.data.createList(),entry=list.push(1);list.get(entry);list.set(entry,2);assert.equal(clones(()=>assert.equal(list.get(entry),2)),0);c.dispose();
});
test('caller-constructed same-owner handle has no acceleration authority',async()=>{
 const {SharedMap}=await import('../../packages/doc-sync/src/data/access.ts');
 const c=make(),root=c.data.root,foreign=new SharedMap(root.owner,root.id);foreign.set('x',6);assert.equal(clones(()=>root.get('x')),1);c.dispose();
});
