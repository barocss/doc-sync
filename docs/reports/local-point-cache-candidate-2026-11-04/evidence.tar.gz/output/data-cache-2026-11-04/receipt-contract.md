# Lazy point-write receipt contract

Status: IMPLEMENTATION CANDIDATE, not performance-approved. 2026-11-04.

## Current authorized scope

Own src/crdt/doc.ts (observation only), engine/typescript-client.ts, local/client.ts, local/editor-host.ts, client/index.ts, data/access.ts and small internal helpers. Preserve inherited WIP. Compiler, History, schema, admission, wire, normal validation and normalization stay unchanged. No subagents, global build/dist, timings, commit, push or mobile. This authorization supersedes the historical four-file STOP below.

## Executable internal API and proof table

| Layer | Internal API | Proof / failure behavior |
| --- | --- | --- |
| Doc | Private trace slot, registered once to an opaque engine owner; begin/finish closures | Trace actual apply attempts and successful winning register writes. run supplies already-owned compiler operation identity. Inactive apply/run uses nil branch, no extra op reads or allocations. One value set, one live entry, stored DataId, physical ticket, register ticket and detached value. Extra/losing/non-set/replayed/replaced/failed action gives no certificate. |
| Engine | Weak registry begin/check/revoke closures, not ClientEngine capabilities | Stock captured descriptors, no escaped Doc/History, no sessions, fixed schema. Existing placements are allowed: stored DataId binds the physical target at apply; final target/spine verifies model path without a pre-action mapping or projection read. Any move during the action invalidates the trace. Own actual Doc trace spans the complete Client.edit action. Revocation cancels trace before raw object is returned. |
| Local | Weak registry begin/check/revoke | Default constructor provenance, stock descriptor chain, zero observers/pending/sessions. Complete edit and History run once. Restore validates privately without resetting revocation or calling user overrides as owned. |
| Client | Weak registry attachment | Captured Client/backend/host identities and descriptors; local only. clientOwner escape revokes before return. No public trusted boolean. |
| Access | Private known-set frame and private cache bundle/epoch/pending | Only stock SharedMap/List setter paths can grant authority; generic write or public owner.set/update cannot. Capture after policy once against same old target/cache. No setter model call or Map copies. |
| Refresh | Single-use pending receipt | Call normal model once at old refresh point. Verify same cache/schema/stamp/epoch and exact target/spine; construct frozen COW graph privately and assign one bundle. Failure uses full clone/walk/validation on SAME model. No added setter read error. |

Supported stamped mutations are checked by trace plus unchanged generation/revision. Direct mutation of TypeScript-private storage without stamp is outside the existing cache protocol. No claim protects hostile replacement of global builtins. Ordinary public overrides and raw Doc.apply are in scope and must fail closed. Extra raw operations after invalidation must not be inspected by the trace.

## Gates

Source candidate only until independent tests, exact-byte High review and root integration gates. Focused source tests/type diagnostics are not full-workspace acceptance. No speed claim. A concrete semantic counterexample that needs algorithm changes keeps the candidate OFF. Absence of a previous trace is no longer a stop reason.

## Historical contract and prior STOP (superseded scope)

# Lazy point-write receipt contract

Status: DRAFT / candidate OFF. No production edits yet. Independent High review is required. This contract supersedes eager verification in design section 5.D.18.

## Ownership

The source writer owns only `packages/doc-sync/src/{data/access.ts,client/index.ts,local/client.ts,engine/typescript-client.ts}` and, if necessary, one small private helper. Other production files, tests, benchmarks, global builds, full tests, documentation, browser work and performance acceptance belong to other lanes. Preserve inherited WIP. No sub-agents, commit, push, release or mobile checks.

## State transition

1. Only existing map-winner/list-ID value setter paths may create an unforgeable private frame. Generic `owner.write` is not a frame producer.
2. Preserve checks, encode, target resolution and policy order. Capture action state only after successful policy. No extra refresh to obtain eligibility.
3. Run the old complete `Client.edit` once. No direct Doc writes or preflight bypass.
4. Lower owner must prove one actual applied physical `set` for `value`, matching ticket, DataId, path and privately owned immutable tagged payload. Public returned operations and numeric +1 alone are insufficient.
5. Grant an owner-bound, single-use receipt only after complete edit success. Store only a pending delta. Do not call model or copy Maps after set.
6. On the next normal refresh miss, call model once at its old position. Validate pending owner, schema, generation/revision, epoch, target and cache identity. Verify the captured target/spine. If proof fails, use that SAME captured model for the FULL old clone/walk/validation; do not recapture or duplicate public getters.
7. COW copies index, childMap, keyMap, affected key Map, candidate/child arrays and root/parent spine. Replace frozen Indexed/node/attrs/path objects as needed. Preserve stored list key, duplicate sort order, references, -0 and all held old frozen objects. Install one private bundle at the end.
8. Discard pending proof on any read attempt during action (including failed refresh), raw/structural/history/session/remote/schema action, owner escape, overrides or uncertainty. Never replace an observer's newer full cache. Optional proof cannot introduce setter errors.

## Ownership / prototype / escape proof table

| Surface | Required evidence | Current evidence / open obligation |
| --- | --- | --- |
| Unified Client | Private backend identity, exact stock prototype/descriptors captured before external code; no getters invoked by checks | Backend WeakMap and #backend exist. `clientOwner()` returns raw backend. Revocation does not yet exist. |
| Local owner | Stock backend, no observers for first pilot, no pending/compositions, complete edit interval | `LocalClient.edit` calls apply then commit; mutable TypeScript-private engine/pending/hooks paths exist. No receipt exists. |
| TS engine | Exact owned engine/Doc/History and stock method/descriptor chain; no foreign factory or hooks | Default factory is frozen; compatibility returns raw Doc/History; no revoke-only ownership state exists. |
| Doc application | Actual applied target ticket linked to cached DataId/path; exact single encoded value; no extra apply/normalization | Compiler returns `doc.edit(...).ops`. No private applied-operation certificate exists. Must not infer this solely from returned ops/stamp. |
| Public raw compatibility | Revoke before returning original values; preserve call count/error/receiver | `typescriptDocument`, `typescriptHistory`, replacements, `clientOwner`, sessions and restored-state validation need separate handling. |
| Restore | Prove privately created checkpoint installation without clearing prior revocation | `LocalClient.fromState` currently uses compatibility getters during validation. No eligible restored-state proof exists. |
| Access | Private frame creation only in internal set/update, private cache identity/epoch | Generic `DataAccess.write` remains publicly reachable via handle owner. No receipt state exists. |
| Tree shaking | Fresh private descriptor captures must not retain unused Client/Sync modules | No captures added. New module evaluation must be reviewed before activation. |

## Fail-closed stop gate

Keep candidate OFF if actual applied-set proof cannot be established with bounded changes to the four owned files and a small helper. Do not expand into Doc, CRDT compiler/storage, History, schema, admission or exported engine contracts. An OFF result preserves legacy behavior; it is not an approved optimization or a performance result.

## Evidence plan

Read the lower compile/application and public escape paths before source changes. Record exact hashes against the frozen 69-file baseline. Run only focused source-hook Data/Client/local-engine/recovery tests and a direct no-emit typecheck under Node 24 with bounded watchdogs. No npm pretest/pretypecheck lifecycle or global build. High final review and independent tests remain separate gates.

## Source-writer stop checkpoint

Candidate remains OFF. No production changes were made. The following alternatives were considered and not implemented:

- Inspect `compile(...).ops` plus one revision increment: REJECTED. This is returned-operation authority, explicitly prohibited by the action contract.
- Capture actual operations by temporarily replacing `doc.apply` or `doc.emit`: NOT_PROVED. This changes the observable method descriptors and inserts a callback into the complete action. It needs an independent proof for own/prototype overrides, nested guard/preflight calls, restoration on partial failure, detached staging, History, and replacement/install paths. Merely calling this a private wrapper does not establish that proof.
- Add a private applied-operation certificate in Doc/compiler: OUTSIDE OWNERSHIP. No edits to those files are made.

The current source does not supply a ready private application trace. I have not established a bounded safe substitute in the four owned files and a small helper. This is a source-writer proof failure and a fail-closed stop, NOT a proof that every future four-file design is impossible. It is NOT permission to broaden scope. Do not activate a stamp/returned-ops approximation while waiting for a stronger design.

Without that prerequisite, partial revocation, descriptor capture and COW code would add overhead but provide no eligible supported workload. They are not installed. Restored local clients continue to use the original full cache refresh; useful 20k acceleration is NOT_PROVED. No revocation reset or unsupported restore shortcut is proposed.
