# DOCUMENT trace-disabled control

Status: **smoke PASS**. 100k timing: **NOT_RUN**. No speed or acceptance claim.

## Owned changes

- `benchmarks/doc-trace-control.mjs` only.
- `output/data-cache-2026-11-04/doc-trace-control.*` only.
- Existing production, tests, docs and other benchmarks were not edited.
- No child agents, builds/dist, browser/mobile tests, commits or pushes.

## Source and runtime identity

- Before realpath: `/Users/user/github/doc-sync/output/refactor-2026-11-03/post-refactor-baseline`.
- Before all-TS source closure SHA256: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`.
- Current realpath at smoke: `/Users/user/github/doc-sync`.
- Current all-TS source closure SHA256: `a80f73deff664d32a41326e10ae1bb2f11fcf69bec1926981eaea7dec7bc7af2`.
- Benchmark SHA256: `de905d02666989f8ec37180d85bd511c29a40b77ce768ab138645f41892b547c`.
- Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node` (`v24.22.1`), no execArgv or NODE_OPTIONS.
- Each JSON contains all source-file hashes, loaded source paths, start/end source hashes, host/CPU/load/process metadata, argv and raw samples.
- Labels do not select source or prove a Git baseline. Before is the explicit post-refactor snapshot, not ec962.
- Source and driver identities must match at run end. Runtime rejection writes a FAIL receipt. Never overwrite an old receipt. A changing source needs a new output name and a later stable run.
- The active source can change after smoke. These receipts prove their recorded source identities only.

## Workload and timers

A validated DocumentSchema contains one doc/p and exactly the requested UTF16 seed length. One public bulk seed edit inserts ASCII, Hangul and emoji. It is outside all timers. No per-character seed edit loop.

Two fresh Docs restore the same exact seed snapshot before each sample. They use the same fixed actor. The fixed seed actor, IDs, clock, text and edit batch are identical across source lanes. There is no pre-timer toJSON on either measured replica.

One timed local `Doc.edit(edits)` performs 8 middle replacements (16 edits). It uses default compiler behavior, with no History or normalization listener. Each replacement inserts `편집🙂` plus a fixed digit and deletes one original ASCII unit. No surrogate pair is split. A 100000-unit seed ends at 100032 live UTF16 units, with 8 tombstones. The bounded state does not accumulate between samples.

Intervals are separate:

1. Full local public Doc.edit batch, including all compiler-internal work.
2. First local toJSON after that edit.
3. Remote loop applying all 16 plain, detached returned wire operations.
4. First remote toJSON after that apply.

The local-edit/read and remote-apply/read sums are also reported. Wire JSON detachment, assertions, schema validation, restore, seeding, snapshots and hashes are outside intervals. Cold means first toJSON after the operation, not empty CPU caches or forced internal invalidation. Eager work inside the real compiler is not removed or reassigned.

Direct Doc imports only. No Engine, Client, Data owner or private storage bridge is imported or claimed by the driver. The current Doc internally installs its normal module bridge, but this script never claims an owner or starts a trace. No prototype or global intrinsic is patched. No trace counter or clone-count assertion is imposed.

## Independent semantic oracle

The reference uses only plain tokens, strings and ticket arithmetic. It does not call production canonicalizers, applyEdits, replay helpers or returned operations to compute expected state.

It checks exact schema validity; the seed model and snapshot; every returned operation, origin, ID and clock; expected final text/model; full encoded snapshot including lines, physical order, origins, tombstones and Lamport clock; and replica convergence. Baseline and final snapshot, model, operations and workload hashes are outside timers. Stored item, line, live/deleted character counts are included. Undo/redo: NOT_RUN because the direct Doc control has no History.

## Verification

- Before and current: 1000 UTF16 seed, 2 warmups, 3 measured smoke samples per process: PASS.
- Final seed, schema, workload, expected operation/model/snapshot hashes match across sources: PASS.
- Final benchmark SHA matches both receipts: PASS.
- Full selected source identity stayed unchanged within each final run: PASS.
- `doc-trace-control.validation.json`: 13 checks PASS, including help, bad/duplicate/missing options, bad integer/mode/size/sample limits, NODE_OPTIONS rejection, exclusive output, hash equality and median/raw consistency.
- Rejected CLI invocations are preserved in `doc-trace-control.validation.log`. They fail before measurement and do not create result JSON.
- Source-change and outside-source import guards are implemented but not fault-injected: NOT_RUN. No source was mutated for a guard test.
- Earlier `before-smoke.json` and `current-smoke.json` are retained. They precede the final input-bound edit. Use `*-smoke-final.json` for the final driver.
- High review, full tests, accepted regression threshold, final frozen-source 100k ABBA and publication remain root-owned.

## Usage

Help:

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node benchmarks/doc-trace-control.mjs --help
```

Small smoke (use unused output names):

```sh
NODE=/Users/user/.nvm/versions/node/v24.22.1/bin/node
$NODE benchmarks/doc-trace-control.mjs --source-root output/refactor-2026-11-03/post-refactor-baseline --label before-smoke-repeat --output output/data-cache-2026-11-04/doc-trace-control.before-smoke-repeat.json --chars 1000 --samples 3 --warmup 2 --mode smoke
$NODE benchmarks/doc-trace-control.mjs --source-root . --label current-smoke-repeat --output output/data-cache-2026-11-04/doc-trace-control.current-smoke-repeat.json --chars 1000 --samples 3 --warmup 2 --mode smoke
```

Root-only later timing example, NOT executed here. Freeze source first, wait for other work to stop, run sequentially in A-B-B-A order, and compare all semantic hashes and source identities before using timings:

```sh
NODE=/Users/user/.nvm/versions/node/v24.22.1/bin/node
BEFORE=output/refactor-2026-11-03/post-refactor-baseline
$NODE benchmarks/doc-trace-control.mjs --source-root "$BEFORE" --label A1 --output output/data-cache-2026-11-04/doc-trace-control.A1.json --chars 100000 --samples 7 --warmup 2 --mode timing
$NODE benchmarks/doc-trace-control.mjs --source-root . --label B1 --output output/data-cache-2026-11-04/doc-trace-control.B1.json --chars 100000 --samples 7 --warmup 2 --mode timing
$NODE benchmarks/doc-trace-control.mjs --source-root . --label B2 --output output/data-cache-2026-11-04/doc-trace-control.B2.json --chars 100000 --samples 7 --warmup 2 --mode timing
$NODE benchmarks/doc-trace-control.mjs --source-root "$BEFORE" --label A2 --output output/data-cache-2026-11-04/doc-trace-control.A2.json --chars 100000 --samples 7 --warmup 2 --mode timing
```

Only raw per-sample totals and medians are emitted. Smoke is functional evidence, not performance evidence. Host isolation is not guaranteed. No retained-heap or allocation claim is made.
