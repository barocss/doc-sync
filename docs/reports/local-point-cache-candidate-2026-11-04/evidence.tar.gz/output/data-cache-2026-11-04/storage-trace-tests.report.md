# Storage-trace independent test report

Status: TEST DELIVERY COMPLETE / CANDIDATE FAIL / NOT GREEN. 2026-11-03T17:22:22.642552+00:00

## Exact results

| Run | PASS | FAIL | SKIP | Boundary |
| --- | ---: | ---: | ---: | --- |
| Frozen BEFORE functional | 116 | 0 | 0 | Original semantic cases, no feature switch. |
| Frozen BEFORE optimization | 0 | 5 | 0 | Expected RED, independent post-refactor source. |
| Frozen candidate point + new trace | 187 | 4 | 0 | 191 = 121 original + 70 new. Exact source pinned outside checkout. |
| Direct scoped no-emit typecheck | PASS | 0 | 0 | Both tests and imported source; no lifecycle/build. |
| Frozen BEFORE source identity | 69 MATCH | 0 | 0 | All 69 manifest Core sources match. |
| Frozen BEFORE proxy oracle | 4 PASS | 0 | 0 | Separate script; not added to the 191 test count. |

First current failure: optional `StoredSetTrace.attempt` error interrupts accepted Doc.emit.
`written` has the same defect after register mutation. Both also fail through the
public Data setter (4 failing tests total). See `tests-proofs.md` and native logs.

The five original projection checks are now unconditional. Original 121 all pass
at this candidate sample. This is an exact frozen-source FAIL, not GREEN or a speed claim.

## Scope

Only `packages/doc-sync/test/data-point-cache.test.ts`, new
`packages/doc-sync/test/private-storage-trace.test.ts`, and this lane's test/report
artifacts were written. No production source edits, builds, dist writes, mobile,
commit, push, release, agents, full root test suite or performance runs. Existing WIP retained.

Prior root baseline 1921 excludes the point-cache file. It is historical, not a
new run here. Do not add its 1919 PASS to this lane or claim a full-suite PASS.

## Frozen source identity for the 191-case run

| Path | SHA-256 |
| --- | --- |
| `packages/doc-sync/src/crdt/doc.ts` | `eac2210f25805fe2ca08ed69ca89e2582fd7816b7c9313c20b557ae11f274268` |
| `packages/doc-sync/src/internal/point-receipt.ts` | `e96fd9a2fe9b1a92b48ce6cf725a1e287c45a7aa12e216ec523c724246e99480` |
| `packages/doc-sync/src/engine/typescript-client.ts` | `e87d94be04bd173df8a3ca775f9b4b2543160b886f64eb58993172bde92aac9f` |
| `packages/doc-sync/src/local/client.ts` | `d64aee4cf1c21fe01a1cd60b51505f1b99f1dd486db4c84a4f72313ae6cd5d76` |
| `packages/doc-sync/src/local/editor-host.ts` | `77bc65ce07223eb7e16ee8afe6c083b0a04a59b8e1b711d8f4895e704ded6ad5` |
| `packages/doc-sync/src/client/index.ts` | `2835ff9e3b36e77523f8d51e3ae259bf3fd6ad6e5e4df526aad0ab35eca959b7` |
| `packages/doc-sync/src/data/access.ts` | `4974ab76c0ef7549fb1db11f678cb06da577f0b15f5efc686dd0cfcf96770195` |


All Core source hashes before/after each run, commands, exact counts, exit codes
and watchdog outcomes are in `storage-trace-tests.receipt.json`. Each process has
a 240-second watchdog and a separately owned process group. No unrelated process
was stopped. Node: 24.22.1. Tests import ordinary source paths and require no Git,
ignored output, generated artifacts or feature gates. Only the separate BEFORE
harness uses an archived source copy and hook outside the checkout.

## Covered proof boundaries

- Original 116 semantic cases plus 5 unconditional projection requirements.
- Actual production `ownStorage`/begin/finish on Doc.apply/emit, not returned-op inference.
- Active single winner; losing/multiple/missing/non-set/non-value/extra/raw operations;
  wrong DataId/physical target/value; replay, compact, throwing physical clone.
- Storage/model/clock/revision deltas/priors/History/undo/redo with tracing active vs inactive.
- Exact raw proxy read order against independently executed frozen BEFORE oracle.
- Unknown raw Ops after first invalidation; revoke before raw access; foreign/stale claims.
- Engine owner-bound single-use tokens; generation/extra apply/failure/raw Doc/History escapes.
- Captured receipt payload remains independent of mutated returned Op DTOs.
- Fake owner.write and direct public owner.set/update never authorize COW.
- Observers refresh fully, retain newer cache, and isolate callback errors.
- Client/local owner/access/Doc descriptor overrides preserve receiver/count/error order.
- Sync synchronous peer/ack source and remote readers retain full projections.
- Fresh restored local clients eligible; escaped original owner stays revoked.
- Optional proof decline captures model once; malformed unrelated data still fails validation.
- Optional trace fault injection must preserve accepted/rejected edit semantics (current FAIL).

## Remaining gates

Fix optional trace error isolation in production, then freeze candidate bytes,
run all 191 with no feature skips, and repeat bounded no-emit typecheck. High
review and root integration/performance gates are separate. No final GREEN yet.

## Final checkpoint

Frozen source-tree SHA-256: `ecad873e25b886ed850bba495ca3750dd8d9dded38a7a0be1fa6e8e9e4e238cc`.
The tree hash is SHA-256 of the canonical compact sorted JSON mapping of relative
Core TS paths to SHA-256 digests. The complete map and frozen hook location are
in `storage-trace-tests-candidate-identity.json`. Frozen bytes are outside the repo.

- `packages/doc-sync/test/data-point-cache.test.ts` SHA-256: `2209b8bda69d7e37f1316b16c372149041814e6e5b3a36089a61f5d98dc0cc3f`.
- `packages/doc-sync/test/private-storage-trace.test.ts` SHA-256: `1750ad5976e0ca64d28889d07867b25e3f0ae0d6b0c1bf0d09799ed66849b4ce`.

Exact final log: `storage-trace-candidate-frozen-191.log`. The receipt records
191 tests, 187 PASS, 4 FAIL, 0 SKIP, exit 1, and stable live-source checksums
during this pinned run. No green acceptance is granted. Production may continue
after this checkpoint; any new bytes require a new qualified run.

`updatedreceipt-contract.md` was not present. I read the requested implementation
prompt and the updated executable API table in `receipt-contract.md`. The
historical STOP section in that file is superseded by the widened prompt.
