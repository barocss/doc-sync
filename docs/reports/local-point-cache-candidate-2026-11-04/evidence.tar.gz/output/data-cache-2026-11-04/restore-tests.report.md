# Restored behavior coverage

## Result and boundary

PASS. This change adds behavior coverage to the qualified phase-1 code. It does not restore the rejected COW/Doc-trace feature. The root-owned full suite is NOT_RUN by this worker.

- Node 24.22.1 native source execution.
- Final focused run: 335 tests, 335 PASS, 0 FAIL, 0 CANCELLED, 0 SKIP, 0 TODO.
- Retained new contracts: 162. Existing Data/Client/History contracts: 173, across 19 existing files. Existing files were not edited. The 22-file combined focused run ran once.
- Initial retained-new-only check: 162 PASS. No source hook was needed.
- Bounded no-emit TypeScript diagnostics for the three new test roots: 0.
- All 69 production files match both the qualified post-refactor manifest and archived file bytes. All production bytes remained equal to the worker-start snapshot.
- Removed `src/internal/point-receipt.ts` remains absent.
- No private candidate helper references remain anywhere in the normal test tree.
- No feature skip, environment gate, output/Git/archive dependency, or generated-dist import exists in the retained new tests or fixture.
- No source/docs/benchmark changes, global build, dist generation, commit, push, browser/mobile test, CPU timing, or sub-agent work.

## Exact disposition

| Original candidate file | Original registrations | Retained | Removed |
| --- | ---: | ---: | ---: |
| data-point-cache.test.ts | 121 | 116 | 5 |
| private-storage-trace.test.ts | 70 | 12 | 58 |
| engine-point-receiver.test.ts | 38 | 27 | 11 |
| data-point-preload.test.ts | 16 | 7 | 9 |
| Total | 245 | 162 | 83 |

### Map/List

Renamed to `packages/doc-sync/test/data-read-contract.test.ts`. All original 116 semantic registrations remain. Removed exactly five owned-point no-full-clone acceptance cases. Removed the clone counter from the remaining raw-edit/escaped-owner case. That case still requires the accepted public value and encoded DTO. Scalar identity, immutable graphs, reference identity, History, validation, ownership, policy, observer, raw edits, and getter/error-order assertions remain.

### Engine/Doc

Renamed to `packages/doc-sync/test/engine-read-contract.test.ts`. Retained 27 engine/Doc registrations: transparent Proxy compatibility (4), frozen call/getter-order oracle (8), disposed first-error (4), restore/clearHistory behavior (1), Doc Proxy behavior (3), read-projection guard (1), accessor first-error (4), and Doc Proxy edit-guard order (2). The restore case now requires unchanged model, correct History status, accepted value, and original-client independence. It no longer requires COW or a clone budget. Public compatibility methods obtain the pointers used by the transparent Proxy test.

Removed 11 receipt/authority registrations: active/pending revocation (4), replacement ownership decline (4), forged Proxy authority (1), and foreign-replacement candidate cache/clone fallback (2). No private receipt assertion was converted to a permissive pass/fail alternative.

The private-storage suite cannot run without its rejected producer. Its 70-registration file is archived and removed from normal discovery. Salvaged 12 producer-independent contracts into engine-read-contract: raw Doc guard/original sentinel and receiver (2), raw physical value/clock/snapshot oracle (6), and exact raw Proxy observation sequence (4). The other 58 registrations remain in the rejected archive. These include active fault injection, token/receipt ownership, optional proof callbacks, optimization invalidation/projection budgets, and associated observer/escape checks. They are not claimed as supported feature coverage.

### Preload

Retained stock public values (1) and pre-client Doc.toJSON method/getter behavior (6): valid unrelated value changes, malformed projection rejection, and original sentinel identity. The fixture obtains Doc through the server before the client engine loads. It retains receiver checks, getter/call counts, exact read order, and failure/cache behavior. Removed nine originalClassSurface/Doc/History/Clock authority cases and every structuredClone budget assertion, including the stock zero-clone requirement. Each fixture invocation uses a fresh process and has no external proof dependency.

## Evidence

All paths below are relative to `output/data-cache-2026-11-04/` unless stated otherwise.

- `rollback.json`: root rollback decision. It states 69 exact post-refactor source files and a rejected first-cycle performance gate.
- `restore-tests-focused.json`: full command, all 22 file names, exit code 0, group counts, and log hash.
- `restore-tests-integrity.json`: all 69 hashes against manifest and archive bytes; source stability; rejected-copy equality against candidate archive; private-reference checks; final test hashes.
- `restore-tests-original-registration-counts.json`: exact original names and counts. A VM registration-only audit never runs the test callbacks or candidate producer.
- `restore-tests-typecheck.json`: bounded roots and zero diagnostics.
- `restore-tests-source-before.json`: worker-start source hashes.
- `rejected-data-point-cache.test.ts`, `rejected-private-storage-trace.test.ts`, `rejected-engine-point-receiver.test.ts`, `rejected-data-point-preload.test.ts`, `rejected-data-point-preload.mjs`: byte-exact copies made before edits/removal. All five match `candidate-proof-tests.tar.gz`.

### Raw logs and SHA-256

- `restore-tests-new-initial.log`: `f3422a9dd4a6a6e0d55b55a8fe1a8b306020d17884000bedf5f70aa0286a53be`
- `restore-tests-focused.log`: `79696b3ffd7ad5f6a160c45e0369484565cefa683fc5c814e369750bab1f3f0e`
- `restore-tests-typecheck.log`: `166bd4a823ca7f2e8157299385b2414df7237a26e72bcf832e9d1d52ec1085ee`

### Immutable candidate evidence and SHA-256

- `candidate-final-core.tar.gz`: `480bc202e83234c95182cd257118fc5388ce07b41cd8d70dc1fc959c2e7a772d`
- `candidate-proof-tests.tar.gz`: `36cabb6a70effca6f7d673dd2c6ad210994218c604e925b340b118fcfda4779a`
- `rollback.json`: `df69023ddc959752038676afbb4338d9aa275a8d8e745b32f660717f304605c5`
- `../refactor-2026-11-03/post-refactor-baseline-manifest.json`: `0efe5221333ee1f645f28bc0ea1b50fd742cdbe26a48daa35eb7cf2e068a7412`

The candidate source archive contains 70 source files. It is rejected evidence only. The current source has 69 files and matches the qualified baseline. Normal tests do not read these archives.

### Focused execution

`restore-tests-run.py` records and runs the exact command. It uses Node 24 with `--import ./output/refactor-2026-11-03/api-client-source-hook.mjs` only to remap existing tests' explicit dist/package imports to source. The three retained new suites import source directly. The command uses `--test-concurrency=4 --test-timeout=60000 --test-reporter=tap`. It uses no test name/skip filter or feature environment variable.

## Handoff

Root can run its full suite now. The performance candidate remains REJECTED. This worker does not make a performance, product/browser, whole-workspace, remote, or release claim.
