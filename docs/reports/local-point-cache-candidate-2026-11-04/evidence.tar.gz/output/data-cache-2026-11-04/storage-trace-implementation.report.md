---
work_id: data-cache-2026-11-04
artifact_type: storage-trace-implementation
status: qa_ready
owner_role: actual-implementation-worker
source_request: authorized runtime-private Doc storage trace, local receipt, lazy COW
last_updated: 2026-11-04
---

# Storage trace and lazy COW implementation

## Disposition

IMPLEMENTED CANDIDATE. No performance acceptance or release approval. No commit,
push, mobile checks, shared build/dist writes, timing, or subagents. Other WIP
and independent test/review artifacts are preserved.

The prior missing-API STOP is superseded. The first change was the executable
API/proof table in receipt-contract.md. Six owned existing sources and one
internal helper now provide actual application proof and a lazy COW path.

## Mechanism

- Doc has private trace/owner slots. A one-time closure bridge binds each actual
  Doc to one engine owner. Foreign/replayed claims cannot overwrite it. The
  existing run loop binds compiler operation identity. Actual apply counts
  attempts, and the successful LWW register branch captures stored DataId/key,
  physical target ticket, winning-register ticket and detached encoded value.
  Returned operations and public stamps do not grant authority.
- Non-winning, missing, multi-target, non-value, unknown/raw, extra apply,
  compact, failed clock/edit/History, generation/replacement and mismatched
  target/value actions cannot produce a receipt. There is no Doc validity flag,
  schema/admission bypass, wire/snapshot field or normalizer/compiler change.
- Engine/local/Client provenance lives in Weak registries and closure-bound
  single-use receipts. Prototype, static and instance descriptors are captured
  before external modification; checks do not invoke user getters. The pilot
  permits default-local unified Clients, fixed Data schema, no observers,
  pending batches or sessions. Sync/custom engines remain full fallback.
- Existing placements are allowed. Normal Graphic/Data insertion itself emits
  placement records, so a blanket hasMoves refusal excluded all useful Data
  clients. No pre-action projection/path-to-ticket mapping is needed: stored
  DataId binds the physical write; next-read target/spine binds the cached path.
  Any placement operation in the action invalidates the single-attempt proof.
- Raw clientOwner and engine Doc/History compatibility escape revoke before
  returning the same original object. Sessions revoke conservatively. Default
  fromState validates through a private owned restore scope, never clears past
  revocation, and refuses ownership of overridden public restore results.
- Only genuine held stock Map/List setter paths establish a private frame.
  Direct owner.set/update/write, caller-constructed handles and public method
  replacements keep the original writer semantics. Policy executes once with
  the original receiver/order; capture follows policy against the same target
  and cache. The complete Client.edit executes once with all staging/History.
- Set stores one pending delta only. No setter model read, eager validation or
  Map copies. Any data refresh/decode attempt during the action advances the
  private epoch, even if the read fails. The next normal refresh obtains model
  once, verifies receipt/stamp/schema/cache/epoch and target/spine, and creates
  new frozen entry/parent/root objects and copied index/children/key Maps,
  affected child/candidate arrays and key Map. One private bundle assignment
  publishes everything. Duplicate ID-sort order, stored list keys (including
  default absent key), -0, references/cycles and old frozen objects remain.
  Optional proof decline/error performs the full old clone/walk/validation
  using that same captured model, retaining normal read errors.

## Concrete review fixes applied by this implementation lane

R1: injected optional StoredSetTrace.attempt/written exceptions previously
interrupted original physical apply. Calls now isolate observation failures and
clear only proof state. Original guard/storage clone/clock/History exceptions
remain outside those catches. Compiler bind/reset and setter begin/finish proof
failures also decline proof without masking original edit errors.

Root receiver finding: unconditional private field access broke transparent
Proxy and unbranded read-projection receivers. Every observation path now checks
private brand AFTER the original guard, without property/proxy reads. Nonbrand
ownStorage returns null. Transparent Proxy apply/emit/compact and original
readonly guard errors match the independently executed frozen baseline.

Root structural note: capture-free pointNodeAt and samePointSpine helpers are
hoisted. Per-owner/action closures remain for actual ownership/lifetime.

## Evidence boundary

Final focused source/diagnostic results and exact hashes are appended after the
last source-stable run. Earlier live point+private suite: 191 PASS, 0 FAIL,
0 SKIP after R1 and receiver fixes. Private additional artifact checks: 9 PASS.
These do not replace independent exact-byte High review or root integration.
Raw frozen/inactive/active getter-order, snapshot and version oracle: exact
byte equality for six raw operation cases. Receiver oracle: exact byte equality
for four receiver/guard cases. No timing result or speed claim is made.

## Limits

Source-private direct storage mutation without a stamp is outside the existing
cache protocol; normal Doc.apply/compact and public compatibility escapes are
not excluded. Hostile replacement of global JS intrinsics is not protected.
Root owns full build/tests, local browser/product verification, AST/tree-shaking
integration checks and performance acceptance. Independent High approval is
pending for final bytes; do not call this release-ready.

## Final source-stable qualification

- Focused live source tests: **371 PASS / 0 FAIL / 0 SKIP**, exit 0. The exact command and eight before/after source hashes are in storage-trace-focused.receipt.json; sourceStable=true, watchdog did not fire. Twenty focused files include both independent Data point/actual trace suites, Data/Client/local-engine/History/recovery/state/snapshot coverage. This is not the full workspace suite. GC coverage is limited to focused Data admission/review coverage, not a new whole-system GC qualification.
- Additional implementation-owned private artifact checks: **9 PASS / 0 FAIL / 0 SKIP**. Restore positive COW, overridden restore negative ownership, direct writer/forged handle fallback, actual owner/token lifecycle and absent stored list key are checked. This is separate from the independent lane.
- Direct no-emit imported source diagnostic closure rooted in all seven changed sources: **0 diagnostics**. No npm lifecycle/build.
- Raw proxy/getter-order oracle: six cases frozen == current inactive == current active (whole output exact equality).
- Proxy/read-projection receiver oracle: four cases frozen == current (whole output exact equality).
- Owned existing sources pass git diff --check. All 69 frozen-manifest sources compared: 63 unchanged; only the six authorized existing sources differ. The one new helper is outside that historical manifest.
- Exact source/manifest hashes: storage-trace-implementation-identity.json. Independent exact-final-byte High review and root integration/performance remain NOT_APPROVED / NOT_RUN by this worker.

### Final production SHA-256

| Path | SHA-256 |
| --- | --- |
| `packages/doc-sync/src/crdt/doc.ts` | `46037917fc6d399eb2f80712950f10db87216e6f8b81fd0ed9e9e1fed5e1ca91` |
| `packages/doc-sync/src/engine/typescript-client.ts` | `e87d94be04bd173df8a3ca775f9b4b2543160b886f64eb58993172bde92aac9f` |
| `packages/doc-sync/src/local/client.ts` | `5b894d5769b21c3e7689f304ca313e193d6422b4471f7f95512fa8ed59b1fa72` |
| `packages/doc-sync/src/local/editor-host.ts` | `77bc65ce07223eb7e16ee8afe6c083b0a04a59b8e1b711d8f4895e704ded6ad5` |
| `packages/doc-sync/src/client/index.ts` | `2835ff9e3b36e77523f8d51e3ae259bf3fd6ad6e5e4df526aad0ab35eca959b7` |
| `packages/doc-sync/src/data/access.ts` | `887397e007952247a2de75b506fa44b5076a9233961e4d0b10d1b176cd0e1281` |
| `packages/doc-sync/src/internal/point-receipt.ts` | `b32fde966f8dc103e620f4877317e14c5d055385ee69efe85c62a30b7c9b0d98` |
