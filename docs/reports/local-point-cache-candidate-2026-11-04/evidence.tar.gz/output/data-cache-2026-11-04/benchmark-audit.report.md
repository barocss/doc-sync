# Independent benchmark audit

Audit timestamp: 2026-11-03T17:42:45.876467+00:00 (UTC; KST is UTC+09:00).

## Verdict

**APPROVE the timer/workload design only for the bounded workloads below. Final-source qualification is NOT READY.** No concrete timer or Doc-reference-oracle defect found. There is one concrete large-count qualification blocker. Existing current receipts are historical, not evidence for final R4 bytes. This audit does not approve source safety or the private receipt design.

Read-only source/artifact inspection and small hash/JSON checks only. No driver workloads, timing, build/dist, source/test/docs edits, browser/mobile, process interruption, child agents, commit or push. Only this report and `benchmark-audit.final.md` are owned outputs.

## Ranked findings and limits

### 1. P1 gate blocker: final-size clone proof cannot use current counts mode

**Evidence, high confidence.** `benchmarks/data-point-cache.mjs:27-30` permits 2,000/20,000 entries only in timing mode; every non-timing mode rejects records >200. Clone instrumentation and assertions exist only in counts mode (`:134-139`, `:195-201`). Concrete trigger: `--mode counts --records 2000 --samples 3 --warmup 1` or records 20000 rejects at line 30 before imports; timing mode emits no count proof (`:205-206`). Thus the requested same-driver, same-final-source 20 + large-fixture branch qualification cannot be satisfied by this SHA as written. The existing N=20 evidence is valid only at N=20. Resolve the large-count route and freeze its identity BEFORE timing; this auditor made no driver change. Do not infer eligibility at scale from a label or from a fast result.

### 2. P1 evidence gate: neither existing current receipt matches current source bytes

**Evidence, high confidence; not a driver bug.** The Data current closure is `001e4dcab5130fb9089ffd0d4babb50bfc7bf145edebc80ef8b9fb889297bbc2`; the Doc current closure is `a80f73deff664d32a41326e10ae1bb2f11fcf69bec1926981eaea7dec7bc7af2`. Both differ from the inspected tree in exactly these recorded files: `crdt/doc.ts`, `crdt/history.ts`, `crdt/ticket.ts`, `engine/typescript-client.ts`, `internal/point-receipt.ts`. No added TS file relative to either receipt. Their within-run stable flags remain valid historical assertions. R4 is active; this difference is expected, not a failing final source result. Final candidate all-TS closure observed when writing: `35040b44f5a5e336112d57e3627480b03469fdda67bb0c20a5ce1316f96f9f4a` (70 files; observation only, NOT a source freeze).

### 3. Coverage limit: Data cross-source internal-state equality is not exported

**Evidence, high confidence; not an observed semantic failure.** `data-point-cache.mjs:122-133,173,177-190` compares full normalized captureState/snapshot/history between public-setter and raw-edit replicas WITHIN one selected source process. `:203-222` exports PASS statuses, but no resulting checkpoint/snapshot/history hashes for before-vs-after comparison. Existing cross-lane receipts prove shared fixtures and independent expected public arrays/model, not exact cross-source captured-state equality. Do not describe that narrower comparison as full before/after wire/checkpoint equivalence. If that stronger gate is required, root needs separate outside-timer evidence before accepting source. No source-safety approval follows from either benchmark.

## Verified identity and existing receipts

Driver SHA-256 (matched existing final receipts, checked again for this report):

- Data: `16d37bde2ebeb70d72551a7bc41cf2569a7166bc324e2e6aee7534f825808be8`.
- Doc: `de905d02666989f8ec37180d85bd511c29a40b77ce768ab138645f41892b547c`.

Canonical BEFORE: `/Users/user/github/doc-sync/output/refactor-2026-11-03/post-refactor-baseline`. All **71 manifest entries match**, including exactly **69 core src entries**. Its conservative source closure is `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`. Manifest HEAD `ec9622571a04a7d7ea3f967bb3e6423b17ce5194` is metadata only; this is an uncommitted post-refactor snapshot, NOT a checkout of that commit. Neither driver uses label text as baseline identity. Baseline hashes were rechecked, not assumed from memory.

Existing Data final smoke/count receipts: N=20, warmup=1, samples=1. All three cases show setter ROOT clones 0, first-read ROOT clones before=1/current=0; raw edit fallback has 1. Common fixture SHA `fa341cab42e964d57ec370675b5747c14e67583442ec7eaddd7dfb9b7d99169e`, actor, entry split, options and final driver SHA match across lanes. Loaded file sets are contained in each recorded selected closure. These are functional/projection-count receipts, NOT timing receipts and NOT final R4 qualification.

Existing Doc final smoke receipts: 1,000 UTF16 units, warmup=2, samples=3. Seed/schema/workload/operation/model/snapshot hashes, actors, expected final counts and options match across lanes. The validation file contains **13 recorded PASS checks**. I inspected that receipt and its recorded checks; I did not rerun those 13 invocations. Median/raw consistency is recorded by the author. Source-change/outside-import fault injection remains NOT_RUN. A 1k smoke is not execution proof for 100k.

Audited author artifacts:

- `performance-driver.report.md`: `73289db5981c67be488d156174d6bc5699b6e5598366919dbce6d3b4f98d5196`.
- `performance-driver.validation.json`: `245ce6a1d2b8ba789171d8f1f3a416eb0a0ea57747489b6ce24a637b21e13f00`.
- `doc-trace-control.report.md`: `2696b68f387348d014801d2b5e9dcc19566ac38ac380228ea07b172d9ad2cf45`.
- `doc-trace-control.validation.json`: `2d707a1a14307b88f2145391ceba38a50f65c84869d1c69ac0ad8f69a45136b6`.

## Timer, path and oracle audit

### Data

- `:60-88`: total N splits across root map, nested map and list. Nonempty stored list keys are present. Fixed actor, deterministic IDs/tickets/scalars; one complete checkpoint. No N repeated public setter seed. N is TOTAL entries, not N per collection (2k -> 666/666/668; 20k -> 6666/6666/6668).
- `:89-103`: public `Client.fromState`, public root/getMap/getList and normal reads warm caches. Setters are genuine SharedMap.set / SharedList.set, not raw edit in disguise. Current wiring is `client/index.ts:217-220` -> LocalClient.fromState; `data/access.ts:315,343` -> normal public known-set frame. No owner/raw Doc acquisition in this driver.
- `:149-160`: whole setter then first point read, with setter/read/combined intervals. No forced eager point read between setter and timestamp. Setter-internal cache work stays in setter cost. Assertions occur after both intervals. Do not claim savings solely from read latency if combined cost moves elsewhere.
- `:162-173`: raw Client.edit replay is separate fallback control. It runs the identical operation sequence to match History; only up to three raw control samples are reported. With proposed samples=3, both sequences record the same sample count. Do not pool fallback and optimized timings or call fallback the optimized workload.
- `:109-133,173-194`: full independent public model/entries/IDs/order/values, full captured state (ONLY History group.at normalized), snapshots/history parity, undo/redo, frozen held entries, repeated writes without reads, refs and -0 are outside timers. Within-lane differential semantics are strong; stronger cross-source internal-state claim is limited as noted above.
- `:134-139`: counts patches only global structuredClone in a separate run, counting data-root NodeJSON. No Client/Doc/History prototype changes. This proves the counted operation, not heap allocation, total clone volume or universal COW eligibility. Timing mode leaves structuredClone stock.
- `:31,37,44-55,211-222`: pinned v24.22.1, no execArgv/NODE_OPTIONS, source-only realpath resolver, conservative all-TS hashes plus loaded set, source/driver stable at end. Timing flags 2k/20k, samples3/warmup1 are accepted. End equality is useful but is not an external immutable-source freeze.

### General Doc control

- `doc-trace-control.mjs:37-45`: timing requires exactly 100,000 UTF16 seed units and pinned stock Node24 executable; smoke bounded at 512..2000. No transform loader or build artifact is used. Source hooks only resolve/check selected TS imports (`:76-84`).
- `:87-145`: one bulk public seed edit, mixed ASCII/Hangul/emoji, independent seed snapshot oracle, eight deterministic middle ASCII replacements in one 16-edit batch. Expected final length is **100,032**, not 100,000; 8 deleted units are retained. Same-work means identical restored 100k baseline and operation batch per sample, NOT constant final length.
- `:146-173`: two fresh replicas from identical baseline per sample; full default local Doc.edit, first local toJSON, detached plain wire remote apply loop, first remote toJSON. Restore, wire JSON serialization, full snapshots/assertions/hash work stay outside intervals. Compiler-internal reads remain charged to Doc.edit. Combined local and remote costs are separately available. Remote control excludes transport/serialization by design; no network/editor/product SLA follows.
- `:106-141,161-167`: independent plain-token expected operation/clock/model/full physical snapshot, including tombstones/origins/order. Checks use expected tokens, not production replay to invent the expected result. Both local and remote must match the full expected snapshot and each other.
- **Nil-trace path, source evidence only:** driver imports direct Doc/schema, never calls ownStorage or a Client/Engine owner. Inspected `crdt/doc.ts:316-334` starts trace/owner null; only bridge port.begin creates StoredSetTrace. `:825-827,932-934,2572-2579` guard observation behind the non-null trace. Thus this direct-Doc workload takes the inactive path without prototype instrumentation. It does not measure active tracing, private point correctness, or every possible Doc workload. R4 source is changing; recheck these hooks at final freeze.
- No History/normalization listener in this general Doc control. This is explicit, not hidden suppression of work present in the public Data workload. No allocation or retained-heap evidence exists.

## Recommended acceptance plan — record BEFORE any timing

This is a proposed plan for root to adopt, not a measurement or an after-results threshold change.

1. Finish R4 and independent exact-byte High safety review. Freeze/hash accepted current source, canonical BEFORE, BOTH drivers and any separate approved large-count probe. Recheck the 71-entry manifest and 69 exact core entries. Use identical Node executable, empty NODE_OPTIONS/execArgv, fixed actors/fixtures and per-size flags. No HEAD/ec962 false baseline label.
2. On that SAME final source closure, repeat N=20 and large-fixture clone qualification for root/nested map/list and separate raw fallback. Existing driver cap must be resolved first (finding 1). Do not instrument prototypes to gain eligibility. Verify all full oracles outside intervals. Compare semantic cross-source hashes where provided; add separate stronger Data state evidence if that is an acceptance requirement.
3. Run **three independent ABBA cycles**. A=canonical BEFORE, B=frozen accepted current. For EACH size 2,000 and 20,000, run A-B-B-A in separate processes, sequentially, with identical `--samples 3 --warmup 1 --mode timing`. Never mix sizes or versions in one process. Keep each raw JSON and label cycle/position/size explicitly. No driver/source changes after observing results; changes require fresh qualification and a new complete series.
4. For each cycle/size/scenario, pool the two A process sample lists and separately the two B lists (six samples per lane with proposed flags). Compute medians from raw samples; preserve each process median, full raw values/distribution/range and forward/reverse pair direction as well. Use improvement = 1 - median(B)/median(A), regression = median(B)/median(A) - 1. Report disagreement instead of averaging it away across cycles, sizes or cases.
5. Fixed first-read trigger: warmed valid existing scalar overwrite, normal History, next public point read, for all THREE cases at BOTH sizes. Require **>=20% first-read median improvement in EVERY cycle**. Gate combined complete setter+read at **<=5% median regression in EVERY cycle/case/size**. Report setter-only values and all actual positive combined regressions. “Within 5%” means within the material-regression guardrail, NOT “no observed regression.” Also report strict-zero sensitivity separately (any positive delta fails that stricter sensitivity); do not substitute the zero rule after results. This is a workload gate, not a total latency SLA.
6. Run separate nil-trace general Doc **100k** A-B-B-A control for each of the same three cycles, separate source process each run. Suggested predeclared flags: `--samples 7 --warmup 2 --mode timing --chars 100000` on every run. Gate BOTH localEditAndReadMs and remoteApplyAndReadMs medians at **<=5% regression in EACH cycle**. Report all four component metrics and flag >5% component regressions; they are diagnostic, not quietly substituted for the declared two total-cost gates. Verify equal independent operation/model/snapshot hashes and expected final clock/counts before using times.
7. Sampling/cost decision MUST precede timings: 3 Data samples/process gives only six observations per lane/cycle, not six independent machines. Treat process/cycle variation as real; do not present a statistical confidence claim. If this is too thin, choose >=7 samples in BOTH lanes before starting. The proposed plan is 24 Data timing processes + 12 Doc timing processes (plus qualification), with potentially substantial restore/oracle CPU and memory cost. Confirm budget first; shortening later makes the gate INCONCLUSIVE, not PASS. A later larger sample plan must be explicit, not optional stopping until a target passes.
8. Preserve other CAD jobs/processes. Do not stop them for isolation. Record host/load/CPU/runtime and timing timestamps per cycle. Existing drivers capture load/resource metadata; external noise is not controlled. If host noise, directional disagreement, unstable results or near-boundary effects prevent a credible result, report **INCONCLUSIVE** with raw observations. Do not dismiss a measured regression as noise without evidence; do not claim a clean pass from a pooled favorable median. Defer or schedule a clean window without killing other work.

## Proof boundary

- Static timer/workload/oracle audit: **APPROVE, workload-limited**.
- BEFORE manifest: **PASS**, 71 entries / 69 core exact at audit.
- Existing smoke/count receipt consistency: **PASS for their recorded historical bytes**.
- Final-source smoke/count qualification, large clone proof, 100k execution, ABBA performance: **NOT_RUN / pending root**.
- R4 safety, full source correctness, package/build, browser/product, heap/allocation, remote publication/release: **NOT_APPROVED by this audit**.
