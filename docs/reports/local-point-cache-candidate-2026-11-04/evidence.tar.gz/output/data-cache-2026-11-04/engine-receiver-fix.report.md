# R3 engine receiver fix

## Disposition

IMPLEMENTED CANDIDATE. Exact-byte High review and performance acceptance remain PENDING. Root owns global integration. No release approval.

Only `packages/doc-sync/src/engine/typescript-client.ts` and NEW `packages/doc-sync/test/engine-point-receiver.test.ts` changed in this lane. The internal helper was not changed. All inherited WIP, R1/R2 fixes, Doc/Data/cache/Local/Client sources, existing tests and other writers' reports were preserved. No build/dist, mobile test, commit, push or subagent.

## Fix and proof

- The four public TS compatibility methods call the original `alive` first. Runtime-private access now uses a brand test, which causes no Proxy property access. Getters capture the original pointer once. Ordinary return identity, undefined replacement returns, original accessor errors and receiver traces are retained.
- A module-private WeakMap binds each privately owned Doc and History pointer to its actual engine point port. A raw pointer returned through an unbranded Proxy revokes that actual port before return. Its existing revoke disables lower active storage tracing; pending tokens fail the existing private check and remain single-use. No operation DTO is inspected by this lookup, and no strong owner registry or global revocation is used.
- Branded public replacements revoke their engine port. Unbranded replacements revoke the supplied pointer's associated port when available, without reading the old public pointer. The owner check also requires current Doc AND History identity to equal privately captured owned pointers. Thus foreign replacements fail closed even when their underlying receiver cannot be resolved. A no-op replacement of the same owned pointer also revokes.
- Only the existing private restore path advances these captured pointers and their weak associations. `installCheckpoint` updates the association after installing History, as well as the existing Doc replacement update. This is ownership bookkeeping, not a History algorithm change. Default `Client.fromState` remains eligible for lazy COW; no revoked flag is cleared.
- No API, capability, wire, admission, compiler, setter, complete Client.edit, or History algorithm change. No eager model read. There is no new generic trusted flag or public ownership accessor.

## Persistent regression evidence

The new self-contained 38-test suite imports normal checkout source only. Its frozen BEFORE receiver fixture is an inline copy of the four original ordinary-field method behaviors. It does not depend on Git, output archives or other tests. It covers all four Proxy calls/returns; accessor and Proxy observations; disposed alive errors first; throwing pointer accessors; actual active and issued pending owner proofs; NIL raw Op reads; same-pointer/foreign replacements; forged Proxy authority denial; default restore COW; real Client full cache fallback after foreign Doc/History replacement with immutable old state; Doc Proxy apply/emit/compact; read-projection error and original editGuard receiver/order.

A separate output-only oracle executed the actual frozen BEFORE archive and current source on the same 16 serialized compatibility/observation/disposal records. Whole output byte equality: PASS. `engine-receiver-fix.oracle.before.json` == `engine-receiver-fix.oracle.current.json`. This supplements, but is not a normal dependency of, the persistent test fixture.

## Commands and outcomes

- Node `/Users/user/.nvm/versions/node/v24.22.1/bin/node`, version 24.22.1, with `--import ./output/refactor-2026-11-03/api-client-source-hook.mjs`.
- Source-stable focused run: **409 PASS / 0 FAIL / 0 SKIP**, exit 0, 21 files. Includes new 38 plus the existing 371 Data-point-cache/private-storage-trace/Data/engine/client/local/state/History/recovery/snapshot tests. Exact argv, duration and before/after hashes: `engine-receiver-fix.receipt.json`; log: `engine-receiver-fix.focused.log`. Source stable=true.
- New suite alone: **38 PASS / 0 FAIL / 0 SKIP**; `engine-receiver-fix.new-suite.log`.
- Bounded no-emit diagnostics rooted in engine source and new regression suite (imported dependency closure only): **0 diagnostics**, exit 0. `engine-receiver-fix.typecheck.{mjs,json,log}`. No lifecycle/build.
- Owned engine diff whitespace check: PASS. No global integration or product/browser check was run.

## All observed failures

1. First new-suite run on fixed code: 25 PASS / 5 FAIL / 0 SKIP. Four disposed tests omitted the method property read performed by their own invocation helper; one projection test expected an incorrect regex rather than the original `Read projection cannot edit the document` error. These were test-expectation defects only. All five were corrected explicitly; no production error behavior was weakened. Full failure details remain in `engine-receiver-fix.initial.log`.
2. Red regression proof after finalizing the tests: reconstructed pre-fix engine source was SHA-256 verified to the exact starting `e87d94...` bytes, then substituted only by an output loader (workspace source untouched). **16 PASS / 22 FAIL / 0 SKIP**, expected exit 1. First failure: transparent Proxy `typescriptDocument` private #pointPort TypeError. Other failures cover the four calls, successful-alive observation cases, active/pending exposure, same/foreign replacements, pointer accessor errors and actual Client fallback. Every failure and stack is retained in `engine-receiver-fix.pre-tests.log`. The replay loader and exact pre-source are `engine-receiver-fix.pre-hook.mjs` and `engine-receiver-fix.pre.ts`.
3. Final focused suite, final no-emit diagnostics and actual frozen-oracle comparison have no failures. No feature skips.

## clearHistory scope

Revocation scope is **MODEL-MUTATING history undo/redo**, not literal all-history actions. `clearHistory` does not mutate the model and need not invalidate an otherwise exact pending point proof. A persistent restore test executes set -> clearHistory -> read and confirms the exact new value with zero full-model clones. Existing undo/redo full-projection regressions remain GREEN. This reports the accepted scope; it does not claim all-history revocation.

## Exact identity

Pre/post values below were captured in this lane. Unowned production sources and the optional helper remain identical. New test SHA-256: `340f8a566d5055a32998bbbfbc57a9a0181a83cd9a37a35a5cce3ca8db52f8ad`.

| Path | Pre SHA-256 | Post SHA-256 |
| --- | --- | --- |
| `packages/doc-sync/src/engine/typescript-client.ts` | `e87d94be04bd173df8a3ca775f9b4b2543160b886f64eb58993172bde92aac9f` | `30db938166a842248782a88a292509ccfd8f99b3c4e7f565eaa4f0b67ca89bb9` |
| `packages/doc-sync/src/internal/point-receipt.ts` | `b32fde966f8dc103e620f4877317e14c5d055385ee69efe85c62a30b7c9b0d98` | `b32fde966f8dc103e620f4877317e14c5d055385ee69efe85c62a30b7c9b0d98` |
| `packages/doc-sync/src/crdt/doc.ts` | `46037917fc6d399eb2f80712950f10db87216e6f8b81fd0ed9e9e1fed5e1ca91` | `46037917fc6d399eb2f80712950f10db87216e6f8b81fd0ed9e9e1fed5e1ca91` |
| `packages/doc-sync/src/data/access.ts` | `887397e007952247a2de75b506fa44b5076a9233961e4d0b10d1b176cd0e1281` | `887397e007952247a2de75b506fa44b5076a9233961e4d0b10d1b176cd0e1281` |
| `packages/doc-sync/src/local/client.ts` | `5b894d5769b21c3e7689f304ca313e193d6422b4471f7f95512fa8ed59b1fa72` | `5b894d5769b21c3e7689f304ca313e193d6422b4471f7f95512fa8ed59b1fa72` |
| `packages/doc-sync/src/local/editor-host.ts` | `77bc65ce07223eb7e16ee8afe6c083b0a04a59b8e1b711d8f4895e704ded6ad5` | `77bc65ce07223eb7e16ee8afe6c083b0a04a59b8e1b711d8f4895e704ded6ad5` |
| `packages/doc-sync/src/client/index.ts` | `2835ff9e3b36e77523f8d51e3ae259bf3fd6ad6e5e4df526aad0ab35eca959b7` | `2835ff9e3b36e77523f8d51e3ae259bf3fd6ad6e5e4df526aad0ab35eca959b7` |

## Limits / handoff

This is a source and focused functional candidate, not global integration, browser/product, performance, release, remote or publication approval. Private unstamped storage mutation and hostile replacement of global intrinsics remain outside the existing proof contract. No new performance claim is made. High review must inspect the new engine hash and private pointer/restore logic. Performance must qualify these exact bytes independently. No files outside the assigned source/test and this lane's output artifacts were edited.
