# Root review notes

Source candidate is still in progress. Check exact final bytes before applying these concerns.

- Doc originally had no ECMAScript private fields. A borrowed read projection from Object.create(doc), or an ordinary transparent Proxy around a Doc, is not a branded receiver. An unconditional this.#storedSetTrace in apply/read/emit can add a TypeError to inactive paths or displace the original readonly editGuard failure. Use a WeakMap or guarded brand check after the original guard; add exact active/inactive tests.
- The existing baseline linear benchmark fixture omits the stored key attribute on list entry atoms. Confirm whether normalization inserts key empty string; do not benchmark an ineligible malformed seed. A valid stable fixture with nonempty list keys is permitted and must be equal before/current.
- Timing must call public Map.set or List.set, not raw Client.edit (which intentionally falls back). Preserve complete setter+first read cost and setter-only cost; avoid an eager cache shift.

## Concrete receiver regression observed during in-progress write

2026-11-03T17:18 UTC approximate. Node24 --experimental-transform-types probe in proxy-receiver-probe.log: frozen before Doc new Proxy(doc,{}).apply({t:set,ids:[],key:value,value:1,at:{t:1,a:proxy-proof}}) PASS; candidate throws Cannot read private member #storedSetTrace. Recheck final bytes, then fix and add regression, or explicitly revert candidate. Normal strip-only loader also saw constructor parameter property SyntaxError while writer in progress; final source must support existing Node strip-only execution.

## Structural refactor requirement

The current DataAccess.#tryPoint `at` and `spine` helpers capture no instance/action state. Hoist those to module scope before final source qualification. Per-owner/action closures can remain if their ownership/lifetime is required. Include updated AST counts; do not assert the old zero capture-free helper count for changed source.

## R3 design option for independent review (not approval)

A possible bounded receiver-safe design: ordinary compatibility getters first retrieve their original Doc/History exactly once, then revoke by a private WeakMap keyed by that retrieved object. Thus a transparent engine Proxy still exposes the same pointer with the original public property read count, while revoking the actual owner. For public replacements, do not read an old public property just to locate a Proxy target: lower eligibility can compare the current Doc/History against privately recorded originally owned pointers (updated only during genuine private restore). A replacement with a foreign object then loses eligibility even through an unbranded receiver. Public method #field access needs a brand guard and the old ordinary-field mutation path; private restore action can keep brand-required code. Verify actual source and baseline calls/error order, and ensure raw pointer exposure invalidates already-issued pending receipts, not merely future storage begin. A global registry of strong owner references or blanket global revocation is unnecessary if this works. This is a design option, not evidence of correctness.

## R4 concrete fail-open preload override counterexample (P1)

Run Node24 output/data-cache-2026-11-04/preload-override-probe.mjs. Log: client-engine-preloaded false; before old/old; after pointset new/old; public-model-unrelated {scalar:{invalid:true}}. Public server import exports DocHub with public hub.doc. Obtain Doc.constructor from that supported Doc object. Replace Doc.prototype.toJSON BEFORE dynamic Client import; constructor's stockDoc checker then captures the MODIFIED method as stock. Initial full read is valid (flag false); after completed public root.set, flag true makes toJSON return an invalid unrelated scalar. Candidate next point read accepts COW and returns old valid value; public model contains invalid data. Frozen baseline must reject invalid encoded scalar. This is ordinary public method overriding across public package entry points, not private field mutation or hostile JS intrinsic replacement.

Fix authority by capturing original Doc instance/static surfaces in Doc's OWN defining module before it can be exposed by /server, and let the internal bridge supply a read-only stock check to engine ownership. Likewise History / Clock originals should be captured in their own defining modules or conservatively decline if not independently original; parent authorization widens minimal ORIGINAL-SURFACE capture for those defining modules, no algorithm/History behavior changes. Avoid merely capturing again in typescript-client on first Client import, or generic public validity flag. Re-run preload override valid/malformed/throw/getter cases and source+package import isolation. Actual source only e87...+460... at probe time; inspect final hashes.
