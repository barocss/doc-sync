import ts from 'typescript';
import vm from 'node:vm';
import {readFileSync,writeFileSync} from 'node:fs';
const base='output/data-cache-2026-11-04/';
const files=['rejected-data-point-cache.test.ts','rejected-private-storage-trace.test.ts','rejected-engine-point-receiver.test.ts','rejected-data-point-preload.test.ts'];
const result={};
for(const file of files){
 const text=readFileSync(base+file,'utf8').replace(/^import .*;\n/gm,'');
 const code=ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/export \{\};?\s*$/,'');
 const names=[];
 vm.runInNewContext(code.replaceAll('import.meta.url', '"file:///test.ts"'),{test(name,_body){names.push(name);}});
 result[file]={count:names.length,names};
}
writeFileSync(base+'restore-tests-original-registration-counts.json',JSON.stringify(result,null,2)+'\n');
console.log(Object.fromEntries(Object.entries(result).map(([k,v])=>[k,v.count])));
