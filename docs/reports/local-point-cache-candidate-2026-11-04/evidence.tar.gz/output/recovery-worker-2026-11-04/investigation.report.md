# 복구 테스트 조사

## 결과와 소유 범위

**PARTIAL.** bot 프로세스 그룹 정리 장치를 수정했다. MCP 원래 실패의 구체적인 원인은 아직 확인하지 못했다.

소유 범위를 확장하지 않았다. 변경한 파일은 다음 두 개다.

- `apps/bot/test/brief-runner.test.ts`
- `apps/mcp/test/automatic-recovery-process.test.ts`

제품 소스, Core69, lease/GC/undo 알고리즘은 수정하지 않았다. 다른 작업자의 변경도 보존했다. 이 작업의 758개 파일 해시 목록에서 달라진 파일은 위 두 테스트뿐이다. 이 목록은 상위 작업자의 1403개 파일 목록을 대체하지 않는다.

## 보존한 최초 실패

원본: `output/refactor-2026-11-03/restored-point-candidate-full-tests.log`

사본: 이 디렉터리의 `original-full-tests.log`. SHA-256은 `receipt.json`에 기록했다. 원본 로그는 수정하지 않았다.

- bot: 56 tests, 54 PASS, 2 FAIL, 0 SKIP. 실패 개수에는 부모 테스트와 중첩 테스트가 포함된다.
  - `authoritative finish checks reject partial text and wrong structure, and accept the complete result`
  - `killed mission resumes with its original detached brief`
  - 첫 오류: `Error: kill EPERM`, `errno: -1`, `code: 'EPERM'`, `syscall: 'kill'`. 원본 위치는 `brief-runner.test.ts:121:26`이다.
- MCP: 193 tests, 190 PASS, 1 FAIL, 2 SKIP.
  - `MCP killed during undo after-accept: exact receipt controls automatic recovery`
  - `AssertionError [ERR_ASSERTION]`: actual `recovery_required`, expected `clear`. 원본 위치는 `automatic-recovery-process.test.ts:358:20`이다.
  - 원본에는 `recovery.message`가 없다. 임시 파일도 이미 삭제되었다. 따라서 그 실행의 내부 오류는 복원할 수 없다.
- 전체 최초 명령: `npm test`, exit 1, 103.9초. 이번 작업에서는 다시 실행하지 않았다.

## bot: 확인한 문제와 변경

기존 테스트는 worker가 스스로 SIGKILL된 뒤 `exit`를 기다렸다. 이후 저장된 PID를 음수로 사용해 그룹을 SIGKILL했다. 종료한 PID만으로 현재 그룹 소유권을 증명할 수 없다. MCP는 stdin EOF를 받고 먼저 종료할 수도 있다. 이미 사라진 그룹 또는 종료 중인 그룹을 대상으로 하는 정리 방식이다.

`probes/group-lifetime.mjs`는 소유한 자식만 생성한다. 살아 있을 때 PGID를 기록하고 자식의 자기 SIGKILL을 관찰한다. 종료 후에는 signal 0으로만 존재 여부를 조회한다. 이 호스트에서는 그룹 구성원이 없어졌고 ESRCH가 나왔다. **원본 EPERM의 정확한 Darwin 커널 조건, 좀비 그룹 또는 PID 재사용은 재현하거나 입증하지 못했다.** EPERM을 무시하는 코드는 추가하지 않았다.

수정한 테스트는 같은 planner 경계에서 IPC 메시지를 보낸다. worker를 살아 있게 둔 상태에서 부모가 소유한 detached 그룹을 SIGKILL한다. 그룹에는 SDK가 detached 없이 생성한 MCP 자식이 포함된다. 이후 worker의 `code === null`, `signal === SIGKILL`을 검사한다. IPC 대기는 10초로 제한했다. 실패 경로에서는 살아 있는 직접 자식을 정리한다. 종료한 그룹을 다시 종료하지 않는다.

따라서 worker 자기 SIGKILL 주입을 부모의 그룹 SIGKILL 주입으로 바꿨다. 제품의 정상 종료 절차는 실행하지 않는다. 원래 brief 파일을 바꾸는 절차, 저장된 원본 brief, 복구 결과 verified, 동일 mission ID 및 history 1개 검사는 유지했다. 기존의 5초 writer-lock 해제 대기도 유지했다. 이 대기는 MCP 복구 상태를 clear로 만들기 위한 대기가 아니다.

`apps/bot/src/runner.ts`와 SDK stdio spawn 경로를 읽었다. provenance 리팩터는 stderr 소비 구현을 바꿨다. spawn의 detached 또는 그룹 생성 조건을 바꾸지는 않았다. 이번 증거로 provenance가 EPERM의 원인이라고 판단할 수 없다.

## MCP: 확인한 계약과 미확인 원인

현재 제품 소스의 순서는 다음과 같다.

1. `apps/mcp/src/main.ts:139-146`: `await session.start()` 후 stdio 서버를 연결한다.
2. `apps/mcp/src/session.ts:69-83`: checkpoint 복구를 기다린다. 복구 오류는 `recoveryError`에 보존하고 연결을 끊는다.
3. `session.ts:137-153`: pending change별 atomic recover를 기다린다. 이후 동기화와 pending 제거, checkpoint 저장 및 필요한 journal 정리까지 기다린다.
4. `session.ts:421-436`: `recovery_status`는 보존한 오류와 journal 상태를 보고한다.

따라서 MCP client 연결 직후의 실패를 단순한 background 복구 미완료로 취급할 근거가 없다. clear가 될 때까지 기다리는 sleep, polling 또는 강제 clear는 넣지 않았다.

진단 실행에서는 실패가 나오지 않았다. **구체적인 production root cause는 미확인이다.** generation, reservation, schema, GC 경계 또는 receipt 검사를 바꾸지 않았다.

다음 실패에서 임시 파일 삭제 전의 정보를 로그에 남기도록 assertion 진단만 보강했다. 진단에는 전체 recovery 응답과 message, 죽이기 전 checkpoint, 원래 exact receipt, 사람 편집 후 서버 상태, ordinary change/recover 요청 수, MCP stderr가 포함된다. 기대값은 여전히 즉시 `clear`다. ordinary pending 재전송 0회, atomic recover 1회, accepted serverSeq 중복 방지, 사람의 텍스트, 반대 history 동작 및 반복 restart 검사는 그대로다.

## 실행 증거

모든 테스트 실행 파일: `/Users/user/.nvm/versions/node/v24.22.1/bin/node` (`v24.22.1`). core 패키지는 기존 dist export를 사용했다. 빌드하거나 dist에 쓰지 않았다.

| 로그 | 범위 | 결과 |
| --- | --- | --- |
| `group-lifetime.log` | 단일 소유 그룹 수명 관찰, 종료 후 signal 0만 사용 | live group, SIGKILL exit, departed ESRCH |
| `mcp-diagnostic-1.log` | undo/redo × before-send/after-accept | 4 PASS, 0 FAIL, 0 SKIP |
| `mcp-diagnostic-2.log` ~ `-10.log` | undo after-accept, 실행마다 1회 | 각각 1 PASS, 0 FAIL, 0 SKIP |
| `bot-live-group-1.log` | brief-runner 파일 전체 | 11 PASS, 0 FAIL, 0 SKIP |
| `mcp-focused-file.log` | automatic-recovery-process 파일 전체 | 7 PASS, 0 FAIL, 0 SKIP |
| `final-focused.log` | 최종 변경 두 파일, file concurrency 2 | **18 PASS, 0 FAIL, 0 SKIP, 0 CANCELLED** |

진단 반복은 10회에서 끝냈다. 별도 파일 검증 2회에도 undo after-accept가 포함되므로, 해당 케이스의 전체 실행 횟수는 12회다. 이 수치는 숨기지 않는다. 추가 반복은 하지 않았다. 실패가 나올 때까지 무한 재실행하지 않았다.

최종 명령:

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node --test --test-concurrency=2 \
  apps/bot/test/brief-runner.test.ts \
  apps/mcp/test/automatic-recovery-process.test.ts
```

소유 파일의 `git diff --check`도 PASS다. 최초 MCP 전체 실행의 플랫폼 lock 2 SKIP는 기존 결과다. 이번 두 파일에는 해당 skip 테스트가 없고 새 skip도 추가하지 않았다.

## 인계와 한계

- 제품 수정: 없음. ownership expansion: 없음.
- Core69: 이 작업에서 변경하지 않음. 1403개 전체 archive 대조는 하지 않음.
- bot 수정: 살아 있는 소유 그룹을 종료하도록 정리 순서를 수정. 제한된 실제 process 테스트 PASS. 원본 EPERM의 커널 세부 원인은 미확인.
- MCP 수정: 진단만 보강. 원래 FAIL는 **미해결**이다. 현재 focused PASS를 원인 해결 또는 전체 통과로 표시하면 안 된다.
- 상위 작업자는 예정된 전체 검증에서 이 진단을 보존해야 한다. 다시 실패하면 `recovery.message`와 checkpoint/receipt/request 수를 먼저 확인해야 한다. 오류가 확인되기 전에는 제품 복구 로직을 바꾸지 않는 것이 맞다.
- 전체 workspace 테스트, 전역 build, dist 쓰기, 모바일, 브라우저, commit, push, 네트워크 및 추가 에이전트: NOT_RUN. 로컬 테스트의 loopback 통신만 사용했다.

해시와 변경 목록은 `source-before.json`, `source-after.json`, `receipt.json`에 있다. 이 작업의 패치는 `owned-tests.patch`에 있다.
