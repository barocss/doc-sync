import {spawn, spawnSync} from 'node:child_process';
import {once} from 'node:events';
const child=spawn(process.execPath,['--input-type=module','-e',`process.send('ready');process.on('message',()=>process.kill(process.pid,'SIGKILL'));`],{detached:true,stdio:['ignore','ignore','pipe','ipc']});
await once(child,'message');
const ps=()=>spawnSync('/bin/ps',['-axo','pid,ppid,pgid,uid,state,command'],{encoding:'utf8'}).stdout.split('\n').filter(l=>l.trim().split(/\s+/)[2]===String(child.pid));
console.log(JSON.stringify({phase:'live',pid:child.pid,members:ps()}));
const done=once(child,'exit');child.send('crash');console.log(JSON.stringify({phase:'exit',exit:await done,members:ps()}));
try{process.kill(-child.pid,0);console.log('signal-0 success')}catch(e){console.log(JSON.stringify({phase:'departed-group-existence-probe-only',code:e.code,errno:e.errno}));}
