// Private source-graph fixture. Each invocation starts a fresh module graph.
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
const scenario = process.argv[2];
let engineLoaded = false;
registerHooks({resolve(specifier, context, next) {
    const result = next(specifier, context);
    if (result.url.endsWith('/engine/typescript-client.ts')) engineLoaded = true;
    return result;
}});
const {DocHub} = await import('../../src/server/index.ts');
const {createDataSchema} = await import('../../src/data/schema.ts');
const hub = new DocHub({schema: createDataSchema()});
const Doc = hub.doc.constructor;
assert.equal(engineLoaded, false, 'server/schema must expose Doc before client engine loads');
let flag = false, gets = 0, calls = 0;
const sentinel = new Error('preloaded original sentinel');
const toJSON = Object.getOwnPropertyDescriptor(Doc.prototype, 'toJSON');
const isReceiver = value => value?.constructor === Doc;
function projected(...args) {
    assert.ok(isReceiver(this), 'original method receiver');
    calls++;
    if (flag && scenario.endsWith('throw')) throw sentinel;
    const model = Reflect.apply(toJSON.value, this, args);
    if (!flag || scenario === 'stock') return model;
    const scalar = scenario.endsWith('malformed') ? {invalid: true} : 'visible';
    return {...model, children: model.children.map((node, i) => i === 1 ? {...node, attrs: {...node.attrs, value: {scalar}}} : node)};
}
if (scenario.startsWith('doc-')) {
    // Accessor descriptors cannot also contain value/writable.
    if (scenario.startsWith('doc-getter-')) Object.defineProperty(Doc.prototype, 'toJSON', {
        configurable: toJSON.configurable, enumerable: toJSON.enumerable,
        get() {gets++; assert.ok(isReceiver(this), 'getter receiver'); return projected;},
    });
    else Object.defineProperty(Doc.prototype, 'toJSON', {...toJSON, value: projected});
}
if (scenario.startsWith('authority-')) {
    const historyModule = await import('../../src/crdt/history.ts');
    const clockModule = await import('../../src/crdt/ticket.ts');
    const docModule = await import('../../src/crdt/doc.ts');
    const history = scenario.includes('history'), doc = scenario.includes('doc');
    const type = doc ? Doc : history ? historyModule.History : hub.doc.clock.constructor;
    const authority = doc ? docModule.originalDocSurface : history ? historyModule.originalHistorySurface : clockModule.originalClockSurface;
    const value = doc ? new type('preload-doc', createDataSchema()) : history ? new type() : new type('preload-clock');
    const key = doc ? 'toJSON' : history ? 'pin' : 'observe';
    const descriptor = Object.getOwnPropertyDescriptor(type.prototype, key);
    assert.equal(engineLoaded, false);
    assert.equal(authority(value), true);
    const accessor = scenario.endsWith('getter'), statics = scenario.endsWith('static');
    let getterCalls = 0, methodCalls = 0;
    function replacement(...args) {
        assert.equal(this, value); methodCalls++;
        return Reflect.apply(descriptor.value, this, args);
    }
    if (statics) Object.defineProperty(type, 'preloadProbe', {configurable: true, get() {getterCalls++; throw sentinel;}});
    else if (accessor) Object.defineProperty(type.prototype, key, {
        configurable: descriptor.configurable, enumerable: descriptor.enumerable,
        get() {assert.equal(this, value); getterCalls++; return replacement;},
    });
    else Object.defineProperty(type.prototype, key, {...descriptor, value: replacement});
    const {enginePoints, originalClassSurface} = await import('../../src/internal/point-receipt.ts');
    const {typescriptClientEngineFactory} = await import('../../src/engine/typescript-client.ts');
    const engine = typescriptClientEngineFactory.create('preload-authority', createDataSchema());
    try {
        assert.equal(authority(value), false);
        assert.equal(enginePoints(engine).check(), false, 'late engine must reject the replaced original surface');
        // Taking another local snapshot cannot replace/reclaim the defining authority.
        originalClassSurface(type);
        assert.equal(authority(value), false);
        assert.equal(getterCalls, 0, 'descriptor proof must not invoke an override getter');
        assert.equal(methodCalls, 0, 'descriptor proof must not call a public method');
        if (!statics) {
            if (doc) assert.equal(value.toJSON().type, 'data');
            else if (history) assert.equal(value.pin(() => undefined), null);
            else {value.observe({lamport: 9, actor: 'remote'}); assert.equal(value.lamport, 9);}
            assert.equal(methodCalls, 1); assert.equal(getterCalls, accessor ? 1 : 0);
        }
    } finally {engine.dispose();}
    console.log(JSON.stringify({scenario, pass: true}));
    process.exit(0);
}
const {Client, clientOwner} = await import('../../src/client/index.ts');
const id = n => `data:00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const seed = [1, 2].map((n, i) => ({type: 'entry', attrs: {id: id(n), key: i ? 'unrelated' : 'target', value: {scalar: 'old'}}}));
function seeded() {
    const client = new Client({actor: 'preload', schema: createDataSchema()});
    client.edit([{op: 'insert', at: [0], content: seed}], null);
    return client;
}
const source = seeded();
const state = source.captureState(); source.dispose();
const candidate = Client.fromState(state, {schema: createDataSchema()});
const legacy = Client.fromState(state, {schema: createDataSchema()});
clientOwner(legacy); // Supported compatibility escape forces the full-refresh oracle.
const clone = globalThis.structuredClone;
let roots = 0;
globalThis.structuredClone = (value, options) => {
    if (value?.type === 'data' && Array.isArray(value.children)) roots++;
    return clone(value, options);
};
try {
    for (const client of [candidate, legacy]) {
        flag = false;
        const root = client.data.root;
        assert.equal(root.get('target'), 'old'); assert.equal(root.get('unrelated'), 'old');
        root.set('target', 'new');
        flag = true; calls = 0; gets = 0; roots = 0;
        if (scenario.endsWith('throw')) {
            assert.throws(() => root.get('target'), error => error === sentinel);
            assert.equal(calls, 1); assert.equal(roots, 0);
            assert.equal(gets, scenario.startsWith('doc-getter-') ? 1 : 0);
            assert.throws(() => root.get('unrelated'), error => error === sentinel);
            assert.equal(calls, 2, 'failed projection must not publish partial cache');
        } else if (scenario.endsWith('malformed')) {
            assert.throws(() => root.get('target'), {message: 'Data: invalid encoded scalar'});
            assert.equal(roots, 1); assert.equal(calls, 1);
            assert.equal(gets, scenario.startsWith('doc-getter-') ? 1 : 0);
            assert.throws(() => root.get('unrelated'), {message: 'Data: invalid encoded scalar'});
            assert.equal(calls, 1, 'engine model read must not be doubled');
            assert.equal(roots, 2, 'failed validation must not publish partial cache');
        } else {
            assert.equal(root.get('target'), 'new');
            assert.equal(root.get('unrelated'), scenario === 'stock' ? 'old' : 'visible');
            assert.equal(roots, scenario === 'stock' && client === candidate ? 0 : 1);
            assert.equal(calls, scenario === 'stock' ? 0 : 1);
            assert.equal(gets, scenario.startsWith('doc-getter-') ? 1 : 0);
        }
    }
} finally {
    globalThis.structuredClone = clone;
    candidate.dispose(); legacy.dispose();
    Object.defineProperty(Doc.prototype, 'toJSON', toJSON);
}
console.log(JSON.stringify({scenario, pass: true}));
