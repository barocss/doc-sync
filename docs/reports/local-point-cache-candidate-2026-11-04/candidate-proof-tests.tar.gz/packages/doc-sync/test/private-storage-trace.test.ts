import assert from "node:assert/strict";
import {test} from "node:test";
import {Client, clientOwner} from "../src/client/index.ts";
import {Doc} from "../src/crdt/doc.ts";
import {LocalClient} from "../src/local/client.ts";
import type {Op} from "../src/crdt/doc.ts";
import type {NodeJSON} from "../src/crdt/model.ts";
import {createDataSchema} from "../src/data/index.ts";
import {DocHub} from "../src/server/hub.ts";
import {ownStorage, StoredSetTrace, enginePoints} from "../src/internal/point-receipt.ts";
import {History} from "../src/crdt/history.ts";
import {typescriptClientEngineFactory} from "../src/engine/typescript-client.ts";
import type {TypeScriptClientCompatibility} from "../src/engine/client-contract.ts";

// Checkout-local tests. No Git, ignored output, generated dist or feature gate.
const id = (n: number) => `data:00000000-0000-4000-8000-${n.toString(16).padStart(12, "0")}`;
const entry = (n: number, key: string, value: unknown): NodeJSON => ({type: "entry", attrs: {id: id(n), key, value: {scalar: value}}});
const seed = (): NodeJSON[] => [entry(90, "key", "winner"), entry(1, "other", 1), entry(5, "key", "loser"),
    {type: "list", attrs: {id: id(100)}, children: [entry(101, "stored-first", 1), entry(102, "stored-second", 2)]}];
function fixture(control = false) {
    const client = new Client({actor: "trace-test", schema: createDataSchema()});
    if (control) clientOwner(client);
    client.edit([{op: "insert", at: [0], content: seed()}], null);
    const root = client.data.root, list = client.data.getList(id(100))!;
    root.get("key"); list.at(0);
    return {client, root, list};
}
function clones() {
    const original = globalThis.structuredClone; let roots = 0;
    globalThis.structuredClone = function<T>(v: T, options?: StructuredSerializeOptions): T {
        if (v && typeof v === "object" && (v as unknown as NodeJSON).type === "data" && Array.isArray((v as unknown as NodeJSON).children)) roots++;
        return original(v, options);
    };
    return {get roots() {return roots;}, reset() {roots = 0;}, restore() {globalThis.structuredClone = original;}};
}
function docFixture() {
    const doc = new Doc("trace-test", createDataSchema());
    doc.edit([{op: "insert", at: [0], content: seed()}]);
    const result = doc.edit([{op: "update", at: [0], attrs: {value: {scalar: "current"}}}]);
    const op = result.ops[0]; assert.equal(op.t, "set");
    return {doc, op};
}

test("trace generic owner.write cannot manufacture authority from a set-shaped action", () => {
    const f = fixture(), counter = clones();
    try {
        f.root.owner.write({collection: "$root", kind: "map", operation: "set", key: "key", value: "forged"},
            [{op: "update", at: [0], attrs: {value: {scalar: "forged"}}}]);
        assert.equal(counter.roots, 0, "generic write remains lazy");
        assert.equal(f.root.get("key"), "forged"); assert.equal(counter.roots, 1);
    } finally {counter.restore(); f.client.dispose();}
});

for (const action of ["raw", "insert", "delete", "move", "undo", "redo"] as const) test(`trace full projection required after ${action}`, () => {
    const f = fixture();
    try {
        if (action === "undo" || action === "redo") {f.root.set("key", "next"); f.root.get("key");}
        if (action === "redo") {f.client.undo(); f.root.get("key");}
        const counter = clones();
        try {
            if (action === "raw") f.client.edit([{op: "update", at: [0], attrs: {value: {scalar: "raw"}}}]);
            else if (action === "insert") f.client.edit([{op: "insert", at: [1], content: [entry(3, "new", 3)]}]);
            else if (action === "delete") f.root.delete("other");
            else if (action === "move") f.list.move(id(101), 1);
            else f.client[action]();
            counter.reset(); f.root.get("key"); assert.equal(counter.roots, 1);
            counter.reset(); f.root.get("key"); assert.equal(counter.roots, 0);
        } finally {counter.restore();}
    } finally {f.client.dispose();}
});

for (const phase of ["modelEvents", "update"] as const) test(`trace observer ${phase} read keeps its cache and no subsequent full refresh`, () => {
    const f = fixture(); let held: ReturnType<typeof f.root.candidates> | undefined;
    try {
        f.client.subscribe({[phase]() {assert.equal(f.root.get("key"), "accepted"); held = f.root.candidates("key"); throw new Error("observer failure");}});
        const counter = clones();
        try {
            assert.doesNotThrow(() => f.root.set("key", "accepted"));
            assert.ok(held); assert.equal(counter.roots, 1, "observer reads must take full projection");
            counter.reset(); assert.equal(f.root.candidates("key"), held); assert.equal(counter.roots, 0);
            assert.equal(f.client.notificationErrors.at(-1)!.message, "observer failure");
        } finally {counter.restore();}
    } finally {f.client.dispose();}
});

test("trace a non-reading observer disables the first pilot without changing semantics", () => {
    const f = fixture(); let updates = 0;
    try {
        f.client.subscribe({update() {updates++;}}); const counter = clones();
        try {
            f.root.set("key", "accepted"); assert.equal(updates, 1); assert.equal(counter.roots, 0);
            assert.equal(f.root.get("key"), "accepted"); assert.equal(counter.roots, 1);
        } finally {counter.restore();}
    } finally {f.client.dispose();}
});

for (const method of ["apply", "edit", "commit", "model", "stamp"] as const) test(`trace escaped local owner ${method} preserves getter receiver and call count`, () => {
    const f = fixture(), owner = clientOwner(f.client); assert.ok(owner instanceof LocalClient);
    const base = owner[method]; let reads = 0, calls = 0;
    try {
        Object.defineProperty(owner, method, {configurable: true, get() {
            reads++; assert.equal(this, owner);
            return function(this: typeof owner, ...args: unknown[]) {calls++; assert.equal(this, owner); return Reflect.apply(base, this, args);};
        }});
        f.root.set("key", "accepted"); assert.equal(method === "model" ? calls : 0, 0);
        assert.equal(f.root.get("key"), "accepted");
        assert.equal(reads, calls); assert.ok(calls >= 1);
        if (method !== "stamp") assert.equal(calls, 1);
    } finally {Reflect.deleteProperty(owner, method); f.client.dispose();}
});

for (const throws of [false, true]) test(`trace raw Doc guard preserves receiver, order and failure throws=${throws}`, () => {
    const {doc, op} = docFixture(), before = doc.snapshot(), sentinel = new Error("guard"), seen: string[] = [];
    const proxy = new Proxy({...op, at: {actor: "remote", lamport: 100}, value: {scalar: "remote"}}, {get(target, key, receiver) {seen.push(String(key)); return Reflect.get(target, key, receiver);}});
    doc.editGuard = function() {assert.equal(this, doc); seen.push("guard"); if (throws) throw sentinel;};
    if (throws) {assert.throws(() => doc.apply(proxy), error => error === sentinel); assert.deepEqual(seen, ["guard"]); assert.deepEqual(doc.snapshot(), before);}
    else {doc.apply(proxy); assert.equal(seen[0], "guard"); assert.deepEqual(doc.toJSON().children![0].attrs!.value, {scalar: "remote"});}
});

for (const action of ["winning", "losing", "multi-id", "missing-id", "non-value", "replay"] as const) test(`trace raw physical ${action} storage and clock are authoritative`, () => {
    const {doc, op} = docFixture(), plain = Doc.fromSnapshot("trace-test", doc.snapshot(), createDataSchema());
    const second = doc.edit([{op: "update", at: [1], attrs: {value: {scalar: 2}}}]).ops[0]; assert.equal(second.t, "set");
    plain.apply(second);
    const at = {actor: "remote", lamport: 100};
    let operation: Op = {...op, at, value: {scalar: "new"}};
    if (action === "losing") operation = {...operation, at: {actor: "remote", lamport: 0}};
    if (action === "multi-id") operation = {...operation, ids: [...op.ids, ...second.ids]};
    if (action === "missing-id") operation = {...operation, ids: [{actor: "absent", lamport: 999}]};
    if (action === "non-value") operation = {...operation, key: "key", value: "changed"};
    const version = doc.version, plainVersion = plain.version;
    doc.apply(operation); plain.apply(structuredClone(operation));
    if (action === "replay") {doc.apply(operation); plain.apply(structuredClone(operation));}
    assert.deepEqual(doc.snapshot(), plain.snapshot()); assert.deepEqual(doc.toJSON(), plain.toJSON());
    assert.equal(doc.clock.lamport, plain.clock.lamport); assert.equal(doc.version - version, plain.version - plainVersion);
    if (action === "losing" || action === "missing-id") assert.deepEqual(doc.toJSON().children![0].attrs!.value, {scalar: "current"});
    else if (action === "non-value") assert.equal(doc.toJSON().children![0].attrs!.key, "changed");
    else assert.deepEqual(doc.toJSON().children![0].attrs!.value, {scalar: "new"});
    if (action === "multi-id") assert.deepEqual(doc.toJSON().children![1].attrs!.value, {scalar: "new"});
});

test("trace synchronous send peer and acknowledgement retain full sync projections", async () => {
    const hub = new DocHub({schema: createDataSchema()}), clients: Client[] = [];
    const peer = (actor: string) => {
        const client = new Client({actor, schema: createDataSchema(), transport: {
            subscribe(since, receive, epoch) {receive(hub.hello(since, epoch)); return hub.listen(receive);},
            async send(message) {if (message.kind === "change") hub.submit(message.change); else hub.ack(message.ack);}, sendPresence() {},
        }}); clients.push(client); client.connect(); return client;
    };
    const drain = async () => {for (let i = 0; i < 40; i++) await Promise.resolve();};
    const a = peer("trace-A"), b = peer("trace-B");
    try {
        a.edit([{op: "insert", at: [0], content: seed()}], null); await drain();
        assert.equal(a.data.root.get("key"), "winner"); assert.equal(b.data.root.get("key"), "winner");
        const counter = clones();
        try {
            a.data.root.set("key", "synced"); await drain(); counter.reset();
            assert.equal(a.data.root.get("key"), "synced"); assert.equal(b.data.root.get("key"), "synced"); assert.equal(counter.roots, 2);
            assert.deepEqual(a.model(), b.model()); assert.deepEqual(a.historyStatus().canUndo, true);
        } finally {counter.restore();}
    } finally {for (const client of clients) client.clearHistory(); await drain(); for (const client of clients) {client.disconnect(); client.dispose();}}
});

// Exact inactive raw-DTO observation order captured from the frozen post-refactor
// Doc.apply. This oracle does not instrument engine or replace Doc methods.
for (const action of ["winning", "losing", "multi-id", "missing-id"] as const) test(`trace inactive raw proxy observation order ${action}`, () => {
    const {doc, op} = docFixture();
    const second = doc.edit([{op: "update", at: [1], attrs: {value: {scalar: 2}}}]).ops[0]; assert.equal(second.t, "set");
    const raw = {...op, at: {actor: "remote", lamport: action === "losing" ? 0 : 100}, value: {scalar: 5}};
    if (action === "multi-id") raw.ids = [...op.ids, ...second.ids];
    if (action === "missing-id") raw.ids = [{actor: "absent", lamport: 999}];
    const seen: string[] = [];
    doc.apply(new Proxy(raw, {
        get(target, key, receiver) {seen.push(`get:${String(key)}`); return Reflect.get(target, key, receiver);},
        ownKeys(target) {seen.push("ownKeys"); return Reflect.ownKeys(target);},
        getOwnPropertyDescriptor(target, key) {seen.push(`descriptor:${String(key)}`); return Reflect.getOwnPropertyDescriptor(target, key);},
    }));
    const winning = ["get:key", "get:at", "get:key", "get:value", "get:at"];
    assert.deepEqual(seen, ["get:t", "get:ids", ...(action === "missing-id" ? [] : action === "losing" ? ["get:key", "get:at"] : action === "multi-id" ? [...winning, ...winning] : winning), "get:at"]);
});

for (const action of ["winning", "losing", "multi-id", "missing-id", "non-value", "non-set", "extra", "wrong-data-id", "wrong-physical-ticket", "wrong-value", "replay", "raw-apply"] as const) test(`trace actual private apply/emit receipt ${action}`, () => {
    const {doc, op} = docFixture(), control = Doc.fromSnapshot("trace-test", doc.snapshot(), createDataSchema());
    const second = doc.edit([{op: "update", at: [1], attrs: {value: {scalar: 2}}}]).ops[0]; assert.equal(second.t, "set"); control.apply(structuredClone(second));
    const port = ownStorage(doc, {}); assert.ok(port);
    const trace = port.begin({id: action === "wrong-data-id" ? id(1) : id(90), value: {scalar: "new"}}); assert.ok(trace);
    let operation: Op = {...op, at: {actor: "trace-test", lamport: 100}, value: {scalar: action === "wrong-value" ? "wrong" : "new"}};
    if (action === "losing") operation = {...operation, at: {actor: "remote", lamport: 0}};
    if (action === "multi-id") operation = {...operation, ids: [...op.ids, ...second.ids]};
    if (action === "missing-id") operation = {...operation, ids: [{actor: "absent", lamport: 999}]};
    if (action === "wrong-physical-ticket") operation = {...operation, ids: second.ids};
    if (action === "non-value") operation = {...operation, key: "key", value: "changed"};
    if (action === "non-set") operation = {t: "del", at: operation.at, ids: op.ids};
    const controlOperation = structuredClone(operation);
    if (action === "replay") {doc.emit([operation]); control.emit([controlOperation]);}
    const version = doc.version, controlVersion = control.version;
    const actual = action === "raw-apply" ? doc.apply(operation) : doc.emit([operation]);
    const expected = action === "raw-apply" ? control.apply(controlOperation) : control.emit([controlOperation]);
    assert.deepEqual(actual, expected);
    if (action === "extra") {doc.emit([{...second, at: {actor: "trace-test", lamport: 101}}]); control.emit([{...second, at: {actor: "trace-test", lamport: 101}}]);}
    const receipt = port.finish(trace);
    if (action === "winning") {
        assert.ok(receipt); assert.equal(receipt.id, id(90)); assert.equal(receipt.key, "key");
        assert.deepEqual(receipt.target, op.ids[0]); assert.deepEqual(receipt.at, operation.at); assert.deepEqual(receipt.value, {scalar: "new"});
        assert.ok(Object.isFrozen(receipt)); assert.ok(Object.isFrozen(receipt.value)); assert.ok(Object.isFrozen(receipt.target)); assert.ok(Object.isFrozen(receipt.at));
    } else assert.equal(receipt, null);
    assert.equal(port.finish(trace), null, "a completed trace cannot be replayed");
    assert.deepEqual(doc.snapshot(), control.snapshot()); assert.deepEqual(doc.toJSON(), control.toJSON());
    assert.equal(doc.clock.lamport, control.clock.lamport); assert.equal(doc.version - version, control.version - controlVersion);
    assert.deepEqual(doc.priorOf(operation), control.priorOf(controlOperation));
    // Undo/redo must use the same physical priors with observation active or off.
    const history = new History(), controlHistory = new History();
    const now = Date.now;
    try {
        Date.now = () => 1;
        history.record([operation], doc, {caretBefore: "", caretAfter: "", typing: false});
        controlHistory.record([controlOperation], control, {caretBefore: "", caretAfter: "", typing: false});
    } finally {Date.now = now;}
    assert.deepEqual(history.snapshot(), controlHistory.snapshot());
    assert.deepEqual(history.undo(doc), controlHistory.undo(control)); assert.deepEqual(doc.snapshot(), control.snapshot());
    assert.deepEqual(history.redo(doc), controlHistory.redo(control)); assert.deepEqual(doc.snapshot(), control.snapshot());
});

test("trace foreign claim and stale finish cannot replace or cancel the current owner", () => {
    const {doc, op} = docFixture(), owner = {}, port = ownStorage(doc, owner); assert.ok(port);
    assert.equal(ownStorage(doc, {}), null); assert.equal(ownStorage(doc, owner), null, "registration is one-time, not a reset");
    const first = port.begin({id: id(90), value: {scalar: "one"}}); assert.ok(first);
    doc.emit([{...op, at: {actor: "trace-test", lamport: 100}, value: {scalar: "one"}}]); assert.ok(port.finish(first));
    const second = port.begin({id: id(90), value: {scalar: "two"}}); assert.ok(second);
    assert.equal(port.finish(first), null);
    doc.emit([{...op, at: {actor: "trace-test", lamport: 101}, value: {scalar: "two"}}]); assert.ok(port.finish(second));
    port.revoke(); assert.equal(port.begin({id: id(90), value: {scalar: "three"}}), null); assert.equal(ownStorage(doc, {}), null);
});

test("trace revoke cancels an active trace before an unknown raw proxy is applied", () => {
    const {doc, op} = docFixture(), port = ownStorage(doc, {}); assert.ok(port);
    const trace = port.begin({id: id(90), value: {scalar: "new"}}); assert.ok(trace); port.revoke();
    const seen: string[] = [], raw = {...op, at: {actor: "remote", lamport: 100}, value: {scalar: "new"}};
    doc.apply(new Proxy(raw, {get(target, key, receiver) {seen.push(String(key)); return Reflect.get(target, key, receiver);}}));
    assert.deepEqual(seen, ["t", "ids", "key", "at", "key", "value", "at", "at"]);
    assert.equal(port.finish(trace), null); assert.deepEqual(doc.toJSON().children![0].attrs!.value, {scalar: "new"});
});

for (const callback of ["attempt", "written"] as const) test(`trace optional ${callback} proof error cannot change accepted storage semantics`, () => {
    const {doc, op} = docFixture(), control = Doc.fromSnapshot("trace-test", doc.snapshot(), createDataSchema());
    const port = ownStorage(doc, {}); assert.ok(port); const trace = port.begin({id: id(90), value: {scalar: "new"}}); assert.ok(trace);
    const original = Object.getOwnPropertyDescriptor(StoredSetTrace.prototype, callback)!, sentinel = new Error("optional trace proof");
    const operation = {...op, at: {actor: "trace-test", lamport: 100}, value: {scalar: "new"}};
    try {
        Object.defineProperty(StoredSetTrace.prototype, callback, {...original, value() {throw sentinel;}});
        assert.doesNotThrow(() => doc.emit([operation])); control.emit([structuredClone(operation)]);
        assert.equal(port.finish(trace), null); assert.deepEqual(doc.snapshot(), control.snapshot()); assert.deepEqual(doc.toJSON(), control.toJSON());
    } finally {Object.defineProperty(StoredSetTrace.prototype, callback, original); port.revoke();}
});

for (const revoked of [false, true]) test(`[projection] trace fresh restore eligible without resetting existing escaped owner revoked=${revoked}`, () => {
    const f = fixture(revoked); let restored: Client | undefined;
    try {
        restored = Client.fromState(f.client.captureState(), {schema: createDataSchema()}); const root = restored.data.root;
        assert.equal(root.get("key"), "winner"); const counter = clones();
        try {
            root.set("key", "restored"); assert.equal(counter.roots, 0); assert.equal(root.get("key"), "restored"); assert.equal(counter.roots, 0);
            counter.reset(); f.root.set("key", "original"); counter.reset(); assert.equal(f.root.get("key"), "original"); assert.equal(counter.roots, revoked ? 1 : 0);
        } finally {counter.restore();}
    } finally {restored?.dispose(); f.client.dispose();}
});

function engineFixture() {
    const engine = typescriptClientEngineFactory.create("engine-trace", createDataSchema());
    engine.setEditHooks({guard: null, listener: null}); engine.apply([{op: "insert", at: [0], content: seed()}]);
    const port = enginePoints(engine); assert.ok(port); assert.equal(port.check(), true);
    return {engine, port};
}

test("trace actual engine token is owner-bound, single-use and independent of returned operation DTOs", () => {
    const a = engineFixture(), b = engineFixture();
    try {
        const action = a.port.begin({id: id(90), value: {scalar: "accepted"}}); assert.ok(action);
        const ops = a.engine.apply([{op: "update", at: [0], attrs: {value: {scalar: "accepted"}}}]);
        assert.equal(ops[0].t, "set"); (ops[0].value as {scalar: string}).scalar = "mutated DTO"; ops.length = 0;
        const token = action.finish(true); assert.ok(token); assert.ok(Object.isFrozen(token)); assert.deepEqual(Reflect.ownKeys(token), []);
        assert.equal(b.port.consume(token), null); assert.equal(a.port.consume({}), null);
        const set = a.port.consume(token); assert.ok(set); assert.deepEqual(set.value, {scalar: "accepted"}); assert.equal(set.id, id(90));
        assert.equal(a.port.consume(token), null); assert.equal(action.finish(true), null);
        assert.deepEqual(a.engine.model().children![0].attrs!.value, {scalar: "accepted"});
    } finally {a.engine.dispose(); b.engine.dispose();}
});

for (const action of ["failed-completion", "extra-apply", "generation", "escape-doc", "escape-history"] as const) test(`trace actual engine receipt declines ${action}`, () => {
    const {engine, port} = engineFixture();
    try {
        const checkpoint = engine.checkpoint(), before = engine.stamp();
        const active = port.begin({id: id(90), value: {scalar: "accepted"}}); assert.ok(active);
        engine.apply([{op: "update", at: [0], attrs: {value: {scalar: "accepted"}}}]);
        if (action === "extra-apply") engine.apply([{op: "update", at: [1], attrs: {value: {scalar: 8}}}]);
        if (action === "generation") engine.installCheckpoint(engine.prepareCheckpoint(checkpoint));
        const compatibility = engine as typeof engine & TypeScriptClientCompatibility;
        if (action === "escape-doc") {
            const doc = compatibility.typescriptDocument(); assert.equal(port.check(), false);
            assert.equal(compatibility.typescriptDocument(), doc);
        }
        if (action === "escape-history") {const history = compatibility.typescriptHistory(); assert.equal(port.check(), false); assert.equal(compatibility.typescriptHistory(), history);}
        assert.equal(active.finish(action !== "failed-completion"), null);
        assert.equal(active.finish(true), null);
        if (action === "generation") assert.notEqual(engine.stamp().generation, before.generation);
        else assert.deepEqual(engine.model().children![0].attrs!.value, {scalar: "accepted"});
    } finally {engine.dispose();}
});

test("trace actual storage compact cancels proof even with no tombstone removed", () => {
    const {doc, op} = docFixture(), port = ownStorage(doc, {}); assert.ok(port);
    const trace = port.begin({id: id(90), value: {scalar: "new"}}); assert.ok(trace);
    doc.emit([{...op, at: {actor: "trace-test", lamport: 100}, value: {scalar: "new"}}]);
    assert.equal(doc.compact(0, () => undefined), 0); assert.equal(port.finish(trace), null);
    assert.deepEqual(doc.toJSON().children![0].attrs!.value, {scalar: "new"});
});

test("trace rejected physical value keeps original exception and partial storage semantics", () => {
    const {doc, op} = docFixture(), control = Doc.fromSnapshot("trace-test", doc.snapshot(), createDataSchema()), port = ownStorage(doc, {}); assert.ok(port);
    const trace = port.begin({id: id(90), value: {scalar: "new"}}); assert.ok(trace);
    const sentinel = new Error("physical copy failure"), bad = {get scalar() {throw sentinel;}};
    const operation = {...op, at: {actor: "trace-test", lamport: 100}, value: bad};
    const version = doc.version, controlVersion = control.version;
    assert.throws(() => doc.emit([operation]), error => error === sentinel);
    assert.throws(() => control.emit([{...operation}]), error => error === sentinel);
    assert.equal(port.finish(trace), null); assert.deepEqual(doc.snapshot(), control.snapshot()); assert.deepEqual(doc.toJSON(), control.toJSON());
    assert.equal(doc.version - version, control.version - controlVersion);
});

for (const when of ["first-raw", "after-winning", "after-invalid"] as const) test(`trace invalidation adds no unknown raw proxy reads ${when}`, () => {
    const {doc, op} = docFixture(), port = ownStorage(doc, {}); assert.ok(port);
    const trace = port.begin({id: id(90), value: {scalar: "one"}}); assert.ok(trace);
    if (when !== "first-raw") doc.emit([{...op, at: {actor: "trace-test", lamport: 100}, value: {scalar: "one"}}]);
    if (when === "after-invalid") doc.apply({...op, at: {actor: "remote", lamport: 101}, value: {scalar: "two"}});
    const seen: string[] = [], raw = {...op, at: {actor: "remote", lamport: 102}, value: {scalar: "raw"}};
    doc.apply(new Proxy(raw, {get(target, key, receiver) {seen.push(String(key)); return Reflect.get(target, key, receiver);}, ownKeys(target) {seen.push("ownKeys"); return Reflect.ownKeys(target);}}));
    assert.deepEqual(seen, ["t", "ids", "key", "at", "key", "value", "at", "at"]);
    assert.equal(port.finish(trace), null); assert.deepEqual(doc.toJSON().children![0].attrs!.value, {scalar: "raw"});
});

for (const method of ["apply", "emit", "edit", "toJSON"] as const) test(`trace Doc prototype ${method} override keeps legacy receiver, counts and full projection`, () => {
    const a = fixture(), b = fixture(true), descriptor = Object.getOwnPropertyDescriptor(Doc.prototype, method)!;
    const traces: string[][] = [[], []]; let lane = 0;
    try {
        Object.defineProperty(Doc.prototype, method, {configurable: descriptor.configurable, enumerable: descriptor.enumerable, get() {
            assert.ok(this instanceof Doc); traces[lane].push(`get:${method}`);
            return function(this: Doc, ...args: unknown[]) {assert.ok(this instanceof Doc); traces[lane].push(`call:${method}`); return Reflect.apply(descriptor.value, this, args);};
        }});
        const counter = clones();
        try {
            a.root.set("key", "accepted"); counter.reset(); assert.equal(a.root.get("key"), "accepted"); assert.equal(counter.roots, 1);
            lane = 1; b.root.set("key", "accepted"); counter.reset(); assert.equal(b.root.get("key"), "accepted"); assert.equal(counter.roots, 1);
            assert.deepEqual(traces[0], traces[1]); assert.ok(traces[0].includes(`call:${method}`));
        } finally {counter.restore();}
    } finally {Object.defineProperty(Doc.prototype, method, descriptor); a.client.dispose(); b.client.dispose();}
});

for (const direct of ["set", "update"] as const) test(`trace direct public owner.${direct} lacks the private setter frame`, () => {
    const f = fixture(), counter = clones();
    try {
        if (direct === "set") f.root.owner.set(f.root, "key", "direct"); else f.list.owner.update(f.list, id(101), "direct");
        assert.equal(counter.roots, 0);
        assert.equal(direct === "set" ? f.root.get("key") : f.list.get(id(101)), "direct"); assert.equal(counter.roots, 1);
    } finally {counter.restore(); f.client.dispose();}
});

for (const method of ["set", "write", "check"] as const) test(`trace public access ${method} getter preserves failure order and no receipt`, () => {
    const f = fixture(), sentinel = new Error(`access:${method}`), owner = f.root.owner; let reads = 0;
    try {
        Object.defineProperty(owner, method, {configurable: true, get() {assert.equal(this, owner); reads++; throw sentinel;}});
        assert.throws(() => f.root.set("key", "rejected"), error => error === sentinel); assert.equal(reads, 1);
        assert.equal(f.root.get("key"), "winner");
    } finally {Reflect.deleteProperty(owner, method); f.client.dispose();}
});

for (const corrupt of [false, true]) test(`trace pending optional proof decline uses exactly one model capture corrupt=${corrupt}`, () => {
    const f = fixture(), original = f.client.model; let calls = 0;
    try {
        f.root.set("key", "accepted");
        Object.defineProperty(f.client, "model", {configurable: true, value() {
            calls++; assert.equal(this, f.client); const value = original.call(this);
            if (!corrupt) return value;
            const bad = structuredClone(value); bad.children![1].attrs!.value = {scalar: {invalid: true}}; return bad;
        }});
        const counter = clones();
        try {
            if (corrupt) assert.throws(() => f.root.get("key"), /invalid encoded scalar/);
            else {assert.equal(f.root.get("key"), "accepted"); assert.equal(counter.roots, 1);}
            assert.equal(calls, 1, "proof decline must not recapture model");
            if (!corrupt) {assert.equal(f.root.get("key"), "accepted"); assert.equal(calls, 1);}
        } finally {counter.restore();}
        Reflect.deleteProperty(f.client, "model"); assert.equal(f.root.get("key"), "accepted");
    } finally {Reflect.deleteProperty(f.client, "model"); f.client.dispose();}
});

for (const callback of ["attempt", "written"] as const) test(`trace optional ${callback} error keeps public setter lazy and forces full validation`, () => {
    const f = fixture(), original = Object.getOwnPropertyDescriptor(StoredSetTrace.prototype, callback)!, counter = clones();
    try {
        Object.defineProperty(StoredSetTrace.prototype, callback, {...original, value() {throw new Error("optional helper error");}});
        assert.doesNotThrow(() => f.root.set("key", "accepted")); assert.equal(counter.roots, 0);
        assert.equal(f.root.get("key"), "accepted"); assert.equal(counter.roots, 1);
        assert.equal(f.client.historyStatus().canUndo, true); f.client.undo(); assert.equal(f.root.get("key"), "winner");
    } finally {Object.defineProperty(StoredSetTrace.prototype, callback, original); counter.restore(); f.client.dispose();}
});
