import assert from "node:assert/strict";
import {test} from "node:test";
import {Client} from "../src/client/index.ts";
import {Doc} from "../src/crdt/doc.ts";
import {History} from "../src/crdt/history.ts";
import type {NodeJSON} from "../src/crdt/model.ts";
import type {TypeScriptClientCompatibility} from "../src/engine/client-contract.ts";
import {typescriptClientEngineFactory} from "../src/engine/typescript-client.ts";
import {enginePoints, ownStorage} from "../src/internal/point-receipt.ts";
import {createDataSchema} from "../src/data/index.ts";

const id = "data:00000000-0000-4000-8000-000000000001";
const seed = (): NodeJSON[] => [{type: "entry", attrs: {id, key: "key", value: {scalar: "old"}}}];
function fixture() {
    const engine = typescriptClientEngineFactory.create("receiver", createDataSchema()) as ReturnType<typeof typescriptClientEngineFactory.create> & TypeScriptClientCompatibility;
    engine.setEditHooks({guard: null, listener: null});
    engine.apply([{op: "insert", at: [0], content: seed()}]);
    const port = enginePoints(engine)!; assert.ok(port); assert.equal(port.check(), true);
    return {engine, port};
}
const methods = ["typescriptDocument", "typescriptHistory", "replaceTypeScriptDocument", "replaceTypeScriptHistory"] as const;
type Method = typeof methods[number];
// Self-contained frozen BEFORE behavior: ordinary TS-private fields, no runtime
// private brands. Tests do not load Git, ignored output, or generated dist.
function before(method: Method, receiver: object, arg: Doc | History): unknown {
    const self = receiver as {alive(): void; doc: Doc; history: History; generation: number; guardWrapper: null; attach(): void};
    self.alive();
    if (method === "typescriptDocument") return self.doc;
    if (method === "typescriptHistory") return self.history;
    if (method === "replaceTypeScriptHistory") {self.history = arg as History; return;}
    self.doc = arg as Doc; self.generation = 1; self.guardWrapper = null; self.attach();
}
function invoke(engine: ReturnType<typeof fixture>["engine"], method: Method, arg: Doc | History): unknown {
    if (method === "replaceTypeScriptDocument") return engine[method](arg as Doc);
    if (method === "replaceTypeScriptHistory") return engine[method](arg as History);
    return engine[method]();
}

for (const method of methods) test(`engine receiver transparent Proxy compatibility ${method}`, () => {
    const {engine} = fixture(), proxy = new Proxy(engine, {});
    // Ordinary field capture is test-only; it does not call a revoking getter.
    const raw = engine as unknown as {doc: Doc; history: History};
    const pointer = method.endsWith("Document") ? raw.doc : raw.history;
    try {
        const result = invoke(proxy, method, pointer);
        assert.equal(result, method.startsWith("replace") ? undefined : pointer);
        assert.equal(invoke(engine, method, pointer), result);
        assert.deepEqual(engine.model().children, seed());
    } finally {engine.dispose();}
});

for (const method of methods) for (const throws of [false, true]) test(`engine receiver frozen observation oracle ${method} throws=${throws}`, () => {
    const {engine} = fixture(), doc = new Doc("foreign", createDataSchema()), history = new History();
    const arg = method.endsWith("Document") ? doc : history;
    const observed = (run: (proxy: typeof engine) => unknown) => {
        const seen: string[] = [], sentinel = new Error("first alive failure");
        let proxy: typeof engine;
        const target = {
            alive() {assert.equal(this, proxy); seen.push("alive"); if (throws) throw sentinel;},
            get doc() {assert.equal(this, proxy); seen.push("doc"); return doc;},
            set doc(value: Doc) {assert.equal(this, proxy); assert.equal(value, arg); seen.push("doc=");},
            get history() {assert.equal(this, proxy); seen.push("history"); return history;},
            set history(value: History) {assert.equal(this, proxy); assert.equal(value, arg); seen.push("history=");},
            set generation(_value: number) {seen.push("generation=");},
            set guardWrapper(_value: null) {seen.push("guardWrapper=");},
            attach() {assert.equal(this, proxy); seen.push("attach");},
        };
        proxy = new Proxy(target, {
            get(t, k, r) {seen.push(`get:${String(k)}`); return Reflect.get(t, k, r);},
            set(t, k, v, r) {seen.push(`set:${String(k)}`); return Reflect.set(t, k, v, r);},
        }) as unknown as typeof engine;
        let result: unknown;
        if (throws) assert.throws(() => run(proxy), error => error === sentinel);
        else result = run(proxy);
        return {seen, result};
    };
    try {
        const actual = observed(proxy => Reflect.apply(engine[method], proxy, [arg]));
        const expected = observed(proxy => before(method, proxy, arg));
        assert.deepEqual(actual, expected);
        if (throws) assert.deepEqual(actual.seen, ["get:alive", "alive"]);
    } finally {engine.dispose();}
});

for (const method of methods) test(`engine receiver disposed alive error is first ${method}`, () => {
    const {engine} = fixture(); engine.dispose();
    const seen: string[] = [], proxy = new Proxy(engine, {get(t, k, r) {seen.push(String(k)); return Reflect.get(t, k, r);}});
    assert.throws(() => invoke(proxy, method, new History()), {name: "Error", message: "Engine is disposed"});
    assert.deepEqual(seen, [method, "alive", "disposed"]);
});

for (const method of ["typescriptDocument", "typescriptHistory"] as const) for (const pending of [false, true]) test(`engine receiver ${method} revokes actual ${pending ? "pending" : "active"} proof before return`, () => {
    const {engine, port} = fixture(), proxy = new Proxy(engine, {});
    try {
        const action = port.begin({id, value: {scalar: "new"}}); assert.ok(action);
        const ops = engine.apply([{op: "update", at: [0], attrs: {value: {scalar: "new"}}}]);
        const token = pending ? action.finish(true) : null; if (pending) assert.ok(token);
        const pointer = proxy[method](); assert.ok(pointer); assert.equal(port.check(), false);
        if (pending) {assert.equal(port.consume(token!), null); assert.equal(port.consume(token!), null);}
        else assert.equal(action.finish(true), null);
        // Raw exposure must leave the lower physical observer in NIL mode.
        const doc = (engine as unknown as {doc: Doc}).doc, seen: string[] = [];
        assert.equal(ops[0].t, "set");
        const op = {...ops[0], at: {actor: "remote", lamport: 100}, value: {scalar: "raw"}};
        doc.apply(new Proxy(op, {get(t, k, r) {seen.push(String(k)); return Reflect.get(t, k, r);}}));
        assert.deepEqual(seen, ["t", "ids", "key", "at", "key", "value", "at", "at"]);
        assert.deepEqual(doc.toJSON().children![0].attrs!.value, {scalar: "raw"});
        assert.equal(port.begin({id, value: {scalar: "later"}}), null);
    } finally {engine.dispose();}
});

for (const method of ["replaceTypeScriptDocument", "replaceTypeScriptHistory"] as const) for (const same of [false, true]) test(`engine receiver public ${method} declines ownership same=${same}`, () => {
    const {engine, port} = fixture(), proxy = new Proxy(engine, {});
    const raw = engine as unknown as {doc: Doc; history: History};
    const oldDoc = raw.doc, oldHistory = raw.history, snapshot = oldDoc.snapshot(), historySnapshot = oldHistory.snapshot();
    const arg = method.endsWith("Document") ? same ? oldDoc : new Doc("foreign", createDataSchema()) : same ? oldHistory : new History();
    try {
        const action = port.begin({id, value: {scalar: "new"}}); assert.ok(action);
        engine.apply([{op: "update", at: [0], attrs: {value: {scalar: "new"}}}]);
        const token = action.finish(true); assert.ok(token);
        const beforeReplace = oldDoc.snapshot();
        assert.equal(invoke(proxy, method, arg), undefined);
        assert.equal(port.check(), false); assert.equal(port.consume(token), null);
        assert.equal(port.begin({id, value: {scalar: "new"}}), null);
        assert.deepEqual(oldDoc.snapshot(), beforeReplace, "replacement never mutates old model");
        assert.deepEqual(oldHistory.snapshot(), historySnapshot);
        if (!same && method.endsWith("Document")) assert.deepEqual(engine.model().children, []);
        assert.notDeepEqual(beforeReplace, snapshot);
    } finally {engine.dispose();}
});

test("engine receiver forged Proxy has no receipt or storage authority", () => {
    const {engine, port} = fixture(), proxy = new Proxy(engine, {getPrototypeOf() {return Object.getPrototypeOf(engine);}});
    try {
        assert.equal(enginePoints(proxy), undefined);
        const doc = (engine as unknown as {doc: Doc}).doc;
        assert.equal(ownStorage(new Proxy(doc, {}), {}), null);
        assert.equal(ownStorage(doc, {}), null);
        assert.equal(port.consume({}), null);
        assert.equal(port.check(), true);
    } finally {engine.dispose();}
});

test("engine receiver default Client.fromState retains lazy COW and clearHistory does not change the model", () => {
    const client = new Client({actor: "restore", schema: createDataSchema()});
    client.edit([{op: "insert", at: [0], content: seed()}], null);
    const restored = Client.fromState(client.captureState(), {schema: createDataSchema()});
    const root = restored.data.root; assert.equal(root.get("key"), "old");
    const clone = globalThis.structuredClone; let modelClones = 0;
    globalThis.structuredClone = function<T>(value: T, options?: StructuredSerializeOptions): T {
        if (value && typeof value === "object" && (value as unknown as NodeJSON).type === "data") modelClones++;
        return clone(value, options);
    };
    try {
        root.set("key", "new"); assert.equal(modelClones, 0);
        restored.clearHistory(); assert.equal(root.get("key"), "new"); assert.equal(modelClones, 0);
    } finally {globalThis.structuredClone = clone; restored.dispose(); client.dispose();}
});

for (const method of ["apply", "emit", "compact"] as const) test(`engine receiver Doc transparent Proxy ${method} preserves ordinary behavior`, () => {
    const doc = new Doc("doc-receiver", createDataSchema()), proxy = new Proxy(doc, {});
    const op = {t: "set" as const, ids: [], key: "value", value: 1, at: {lamport: 1, actor: "doc-receiver"}};
    if (method === "compact") assert.equal(proxy.compact(0, () => undefined), 0);
    else if (method === "emit") proxy.emit([op]);
    else proxy.apply(op);
    assert.deepEqual(doc.toJSON().children, []);
});

test("engine receiver Doc read projection retains its original guard error", () => {
    const doc = new Doc("projection", createDataSchema());
    assert.throws(() => doc.withReadProjection(read => read.apply({t: "set", ids: [], key: "value", value: 1, at: {lamport: 1, actor: "projection"}})), {name: "Error", message: "Read projection cannot edit the document"});
});

for (const method of methods) test(`engine receiver original accessor failure order ${method}`, () => {
    const {engine} = fixture(), sentinel = new Error("pointer access"), seen: string[] = [];
    const key = method.endsWith("Document") ? "doc" : "history";
    const target = {alive() {seen.push("alive");}};
    Object.defineProperty(target, key, {get() {seen.push("get:pointer"); throw sentinel;}, set() {seen.push("set:pointer"); throw sentinel;}});
    const proxy = new Proxy(target, {get(t, k, r) {seen.push(`get:${String(k)}`); return Reflect.get(t, k, r);}, set(t, k, v, r) {seen.push(`set:${String(k)}`); return Reflect.set(t, k, v, r);}});
    try {
        assert.throws(() => Reflect.apply(engine[method], proxy, [new History()]), error => error === sentinel);
        const mode = method.startsWith("replace") ? "set" : "get";
        assert.deepEqual(seen, ["get:alive", "alive", `${mode}:${key}`, `${mode}:pointer`]);
    } finally {engine.dispose();}
});

for (const throws of [false, true]) test(`engine receiver Doc Proxy original edit guard first throws=${throws}`, () => {
    const doc = new Doc("guard", createDataSchema()), proxy = new Proxy(doc, {}), seen: string[] = [], sentinel = new Error("guard failure");
    doc.editGuard = function() {assert.equal(this, proxy); seen.push("guard"); if (throws) throw sentinel;};
    const op = new Proxy({t: "set" as const, ids: [], key: "value", value: 1, at: {lamport: 1, actor: "guard"}}, {get(t, k, r) {seen.push(String(k)); return Reflect.get(t, k, r);}});
    if (throws) {assert.throws(() => proxy.apply(op), error => error === sentinel); assert.deepEqual(seen, ["guard"]);}
    else {proxy.apply(op); assert.deepEqual(seen, ["guard", "t", "ids", "at"]);}
});

for (const method of ["replaceTypeScriptDocument", "replaceTypeScriptHistory"] as const) test(`engine receiver foreign ${method} forces actual Client cache fallback`, () => {
    const client = new Client({actor: "cache-receiver", schema: createDataSchema()});
    client.edit([{op: "insert", at: [0], content: seed()}], null);
    const root = client.data.root; assert.equal(root.get("key"), "old");
    // Test-only reachability, without the public compatibility escape that would
    // itself revoke and hide the replacement bug.
    const engine = (client as unknown as {host: {client: {engine: ReturnType<typeof fixture>["engine"]}}}).host.client.engine;
    const port = enginePoints(engine)!; assert.equal(port.check(), true);
    const old = root.candidates("key"), oldCopy = structuredClone(old);
    root.set("key", "new");
    const raw = engine as unknown as {doc: Doc; history: History};
    const oldDoc = raw.doc, oldHistory = raw.history, snapshot = oldDoc.snapshot(), history = oldHistory.snapshot();
    const arg = method.endsWith("Document") ? Doc.fromSnapshot(client.actor, snapshot, engine.schema()) : new History();
    invoke(new Proxy(engine, {}), method, arg);
    const clone = globalThis.structuredClone; let modelClones = 0;
    globalThis.structuredClone = function<T>(value: T, options?: StructuredSerializeOptions): T {
        if (value && typeof value === "object" && (value as unknown as NodeJSON).type === "data") modelClones++;
        return clone(value, options);
    };
    try {
        assert.equal(port.check(), false); assert.equal(root.get("key"), "new"); assert.equal(modelClones, 1);
        assert.deepEqual(old, oldCopy); assert.deepEqual(oldDoc.snapshot(), snapshot); assert.deepEqual(oldHistory.snapshot(), history);
        root.set("key", "later"); modelClones = 0; assert.equal(root.get("key"), "later"); assert.equal(modelClones, 1);
        if (method.endsWith("Document")) assert.deepEqual(oldDoc.snapshot(), snapshot);
    } finally {globalThis.structuredClone = clone; client.dispose();}
});
