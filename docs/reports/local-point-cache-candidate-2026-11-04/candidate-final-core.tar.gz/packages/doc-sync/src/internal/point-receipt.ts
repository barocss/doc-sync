// Internal runtime ownership only. Not exported by any package barrel.
import type {Doc, Item, Op} from "../crdt/doc.ts";
import type {History} from "../crdt/history.ts";
import type {Ticket} from "../crdt/ticket.ts";
export type PointValue = {readonly scalar: null | boolean | number | string} | {readonly reference: string; readonly kind: "map" | "list"};
export type PointIntent = {readonly id: string; readonly value: PointValue};
export type PhysicalSet = {readonly id: string; readonly key: string; readonly target: Ticket; readonly at: Ticket; readonly value: PointValue};
export function samePointValue(a: unknown, b: PointValue): boolean {
    if (!a || typeof a !== "object" || Array.isArray(a)) return false;
    const value = a as Record<string, unknown>, keys = Object.keys(value);
    return "scalar" in b ? keys.length === 1 && Object.hasOwn(value, "scalar") && Object.is(value.scalar, b.scalar)
        : keys.length === 2 && Object.hasOwn(value, "reference") && Object.hasOwn(value, "kind") && value.reference === b.reference && value.kind === b.kind;
}
export const detachPointValue = (value: PointValue): PointValue => Object.freeze("scalar" in value ? {scalar: value.scalar} : {reference: value.reference, kind: value.kind});

/** No operation DTO is inspected until run has bound its compiler-owned identity. */
export class StoredSetTrace {
    invalid = false;
    attempts = 0;
    compiler: Op | null = null;
    result: PhysicalSet | null = null;
    readonly intent: PointIntent;
    constructor(intent: PointIntent) { this.intent = intent; }
    attempt(op: Op): void { if (this.invalid) return; if (++this.attempts !== 1 || this.compiler !== op) this.invalid = true; }
    written(item: Item, key: string, op: Op): void {
        if (this.invalid) return;
        if (op.t !== "set" || op.ids.length !== 1 || key !== "value" || this.result || item.kind !== "node" || item.born !== "entry" || item.attrs.get("$type")?.value !== "entry" || item.attrs.get("id")?.value !== this.intent.id) { this.invalid = true; return; }
        const register = item.attrs.get(key)!;
        if (register.at !== op.at || !samePointValue(register.value, this.intent.value) || item.attrs.has("key") && typeof item.attrs.get("key")!.value !== "string") { this.invalid = true; return; }
        this.result = Object.freeze({id: this.intent.id, key: (item.attrs.get("key")?.value ?? "") as string,
            target: Object.freeze({...item.id}), at: Object.freeze({...register.at}), value: detachPointValue(this.intent.value)});
    }
}
export interface StoragePort {begin(intent: PointIntent): StoredSetTrace | null; finish(trace: StoredSetTrace): PhysicalSet | null; revoke(): void}
let claimStorage: ((doc: Doc, owner: object) => StoragePort | null) | undefined;
export function installStorageBridge(bridge: NonNullable<typeof claimStorage>): void { if (claimStorage) throw new Error("Storage bridge already installed"); claimStorage = bridge; }
export function ownStorage(doc: Doc, owner: object): StoragePort | null {
    if (!doc || typeof doc !== "object") return null;
    return claimStorage?.(doc, owner) ?? null;
}

const getOwnDescriptors = Object.getOwnPropertyDescriptors, ownDescriptorKeys = Reflect.ownKeys;

/** Capture original descriptors, never invoke a getter to test eligibility. */
export function stockPrototype(prototype: object): (value: object) => boolean {
    const descriptors = getOwnDescriptors(prototype), keys = ownDescriptorKeys(descriptors), parent = Object.getPrototypeOf(prototype);
    return value => {
        if (Object.getPrototypeOf(value) !== prototype || Object.getPrototypeOf(prototype) !== parent) return false;
        const current = getOwnDescriptors(prototype);
        if (ownDescriptorKeys(current).length !== keys.length) return false;
        for (const key of keys) {
            const a = Reflect.get(descriptors, key) as PropertyDescriptor, b = Reflect.get(current, key) as PropertyDescriptor | undefined;
            if (!b || a.value !== b.value || a.get !== b.get || a.set !== b.set || a.writable !== b.writable || a.configurable !== b.configurable || a.enumerable !== b.enumerable || key !== "constructor" && Object.hasOwn(value, key)) return false;
        }
        return true;
    };
}
export function stockSurface(value: object): () => boolean {
    const before = getOwnDescriptors(value), parent = Object.getPrototypeOf(value), keys = ownDescriptorKeys(before);
    return () => {
        if (Object.getPrototypeOf(value) !== parent) return false;
        const after = getOwnDescriptors(value);
        return ownDescriptorKeys(after).length === keys.length && keys.every(key => {
            const a = Reflect.get(before, key) as PropertyDescriptor, b = Reflect.get(after, key) as PropertyDescriptor | undefined;
            return !!b && a.value === b.value && a.get === b.get && a.set === b.set && a.writable === b.writable && a.configurable === b.configurable && a.enumerable === b.enumerable;
        });
    };
}
/** Call only in the class's defining module, before any entry point exposes it.
 * No registry or setter can replace this closure's original descriptor proof. */
export function originalClassSurface(type: {prototype: object}): (value: object) => boolean {
    const sameClass = stockSurface(type), samePrototype = stockPrototype(type.prototype);
    return value => sameClass() && samePrototype(value);
}
export function ownValue(value: object, key: string, expected: unknown): boolean {
    const d = Object.getOwnPropertyDescriptor(value, key); return !!d && "value" in d && d.value === expected;
}
export interface PointAction {finish(success: boolean): object | null}
export interface PointOwner {check(): boolean; begin(intent: PointIntent): PointAction | null; consume(receipt: object): PhysicalSet | null; revoke(): void}
export interface EnginePointOwner extends PointOwner {restore(run: () => void, read: (doc: Doc, history: History) => void): boolean}
const engines = /* @__PURE__ */ new WeakMap<object, EnginePointOwner>();
const locals = /* @__PURE__ */ new WeakMap<object, PointOwner>();
const clients = /* @__PURE__ */ new WeakMap<object, PointOwner>();
function register<T>(map: WeakMap<object, T>, owner: object, port: T): void { if (!map.has(owner)) map.set(owner, port); }
export const registerEnginePoints = (owner: object, port: EnginePointOwner): void => register(engines, owner, port);
export const enginePoints = (owner: object): EnginePointOwner | undefined => engines.get(owner);
export const registerLocalPoints = (owner: object, port: PointOwner): void => register(locals, owner, port);
export const localPoints = (owner: object): PointOwner | undefined => locals.get(owner);
export const registerClientPoints = (owner: object, port: PointOwner): void => register(clients, owner, port);
export const clientPoints = (owner: object): PointOwner | undefined => clients.get(owner);

/** Bind lower single-use receipts to the current upper owner and descriptor proof. */
export function pointOwner(lower: PointOwner, valid: () => boolean): PointOwner {
    let revoked = false, active = false;
    const receipts = new WeakMap<object, object>();
    const check = () => !revoked && valid() && lower.check();
    return {
        check,
        begin(intent) {
            if (active || !check()) return null;
            const action = lower.begin(intent); if (!action) return null;
            active = true; let used = false;
            return {finish(success) {
                if (used) return null; used = true; active = false;
                const receipt = action.finish(success && check());
                if (!receipt) return null;
                const token = Object.freeze({}); receipts.set(token, receipt); return token;
            }};
        },
        consume(token) { const receipt = receipts.get(token); receipts.delete(token); return receipt && check() ? lower.consume(receipt) : null; },
        revoke() { revoked = true; lower.revoke(); },
    };
}
