import {clientPoints, stockSurface, stockPrototype, detachPointValue, samePointValue} from "../internal/point-receipt.ts";
import type {PointOwner, PointValue} from "../internal/point-receipt.ts";
import type {Snapshot} from "../crdt/doc.ts";
import type {Client} from "../client/index.ts";
import {schemaVersion} from "../crdt/schema-version.ts";
import {createDataSchema} from "./schema.ts";
import type {EditOp, NodeJSON} from "../crdt/model.ts";

export type DataId = string;
export type DataScalar = null | boolean | number | string;
export type DataValue = DataScalar | SharedMap | SharedList;
export interface DataWrite {readonly collection: DataId; readonly kind: "map" | "list"; readonly operation: "set" | "insert" | "delete" | "move"; readonly key?: string; readonly id?: DataId; readonly index?: number; readonly value?: DataValue}
/** Application policy for local writes only. Remote admission needs server policy. */
export type DataValidator = (write: Readonly<DataWrite>) => void;
/** Collection access for one Client. Client owns editing, history and persistence. */
export interface SharedData {
    readonly root: SharedMap;
    createMap(): SharedMap;
    createList(): SharedList;
    getMap(id: DataId): SharedMap | undefined;
    getList(id: DataId): SharedList | undefined;
}
type Encoded = {scalar: DataScalar} | {reference: DataId; kind: "map" | "list"};
type Indexed = {id: DataId; node: NodeJSON; path: number[]};
const ROOT = "$root";
const recordKinds: readonly string[] = Object.freeze(["map", "list", "entry"]);
type DataIndexes = {
    index: Map<DataId, Indexed>;
    children: Map<DataId, Indexed[]>;
    keys: Map<DataId, Map<string, Indexed[]>>;
};
type CacheBundle = DataIndexes & {version: string};
type PendingPoint = {cache: CacheBundle; epoch: number; owner: PointOwner; token: object; entry: Indexed; parent: Indexed; value: PointValue; version: string};
let knownSet: (owner: DataAccess, handle: SharedMap | SharedList, run: () => void) => void;
const validId = (id: unknown): id is DataId => typeof id === "string" && /^data:[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id);
const fail = (message: string): never => {throw new Error(`Data: ${message}`);};
function freeze<T>(value: T): T {
    if (value && typeof value === "object" && !Object.isFrozen(value)) { Object.values(value).forEach(freeze); Object.freeze(value); }
    return value;
}

function deeplyFrozen(value: unknown): boolean {
    return !value || typeof value !== "object" ||
        Object.isFrozen(value) && Object.values(value).every(deeplyFrozen);
}

function pointNodeAt(node: NodeJSON, path: readonly number[]): NodeJSON | undefined {
    let found: NodeJSON | undefined = node;
    for (const n of path) found = found?.children?.[n];
    return found;
}
function samePointSpine(actual: NodeJSON | undefined, old: NodeJSON): boolean {
    return !!actual && actual.type === old.type && !actual.runs && Object.keys(actual).every(k => k === "type" || k === "attrs" || k === "children")
        && Object.keys(actual.attrs ?? {}).length === Object.keys(old.attrs ?? {}).length && Object.keys(old.attrs ?? {}).every(k => Object.is(actual.attrs?.[k], old.attrs?.[k]))
        && Array.isArray(actual.children) && actual.children.length === (old.children?.length ?? 0);
}
function visitRecord(node: NodeJSON, path: number[], indexes: DataIndexes, parent?: DataId): void {
    const {index, children, keys} = indexes;
    const id = path.length ? node.attrs?.id : ROOT;
    if (path.length ? !validId(id) : id !== ROOT) fail("invalid storage ID");
    if (index.has(id as string)) fail("duplicate storage ID");
    const item = freeze({id: id as string, node, path}); index.set(item.id, item);
    if (parent !== undefined && node.type === "entry") {
        const list = children.get(parent) ?? []; list.push(item); children.set(parent, list);
        const keyMap = keys.get(parent) ?? new Map<string, Indexed[]>(), key = node.attrs!.key as string;
        const candidates = keyMap.get(key) ?? []; candidates.push(item); keyMap.set(key, candidates); keys.set(parent, keyMap);
    }
    node.children?.forEach((child, at) => visitRecord(child, [...path, at], indexes, item.id));
}

function retainedRecordKinds(snapshot: Snapshot): Map<string, string> {
    const kinds = new Map<string, string>();
    for (const line of snapshot.lines) for (const item of line.items) {
        if (item.z || item.k !== "n" || !recordKinds.includes(item.b ?? "")) continue;
        const storedId = item.a?.find(([key]) => key === "id")?.[1];
        if (!validId(storedId)) fail("invalid storage ID");
        if (kinds.has(storedId as string)) fail("duplicate storage ID");
        kinds.set(storedId as string, item.b!);
    }
    return kinds;
}

/** Map/List facade. All edits, history and transport use the existing Client. */
class DataAccess implements SharedData {
    readonly #client: Client;
    readonly root: SharedMap;
    readonly #validate: DataValidator;
    readonly #assertMutable: () => void;
    #cache: CacheBundle = {index: new Map(), children: new Map(), keys: new Map(), version: ""};
    #pending?: PendingPoint;
    #epoch = 0;
    #inAction = false;
    #frame: SharedMap | SharedList | null = null;
    static {
        knownSet = (owner, handle, run) => {
            if (!stockAccess(owner) || !stockMapClass() || !stockListClass() || !(stockMap(handle) || stockList(handle)) || owner.#handles.get(handle.id) !== handle || owner.#frame || owner.#inAction) { run(); return; }
            owner.#frame = handle;
            try { run(); } finally { owner.#frame = null; }
        };
    }
    #handles = new Map<DataId, SharedMap | SharedList>();
    constructor(client: Client, validate: DataValidator, assertMutable: () => void) {
        this.#client = client;
        this.#validate = validate;
        this.#assertMutable = assertMutable;
        this.root = new SharedMap(this, ROOT);
        this.#handles.set(ROOT, this.root);
    }
    createMap(): SharedMap { return this.create("map") as SharedMap; }
    createList(): SharedList { return this.create("list") as SharedList; }
    getMap(id: DataId): SharedMap | undefined { const item = this.lookup(id); return item?.node.type === "map" || id === ROOT ? this.handle(id, "map") as SharedMap : undefined; }
    getList(id: DataId): SharedList | undefined { return this.lookup(id)?.node.type === "list" ? this.handle(id, "list") as SharedList : undefined; }
    mutable() { this.#assertMutable(); assertDataSchema(this.#client); }
    private refresh() {
        if (this.#inAction) this.#epoch++;
        assertDataSchema(this.#client);
        const stamp = this.#client.stamp(), version = `${stamp.generation}:${stamp.revision}`;
        if (this.#cache.version === version) return;
        const pending = this.#pending; this.#pending = undefined;
        const model = this.#client.model();
        if (pending) {
            try { if (this.#tryPoint(pending, model, version)) return; }
            catch { /* Optional proof failure uses this same model and the old validator. */ }
        }
        const index = new Map<DataId, Indexed>(), children = new Map<DataId, Indexed[]>(), keys = new Map<DataId, Map<string, Indexed[]>>();
        visitRecord(structuredClone(model), [], {index, children, keys});
        let retainedKinds: Map<string, string> | undefined;
        for (const item of index.values()) if (item.node.type === "entry") {
            if (typeof item.node.attrs!.key !== "string") fail("invalid encoded map key");
            const value = item.node.attrs!.value;
            if (!value || typeof value !== "object" || Array.isArray(value)) fail("invalid encoded value");
            const encoded = value as Record<string, unknown>, fields = Object.keys(encoded);
            if (fields.length === 1 && Object.hasOwn(encoded, "scalar")) {
                const scalar = encoded.scalar;
                if (scalar !== null && typeof scalar !== "boolean" && typeof scalar !== "string" && !(typeof scalar === "number" && Number.isFinite(scalar))) fail("invalid encoded scalar");
            } else if (fields.length === 2 && Object.hasOwn(encoded, "reference") && Object.hasOwn(encoded, "kind")) {
                const target = index.get(encoded.reference as string), kind = encoded.kind;
                let targetKind = encoded.reference === ROOT ? "map" : target?.node.type;
                if (targetKind === undefined) {
                    retainedKinds ??= retainedRecordKinds(this.#client.snapshot());
                    targetKind = retainedKinds.get(encoded.reference as string);
                }
                if ((kind !== "map" && kind !== "list") || targetKind !== kind) fail("invalid encoded reference");
            } else fail("invalid encoded value");
        }
        for (const list of children.values()) Object.freeze(list);
        for (const keyMap of keys.values()) {
            for (const candidates of keyMap.values()) { candidates.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0); Object.freeze(candidates); }
            Object.freeze(keyMap);
        }
        this.#cache = Object.freeze({index: Object.freeze(index), children: Object.freeze(children), keys: Object.freeze(keys), version});
    }
    private lookup(id: DataId) { this.refresh(); return this.#cache.index.get(id); }
    /** Internal facade operation; deleted collections reject new edits. */
    collection(id: DataId, kind: "map" | "list"): Indexed {
        const value = this.lookup(id);
        if (!value || (id === ROOT ? kind !== "map" : value.node.type !== kind)) return fail("collection is not visible");
        return value;
    }
    children(id: DataId, kind: "map" | "list"): Indexed[] {
        this.collection(id, kind); return this.#cache.children.get(id) ?? [];
    }
    mapSize(id: DataId): number {
        this.collection(id, "map"); return this.#cache.keys.get(id)?.size ?? 0;
    }
    candidates(id: DataId, key: string): Indexed[] { this.collection(id, "map"); return this.#cache.keys.get(id)?.get(key) ?? []; }
    findEntry(collection: DataId, id: DataId): Indexed | undefined {
        const parent = this.collection(collection, "list"), entry = this.lookup(id);
        return entry?.node.type === "entry" && entry.path.length === parent.path.length + 1 && parent.path.every((part, index) => entry.path[index] === part) ? entry : undefined;
    }
    private newId(): DataId { return `data:${globalThis.crypto.randomUUID()}`; }
    private create(kind: "map" | "list") {
        this.mutable(); const id = this.newId();
        // Allocation is structural and permanent. Undo cannot hide peer descendants.
        this.#client.edit([{op: "insert", at: [this.#client.model().children?.length ?? 0], content: [{type: kind, attrs: {id}, children: []}]}], null);
        return this.handle(id, kind);
    }
    private handle(id: DataId, kind: "map" | "list", retained = false) {
        // A validated reference can name a retained hidden collection. Reads can
        // return its handle; collection operations still require visibility.
        if (!retained) this.collection(id, kind);
        let handle = this.#handles.get(id);
        if (handle && (handle instanceof SharedMap ? kind !== "map" : kind !== "list")) fail("reference kind mismatch");
        if (!handle) { handle = kind === "map" ? new SharedMap(this, id) : new SharedList(this, id); this.#handles.set(id, handle); }
        return handle;
    }
    private encode(value: DataValue): Encoded {
        if (value instanceof SharedMap || value instanceof SharedList) {
            if (value.owner !== this) return fail("shared reference belongs to another client");
            const kind = value instanceof SharedMap ? "map" : "list"; this.collection(value.id, kind);
            return {reference: value.id, kind};
        }
        if (value === null || typeof value === "boolean" || typeof value === "string" || typeof value === "number" && Number.isFinite(value)) return {scalar: value};
        return fail("value must be a finite scalar or a shared collection");
    }
    decode(item: Indexed): DataValue {
        if (this.#inAction) this.#epoch++;
        const value = item.node.attrs!.value as Encoded;
        if ("scalar" in value) return value.scalar;
        return this.handle(value.reference, value.kind, true);
    }
    private check(write: DataWrite) {
        this.mutable(); this.#validate(Object.freeze({...write}));
    }
    write(write: DataWrite, edits: EditOp[]) { this.check(write); this.#client.edit(edits); }
    set(map: SharedMap, key: string, value: DataValue) {
        const framed = this.#frame === map; this.#frame = null;
        const encoded = this.encode(value), entries = map.candidates(key), winner = entries.at(-1);
        const parent = this.collection(map.id, "map");
        const write: DataWrite = {collection: map.id, kind: "map", operation: "set", key, value};
        if (winner && framed) this.#writePoint(map, winner, parent, encoded, write);
        else this.write(write, winner
            ? [{op: "update", at: winner.path, attrs: {value: encoded}}]
            : [{op: "insert", at: [...parent.path, parent.node.children?.length ?? 0], content: [{type: "entry", attrs: {id: this.newId(), key, value: encoded}}]}]);
    }
    insert(list: SharedList, index: number, value: DataValue): DataId {
        const encoded = this.encode(value), children = this.children(list.id, "list");
        if (!Number.isSafeInteger(index) || index < 0 || index > children.length) return fail("invalid list index");
        const parent = this.collection(list.id, "list"), id = this.newId();
        this.write({collection: list.id, kind: "list", operation: "insert", index, id, value}, [{op: "insert", at: [...parent.path, index], content: [{type: "entry", attrs: {id, value: encoded}}]}]);
        return id;
    }
    update(list: SharedList, id: DataId, value: DataValue) {
        const framed = this.#frame === list; this.#frame = null;
        const encoded = this.encode(value), entry = list.entry(id);
        const write: DataWrite = {collection: list.id, kind: "list", operation: "set", id, value};
        // Use the already cached parent. Do not add another public resolution.
        const parent = this.#cache.index.get(list.id);
        if (framed && parent) this.#writePoint(list, entry, parent, encoded, write);
        else this.write(write, [{op: "update", at: entry.path, attrs: {value: encoded}}]);
    }
    #writePoint(handle: SharedMap | SharedList, entry: Indexed, parent: Indexed, encoded: Encoded, write: DataWrite): void {
        const edits: EditOp[] = [{op: "update", at: entry.path, attrs: {value: encoded}}];
        // Preserve a public writer override. Only the known stock path may capture.
        if (!stockAccess(this)) { this.write(write, edits); return; }
        this.check(write);
        const owner = clientPoints(this.#client), cache = this.#cache, epoch = this.#epoch;
        let action: ReturnType<PointOwner["begin"]> = null;
        let value: PointValue | undefined;
        try {
            if (stockAccess(this) && stockMapClass() && stockListClass() && (stockMap(handle) || stockList(handle)) && owner?.check()
                && cache.index.get(entry.id) === entry && cache.index.get(parent.id) === parent && entry.path.length >= 1 && entry.path.length <= 2) {
                const stamp = this.#client.stamp();
                if (cache.version === `${stamp.generation}:${stamp.revision}`) {
                    value = detachPointValue(encoded);
                    action = owner.begin({id: entry.id, value});
                }
            }
        } catch {
            // Optional ownership proof must not change the complete edit result.
            try { owner?.revoke(); } catch { /* already ineligible */ }
            action = null;
        }
        this.#pending = undefined;
        if (!action || !owner || !value) { this.#client.edit(edits); return; }
        this.#inAction = true;
        let success = false;
        try { this.#client.edit(edits); success = true; }
        finally {
            this.#inAction = false;
            try {
                const token = action.finish(success);
                if (success && token && epoch === this.#epoch && cache === this.#cache) {
                    const stamp = this.#client.stamp();
                    this.#pending = {cache, epoch, owner, token, entry, parent, value, version: `${stamp.generation}:${stamp.revision}`};
                }
            } catch {
                try { owner.revoke(); } catch { /* preserve original edit/History/clock errors */ }
            }
        }
    }
    #tryPoint(pending: PendingPoint, model: NodeJSON, version: string): boolean {
        const {cache, entry, parent, value, owner, token, epoch} = pending;
        if (cache !== this.#cache || epoch !== this.#epoch || version !== pending.version || !stockAccess(this) || !owner.check()) return false;
        const physical = owner.consume(token);
        if (!physical || physical.id !== entry.id || physical.key !== entry.node.attrs!.key || !samePointValue(physical.value, value)) return false;
        const root = cache.index.get(ROOT)!;
        const actualParent = pointNodeAt(model, parent.path), actualEntry = pointNodeAt(model, entry.path);
        if (!samePointSpine(model, root.node) || !samePointSpine(actualParent, parent.node) || !actualEntry || actualEntry.type !== "entry" || actualEntry.children || actualEntry.runs
            || Object.keys(actualEntry).some(k => k !== "type" && k !== "attrs") || Object.keys(actualEntry.attrs ?? {}).length !== 3
            || actualEntry.attrs?.id !== entry.id || actualEntry.attrs.key !== physical.key || !samePointValue(actualEntry.attrs.value, value)) return false;
        const node = freeze({...entry.node, attrs: {...entry.node.attrs, value}}), nextEntry = freeze({...entry, node});
        const parentChildren = parent.node.children!.slice(); parentChildren[entry.path.at(-1)!] = node;
        const nextParent = freeze({...parent, node: {...parent.node, children: parentChildren}});
        let nextRoot = nextParent;
        if (parent.id !== ROOT) {
            const rootChildren = root.node.children!.slice(); rootChildren[parent.path[0]] = nextParent.node;
            nextRoot = freeze({...root, node: {...root.node, children: rootChildren}});
        }
        const index = new Map(cache.index), children = new Map(cache.children), keys = new Map(cache.keys);
        index.set(entry.id, nextEntry); index.set(parent.id, nextParent); index.set(ROOT, nextRoot);
        const siblings = cache.children.get(parent.id), oldKeys = cache.keys.get(parent.id), oldCandidates = oldKeys?.get(physical.key);
        if (!siblings || !oldKeys || !oldCandidates || !siblings.includes(entry) || !oldCandidates.includes(entry)) return false;
        children.set(parent.id, Object.freeze(siblings.map(item => item === entry ? nextEntry : item)) as Indexed[]);
        const newKeys = new Map(oldKeys);
        newKeys.set(physical.key, Object.freeze(oldCandidates.map(item => item === entry ? nextEntry : item)) as Indexed[]); keys.set(parent.id, Object.freeze(newKeys));
        // No public calls between this final proof and the one bundle publication.
        const stamp = this.#client.stamp();
        if (cache !== this.#cache || epoch !== this.#epoch || version !== `${stamp.generation}:${stamp.revision}` || !owner.check() || !stockAccess(this)) return false;
        this.#cache = Object.freeze({index: Object.freeze(index), children: Object.freeze(children), keys: Object.freeze(keys), version});
        return true;
    }
}

export class SharedMap {
    readonly owner: DataAccess;
    readonly id: DataId;
    constructor(owner: DataAccess, id: DataId) { this.owner = owner; this.id = id; Object.freeze(this); }
    candidates(key: string): Indexed[] {
        if (typeof key !== "string") return fail("map key must be a string");
        return this.owner.candidates(this.id, key);
    }
    get(key: string): DataValue | undefined { const value = this.candidates(key).at(-1); return value ? this.owner.decode(value) : undefined; }
    has(key: string): boolean { return this.candidates(key).length > 0; }
    set(key: string, value: DataValue): this { this.owner.mutable(); knownSet(this.owner, this, () => this.owner.set(this, key, value)); return this; }
    delete(key: string): boolean {
        this.owner.mutable();
        const entries = this.candidates(key); if (!entries.length) return false;
        this.owner.write({collection: this.id, kind: "map", operation: "delete", key}, [...entries].sort((a, b) => b.path.at(-1)! - a.path.at(-1)!).map(item => ({op: "delete", at: item.path, count: 1})));
        return true;
    }
    entries(): Array<[string, DataValue]> {
        const keys = [...new Set(this.owner.children(this.id, "map").map(item => item.node.attrs!.key as string))].sort();
        return keys.map(key => [key, this.get(key)!]);
    }
    get size() { return this.owner.mapSize(this.id); }
}

export class SharedList {
    readonly owner: DataAccess;
    readonly id: DataId;
    constructor(owner: DataAccess, id: DataId) { this.owner = owner; this.id = id; Object.freeze(this); }
    entry(id: DataId): Indexed { return this.owner.findEntry(this.id, id) ?? fail("list entry is not visible"); }
    entries(): Array<{id: DataId; value: DataValue}> { return this.owner.children(this.id, "list").map(item => ({id: item.id, value: this.owner.decode(item)})); }
    get length() { return this.owner.children(this.id, "list").length; }
    get(id: DataId): DataValue | undefined { const entry = this.owner.findEntry(this.id, id); return entry ? this.owner.decode(entry) : undefined; }
    at(index: number): {id: DataId; value: DataValue} | undefined {
        const item = this.owner.children(this.id, "list").at(index);
        return item ? {id: item.id, value: this.owner.decode(item)} : undefined;
    }
    insert(index: number, value: DataValue): DataId { this.owner.mutable(); return this.owner.insert(this, index, value); }
    push(value: DataValue): DataId { this.owner.mutable(); return this.insert(this.length, value); }
    set(id: DataId, value: DataValue): void { this.owner.mutable(); knownSet(this.owner, this, () => this.owner.update(this, id, value)); }
    delete(id: DataId): boolean {
        this.owner.mutable();
        const entry = this.owner.findEntry(this.id, id); if (!entry) return false;
        this.owner.write({collection: this.id, kind: "list", operation: "delete", id}, [{op: "delete", at: entry.path, count: 1}]); return true;
    }
    /** index is the position in the resulting list, after removal. */
    move(id: DataId, index: number): void {
        this.owner.mutable();
        const entry = this.entry(id), parent = this.owner.collection(this.id, "list");
        if (!Number.isSafeInteger(index) || index < 0 || index >= this.length) return fail("invalid list index");
        this.owner.write({collection: this.id, kind: "list", operation: "move", id, index}, [{op: "move", from: entry.path, at: [...parent.path, index]}]);
    }
}

/** Internal attachment. The schema check does not modify the Client. */
export function createDataAccess(client: Client, validate: DataValidator, assertMutable: () => void): SharedData {
    assertDataSchema(client);
    return new DataAccess(client, validate, assertMutable);
}

const dataSchemaVersion = schemaVersion(createDataSchema());
const checkedSchemas = new WeakSet<object>();
/** Recheck schema transitions for both cached access and retained handles. */
export function assertDataSchema(client: Client): void {
    const schema = client.schema;
    if (checkedSchemas.has(schema)) return;
    if (schemaVersion(schema) !== dataSchemaVersion) fail("client.data requires createDataSchema()");
    // Engine schemas are deeply frozen. A mutable external schema must be checked again.
    if (deeplyFrozen(schema)) checkedSchemas.add(schema);
}

const stockAccess = /* @__PURE__ */ stockPrototype(DataAccess.prototype);
const stockMap = /* @__PURE__ */ stockPrototype(SharedMap.prototype);
const stockList = /* @__PURE__ */ stockPrototype(SharedList.prototype);

const stockMapClass = /* @__PURE__ */ stockSurface(SharedMap);
const stockListClass = /* @__PURE__ */ stockSurface(SharedList);
