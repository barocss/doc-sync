from pathlib import Path
import hashlib,json,subprocess,datetime
ROOT=Path('/Users/user/github/doc-sync')
OUT=ROOT/'output/rust-d2-alias-2026-11-04/core'
OLD=OUT/'baseline-target/debug/doc-sync-rust-shadow'
NEW=ROOT/'experiments/rust-shadow/target/debug/doc-sync-rust-shadow'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes():
 return {str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'experiments/rust-shadow/src').glob('*.rs'))}
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def ticket(n):return {'lamport':n,'actor':'A'}
recorded=json.loads((OUT/'receipt.json').read_text())['source']
for path,entry in recorded.items():assert sha(ROOT/path)==entry['sha256'],path
source_before=hashes();binary_before={'baseline':sha(OLD),'current':sha(NEW)}
cases=[]
for name,default,multiple in [('object-single',{'tone':'warm','n':1},False),('object-multiple',{'tone':'warm','n':1},True),('array-single',['warm',1],False),('array-multiple',['warm',1],True)]:
 manifest={'root':'doc','marks':[],'markValues':{'choice':{'default':default,'values':[default,default]}},'nodes':{'doc':{'shape':'flow','children':['p'],'default':'p'},'p':{'shape':'text'}}}
 edges=[{'at':['markValues','choice'],'enumIndex':i} for i in ([0,1] if multiple else [0])]
 dto={'format':'doc-sync-runtime-schema-alias-v1','manifest':manifest,'defaultReferences':edges}
 identity='sha256:'+hashlib.sha256(canonical(dto).encode()).hexdigest()
 enum_index=1 if multiple else 0
 def wrap(n,source,index=None):
  reference={'path':['value'],'schema':identity,'at':['markValues','choice'],'source':source}
  if index is not None:reference['index']=index
  return {'t':'reference','format':'doc-sync-runtime-reference-op-v1','op':{'t':'set','at':ticket(n),'ids':[ticket(1)],'key':'choice','value':default},'references':[reference]}
 requests=[{'cmd':'new','actor':'A','replica':name,'schema':identity,'runtimeSchema':dto},
 {'cmd':'apply','replica':name,'schema':identity,'ops':[{'t':'text','id':ticket(1),'origin':{'lamport':0,'actor':'~root'},'units':[97]}]},
 {'cmd':'apply','replica':name,'schema':identity,'ops':[wrap(2,'default')]},
 {'cmd':'apply','replica':name,'schema':identity,'ops':[wrap(3,'enum',enum_index)]},
 {'cmd':'snapshot','replica':name,'schema':identity}]
 path=OUT/(name+'-requests-01.jsonl');path.write_text(''.join(json.dumps(v,separators=(',',':'))+'\n' for v in requests));request_hash=sha(path)
 responses={}
 for label,binary in [('baseline',OLD),('current',NEW)]:
  result=subprocess.run([str(binary)],input=path.read_bytes(),capture_output=True,check=True)
  response_path=OUT/(name+'-'+label+'-responses-01.jsonl');response_path.write_bytes(result.stdout)
  (OUT/(name+'-'+label+'-stderr-01.log')).write_bytes(result.stderr)
  responses[label]=[json.loads(line) for line in result.stdout.splitlines()]
  assert len(responses[label])==len(requests),(name,label,result.stdout)
 assert responses['baseline'][0]['ok'] is False
 assert 'UnsupportedSchema at $.format' in responses['baseline'][0]['error']
 assert all(r['ok'] is True for r in responses['current']),(name,responses['current'])
 current=responses['current']
 for i in [2,3]:
  item=next(v for v in current[i]['state']['items'] if v['id']==ticket(1))
  assert item['attrs']['choice']['value']==default
  assert item['attrs']['choice']['at']==ticket(i)
 snapshot=current[4]['snapshot'];assert snapshot['manifest']==dto
 assert snapshot['ops'][1]['references'][0]['source']=='default'
 assert snapshot['ops'][2]['references'][0]['source']=='enum'
 assert snapshot['ops'][2]['references'][0]['index']==enum_index
 assert sha(path)==request_hash
 cases.append({'name':name,'status':'PASS','requestSha256':request_hash,'requests':len(requests),'schema':identity,'baselineFirstResponse':responses['baseline'][0],'currentAllResponsesOk':True,'currentReferenceEdits':2,'enumIndex':enum_index,'explicitEdges':len(edges),'snapshotPreservesDtoAndExactReferenceSourceIndex':True})
assert hashes()==source_before
assert sha(OLD)==binary_before['baseline'];assert sha(NEW)==binary_before['current']
receipt={'status':'PASS','scope':'Independent fixed JSONL protocol requests against baseline153 rebuilt CLI and unchanged current CLI; no native production source edits','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baselineSourceReceipt':'baseline-source-hashes.json','baselineSourceVerifiedFiles':23,'baselineBuildLog':'baseline-build-01.log','buildCommand':'/opt/homebrew/bin/cargo build --offline --locked --manifest-path output/rust-d2-alias-2026-11-04/core/baseline-source/Cargo.toml --target-dir output/rust-d2-alias-2026-11-04/core/baseline-target','binaries':{'baseline':{'path':str(OLD),'sha256':binary_before['baseline']},'current':{'path':str(NEW),'sha256':binary_before['current']}},'sourceSha256':source_before,'sourceAndBinariesUnchangedDuringProbe':True,'cases':cases}
(OUT/'protocol-before-after-receipt-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':len(cases),'currentReferenceEdits':8,'baselineRejectedCases':4,'currentAdmittedCases':4,'sourceAndBinariesUnchangedDuringProbe':True},indent=2))
