from pathlib import Path
import hashlib,json,subprocess,datetime
root=Path('/Users/user/github/doc-sync');out=root/'output/rust-d2-alias-2026-11-04/core'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=out/'keyorder-factory-before-bin-01';new=out/'keyorder-factory-target/debug/alias-keyorder-factory-probe';node='/Users/user/.nvm/versions/node/v24.22.1/bin/node';ts=out/'keyorder-factory-ts-01.mjs'
base=json.loads((out/'keyorder-factory-input-01.json').read_text());cases=[]
for name,default,choice in [('object','{"a":1,"b":2}','{"b":2,"a":1}'),('nested-array','[{"a":1,"b":2},{"nested":[{"x":3,"y":4}],"tail":5}]','[{"b":2,"a":1},{"tail":5,"nested":[{"y":4,"x":3}]}]'),('nested-object','{"outer":[{"a":1,"b":2}],"other":{"x":3,"y":4}}','{"other":{"y":4,"x":3},"outer":[{"b":2,"a":1}]}')]:
 dto=json.loads(json.dumps(base));descriptor={'default':json.loads(default),'values':[json.loads(choice),json.loads(choice)]};dto['manifest']['nodes']['p']['attrs']['choice']=descriptor;dto['manifest']['markValues']['paint']=descriptor
 input=out/('keyorder-'+name+'-input-02.json');input.write_text(json.dumps(dto,separators=(',',':'))+'\n');input_hash=sha(input);results={}
 for label,binary in [('before',old),('after',new),('typescript',node)]:
  cmd=[str(binary),str(input)] if label!='typescript' else [node,str(ts),str(input)]
  result=subprocess.run(cmd,capture_output=True,check=True);path=out/('keyorder-'+name+'-'+label+'-02.json');path.write_bytes(result.stdout);results[label]=json.loads(result.stdout)
 before,after,oracle=results['before'],results['after'],results['typescript']
 assert before['sdkLinkedEnumPayloadJson']!=oracle['rehydratedLinkedEnumPayloadJson']
 for payload in ['sdkDefaultPayloadJson','sdkLinkedEnumPayloadJson','coreLinkedEnumPayloadJson','markDefaultPayloadJson','markLinkedEnumPayloadJson']:assert after[payload]==default,(name,payload,after[payload],default)
 assert after['sdkLinkedEnumPayloadJson']==oracle['rehydratedLinkedEnumPayloadJson']
 assert after['sdkUnlinkedEnumPayloadJson']==choice==oracle['rehydratedUnlinkedEnumPayloadJson']
 assert before['selectedReference']==after['selectedReference'];assert after['selectedReference']['source']=='enum' and after['selectedReference']['index']==0
 assert after['sdkBoundOperation']['references'][0]['source']=='enum' and after['sdkBoundOperation']['references'][0]['index']==0
 assert sha(input)==input_hash
 cases.append({'name':name,'status':'PASS','input':input.name,'inputSha256':input_hash,'beforeMismatchReproduced':True,'afterMatchesActualJavaScriptSharedObject':True,'nestedObjectOrderExact':True,'unlinkedSlotOrderUnchanged':True,'selectedEnumSourceIndexUnchanged':True})
paths=list((root/'experiments/rust-shadow/src').glob('*.rs'))+list((root/'experiments/rust-sdk/src').glob('*.rs'))+[root/'experiments/rust-shadow/tests/runtime_alias.rs',ts,out/'keyorder-factory-probe/src/main.rs',out/'keyorder-factory-probe/Cargo.lock',out/'keyorder-factory-probe/Cargo.toml',root/'experiments/runtime-document-alias/schema.mjs',root/'packages/doc-sync/dist/crdt/schema.js']
receipt={'status':'PASS','scope':'Alias-linked reference factory payload order only; independent preserved old consumer binary vs rebuilt same-source consumer, plus actual JS shared-reference and alias-rehydration JSON.stringify oracle','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':cases,'binaries':{'before':{'path':str(old),'sha256':sha(old)},'after':{'path':str(new),'sha256':sha(new)}},'sameConsumerSourceSha256':sha(out/'keyorder-factory-probe/src/main.rs'),'sourceHashes':{str(p.relative_to(root)):sha(p) for p in sorted(paths)},'historyRedoRegression':{'test':'linked_enum_history_redo_preserves_shared_payload_serialized_order_and_selected_index','log':'alias-keyorder-focused-01.log','passed':True,'assertions':['nested array value raw JSON order exact after History undo/checkpoint/restore/redo','source enum index1 preserved','last snapshot journal op raw serialized payload order exact']},'unchangedAdmission':'Incoming payload canonical binding remains unchanged; reordered_same_identity_schema_binds_payload_without_reordering_raw_json still passes'}
(out/'keyorder-before-after-receipt-02.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':'PASS','cases':len(cases),'selectedMetadataUnchanged':True,'unlinkedSlotOrderUnchanged':True}))
