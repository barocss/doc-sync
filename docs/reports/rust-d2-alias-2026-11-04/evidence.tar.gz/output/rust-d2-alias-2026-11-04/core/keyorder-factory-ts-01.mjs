import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {hydrate} from '/Users/user/github/doc-sync/experiments/runtime-document-alias/schema.mjs';
import {checkSchema,attrValueOk} from '/Users/user/github/doc-sync/packages/doc-sync/dist/crdt/schema.js';
const dto=JSON.parse(readFileSync(process.argv[2],'utf8'));const schema=hydrate(dto);assert.deepEqual(checkSchema(schema),[]);
const d=schema.nodes.p.attrs.choice,m=schema.markValues.paint;
assert.equal(d.default,d.values[0]);assert.notEqual(d.default,d.values[1]);assert(attrValueOk(d,d.values[0]));
const direct={a:1,b:2};const shared={default:direct,values:[direct]};assert.equal(shared.default,shared.values[0]);
console.log(JSON.stringify({actualSharedReference:true,directSharedDefaultPayloadJson:JSON.stringify(shared.default),directSharedEnumPayloadJson:JSON.stringify(shared.values[0]),rehydratedDefaultPayloadJson:JSON.stringify(d.default),rehydratedLinkedEnumPayloadJson:JSON.stringify(d.values[0]),rehydratedUnlinkedEnumPayloadJson:JSON.stringify(d.values[1]),markDefaultPayloadJson:JSON.stringify(m.default),markLinkedEnumPayloadJson:JSON.stringify(m.values[0]),rehydrationRetainsSharedReference:d.default===d.values[0],unlinkedSlotRemainsDistinct:d.default!==d.values[1]}));
