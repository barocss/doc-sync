use doc_sync_native_sdk::{Op,RuntimeSchema,Ticket};
use serde_json::{json,Value};
fn main(){
    let dto:Value=serde_json::from_str(&std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap()).unwrap();
    let sdk=RuntimeSchema::compile(dto.clone()).unwrap();
    let core=doc_sync_rust_shadow::runtime_schema::RuntimeSchema::compile(dto).unwrap();
    let default=sdk.default_value("p","choice").unwrap();let member=sdk.enum_value("p","choice",0).unwrap();
    let reference=core.reference_value(&["nodes","p","attrs","choice"],Some(0)).unwrap();
    let bound=member.bind(Op::Set{at:Ticket{lamport:1,actor:"A".into()},ids:vec![Ticket{lamport:0,actor:"~root".into()}],key:"choice".into(),value:member.value().clone()},&["value"]).unwrap();
    println!("{}",json!({"compiled":true,"sdkDefaultPayloadJson":default.value().to_string(),"sdkLinkedEnumPayloadJson":member.value().to_string(),"coreLinkedEnumPayloadJson":core.reference_payload(&reference).unwrap().to_string(),"sdkUnlinkedEnumPayloadJson":sdk.enum_value("p","choice",1).unwrap().value().to_string(),"markDefaultPayloadJson":sdk.reference_value(&["markValues","paint"],None).unwrap().value().to_string(),"markLinkedEnumPayloadJson":sdk.reference_value(&["markValues","paint"],Some(0)).unwrap().value().to_string(),"selectedReference":reference,"sdkBoundOperation":bound}));
}
