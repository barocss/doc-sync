use doc_sync_native_sdk::*;
use serde_json::json;

fn main() -> Result<()> {
    let manifest = json!({"root":"root","marks":[],"nodes":{
        "root":{"shape":"flow","children":["line"],"default":"line"},
        "line":{"shape":"text","attrs":{"choice":{
            "default":{"x":1},"values":[{"x":1},{"x":1},{"x":2}]
        }}}
    }});
    let schema = RuntimeSchema::compile_with_default_references(
        manifest,
        [DefaultReference::new(&["nodes", "line", "attrs", "choice"], 0)],
    )?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema.clone())?;
    let (id, birth) = a.insert_runtime_block(
        "line", None, None,
        SchemaAttributes::from([("choice".into(), schema.enum_value("line", "choice", 0)?)]),
        EditOptions::default(), 1.,
    )?;
    // Enum slot 0 is the default object. It creates no birth register.
    assert!(matches!(birth.ops[0].raw_operation(), Op::Node { attrs: Some(attrs), .. } if attrs.is_empty()));
    let birth: Change = serde_json::from_str(&serde_json::to_string(&birth)?)?;
    b.apply_remote(&birth.ops)?;
    // Slot 1 has equal JSON but a distinct identity. Its explicit update is kept.
    let update = a.set_runtime_attribute(
        &id, "choice", schema.enum_value("line", "choice", 1)?,
        EditOptions::default(), 2.,
    )?;
    let update: Change = serde_json::from_str(&serde_json::to_string(&update)?)?;
    assert!(matches!(&update.ops[0], Op::Reference { references, .. } if references[0]["index"] == 1));
    b.apply_remote(&update.ops)?;
    let saved = a.checkpoint()?.to_json()?;
    let mut restored = RuntimeDocument::restore(&RuntimeCheckpoint::from_json(&saved)?)?;
    assert_eq!(restored.schema().dto(), schema.dto());
    assert_eq!(restored.pending_changes(), a.pending_changes());
    for change in restored.pending_changes().to_vec() {
        restored.apply_remote(&change.ops)?;
    }
    assert_eq!(restored.checkpoint()?.to_json()?, saved);
    for change in [restored.undo()?, restored.redo()?] {
        b.apply_remote(&change.ops)?;
    }
    assert_eq!(restored.model()?, b.model()?);
    let pending = restored.pending_changes().to_vec();
    restored.acknowledge(&pending)?;
    assert!(restored.pending_changes().is_empty());
    println!("PASS: explicit alias, distinct enum, native JSON peers, restore, retry, undo/redo, ACK");
    Ok(())
}
