from pathlib import Path
root=Path('/Users/user/github/doc-sync')
def rep(name,a,b):
 p=root/name;s=p.read_text();assert a in s,name;p.write_text(s.replace(a,b))
rep('README.md','explicit native schema references for composite defaults/enums, nested field attributes','explicit native schema references and declared default/enum sharing, nested field attributes')
rep('apps/docs/src/schemas/document.md','for the native protocol and its TypeScript transport boundary. A composite enum\nwith a composite default, and `markValues.fields`, remain unsupported.','''for the native protocol and its TypeScript transport boundary. A composite enum
can share its default with explicitly listed enum slots through the versioned
alias schema DTO. Equal JSON alone does not declare sharing. `markValues.fields`
and arbitrary cross-descriptor reference graphs remain unsupported.''')
rep('apps/docs/src/schemas/custom.md','scalar and JSON marks with native composite-reference handles','scalar and JSON marks with native composite-reference handles and explicit default/enum sharing')
rep('apps/docs/src/schemas/custom.md','Composite enums with composite defaults, markValues.fields, unsafe JSON keys','Arbitrary cross-descriptor or enum-only reference aliases, markValues.fields, unsafe JSON keys')
rep('apps/docs/src/guide/document-rules.md','''Object/array defaults without enums and composite enum choices with a null
default are supported separately; combining a composite default and enum is
still unsupported. The native extension does not make raw TypeScript DocHub
accept serialized composite enum edits. See the [Rust guide](./rust).''','''Object/array defaults and composite enum choices can share a reference through
`RuntimeSchema::compile_with_default_references`. Each declared edge binds a
default to an enum index at the same attribute or value-mark descriptor. Several
listed slots may share the default; equal unlisted slots remain distinct.
A versioned schema DTO retains these edges through JSON and checkpoint restore.
Bare schemas keep their existing identity and wire format. The alias schema ID
includes the graph, while `base_identity()` describes only the raw rules.

Birth canonicalization omits a default or listed alias and can pass the existing
TypeScript DocHub path because that operation carries no composite value. A
retained enum birth writer or explicit default/enum update still loses identity
in the server's retained payload copy and rejects atomically. This native
extension does not supply a general TS/native transport adapter. See the
[Rust guide](./rust#atomic-objectarray-defaults-and-enums) for a compiled example.''')
rep('docs/rust-roadmap.md','Composite default-to-enum aliases need a schema identity format and remain open.','''That checkpoint left composite default-to-enum aliases open; the next extension
implements explicit same-descriptor sharing as described below.''')
p=root/'docs/rust-roadmap.md';s=p.read_text();needle='Replace preset/type-name branches with per-document compiled schema data.';assert needle in s;s=s.replace(needle,'''The shared-reference extension compiles
`doc-sync-runtime-schema-alias-v1` descriptors. Each edge identifies an atomic
attribute or value mark and an enum index that shares its composite default.
Several slots may explicitly share that default; equal unlisted slots remain
distinct. Invalid/duplicate edges and inferred sharing reject. The schema's
semantic identity includes the graph; `base_identity()` retains the raw TS
schema hash. Bare schema identity and serialization remain unchanged. Snapshots
retain the versioned DTO and references retain their selected source/index.
Compiled lookup tables avoid scanning the entire graph during an edit.

TypeScript material/History comparison rehydrates actual shared object references.
A default-alias birth can pass DocHub when canonicalization omits its value;
retained composite payloads still fail its cloning/admission path. This does
not close TS/native wire integration, cross-descriptor or enum-only alias graphs,
live schema transitions, D3 or the remaining D2 product/compiler gates. See the
[shared-reference report](reports/rust-d2-alias-2026-11-04/README.md).

'''+needle);p.write_text(s)
rep('apps/docs/src/roadmap.md','Composite enums with composite defaults and TS/native wire exchange remain open.','''The next extension adds explicit default/enum sharing at one descriptor through
a versioned schema DTO, preserving selected reference provenance and graph-bound
checkpoint identity. Arbitrary cross-descriptor/enum-only alias graphs and
TS/native wire exchange remain open.''')
