### 5.146 D2 shared default/enum references

Three agents own core, SDK/docs and independent TS/native comparison. Baseline
is main1cfb7a2 plus captured153file inherited D2 reference/composite WIP, rather
than GitHEAD alone. All five earlier D2 report seals remain unchanged. Production
TS CRDT source is unchanged in this task. No commit/push or release is included.

RuntimeSchema accepts doc-sync-runtime-schema-alias-v1 descriptors with a full
manifest and nonempty defaultReferences edges. Each {at,enumIndex} binds an
atomic node attribute or value-mark composite default to an enum slot at that
same descriptor. Multiple explicitly listed slots share the default; equal
unlisted entries remain distinct. Duplicate/invalid edges, payload mismatch,
unknown format, scalar/field/computed aliases and inferred bareJSON sharing
reject atomically. Field-leaf structural equality remains separate.

The raw manifest/base_identity describes TS schemaVersion data; the semantic
identity includes the graph. DTO/checkpoints retain that graph. Native handles
and checkpoints use semantic identity, not base_identity. Edge/property order
and explicit/omitted document domain normalize as declared; selected enum index
remains part of provenance. Bare schema serialization and identity stay intact.
compile_with_default_references and with_default_references create schemas;
they do not migrate an open document. Cached graph lookup avoids per-edit full
edge scans, schema compilation or extra journal replay solely for preflight.

Native reference-aware birth helpers omit actual default/linked enum handles.
An equal unlinked slot retains its writer/index. Explicit updates retain writers
and the existing operation envelope preserves selected source/index through
native JSON peers, full History, pending replay, exact ACK and own checkpoints.
Selective undo preserves foreign writers and concurrent text/delete/format.

Final core147/147 PASS (new9), SDK93/93 PASS (new7), documented independent
Cargo consumer PASS. Frozen final12-driver run passes180 source/binary hashes
without drift or previous-PASS reuse. Alias2schemas182actions/364actorstates
include110 actual staged Doc.edit checks. Earlier six corpus files are byte-
identical: flow162/324states, grid180/360, shapes188/376, rules260/520,
legacy6schemas82/164, composite160/320. No old negatives were removed or changed.
Old/new native scope10/20, old/new JS identity and actualHub probes also pass.

Actual TS DocHub48expected outcomes distinguish transport cases. structuredClone
preserves sharing within the copied schema but separates source references.
Default/linked-enum births omit the value and can pass Hub. A retained unlinked
enum birth or explicit default/enum update fails the retained-payload clone
check atomically. Only hub-owned retained refs pass the initial check. This is
partial existing TS transport behavior, not a native-to-TS protocol adapter.
Raw History redo admission is distinguished from Doc.apply material semantics;
cloned enum attrs still use default fallback and marks retain token/span rules.

Review reproduced an alias factory key-order mismatch: default a,b and linked
enum slot b,a declared the same object but native emitted two payload orders.
Linked enum resolution now uses the default object payload; unlinked slot order,
selected source/index and incoming canonical binding stay intact. Core/SDK
beforeFAIL logs and independent actualJS/native before/after proof are preserved.
Final exact-order probe compares directsharedJS, hydratedDTO and nativeSDK across
4schemas/32factories (objects/nested arrays, marks/attrs, single/multiple edges).
Full History/redo/checkpoint order is also tested. Before/after protocol proof
builds23 matched baseline source inputs independently and sends identical4
requests to old and final147 CLIs: old4reject/current4admit with8reference edits.

Arbitrary cross-descriptor/enum-only alias graphs, markValues.fields, callback/
general computed rules, model-only attributes, text:false, axis moves, positive-
minimum cycles, live schema transitions and full product/compiler coverage stay
open. Observed D3 empty-patch clock, postmove and empty-head compiler gaps remain.
Public Rust Client/editor integration, native Map/List, CRDTWASM, production GC/
recovery and real native process/server-crash or mixed-wire qualification are
separate gates. Same-process checkpoint proof is not production crash recovery.
No Chrome/mobile/performance benchmark, deployment or npm/crates publication
is included.

[Source-bound shared-reference report](docs/reports/rust-d2-alias-2026-11-04/README.md).
