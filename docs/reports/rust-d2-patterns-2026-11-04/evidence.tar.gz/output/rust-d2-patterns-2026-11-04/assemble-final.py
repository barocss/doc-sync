from pathlib import Path
import json,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-patterns-2026-11-04';report=r/'docs/reports/rust-d2-patterns-2026-11-04'
def read(p):return json.loads(p.read_text())
s=read(t/'compare-summary.json');assert s['status']=='PASS'
summary={'status':'PASS','scope':'Bounded product patterns; main/oracle qualified, product compile probes and one filtered historical-corpus diagnostic separately labeled','main':{'receipt':str((r/s['receipts']['main']).relative_to(t))},'cases':{n:{'status':s[n]['status'],'receipt':str((r/p).relative_to(t))} for n,p in s['receipts'].items()},'coreSources':'core/sourcehashes-01.sha256','sdk':'sdk/receipt-final.json','fullComparison':'compare-summary.json','compression':'compare-compression-receipt.json'}
(t/'final-comparison-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paragraph='''Final verification: native core **177 PASS**, SDK **113 PASS**. The two-schema
trace passes **84 actions / 168 actor-state comparisons / 44 exact operations**,
with 36 positive staged Doc.edit cases and 16 rejected target actions. The oracle
passes **1,267 typed cases**: 362 new and 905 legacy-pattern cases. It executes
1,232 string RegExp tests, 2,534 native value-validator checks, 1,416 actual JS
target checks/staged edit records and 33 schema compile cases. Its whitespace
matrix covers all 25 ECMAScript whitespace codepoints and 15 contrasting values.
Two lone-surrogate inputs are BOUNDARY_OBSERVED, excluded from parity PASS.

The 24 product compilation probes use demo, Word, Notion and presentation.
Current originals reach a text:false rejection after passing pattern admission;
they remain unsupported complete profiles. One selected inherited composite
article trace retains status **FILTERED_DIAGNOSTIC_PASS**, 80 actions. It is not
a fresh full-corpus or full 23-driver PASS. Final before/after/current guards match
main139, oracle80, product8 and filtered legacy140 source/binary entries.

Whole npm: **2,114 tests / 2,112 PASS / two expected platform SKIPs / zero FAIL /
zero cancelled**, 133.424 seconds. Typecheck passes; docs build and checks pass
**55 pages / 2,635 internal links**, with English content and local paths excluded.
Nine earlier report seals and 14 previous target binaries remain unchanged.
The 17 new compressed outputs restore all 223,812,772 original bytes with exact
SHA256 checks. Compiled documentation program bodies match both current fences.
'''
p=report/'README.md';text=p.read_text();assert paragraph not in text;text=text.replace('## Boundaries\n',paragraph+'\n## Boundaries\n',1);p.write_text(text)
section='''### 5.150 D2 product validation patterns

Three agents delivered the core implementation, SDK tests/docs and independent
JavaScript comparison. Baseline: main `1cfb7a2` plus 144 captured inherited files.
The only native production edit adds two exact recognized patterns and their
validators in runtime_schema.rs; existing handlers remain unchanged. SDK
production code, TS collaboration rules and inherited fixtures remain unchanged.

Supported expressions are `^(https?://\\S+)?$` and `^(#[0-9a-fA-F]{6})?$`.
The link rule accepts the empty string or lowercase HTTP(S) prefix followed by a
nonempty suffix with no ECMAScript whitespace. Explicit classification rejects
BOM and accepts NEL/U+180E, matching actual JS RegExp. The color rule accepts
empty or six ASCII hex digits after #. Null keeps existing reset behavior;
model projection can omit default-valued attributes. Arbitrary regex variants
still reject. These are declared pattern rules, not a full URL parser.

Public validators, SDK attribute/mark/field/cell edits, batch atomic rejection,
concurrent actors, own undo/redo, checkpoint/pending retry and foreign writer
preservation are covered. No new public client API or regex dependency is added.
A documented native program compiles and runs in independent README and guide
Cargo consumers. A later Markdown-only wording correction leaves the exact
program bodies unchanged; original receipts are retained.

'''+paragraph+'''
The initial SDK test expected a reset color property to be emitted as an empty
string. Existing projection omits it; only the test assertion changed. The new
JS comparison adapter initially dropped insertCellText run marks. It now uses
the matching text-run command; the first mismatch remains a diagnostic. A root
verification initially used the wrong core log directory; the captured log path
was corrected without changing code or test outcomes.

Disk started near 3.25GiB free. The new target is an APFS copy-on-write clone of
the completed prior target; old binaries and seals are verified unchanged. New
large evidence files use SHA-verified gzip. No prior output or target cleanup.

Next D2: `image-block.text: false`, then valid unused node declarations. Demo's
image descriptor has the same text:false blocker. Removing these constraints in
diagnostic copies does not qualify original profiles. Full D2/D3, native object
wire compatibility, Rust/WASM Client/editor integration, native Map/List,
protected GC and production native process/server recovery remain separate.
Native own checkpoint replay is not mixed-runtime or durability qualification.
No Chrome, mobile or performance benchmark was run. No commit, push, deployment
or registry publication is included.

[Source-bound pattern report](docs/reports/rust-d2-patterns-2026-11-04/README.md).
'''
(t/'handoff-section.md').write_text(section)
p=r/'HANDOFF.md';text=p.read_text();assert '### 5.150 D2 product validation patterns' not in text
intro='''Latest **§5.150** supports the two product link/color patterns through existing
native APIs. Core177/SDK113 PASS; TS/native84 actions/168 states and the
1,267-case validator oracle PASS. Whole npm2,112 PASS/two SKIPs/zero failures;
docs55 pages/2,635 links PASS. Original product schemas now reach text:false;
full D2 and production Rust/WASM Client remain open. See
`docs/reports/rust-d2-patterns-2026-11-04/`. No commit/push/publication included.

'''
text=text.replace('# Handoff — @barocss/doc-sync\n\n','# Handoff — @barocss/doc-sync\n\n'+intro,1);p.write_text(text.rstrip()+'\n\n'+section)
subprocess.run(['python3',str(t/'verify-final.py')],cwd=r,check=True)
checks={'status':'PASS','nativeCore':{'passed':177,'log':'core-full-02.log'},'nativeSdk':{'passed':113,'receipt':'sdk/receipt-final.json'},'comparison':s,'workspace':{**read(t/'workspace-test-01.json'),**read(t/'workspace-test-totals.json')},'typecheck':read(t/'typecheck-01.json'),'documentation':{'build':read(t/'docs-build-02.json'),'check':read(t/'docs-check-01.json'),'pages':55,'internalLinks':2635,'english':True,'localPathsExcluded':True},'sourceVerification':read(t/'final-source-verification.json'),'legacyFull23Drivers':'NOT_RERUN_THIS_TASK','chrome':'NOT_RUN','mobile':'NOT_RUN','performance':'NOT_RUN','productionRustWasmClient':'NOT_QUALIFIED','publication':'NOT_REQUESTED'}
(report/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n');print('Final metadata and HANDOFF assembled')
