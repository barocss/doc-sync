from pathlib import Path
import os,json,hashlib,tarfile
root=Path('/Users/user/github/doc-sync');task=root/'output/rust-d2-patterns-2026-11-04';report=root/'docs/reports/rust-d2-patterns-2026-11-04'
summary=json.loads((task/'final-comparison-summary.json').read_text()); main=(task/summary['main']['receipt']).parent
qualified_roots=[(task/v['receipt']).parent for v in summary['cases'].values()]
selected=set(); excluded=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def reject(p,reason,hashit=True):
 excluded.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'reason':reason,**({'sha256':sha(p)} if hashit else {})})
for base,dirs,files in os.walk(task):
 dirs[:]=[d for d in dirs if 'target' not in d and d not in {'baseline-source','before-src','before-source','before-required-anchor-source','baseline'}]
 for name in files:
  p=Path(base)/name;rel=p.relative_to(task)
  if p.suffix=='.stdout':reject(p,'duplicate raw stdout',False);continue
  if p.suffix == '' and os.access(p,os.X_OK):reject(p,'loose executable omitted; sources and digests retained');continue
  if p.suffix not in {'.json','.jsonl','.gz','.diff','.log','.rs','.mjs','.ts','.py','.toml','.lock','.md','.stderr','.patch','.txt','.sha256'} and not name.endswith('.tar.gz'):continue
  if name.endswith('.tar.gz'):
   with tarfile.open(p,'r:gz') as t:
    binary=any(any('target' in part for part in Path(m.name).parts) for m in t.getmembers())
   if binary:reject(p,'binary-containing bundle; before-build source snapshots retained');continue
  if len(rel.parts)>2 and rel.parts[0] in {'compare','regressions'} and p.parent!=main and not any(q in p.parents for q in qualified_roots) and p.stat().st_size>8*1024*1024:
   reject(p,'large nonfinal raw trace retained locally; compact diagnostic/source/receipt selected');continue
  selected.add(p)
for folder in ['experiments/rust-sdk','experiments/rust-shadow']:
 for base,dirs,files in os.walk(root/folder):
  dirs[:]=[d for d in dirs if 'target' not in d]
  for n in files:
   p=Path(base)/n
   if p.suffix in {'.rs','.toml','.lock','.json'}:selected.add(p)
for folder in ['experiments/runtime-document-patterns','experiments/runtime-document-fieldrefs','experiments/runtime-document-payload','experiments/runtime-document-shared','experiments/runtime-document-alias','experiments/runtime-document-composite','experiments/runtime-document-rules','experiments/runtime-document-shapes','experiments/runtime-document-grid','experiments/runtime-document-nested']:
 selected.update((root/folder).glob('*.mjs'))
integration=json.loads((root/'output/rust-d2-shared-2026-11-04/sdk/mcp-diagnosis/integration-source-after-01.json').read_text())
selected.update(root/p for p in integration)
for n in ['experiments/rust-sdk/.gitignore','experiments/runtime-schema-native/compare.mjs','README.md','HANDOFF.md','experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md','apps/docs/src/guide/document-rules.md','apps/docs/src/roadmap.md','apps/docs/src/schemas/custom.md','apps/docs/src/schemas/document.md','docs/rust-roadmap.md','packages/doc-sync/src/crdt/doc.ts','packages/doc-sync/test/required-gap-projection.test.ts','docs/reports/rust-d2-patterns-2026-11-04/README.md','docs/reports/rust-d2-patterns-2026-11-04/final-checks.json']:
 selected.add(root/n)
files=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(selected)]
archive=report/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in sorted(selected):t.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'status':'SELECTED_EVIDENCE_SEALED','baseline':'main1cfb7a2 plus captured144-file source baseline; only runtime_schema.rs production delta;31 inheritedTS/integration files unchanged','archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},'files':files,'excludedLocalArtifacts':excluded,'notSelected':['loose binaries and Cargo targets','duplicate baseline source extractions'],'scope':'Final full traces and compact diagnostics/source archives, not a complete dump of every local diagnostic'}
(report/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as t:
 for f in files:
  h=hashlib.sha256();stream=t.extractfile(f['path'])
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
  assert h.hexdigest()==f['sha256'],f['path']
seal={'status':'PASS','files':{p.name:sha(p) for p in [report/'README.md',report/'final-checks.json',report/'manifest.json',archive]},'archiveMembersVerified':len(files)}
(report/'seal.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'members':len(files),'archiveBytes':archive.stat().st_size,'excludedRecords':len(excluded),'readback':'PASS'}))
