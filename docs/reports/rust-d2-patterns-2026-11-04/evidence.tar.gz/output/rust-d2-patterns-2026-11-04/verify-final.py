from pathlib import Path
import json,hashlib,re,gzip,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-patterns-2026-11-04'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
s=read(t/'compare-summary.json');counts={}
core={n:h for h,n in (line.split(None,1) for line in (t/'core/sourcehashes-01.sha256').read_text().splitlines())}
maps={'core':core,'sdk':read(t/'sdk/source-hashes-final.json'),'main':read(r/s['receipts']['main'])['sourceHashes'],'oracle':read(r/s['guards']['oracle']['guards']),'product':read(r/s['receipts']['product'])['hashesBefore'],'filteredLegacy':read(r/s['receipts']['legacy'])['sourceHashes'],'drivers':s['driverSourceHashes'],'inheritedTsIntegration':read(t/'inherited-ts-integration-source.json')['files']}
for label,files in maps.items():
 bad=[n for n,h in files.items() if sha(r/n)!=h];assert not bad,(label,bad);counts[label]=len(files)
assert read(r/s['receipts']['product'])['hashesBefore']==read(r/s['receipts']['product'])['hashesAfter']
for label in ['main','legacy']:
 a=read(r/s['guards'][label]['guards'])
 assert all(x['status']=='PASS' and x['hashesBefore']==x['hashesAfter'] for x in a)
assert read(r/s['guards']['oracle']['guards'])==read((r/s['guards']['oracle']['guards']).with_name('hashes-after.json'))
base=read(t/'baseline.json');allowed={'HANDOFF.md','README.md','docs/rust-roadmap.md','apps/docs/src/roadmap.md','apps/docs/src/guide/rust.md','apps/docs/src/guide/document-rules.md','apps/docs/src/schemas/custom.md','apps/docs/src/schemas/document.md','experiments/rust-sdk/README.md','experiments/rust-shadow/src/runtime_schema.rs'}
changed=[n for n,h in base['files'].items() if sha(r/n)!=h];assert set(changed)<=allowed,changed
for old in read(t/'earlier-seals.json'):
 p=r/old['report'];assert sha(p/'seal.json')==old['sealSha256']
 for n,h in read(p/'seal.json')['files'].items():assert sha(p/n)==h,(p,n)
previous=read(r/'output/rust-d2-fieldrefs-2026-11-04/compare-regressions/run-2026-11-04T07-07-06.074Z-60037/receipt.json')['frozenHashes'];oldbins={n:h for n,h in previous.items() if n.startswith('output/')}
for n,h in oldbins.items():assert sha(r/n)==h,n
example=(r/'experiments/rust-sdk/examples/runtime_patterns.rs').read_text();comment,body=example.split('\n',1);assert comment.startswith('//! ')
for n in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
 text=(r/n).read_text().split('### Product validation patterns',1)[1];fence=re.search(r'```rust\n(.*?)```',text,re.S).group(1);assert fence==body,n
for n in ['sdk/readme-consumer/src/main.rs','sdk/guide-consumer/src/main.rs']:assert (t/n).read_text()==body,n
compression=read(t/'compare-compression-receipt.json')
for row in compression['files']:
 p=r/row['compressed'];assert sha(p)==row['compressedSha256'];h=hashlib.sha256();size=0
 with gzip.open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 assert h.hexdigest()==row['originalSha256']==row['roundtripSha256'] and size==row['originalBytes']
for n,total in [('core-full-02.log',177),('sdk/full-01.log',113)]:
 text=(t/n).read_text();numbers=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',text);assert sum(int(x) for x,y in numbers)==total and all(y=='0' for x,y in numbers),(n,numbers)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head==base['head']
d={'status':'PASS','sourceMaps':counts,'baselineChangesWithinOwnedScope':changed,'oldReportSeals':9,'oldTargetBinariesUnchanged':len(oldbins),'documentedBodySha256':hashlib.sha256(body.encode()).hexdigest(),'exampleDifference':'One module documentation comment only.','gzipRoundTrips':len(compression['files']),'gzipOriginalBytes':compression['originalBytes'],'head':head}
(t/'final-source-verification.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
