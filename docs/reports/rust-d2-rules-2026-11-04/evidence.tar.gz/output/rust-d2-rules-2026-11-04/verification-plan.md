# Runtime structured values and required-child rules

Preserve inherited uncommitted flow/grid/group/inline/span implementation.
The actual72file baseline is archived, not identified by GitHEAD alone.
Core, SDK and independent TS/native comparison own disjoint files.

Required: schema-driven recursive field attrs with independent leaf writers,
scalar/object/array value-mark handling only where TypeScript semantics can be
qualified, and flow.childRules min/max including deterministic required virtual
storage, real editing/materialization, selection, undo/redo and checkpoint retry.
Reject unsupported model-only fields/invalid refs before partial mutation.
JS object identity must not be silently replaced by JSON deep equality.
TS checkSchema and staged Doc.check validate positive inputs.

Exact semantic authoring comparison retains operation IDs, raw full History,
availability, nonempty pendingcarets, material state/model and clock. Each
runtime restores its own checkpoint; cross-wire exchange is not presumed.
Preserve per-attempt fixtures, failures, receipts and source snapshots; old
sealed reports untouched. Existing D3 physical-source/model compiler gaps stay
observed and explicit. Do not call an accepted schema with uneditable required
children complete support.

After native freeze rerun earlier scoped corpora with explicit supported/
rejected expectation migration and unchanged positive hashes. Never overlap
npm/docs builds with TS traces or workspace tests (dist is removed/recreated).
Run final fullworkspace then docsbuild/check sequentially and executable docs
consumer with frozen native source/data/manifest map.
No mobile, Chrome/performance/nativeprocess-servercrash, productionRust/WASM,
commit/push or registry publication is requested by this task.
