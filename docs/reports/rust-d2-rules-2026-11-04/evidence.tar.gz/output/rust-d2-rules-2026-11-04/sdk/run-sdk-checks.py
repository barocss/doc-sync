from pathlib import Path
import hashlib, json, os, subprocess, sys, time
root=Path('/Users/user/github/doc-sync')
out=root/'output/rust-d2-rules-2026-11-04/sdk'
name=sys.argv[1]
receipt=out/(name+'.json')
assert not receipt.exists()
base=json.loads((out.parent/'baseline.json').read_text())
paths=set(base['files'])
for crate in ['rust-sdk','rust-shadow']:
    package=root/'experiments'/crate
    for folder in ['src','tests','examples','data']:
        paths.update(str(p.relative_to(root)) for p in (package/folder).rglob('*') if p.is_file())
    for file in ['Cargo.toml','Cargo.lock']:
        if (package/file).is_file():paths.add(str((package/file).relative_to(root)))
paths.update(str(p.relative_to(root)) for p in (root/'experiments/runtime-document-rules').rglob('*') if p.is_file())
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
before=hashes()
(out/(name+'-sources-before.json')).write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,RUSTC='/opt/homebrew/bin/rustc',CARGO_TARGET_DIR=str(out.parent/'sdk-target'))
command=['/opt/homebrew/bin/cargo','test','--offline','--locked','--manifest-path','experiments/rust-sdk/Cargo.toml']
start=time.monotonic()
with (out/(name+'.log')).open('xb') as log:
    run=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
after=hashes()
(out/(name+'-sources-after.json')).write_text(json.dumps(after,indent=2)+'\n')
result={'status':'PASS' if run.returncode==0 and before==after else 'FAIL','exit':run.returncode,'seconds':round(time.monotonic()-start,3),'command':command,'sourceCount':len(before),'sourcesStable':before==after,'hashesBefore':before,'hashesAfter':after}
receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if not k.startswith('hashes')}))
sys.exit(0 if result['status']=='PASS' else 1)
