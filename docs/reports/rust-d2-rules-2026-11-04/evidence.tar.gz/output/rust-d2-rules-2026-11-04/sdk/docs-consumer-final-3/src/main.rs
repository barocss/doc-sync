use doc_sync_native_sdk::*;
use serde_json::{json, Value};

fn attrs(value: Value) -> Result<Attributes> { Ok(serde_json::from_value(value)?) }
fn style(doc: &mut RuntimeDocument) -> Result<Value> {
    let model = doc.model()?;
    Ok(model["children"].as_array().unwrap().iter()
        .find(|node| node["type"] == "title").unwrap()["attrs"]["style"].clone())
}
fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({
        "root":"page", "marks":[],
        "markValues":{"paint":{"default":null,"inherit":false}},
        "nodes":{
            "page":{"shape":"flow","children":["paragraph","title"],
                "default":"paragraph","childRules":{"title":{"min":1,"max":1}}},
            "paragraph":{"shape":"text"},
            "title":{"shape":"text","children":["tint"],"attrs":{"style":{
                "default":{"tone":"plain","metrics":{"weight":0}},"fields":{
                    "tone":{"default":"plain"},
                    "metrics":{"default":{"weight":0},"fields":{
                        "weight":{"default":0,"min":0,"max":5}
                    }}
                }
            }}},
            "tint":{"shape":"span","mark":"paint","attr":"value"}
        }
    }))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let title = RuntimeDocument::required_head(&Key::root(), "title", 0)?;
    let text = a.insert_text_at(
        &title, None, "A😀", Attributes::new(), EditOptions::default(), 1.0,
    )?;
    b.apply_remote(&text.ops)?;
    let ids = b.line_token_ids(&title)?;
    let foreign = b.insert_text_at(
        &title, ids.last(), " from B", Attributes::new(), EditOptions::default(), 2.0,
    )?;
    a.apply_remote(&foreign.ops)?;
    let local = a.set_attributes(&title, attrs(json!({"style":{
        "tone":"red", "metrics":{"weight":2}
    }}))?, EditOptions::default(), 3.0)?;
    b.apply_remote(&local.ops)?;
    // An explicit equal-value write still gives B ownership of this leaf.
    let fence = b.set_field_path(
        &title, "style", &["tone"], json!("red"), EditOptions::default(), 4.0,
    )?;
    a.apply_remote(&fence.ops)?;
    let undo = a.undo()?;
    b.apply_remote(&undo.ops)?;
    assert_eq!(style(&mut a)?, json!({"tone":"red","metrics":{"weight":0}}));
    let redo = a.redo()?;
    b.apply_remote(&redo.ops)?;
    assert_eq!(style(&mut a)?, json!({"tone":"red","metrics":{"weight":2}}));
    let ids = a.line_token_ids(&title)?;
    let paint = a.format_span(
        &ids[..1], "tint", json!({"tone":"warm","levels":[1,2]}),
        EditOptions::default(), 5.0,
    )?;
    b.apply_remote(&paint.ops)?;
    assert_eq!(a.model()?, b.model()?);
    let saved = a.checkpoint()?.to_json()?;
    let mut resumed = RuntimeDocument::restore(&RuntimeCheckpoint::from_json(&saved)?)?;
    assert_eq!(resumed.pending_changes(), a.pending_changes());
    let pending = resumed.pending_changes().to_vec();
    for _ in 0..2 {
        for change in &pending {
            b.apply_remote(&change.ops)?;
            resumed.apply_remote(&change.ops)?;
        }
    }
    assert_eq!(resumed.model()?, b.model()?);
    resumed.acknowledge(&pending)?;
    assert!(resumed.pending_changes().is_empty());
    println!("PASS: required title, fields, foreign writer, JSON mark, restart/retry/ACK");
    Ok(())
}
