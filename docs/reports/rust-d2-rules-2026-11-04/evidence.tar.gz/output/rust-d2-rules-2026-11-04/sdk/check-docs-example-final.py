from pathlib import Path
import hashlib,json,os,re,subprocess,time,sys
root=Path('/Users/user/github/doc-sync');out=root/'output/rust-d2-rules-2026-11-04/sdk'
run_name=sys.argv[1]; suite=sys.argv[2]
paths=['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']
programs=[]
for name in paths:
 text=(root/name).read_text();found=re.search(r'<!-- runtime-rules-rust-example -->\n```rust\n(.*?)```',text,re.S);assert found,name;programs.append(found.group(1))
assert programs[0]==programs[1],'embedded programs differ'
assert len(programs[0].splitlines())<=140
consumer=out/run_name;(consumer/'src').mkdir(parents=True,exist_ok=True)
(consumer/'Cargo.toml').write_text('[package]\nname="rules-docs-consumer"\nversion="0.0.0"\nedition="2021"\n\n[dependencies]\ndoc-sync-native-sdk={path="'+str(root/'experiments/rust-sdk')+'"}\nserde_json="=1.0.140"\n')
(consumer/'src/main.rs').write_text(programs[0])
source_paths=json.loads((out/(suite+'-sources-after.json')).read_text())
def hashes():return{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source_paths}
before=hashes();(out/(run_name+'-sources-before.json')).write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,RUSTC='/opt/homebrew/bin/rustc',CARGO_TARGET_DIR=str(out/'docs-example-target'))
commands=[['/opt/homebrew/bin/cargo','generate-lockfile','--offline','--manifest-path',str(consumer/'Cargo.toml')],['/opt/homebrew/bin/cargo','run','--offline','--locked','--manifest-path',str(consumer/'Cargo.toml')]]
start=time.monotonic();codes=[]
with (out/(run_name+'.log')).open('w') as log:
 for cmd in commands:
  result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240);codes.append(result.returncode)
  if result.returncode:break
after=hashes();(out/(run_name+'-sources-after.json')).write_text(json.dumps(after,indent=2)+'\n')
result={'status':'PASS' if all(c==0 for c in codes) and len(codes)==2 and before==after and before==source_paths else 'FAIL','commands':commands,'exitCodes':codes,'seconds':round(time.monotonic()-start,3),'sourceCount':len(before),'nativeSourcesStable':before==after,'matchesSuiteBefore':before==source_paths,'matchesSuiteAfter':after==source_paths,'suiteSnapshot':suite,'embeddedProgramsEqual':True,'exampleLines':len(programs[0].splitlines()),'exampleSha256':hashlib.sha256(programs[0].encode()).hexdigest(),'docsSha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'cargoLockSha256':hashlib.sha256((consumer/'Cargo.lock').read_bytes()).hexdigest() if (consumer/'Cargo.lock').exists() else None,'nativeHashesBefore':before,'nativeHashesAfter':after}
(out/(run_name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if not k.startswith('nativeHashes')},indent=2));raise SystemExit(0 if result['status']=='PASS' else 1)
