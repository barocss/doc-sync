from pathlib import Path
import json,hashlib,tarfile,subprocess,sys
root=Path('/Users/user/github/doc-sync');out=root/'output/rust-d2-rules-2026-11-04/core'
baseline=json.loads((out.parent/'baseline.json').read_text()); verified={}
with tarfile.open(out.parent/'baseline.tar.gz') as tar:
 for path,wanted in baseline['files'].items():
  actual=hashlib.sha256(tar.extractfile(path).read()).hexdigest();assert actual==wanted,path;verified[path]=actual
(out/'baseline-archive-verified.json').write_text(json.dumps({'status':'PASS','head':baseline['head'],'fileCount':len(verified),'files':verified},indent=2)+'\n')
base={'root':'doc','marks':[],'nodes':{'doc':{'shape':'flow','children':['p'],'default':'p'},'p':{'shape':'text'}}}
fields=json.loads(json.dumps(base));fields['nodes']['p']['attrs']={'meta':{'default':{'layout':{'width':0}},'fields':{'layout':{'default':{'width':0},'fields':{'width':{'default':0}}}}}}
rules=json.loads(json.dumps(base));rules['nodes']['doc']['childRules']={'p':{'min':2,'max':2}}
marks=json.loads(json.dumps(base));marks['markValues']={'paint':{'default':None}}
results=[]
for label,schema,ops in [('structured-document-fields',fields,[]),('required-editable-text',rules,[]),('nullable-composite-mark-value',marks,[{'t':'text','id':{'lamport':1,'actor':'A'},'origin':{'lamport':0,'actor':'~root'},'units':[97,98],'marks':{'paint':{'tone':'warm','parts':[1,'x']}}}])]:
 identity='sha256:'+hashlib.sha256(json.dumps(schema,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
 requests=[{'cmd':'new','replica':'r','actor':'A','schema':identity,'runtimeSchema':schema}]
 if ops:requests.append({'cmd':'apply','replica':'r','schema':identity,'ops':ops})
 row={'name':label,'requests':requests}
 for phase,binary in [('before','/tmp/doc-sync-d2-core-before-target/debug/doc-sync-rust-shadow'),('after','/tmp/doc-sync-d2-core-target/debug/doc-sync-rust-shadow')]:
  p=subprocess.run([binary],input=''.join(json.dumps(x,separators=(',',':'))+'\n' for x in requests),text=True,capture_output=True,check=True)
  values=[json.loads(x) for x in p.stdout.splitlines()];row[phase]=values
 assert row['before'][-1]['ok']==False,row
 assert row['after'][-1]['ok']==True,row
 results.append(row)
(out/(sys.argv[1] if len(sys.argv)>1 else 'before-after-probes.json')).write_text(json.dumps({'status':'PASS','baselineFileCount':len(verified),'cases':results},indent=2)+'\n')
print(json.dumps({'status':'PASS','baselineFileCount':len(verified),'beforeAfterCases':len(results)}))
