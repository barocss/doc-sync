# Experimental native Rust SDK

This private crate provides a callable Rust API over the experimental native engine in `../rust-shadow`. It does not start a JSONL process. `publish = false` prevents publication.

## Add a Cargo dependency

Create a Rust application with `cargo new /tmp/doc-sync-native-example`.
Add the following to its `Cargo.toml`. Replace the absolute path with your checkout:

```toml
[dependencies]
doc-sync-native-sdk = { path = "/absolute/path/to/doc-sync/experiments/rust-sdk" }
```

Put the complete program below in the application's `src/main.rs`, then run
`cargo run --manifest-path /tmp/doc-sync-native-example/Cargo.toml`.
This native path does not require an npm build.

Use `Document` for one actor and one fixed `SchemaPreset`. Local commands return a `Change` with typed `Op` values. The host must send those operations to peers. Use `apply_remote` for delivery and exact retry. Remote delivery does not add local history or pending changes. Use a distinct actor for each independent author.

```rust
use doc_sync_native_sdk::{Attributes, Document, EditOptions, Key, SchemaPreset};

fn main() -> Result<(), doc_sync_native_sdk::Error> {
    let mut alice = Document::new("alice", SchemaPreset::Text)?;
    let mut bob = Document::new("bob", SchemaPreset::Text)?;
    let change = alice.insert_text(
        &Key::root(), "hello", Attributes::new(), EditOptions::default(), 0.0,
    )?;
    bob.apply_remote(&change.ops)?;
    let undo = alice.undo()?;
    bob.apply_remote(&undo.ops)?;
    Ok(())
}
```

Run the complete two-actor, undo/redo, checkpoint, restart, and duplicate delivery example:

```sh
CARGO_TARGET_DIR=output/r4-sdk-target cargo run --offline \
  --manifest-path experiments/rust-sdk/Cargo.toml --example two_actors
```

Run tests from the repository root:

```sh
CARGO_TARGET_DIR=output/r4-sdk-target cargo test --offline \
  --manifest-path experiments/rust-sdk/Cargo.toml
```

See the [Rust guide](../../apps/docs/src/guide/rust.md#checkpoint-retry-selection-and-history-recipe) for a complete selection, checkpoint, exact retry, acknowledgement, and History recipe. See [packages and engines](../../apps/docs/src/guide/packages.md#engine-selection-is-a-separate-milestone) for the TypeScript client and browser adapter boundary.

## Supported presets

`Document` keeps these six fixed presets. Its enum is closed, and an instance cannot change its preset. Use the separate `RuntimeSchema` and `RuntimeDocument` API below for supported custom schemas.

| SDK preset | Native schema identity | Native capability |
| --- | --- | --- |
| `Text` | `flow-root-paragraph:boolean-marks:bold,italic:v1` | none |
| `Paragraphs` | `flow-root-paragraph:boolean-marks:bold,italic:v1` | `paragraph-markers-v1` |
| `Blocks` | `general-flow-blocks:json-attrs:v1` | `general-blocks-attrs-v1` |
| `Nested` | `nested-flows-tables:json-attrs:v1` | `nested-flows-tables-v1` |
| `Shapes` | `groups-inline-spans:json-attrs:value-marks:v1` | `groups-inline-spans-v1` |
| `Movement` | `movement-logical-storage:json-attrs:value-marks:v1` | `movement-logical-storage-v1` |

The native preset validates node types, attributes, marks, boundaries, and moves. `Mark::Link` requires a preset that supports links. A typed operation can still be invalid for its preset. The engine rejects invalid input.

## Runtime schemas

`RuntimeSchema::compile(serde_json::Value)` compiles and owns a pure JSON tree schema.
`RuntimeDocument::new(actor, schema)` creates its native storage. Custom names are
strings supplied at runtime. The native binary does not contain a registry of
those names. Compilation checks the complete schema before it creates a replica.

| Domain | Native runtime rules | Explicit limits |
| --- | --- | --- |
| Document | Recursive `flow`/`grid`/`row`/`cell`/`text`/`atom`/`group`/`inline`/`span`, defaults, nested field registers, required min/max children, scalar/nullable JSON value marks, boolean marks, selection and block movement | `text: false`, axis movement, derived-wrapper attributes and general computed rules remain unavailable |
| Graphic | Root and nested `container` nodes, `text` and `atom` nodes, declared child membership, custom root/type/attribute/mark names, scalar and declared field attributes | Flow/grid nodes, inline children, value marks, and computed attributes are unavailable |
| Spreadsheet | `SpreadsheetSchema::compile` plus `RuntimeSheet`, 1–128 arbitrary declared field names, scalar defaults, type/enum/range/string-length constraints | Fixed axes; no formulas, structural axes, or renderer |

Unsupported tree rules return `UnsupportedSchema at <JSON path>: <reason>`.
The native string-pattern grammar supports anchored ASCII literals, the declared
six/eight-digit hex color patterns, and the control-free bounded string pattern
`^[^\\u0000-\\u001f\\u007f]{0,N}$` with `N <= 1000000`. Other regex syntax
fails compilation. No callback or executable schema rule is accepted.

Tree identities use the same canonical JSON SHA-256 as TypeScript
`schemaVersion`. Explicit `domain: "document"` has the identity of the omitted
legacy document domain. UI metadata is included in the fingerprint. Native tree compilation rejects JSON integer values that JavaScript cannot represent exactly, including values in UI metadata.
`SpreadsheetSchema::identity` matches `spreadsheetSchemaVersion`.

`RuntimeDocument` provides generic `insert`, `set_attribute`, `set_field`,
`insert_label_text`, and `reparent` methods for graphics. For Document flows,
use `insert_block_in` and `insert_text_in`. `record` accepts typed wire operations.
`model` returns JSON because custom schemas define their own names. Both domains
use the existing native LWW, deletion, and selective History rules.

The current suites pass **78 SDK tests and 120 shadow-core tests**. The shapes checkpoint passed 67 and 107. The grid checkpoint passed 60 and 96. The recursive-flow
checkpoint passed 55 and 89; the earlier flat checkpoint passed 48 and 78 respectively. D2 remains partial;
these counts do not qualify full product schemas or a production backend.

`insert_block_in` and `insert_text_in` address a flow's **physical source
sequence**. `None` parent selects the root; a parent key selects that flow's
body. `after` and `right` identify source tokens. A moved block retains its
original source sequence. These methods do not compile current model positions
or the complete TypeScript `EditOp` surface. Root-only `insert_block` and
`insert_text` remain available.

Use `flow_text_ids(parent)` to read visible UTF-16 token keys in that source
sequence. `capture_selection` and `resolve_selection` convert nested model paths
and stable anchor ranges; the final text path component is a UTF-16 offset.
Use `reparent_block` for a compatible Document move. Its `after` argument names
a block; the SDK uses that block's current accepted placement writer. This
supports an anchor that has already moved across flows and excludes a move
ignored by cycle projection. Graphic moves keep the separate `reparent` API.

The expanded 150-action comparison found
`OBSERVED_D3_MODEL_INSERTION_MISMATCH`: insertion at a current model position
after earlier moves produced `Node + Move` in TypeScript and only `Node` through
the native physical-source helper. This is an observed failed case, not a
`NOT_RUN` result. Its failing traces remain in
`output/rust-d2-nested-2026-11-04/compare/post-move-insert-gap-*`.
The qualified comparison passes 162 actions across two renamed schemas. It
creates future sibling flows before moves and checks the source-anchor contract. It does not close this D3 compiler
gap. A full `EditOp` compiler, arbitrary post-move selection, live schema changes,
protected GC, and production Client/WASM integration remain open.


`RuntimeSheet` takes `RuntimeSheetOptions {actor, sheet_id, rows, columns, schema}`.
Patches are `BTreeMap<String, RuntimeValue>`. `get_cell` returns stored non-null
values. `get_cell_value` resolves an unwritten or cleared field to its default
without creating a register. Custom operations carry the exact `schemaVersion`.
Legacy `SparseSheet` retains its existing v1 format and field order.

Runtime checkpoints retain the descriptor, its fingerprint, document or sheet
state, History, and exact pending queue. Restore recompiles the descriptor and
replays the journal before it commits state. Live checkpoint replacement requires
the same actor and schema identity. Checkpoints require trusted host storage.

Run the complete custom Graphic peer/checkpoint and Spreadsheet default/checkpoint
example from the repository root:

```sh
CARGO_TARGET_DIR=output/runtime-quickstart-target cargo +stable run --offline --locked \
  --manifest-path experiments/rust-sdk/Cargo.toml --example runtime_quickstart
```

Run the independent six-schema differential trace:

```sh
node experiments/runtime-schema-native/compare.mjs
node experiments/runtime-document-nested/compare.mjs
```

The six-schema trace builds one native binary and supplies two schemas per domain to one
process. It compares normalized Document/Graphic models and History availability.
Spreadsheet comparisons include exact operations, pending queues, journals,
History, and checkpoints. The receipt lists its exact scope and excluded work.
This does not qualify the full arbitrary Document schema surface or a browser,
WASM, renderer, transport, or release.

## Nested Document example

Add `serde_json = "1"` beside the Cargo path dependency. This complete program
creates two nested flow levels, delivers native operations between two actors,
restores a coupled checkpoint, retries pending changes twice, and verifies
model equality through undo/redo. The peer's text remains present.

<!-- runtime-nested-rust-example -->
```rust
use doc_sync_native_sdk::*;
use serde_json::json;

fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({
        "root": "page", "marks": ["strong"],
        "nodes": {
            "page": {"shape": "flow", "children": ["line", "section"], "default": "line"},
            "section": {
                "shape": "flow", "children": ["line", "section"], "default": "line",
                "attrs": {"rank": {"default": 0, "min": 0, "max": 5}}
            },
            "line": {"shape": "text"}
        }
    }))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let (outer, _) = a.insert_block_in(
        "section", None, None, None, Attributes::new(), EditOptions::default(), 1.0,
    )?;
    let (inner, _) = a.insert_block_in(
        "section", Some(&outer), None, None, Attributes::new(), EditOptions::default(), 2.0,
    )?;
    a.insert_text_in(
        Some(&inner), None, "Hello😀", Attributes::new(), EditOptions::default(), 3.0,
    )?;
    for change in a.pending_changes() {
        b.apply_remote(&change.ops)?;
    }
    assert_eq!(a.model()?, b.model()?);

    // B writes into the same nested body. A receives B's exact operations.
    let ids = b.flow_text_ids(Some(&inner))?;
    let foreign = b.insert_text_in(
        Some(&inner), ids.last(), " from B", Attributes::new(), EditOptions::default(), 4.0,
    )?;
    a.apply_remote(&foreign.ops)?;
    let own = a.set_attribute(&outer, "rank", json!(3), EditOptions::default(), 5.0)?;
    b.apply_remote(&own.ops)?;
    let expected = a.model()?;
    let text_ids = a.flow_text_ids(Some(&inner))?;
    let pending = a.pending_changes().to_vec();
    let saved = a.checkpoint()?.to_json()?;
    a = RuntimeDocument::restore(&RuntimeCheckpoint::from_json(&saved)?)?;
    assert_eq!(a.pending_changes(), pending.as_slice());

    // Retry on both actors without recording new History or pending changes.
    let before_retry = a.checkpoint()?.to_json()?;
    for _ in 0..2 {
        for change in &pending {
            a.apply_remote(&change.ops)?;
            b.apply_remote(&change.ops)?;
        }
    }
    assert_eq!(a.checkpoint()?.to_json()?, before_retry);
    assert_eq!(a.model()?, b.model()?);
    // A real host acknowledges only after its transport accepts this prefix.
    a.acknowledge(&pending)?;
    assert!(a.pending_changes().is_empty());

    let undo = a.undo()?;
    b.apply_remote(&undo.ops)?;
    assert_eq!(a.model()?, b.model()?);
    assert_eq!(a.flow_text_ids(Some(&inner))?, text_ids);
    let redo = a.redo()?;
    b.apply_remote(&redo.ops)?;
    assert_eq!(a.model()?, expected);
    assert_eq!(a.model()?, b.model()?);
    println!("PASS: nested peers, checkpoint, exact retry, acknowledgement, undo/redo");
    Ok(())
}
```

### Structured fields and required children

A Document attribute can declare recursive `fields`. Each leaf has an independent
LWW writer. Unwritten and null leaves read as their declared defaults.
`set_attributes(id, patch, options, time)` validates the whole patch, then records
one atomic transaction. `set_attribute` accepts a partial structured branch;
`set_field_path(id, attribute, &["branch", "leaf"], value, options, time)` writes
one declared leaf. A branch null resets every declared leaf. Omitted leaves keep
their values. Explicit equal-value updates retain their writers.
`set_cell_attribute` accepts the same patches for cells. `set_group_attribute`
expands them on explicit stored members. Its structured patch path requires
field specifications on all targeted members; mixed scalar/field group attributes
are outside this helper's compiler contract.

These field attributes are supported on stored text, flow, grid, atom and inline
nodes, and on cells. Root fields, row attributes, cell-body attributes, and
attributes on derived group/span wrappers remain unavailable. A field branch's
default must equal its child defaults. Leaves can hold scalar or safe JSON
object/array values. Keys that start with `$`, and `__proto__`, `constructor` or
`prototype` keys, fail validation. JSON nesting and field paths are bounded to
64 levels/segments. Three atomic-mark probes (`$bad`, `prototype`, and `constructor` keys) are
valid under TypeScript admission but rejected by this native safe-JSON subset.
They are retained as native-unsupported value cases, separate from invalid schemas.

Document value marks also accept safe JSON object/array **values** when their
default is null and they have no enum. They remain one atomic mark register;
`markValues.fields`, composite defaults and composite enum entries are rejected.
Null clears a mark. TypeScript copies composite marks for each UTF-16 token, so
equal adjacent object values can produce separate spans. Scalar mark defaults,
constraints and `inherit: true` keep their existing behavior.

A flow can declare `childRules: {title: {min: 1, max: 1}}`. Bounds are integers
from 0 to 1000. Projection supplies missing required slots, hides excess authored
candidates, and promotes the next candidate after deletion. Positive-minimum
cycles are rejected. Required text, atom, flow, grid and group slots have stable
reserved addresses. Required grids provide their initial row and column.
`required_head(parent_physical_head, kind, ordinal)` returns the source head;
`required_node` returns that head for text/group slots and the fixed node marker
for other shapes. Pass the root key or `flow_head(Some(&flow))` as the parent.
The reserved actor uses `~required:<URI parent>:<URI kind>:<ordinal>`; head,
nontext marker, initial row and initial column use Lamport values 0, 1, 2 and 3.
These IDs are schema-owned. A required marker cannot be deleted, moved or changed
to another type. `delete_block` clears required text and supported flow/text descendants while
keeping those slots. It does not recursively clear grid-cell lines. Removing a
required atom/grid marker is a no-op; edit grid cell tokens through the cell APIs. Attributes, concurrent text, token
selections, History and coupled checkpoint restore use the same native storage rules.

Source insertion still needs physical `after` and `right` keys. For a required
right boundary, use the canonical text/group head 0 or nontext marker 1 from
the same parent flow. A forged ordinal, foreign parent or noncanonical marker
fails before commit. Move anchors remain block keys or source heads; a character
is not a block move anchor. Generic birth operations and `record` retain supplied
scalar attributes. Only the group-member/inline semantic helpers omit default
birth attributes. Existing scalar and Graphic writers keep their prior behavior.

D2 remains partial. `text: false`, axis movement, derived stored attributes,
callback rules, arbitrary computed rules, live schema changes and a complete
model-position `EditOp` compiler remain open. Only the standard computed cell
metadata described below is accepted. The earlier post-move insertion and
empty-cell head-rewrite D3 failures remain separate evidence. An empty structured
patch `{}` also exposes a D3 compiler-only clock gap: both APIs produce no
operations or model/pending change, but TypeScript consumes a discarded compiler
ticket while the native source helper does not. No new clock or Client API was
added to hide that difference.

Independent comparison passes **260 semantic actions and 520 actor states**
across four renamed descriptors, plus 19 exact schema checks. It compares
operation IDs, full raw History, pending/carets, material state, selection,
clocks and normalized models with each runtime's own checkpoint restore. A
required-anchor projection cycle that hid nonempty content after move/undo/redo
was fixed in both TS and native engines; before-failure and focused regressions
are preserved. Earlier flow/grid/shapes and six runtime-profile corpora pass
again. See `docs/reports/rust-d2-rules-2026-11-04/` for the exact scope and
separate observed compiler/JSON-identity boundaries.

The rules checkpoint passes **78 SDK tests and 120 shadow-core tests**. The
shapes checkpoint's **67 SDK / 107 core** counts are historical. These native
checks do not qualify the production Client, renderer, WASM, transport, mobile,
checkpoint exchange between runtimes, or complete D2/D3 acceptance.

Add `serde_json = "=1.0.140"` beside the Cargo path dependency. This complete
program edits a required title, keeps a foreign equal-value leaf writer through
undo/redo, applies an atomic JSON mark, and restores/retries/acknowledges work:

This example serializes a checkpoint and reconstructs it in the same process.
It does not test native process termination or server crash recovery.

<!-- runtime-rules-rust-example -->
```rust
use doc_sync_native_sdk::*;
use serde_json::{json, Value};

fn attrs(value: Value) -> Result<Attributes> { Ok(serde_json::from_value(value)?) }
fn style(doc: &mut RuntimeDocument) -> Result<Value> {
    let model = doc.model()?;
    Ok(model["children"].as_array().unwrap().iter()
        .find(|node| node["type"] == "title").unwrap()["attrs"]["style"].clone())
}
fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({
        "root":"page", "marks":[],
        "markValues":{"paint":{"default":null,"inherit":false}},
        "nodes":{
            "page":{"shape":"flow","children":["paragraph","title"],
                "default":"paragraph","childRules":{"title":{"min":1,"max":1}}},
            "paragraph":{"shape":"text"},
            "title":{"shape":"text","children":["tint"],"attrs":{"style":{
                "default":{"tone":"plain","metrics":{"weight":0}},"fields":{
                    "tone":{"default":"plain"},
                    "metrics":{"default":{"weight":0},"fields":{
                        "weight":{"default":0,"min":0,"max":5}
                    }}
                }
            }}},
            "tint":{"shape":"span","mark":"paint","attr":"value"}
        }
    }))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let title = RuntimeDocument::required_head(&Key::root(), "title", 0)?;
    let text = a.insert_text_at(
        &title, None, "A😀", Attributes::new(), EditOptions::default(), 1.0,
    )?;
    b.apply_remote(&text.ops)?;
    let ids = b.line_token_ids(&title)?;
    let foreign = b.insert_text_at(
        &title, ids.last(), " from B", Attributes::new(), EditOptions::default(), 2.0,
    )?;
    a.apply_remote(&foreign.ops)?;
    let local = a.set_attributes(&title, attrs(json!({"style":{
        "tone":"red", "metrics":{"weight":2}
    }}))?, EditOptions::default(), 3.0)?;
    b.apply_remote(&local.ops)?;
    // An explicit equal-value write still gives B ownership of this leaf.
    let fence = b.set_field_path(
        &title, "style", &["tone"], json!("red"), EditOptions::default(), 4.0,
    )?;
    a.apply_remote(&fence.ops)?;
    let undo = a.undo()?;
    b.apply_remote(&undo.ops)?;
    assert_eq!(style(&mut a)?, json!({"tone":"red","metrics":{"weight":0}}));
    let redo = a.redo()?;
    b.apply_remote(&redo.ops)?;
    assert_eq!(style(&mut a)?, json!({"tone":"red","metrics":{"weight":2}}));
    let ids = a.line_token_ids(&title)?;
    let paint = a.format_span(
        &ids[..1], "tint", json!({"tone":"warm","levels":[1,2]}),
        EditOptions::default(), 5.0,
    )?;
    b.apply_remote(&paint.ops)?;
    assert_eq!(a.model()?, b.model()?);
    let saved = a.checkpoint()?.to_json()?;
    let mut resumed = RuntimeDocument::restore(&RuntimeCheckpoint::from_json(&saved)?)?;
    assert_eq!(resumed.pending_changes(), a.pending_changes());
    let pending = resumed.pending_changes().to_vec();
    for _ in 0..2 {
        for change in &pending {
            b.apply_remote(&change.ops)?;
            resumed.apply_remote(&change.ops)?;
        }
    }
    assert_eq!(resumed.model()?, b.model()?);
    resumed.acknowledge(&pending)?;
    assert!(resumed.pending_changes().is_empty());
    println!("PASS: required title, fields, foreign writer, JSON mark, restart/retry/ACK");
    Ok(())
}
```

### Runtime Document groups, inline nodes and spans

Document descriptors support `group`, `inline`, `span`, and scalar or supported
nullable JSON `markValues`.
Groups collect consecutive stored text members. The containing flow's child
order selects the first matching group when groups share a member type.
A span uses its declared `mark` and `attr`. The first active span in node
declaration order becomes the wrapper; other value marks remain on child runs.
Neither wrapper has a stored ID.
Insert group members and set value marks; do not insert a group or span `Node`.
Group `by` values project onto the group and are removed from its member model.
The new group-member and inline helpers validate the supplied birth attributes,
then omit null/default values from the stored birth operation. Unknown keys and
invalid values still fail. Attribute and mark updates retain their writer
operations, including same-value updates.

Use `insert_group_member_at`, `insert_inline_at`, and `insert_text_at` with a
physical head from `flow_head` or `cell_head`. Use `set_group_attribute` for
explicit member keys and their current effective text types, `set_attribute`
for inline attributes, and `delete` for
inline keys. `format_tokens` sets a declared boolean or supported atomic value mark; `format_span`
resolves the mark from a span type. `line_token_ids` returns visible character
and inline keys in that physical source line. A surrogate pair uses two UTF-16
positions; an inline token uses one. Selection APIs retain stable token anchors.
Moved blocks keep their birth sequence. These APIs do not compile arbitrary
current model insertion paths.

Scalar value marks use their declared defaults and constraints. A non-null
default fixes the scalar type; a null default also permits the safe JSON values
under the restrictions above.
Null clears a mark, and default values do not create span wrappers.
`insert_inherited_text_at` inherits boolean marks and value marks whose
specification has `inherit: true`. Explicit `insert_text_at` uses supplied marks.
Graphic runtime value marks still fail compilation; this expansion is Document
support only.

Local edits use the existing selective History, pending queue, and coupled
checkpoint APIs. Undo retains later foreign writers. Retry exact operations
with `apply_remote`; acknowledge only an accepted exact pending prefix.
`text: false`, axis movement, and attributes declared directly on derived
group/span wrappers remain unsupported. Structured fields and child rules use
the bounded APIs above.
General computed rules and live schema changes also remain open. D3 still
needs a complete model-position `EditOp` compiler. Full WASM, production Client,
transport, browser, and recovery/GC integration remain separate delivery work.

The historical shapes checkpoint passed **67 SDK tests and 107 shadow-core tests**. The
previous grid checkpoint passed 60 and 96 respectively; those are historical
counts. D2 remains partial. These checks do not qualify a production backend.

Independent native/TypeScript authoring passes **188 actions and 376 actor
states** across two renamed descriptors, each with multiple group/inline/span
types. The twelve schema checks now include eleven rejections and one explicit
cardinality admission after the required-child extension.
Raw History, typed operations/IDs, pending/carets, UTF-16 selections, material
storage, clocks and normalized models are compared. Each runtime restores its
own checkpoint format; cross-runtime checkpoint exchange is not qualified.
A separate empty-cell group insertion probe still observes the D3 head-rewrite
and trailing-boundary gap. Physical-source helpers do not compile that model
operation. Evidence is in `docs/reports/rust-d2-shapes-2026-11-04/`.

Add `serde_json = "1"` beside the native SDK Cargo path dependency. This complete
two-peer program checks group/inline/span edits, foreign value preservation
through undo/redo, checkpoint restore, exact retry, and acknowledgement.

<!-- runtime-shapes-rust-example -->
```rust
use doc_sync_native_sdk::*;
use serde_json::{json, Value};

fn find<'a>(value: &'a Value, kind: &str) -> Option<&'a Value> {
    if value["type"] == kind { return Some(value); }
    match value {
        Value::Object(fields) => fields.values().find_map(|v| find(v, kind)),
        Value::Array(items) => items.iter().find_map(|v| find(v, kind)),
        _ => None,
    }
}
fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({
        "root":"book", "marks":["bold"],
        "markValues":{"destination":{"default":"","inherit":false}},
        "nodes":{
            "book":{"shape":"flow","children":["line","list"],"default":"line"},
            "line":{"shape":"text","children":["badge","link"]},
            "list":{"shape":"group","children":["entry"],"by":["depth"]},
            "entry":{"shape":"text","children":["badge","link"],
                "attrs":{"depth":{"default":0}}},
            "badge":{"shape":"inline","attrs":{"label":{"default":""}}},
            "link":{"shape":"span","mark":"destination","attr":"href"}
        }
    }))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let head = RuntimeDocument::flow_head(None)?;
    let (entry, _) = a.insert_group_member_at(
        &head, "list", "entry", None, None, Attributes::new(), EditOptions::default(), 1.,
    )?;
    a.insert_text_at(
        &head, Some(&entry), "A😀", Attributes::new(), EditOptions::default(), 2.,
    )?;
    let text = a.line_token_ids(&head)?;
    assert_eq!(text.len(), 3); // UTF-16: A plus two surrogate units.
    let (badge, _) = a.insert_inline_at(
        &head, "badge", text.last(), Attributes::new(), EditOptions::default(), 3.,
    )?;
    assert_eq!(a.line_token_ids(&head)?.len(), 4); // Inline occupies one position.
    a.set_attribute(&badge, "label", json!("status"), EditOptions::default(), 4.)?;
    a.set_group_attribute(&[entry], "list", "depth", json!(1), EditOptions::default(), 5.)?;
    a.format_span(&text, "link", json!("own"), EditOptions::default(), 6.)?;
    for change in a.pending_changes() { b.apply_remote(&change.ops)?; }
    let foreign = b.format_span(&text, "link", json!("peer"), EditOptions::default(), 7.)?;
    a.apply_remote(&foreign.ops)?;
    let undo = a.undo()?;
    b.apply_remote(&undo.ops)?;
    assert_eq!(find(&a.model()?, "link").unwrap()["attrs"]["href"], "peer");
    let redo = a.redo()?;
    b.apply_remote(&redo.ops)?;
    assert_eq!(find(&a.model()?, "link").unwrap()["attrs"]["href"], "peer");
    assert_eq!(a.model()?, b.model()?);

    let pending = a.pending_changes().to_vec();
    let checkpoint = a.checkpoint()?.to_json()?;
    a = RuntimeDocument::restore(&RuntimeCheckpoint::from_json(&checkpoint)?)?;
    assert_eq!(a.pending_changes(), pending.as_slice());
    let before_retry = a.checkpoint()?.to_json()?;
    for _ in 0..2 {
        for change in &pending {
            a.apply_remote(&change.ops)?;
            b.apply_remote(&change.ops)?;
        }
    }
    assert_eq!(a.checkpoint()?.to_json()?, before_retry);
    assert_eq!(a.model()?, b.model()?);
    // A host acknowledges only a transport-accepted exact prefix.
    a.acknowledge(&pending)?;
    assert!(a.pending_changes().is_empty());
    println!("PASS: shapes, foreign value, History, checkpoint, retry, acknowledgement");
    Ok(())
}
```

### Runtime Document grids

A descriptor can declare multiple `grid -> row -> cell -> flow` chains with
custom names. Each cell body uses its declared flow default and child rules.
A grid can be nested in a flow or a cell. Grid and cell scalar attributes use
the declared defaults and constraints.

The grid checkpoint passed **60 SDK tests and 96 shadow-core tests**.
The later shapes checkpoint passed **67 SDK tests and 107 shadow-core tests**.
The recursive-flow checkpoint passed 55 and 89 respectively. D2 remains partial.
This native evidence does not qualify full D2, a production backend, Client
integration, mixed-runtime network delivery, or WASM.

The grid comparison passes **180 independent actions and 360 actor states**
across two renamed descriptors, each containing two different grid chains.
It compares typed operations/IDs, raw History, pending/carets, models and
material storage under declared format projections. The twelve schema checks
now include seven targeted rejections and five explicit admissions for newly
supported group/inline/value-mark/span and cardinality descriptors. Native and TS checkpoint
formats are different; this is recovery parity within each runtime, not wire
exchange. A separate post-move insertion probe still observes the D3 compiler
gap. The source-bound evidence is in `docs/reports/rust-d2-grid-2026-11-04/`.

Use `insert_grid_at` to create a grid and its rows and columns in one History
transaction. Use `insert_grid_row` and `insert_grid_column` for later axes;
`delete` removes axis keys. `insert_cell_block` and `insert_cell_text` edit cell
content. `set_cell_attribute`, `merge_cells`, and `split_cell` update cell state.
Covered cells retain their content. Splitting reveals their retained content.
`reparent_block` moves a compatible block or grid to a flow;
`reparent_block_to_cell` moves it to a cell. Axis movement is unsupported.

`flow_head`, `grid_rows_head`, `grid_columns_head`, and `cell_head` return
physical storage addresses. Rows and columns have stable token identities;
`col` is a reserved wire type. `insert_grid_at` takes a physical flow head and
positive dimensions. It allocates a dense table, so use bounded dimensions.
It does not compile a model insertion position or add a trailing text block.
Cell `after` and `right` arguments also identify physical source tokens.
Moved blocks retain their original source sequence. Selection APIs resolve
model paths and UTF-16 offsets. The observed D3 model-insertion mismatch above
remains open.

Only the standard computed cell metadata is accepted: `colspan` and `rowspan`
with default `1` and optional minimum `1`, and `spanned` with default `false`.
These values come from span projection and cannot be written directly.
Other computed rules, row attributes, model-only cell-body attributes,
axis movement, `text: false`, and derived group/span attributes remain unsupported. Runtime groups, inline nodes,
spans and scalar Document value marks use the source-token APIs above.

The independent grid corpus authors TypeScript and native semantic actions for
renamed chains, cell bodies, selection, axes, spans, History, pending changes,
and checkpoint recovery. Its native driver uses SDK helpers. This is a bounded
native comparison; it does not establish a browser or network adapter.

This complete consumer program uses two grid chains and two actors. It checks
foreign text through undo/redo, merge/split visibility, checkpoint input,
duplicate pending replay, and acknowledgement. Add `serde_json = "1"` beside
the native SDK Cargo path dependency.

<!-- runtime-grid-rust-example -->
```rust
use doc_sync_native_sdk::*;
use serde_json::{json, Value};

fn has_units(node: &Value, text: &str) -> bool {
    if node["attrs"]["spanned"] == true {
        return false;
    }
    let units: Vec<u16> = text.encode_utf16().collect();
    match node {
        Value::Object(fields) => {
            fields.get("units") == Some(&json!(units))
                || fields.values().any(|value| has_units(value, text))
        }
        Value::Array(values) => values.iter().any(|value| has_units(value, text)),
        _ => false,
    }
}

fn find_type<'a>(node: &'a Value, kind: &str) -> Option<&'a Value> {
    if node["type"] == kind {
        return Some(node);
    }
    node["children"]
        .as_array()?
        .iter()
        .find_map(|child| find_type(child, kind))
}

fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({"root":"notebook","marks":[],"nodes":{
        "notebook":{"shape":"flow","children":["line","section"],"default":"line"},
        "line":{"shape":"text"},
        "section":{"shape":"flow","children":["line","matrix"],"default":"line"},
        "matrix":{"shape":"grid","children":["band"]},
        "band":{"shape":"row","children":["tile"]},
        "tile":{"shape":"cell","children":["body"],"attrs":{
            "shade":{"default":"white"},
            "colspan":{"default":1,"min":1,"computed":true},
            "rowspan":{"default":1,"min":1,"computed":true},
            "spanned":{"default":false,"computed":true}}},
        "body":{"shape":"flow","children":["line","detail"],"default":"line"},
        "detail":{"shape":"grid","children":["track"]},
        "track":{"shape":"row","children":["entry"]},
        "entry":{"shape":"cell","children":["content"]},
        "content":{"shape":"flow","children":["caption"],"default":"caption"},
        "caption":{"shape":"text"}
    }}))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let options = EditOptions::default();
    let (section, _) = a.insert_block(
        "section",
        None,
        None,
        Attributes::new(),
        options.clone(),
        1.,
    )?;
    let head = RuntimeDocument::flow_head(Some(&section))?;
    let (grid, rows, cols, _) = a.insert_grid_at(
        &head,
        "matrix",
        None,
        2,
        2,
        Attributes::new(),
        options.clone(),
        2.,
    )?;
    let cell = RuntimeDocument::cell_head(&grid, &rows[0], &cols[0])?;
    let (nested, nr, nc, _) = a.insert_grid_at(
        &cell,
        "detail",
        None,
        1,
        1,
        Attributes::new(),
        options.clone(),
        3.,
    )?;
    a.insert_cell_text(
        &nested,
        &nr[0],
        &nc[0],
        None,
        "own😀",
        Attributes::new(),
        options.clone(),
        4.,
    )?;
    for change in a.pending_changes() {
        b.apply_remote(&change.ops)?;
    }
    let peer = b.insert_cell_text(
        &grid,
        &rows[0],
        &cols[1],
        None,
        "peer",
        Attributes::new(),
        options.clone(),
        5.,
    )?;
    a.apply_remote(&peer.ops)?;
    let undo = a.undo()?;
    b.apply_remote(&undo.ops)?;
    assert!(!has_units(&a.model()?, "own😀"));
    assert!(has_units(&a.model()?, "peer"));
    let redo = a.redo()?;
    b.apply_remote(&redo.ops)?;
    assert!(has_units(&a.model()?, "own😀"));
    assert!(has_units(&a.model()?, "peer"));
    let merge = a.merge_cells(
        &grid,
        &rows[0],
        &cols[0],
        &rows[0],
        &cols[1],
        options.clone(),
        6.,
    )?;
    b.apply_remote(&merge.ops)?;
    let merged = a.model()?;
    let covered = &find_type(&merged, "matrix").unwrap()["children"][0]["children"][1];
    assert_eq!(covered["attrs"]["spanned"], true);
    assert!(has_units(&covered["children"], "peer"));
    assert!(!has_units(&merged, "peer"));
    let split = a.split_cell(&grid, &rows[0], &cols[0], options, 7.)?;
    b.apply_remote(&split.ops)?;
    assert!(has_units(&a.model()?, "peer"));
    assert_eq!(a.model()?, b.model()?);
    let saved = RuntimeCheckpoint::from_json(&a.checkpoint()?.to_json()?)?;
    let mut restored = RuntimeDocument::restore(&saved)?;
    let before = restored.checkpoint()?.to_json()?;
    let pending = restored.pending_changes().to_vec();
    for change in &pending {
        restored.apply_remote(&change.ops)?;
    }
    assert_eq!(restored.checkpoint()?.to_json()?, before);
    restored.acknowledge(&pending)?;
    assert!(restored.pending_changes().is_empty());
    assert_eq!(restored.model()?, b.model()?);
    println!("PASS: two grid chains, peers, foreign text, spans and checkpoint retry");
    Ok(())
}
```



## API and ownership

- `insert_text`, `delete_text`, and `set_mark` allocate fresh own tickets and record own history. `record` accepts an explicit typed batch for block births, moves, and other supported native operations. It requires fresh own tickets in order. It is not a retry API.
- `next_ticket` returns the next available ticket from the observed clock. It does not reserve a ticket. Construct all tickets in a batch with distinct clocks. A text birth occupies one clock per UTF-16 unit.
- `model` returns `ModelNode`, `ModelRun`, and `ModelText`. `Utf16Text` retains isolated surrogate units. Its conversion to a Rust `String` can fail.
- `capture_anchor`, `resolve_anchor`, `capture_selection`, and `resolve_selection` use native stable token anchors. `Position` indexes follow native model paths. The last text index is a UTF-16 offset. Anchor keys can include engine-owned storage heads.
- `undo` and `redo` return operations for peer delivery. The engine retains actor ownership and foreign edit fences. Each nonempty local result enters `pending_changes`.
- `acknowledge` removes only an exact pending prefix. An invalid acknowledgement leaves the queue intact. A host must call it only after its transport accepts that prefix.

## Coupled restart and retry

Persist `checkpoint().to_json()` as one host storage transaction. It contains the actor, preset, opaque native document/history checkpoint, and exact pending changes. `Checkpoint::from_json` validates with a fresh native server. `Document::restore` restores this coupled state. `restore_checkpoint` replaces a live document only when actor and preset match and all validation succeeds.

After restart, send the stored pending operations unchanged. The peer can receive them more than once. A retry must use `apply_remote`, including a retry on the source actor. Replaying pending changes does not add history or pending entries. Restoration rejects a pending queue that changes the native document/history when replayed. Pending changes can include undo and redo output.

The host must provide trusted checkpoint storage and transport. Checkpoints have no signature or authentication. These checks do not prove that an external checkpoint came from a trusted author.

## Error and proof limits

Native batches are atomic. SDK history commands also stage a fresh native replica before decoding their result. The SDK commits the replica and pending change only after decoding succeeds. Invalid checkpoint replacement leaves the live document intact. Staging uses a full checkpoint restore for each history command; this slice makes no performance claim.

This is an experimental native SDK slice. It provides no full `doc.edit` compiler, mark inheritance, text split/join compiler, network transport, durable storage driver, browser or editor adapter, WASM package, Node binding, or MCP integration. It is not a released Rust package. The native engine dependency keeps its existing scope and limits.

## Independent authoring comparison

Run `node --experimental-strip-types experiments/rust-sdk/scripts/compare-typescript.mjs` from the repository root. It executes `authoring_trace`, a Rust example that uses only public SDK authoring methods. The TypeScript oracle independently calls `Doc`, `History`, and editing commands. It does not send expected operations, state, or inverses to Rust.

The fixed 20-action trace covers two concurrent actors, explicit italic and empty marks, isolated UTF-16 surrogate units, a foreign same-value mark writer, concurrent deletion of the same unit, undo/redo, checkpoint restart, and exact pending retry twice on source and peer. After each action it compares generated operations, both models, both history availability flags, and both pending queues. It converts TypeScript strings to UTF-16 units, treats omitted empty birth marks as an empty map, and fills omitted empty model containers. It does not compare transport bytes or full internal history snapshot structures.

The script writes raw traces, source hashes, and its PASS/FAIL receipt to `output/r4-sdk-evidence/sdk-typescript-receipt.json`. This is bounded authoring proof for these declared actions. It does not prove a generic `doc.edit` compiler or any adapter, network, or production behavior.
