### 5.148 D2 nested schema payload references

Three agents own core, typedSDK/docs and independent TS/native authoring/probes.
Baseline is main1cfb7a2 plus193 captured inherited files, including shared-v2 and
the previous optional IPv4 demo testbinding repair. All seven prior D2 report
seals remain unchanged. Production TS CRDT/integration sources are unchanged in
this task. No commit/push, deployment or registry publication is included.

PAYLOAD_FORMAT doc-sync-runtime-schema-payload-v3 extends ReferenceSlot with
optional valuePath, omitted when empty. Typed Key(String)/Index(usize) selectors
traverse atomic schema-owned defaults/enums; objectkey"0" differs fromarrayindex0.
Nested endpoints are composite only, paths/depth bounded64. NonemptyvaluePath
requiresv3, and bare/v1/v2 root serialization/identity remain. Fieldbranches and
mutable runtime links remain separate. Existing root constructors stay valid;
direct Rust ReferenceSlot literals initialize value_path explicitly.

Compiled object classes propagate parent sharing DOWNWARD only. Sharing/equal
children never merge independent parents. Nested explicit representatives override
inherited child order through all shared parents. Ambiguous implicit overlaps,
cycles, unequal/unsafe nodes and invalid/missing/scalar/index-type paths reject.
Unicode path/member normalization uses UTF16 ordering. Classes cache representative
locators and target indices instead of full expanded value copies per node;
effective roots build fresh containers and clone leaves, avoiding repeated raw
subtree clones. Per-edit lookup does not recompile or scan the full graph.

SchemaValue::at_value_path and RuntimeSchema::reference_value_at retain original
at/source/index/valuePath. Operation binding.path remains the actual target;
root enum/default admission uses whole-object class rather than child equality
or the outer descriptor name. Raw manifest/DTO and diagnostic base identity
remain separate from effective rules and native semantic graph identity.
Targets keep independent writers; these are schema constants, not mutable
links or per-nested-key CRDT registers.

Core166PASS(prior156+new10), SDK105PASS(prior101+new4). All SDK examples build;
runtime_payload runs; the same README/guide program compiles/runs in two independent
Cargo consumers. Old pinned156 CLI digest and32source hashes reverified against
193baseline, rather than reusing an unverified count. Same5request sequence:
old0ok/current5ok with registers/source provenance/snapshot and clone-compatible
enumfallback checked. Initial wrong model expectation is preserved as failed
before-after01, corrected raw02 proof links exact sources/binaries.

Fresh final20driver run PASS;208source/binary hashes fixed. New2schema corpus
296commands/592actorstates has162 actual stagedDoc.edit checks. Nonempty nested
format→undo→JSONHistorycheckpoint→redo→delivery preserves SOURCE at/source/
index/valuePath and TARGET path exactly. Raw/JSON redo Doc.check rejection is
separate from successful material Doc.apply. Factory4directJS DAGs/200selections/
200actualDoc.edit, scope56, actualHub32+clone2 observations all PASS. All36
inherited runtime fixtures/helpers/docs match baseline. Eight inherited corpora
pass: flow162,grid180,shapes188,rules260,legacy82,composite160,alias182,shared246
commands (twoactor states each). No fixture or negative was removed/rewritten.
Trace-reuse diagnostics are not finalfresh qualification.

ActualTS Doc.apply structuredClone perpayload preserves INNER aliases while
separating schema/payloads; direct snapshots preserve that observation. JSON
snapshots and History.snapshot flatteninneraliases. Native public Value/model
is a JSONtree: physicalheapidentity NOT_REPRESENTED; liveobjectbridge
NOT_QUALIFIED. Logical schema/handle identity, factory payload order and material
History/recovery comparisons are qualified separately. Native own checkpoint
proof is not production process/server crash or mixed-wire acceptance. Composite
nonnull enum defaults still need ownroot-enum sharing in the native subset;
TS-valid unlisteddefaults can remain unsupported.

Preflight free space was363MiB. Completed owned prior traceoutputs101files were
losslessly gzipped with original/restored SHA proof (4,308,968,663bytes reclaimed);
sealed reports, source and binaries unchanged. Final drivers also compressed29
large traces after comparison. Independent audit restores all1,214,631,816rawbytes
with matching SHA+size and compressed hashes. No repeated ENOSPC occurred. Maps
and failed diagnostic artifacts are retained; original raw files can be restored
from gzip/earlier capsules. No unrelated workspace/source/process cleanup.

Nestedfield aliases, mutable runtime object graphs, callback/generalcomputed,
model-only attrs, text:false, axes, positive-min requiredcycles, fullproduct and
live schema/compiler coverage stayopen. Inherited D3 empty-patchclock/postmove/
emptyhead gaps stayopen. Rust/WASM Client/editor, nativeMap/List, protectedGC/
productionrecovery and a TS/native liveobjectcodec remain separate gates.
No Chrome/mobile, performance benchmark or productionnative crash test is claimed.

[Source-bound nested-payload report](docs/reports/rust-d2-payload-2026-11-04/README.md).
