import gzip, hashlib, json
from pathlib import Path
root=Path('/Users/user/github/doc-sync')
run=root/'output/rust-d2-payload-2026-11-04/regressions/run-2026-11-04T06-22-06.677Z-24415'
r=json.loads((run/'receipt.json').read_text())
assert r['status']=='PASS'
rows=[]
for result in r['results']:
 for item in result['compressed']:
  path=root/item['path']; compressed=hashlib.sha256(path.read_bytes()).hexdigest(); restored=hashlib.sha256(); size=0
  with gzip.open(path,'rb') as f:
   while chunk:=f.read(1024*1024):restored.update(chunk);size+=len(chunk)
  digest=restored.hexdigest();assert digest==item['rawSha256'];assert size==item['rawBytes']
  rows.append({**item,'compressedSha256':compressed,'restoredSha256':digest,'restoredBytes':size,'status':'PASS'})
(run/'gzip-roundtrip-audit.json').write_text(json.dumps({'status':'PASS','artifacts':len(rows),'rawBytes':sum(x['rawBytes'] for x in rows),'rows':rows},indent=2)+'\n')
results={x['name']:x for x in r['results']}
payload=Path(results['payload']['summary']['out'])
pr=json.loads((payload/'receipt.json').read_text())
with gzip.open(payload/'typescript-trace.json.gz','rt') as f:ts=json.load(f)
with gzip.open(payload/'native-trace.json.gz','rt') as f:native=json.load(f)
actions=lambda v:sum(len(d['trace']) for d in v['documents'])
actors=lambda v:sum(sum(k in row for k in ['A','B']) for d in v['documents'] for row in d['trace'])
edits=sum(row['editAdmission'] is not None for d in ts['documents'] for row in d['trace'])
assert actions(ts)==actions(native)==pr['semanticActions']==296
assert actors(ts)==actors(native)==592
assert edits==pr['typescriptDocumentEdits']==162
nonempty=[{'document':d['name'],'label':row['label'],'ops':len(row['ops'])} for d in ts['documents'] for row in d['trace'] if row['label'] in ['payload nonempty nested undo','payload nonempty nested redo after JSON checkpoint']]
assert len(nonempty)==4 and all(x['ops']>0 for x in nonempty)
history_refs=[]
for doc in native['documents']:
 initial=next(row for row in doc['trace'] if row['label']=='payload independent nested format')
 redo=next(row for row in doc['trace'] if row['label']=='payload nonempty nested redo after JSON checkpoint')
 refs=lambda row:[ref for op in row['ops'] for ref in op.get('references',[])]
 assert refs(initial) and refs(initial)==refs(redo)
 assert all(ref['source']=='enum' and ref['index']==0 and ref['valuePath']==['list'] and ref['path']==['value'] for ref in refs(redo))
 history_refs.append({'document':doc['name'],'initialReferences':refs(initial),'recoveredRedoReferences':refs(redo),'status':'PASS'})
load=lambda name:json.loads((Path(results[name]['summary']['out'])/'receipt.json').read_text())
factory=load('payload-factory'); scope=load('payload-scope');identity=load('payload-identity')
assert factory['factories']==factory['actualDocEdits']==200
assert len(scope['cases'])==56
assert len(identity['rows'])==32 and len(identity['clones'])==2
out={'status':'PASS','wrapperDrivers':len(r['results']),'all36InheritedRuntimeFilesUnchanged':len(r['positiveHashesUnchanged'])==36,'sourceAndBinaryDrift':False,'payload':{'semanticActions':actions(ts),'actorStateComparisons':actors(ts),'actualTypeScriptDocEdits':edits,'nonemptyNestedHistory':nonempty,'originalSourceProvenanceAfterJsonHistory':history_refs,'historyRedoAdmission':pr['historyRedoAdmission'],'nativeStoredHeapIdentity':pr['nativeStoredHeapIdentity'],'nativeLiveObjectBridge':pr['nativeLiveObjectBridge']},'factory':{'schemas':factory['schemas'],'selections':factory['factories'],'actualTypeScriptDocEdits':factory['actualDocEdits']},'scopeCases':len(scope['cases']),'identityHubRows':len(identity['rows']),'typeScriptCloneObservations':identity['clones'],'losslessCompressedArtifacts':len(rows),'inherited':[{'name':name,**{k:v for k,v in results[name]['summary'].items() if k!='out'}} for name in ['nested','grid','shapes','rules','legacy','composite','alias','shared']]}
(run/'count-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','out':str(run),'drivers':len(r['results']),'semanticActions':actions(ts),'actorStateComparisons':actors(ts),'actualTypeScriptDocEdits':edits,'gzipArtifacts':len(rows)}))
