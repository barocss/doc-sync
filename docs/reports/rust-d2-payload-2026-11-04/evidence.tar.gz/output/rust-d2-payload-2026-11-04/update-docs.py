from pathlib import Path
root=Path('/Users/user/github/doc-sync')
def rep(name,a,b):
 p=root/name;s=p.read_text();assert a in s,name;p.write_text(s.replace(a,b))
rep('README.md','explicit native reference groups across atomic attributes and value marks','explicit native reference groups across atomic attributes and value marks, including nested object/array value paths')
rep('apps/docs/src/schemas/document.md','References inside payloads, field-branch aliases and `markValues.fields` remain\nunsupported.','''The v3 payload descriptor adds typed `valuePath` selectors inside atomic
schema-owned defaults and enum values. Parent sharing also shares descendants;
sharing a child leaves its separate parents independent. Effective rules resolve
nested representative order without changing raw schema data. The native API
exposes logical schema references and JSON trees; it does not expose JavaScript
heap aliasing or linked mutable registers. Field-branch aliases and
`markValues.fields` remain unsupported.''')
rep('apps/docs/src/schemas/custom.md','native reference handles, default/enum sharing and cross-descriptor reference groups','native reference handles, default/enum and cross-descriptor groups, nested object/array schema value paths')
rep('apps/docs/src/schemas/custom.md','Nested payload identity and field-branch aliases, markValues.fields','Field-branch aliases and mutable runtime object graphs, markValues.fields')
p=root/'apps/docs/src/guide/document-rules.md';s=p.read_text();a='''This format covers whole atomic values, not pointers inside JSON payloads or
structured field branches.''';assert a in s;s=s.replace(a,'''The v2 format covers whole atomic values; v3 adds the nested schema paths below.
Structured field branches keep their independent register contract.''');s+='''
## Nested schema payloads

Use `compile_with_payload_references` for the v3 descriptor. A `ReferenceSlot`
can append `at_value_path` segments inside its atomic default or enum value.
`ValuePathSegment::Key` selects an object key and `Index` selects an array index.
The string key `"0"` and array index `0` are different selectors. Endpoints must
be composite objects or arrays, with safe paths bounded to 64 segments.

`SchemaValue::at_value_path` selects a schema-owned subtree for an existing
reference-aware edit helper. The source `at/source/index/valuePath` stays in
the operation metadata; its binding `path` still identifies the target. Edits
continue to write whole atomic registers. This does not add per-subkey LWW
merging or mutable links between document properties.

A shared parent induces sharing of its composite descendants. Child sharing
preserves the identity of distinct parents. Nested representatives propagate
through shared parents; ambiguous implicit overlaps and cycles reject. Equal
JSON values alone never imply a shared parent or child. Bare/v1/v2 root
constructors, serialized data and identities retain their existing behavior.

These are logical schema references. Actual TypeScript `Doc.apply` copies a
payload with `structuredClone`, which keeps internal aliases but separates it
from the schema and other payloads. JSON snapshots/History flatten those
aliases. Rust public values remain JSON trees, so heap-identity parity is not
represented by material JSON equality. See the
[compiled Rust example](./rust#nested-schema-payload-references) for API use and
its explicit storage/transport boundaries.
''';p.write_text(s)
rep('docs/rust-roadmap.md','Nested payload identity, field-branch aliases, markValues.fields, text:false,','Nested schema payload selectors are supported through v3 logical reference\nclasses. Field-branch aliases, mutable runtime graphs, markValues.fields, text:false,')
rep('docs/rust-roadmap.md','Nested\npayload reference graphs, field aliases, live transitions, remaining D2 and D3','Field aliases, mutable runtime graphs, live transitions, remaining D2 and D3')
p=root/'docs/rust-roadmap.md';s=p.read_text();needle='Replace preset/type-name branches with per-document compiled schema data.';assert needle in s;s=s.replace(needle,'''The payload extension adds `doc-sync-runtime-schema-payload-v3` and optional
`valuePath` selectors inside atomic default/enum JSON. Typed string keys and
integer array indices remain distinct. Parent identity propagates downward to
composite descendants; equal/shared children never merge distinct parents.
Nested representatives resolve through shared parents once, with ambiguous
explicit-group overlaps, unsafe paths and cycles rejected. Logical class
indices retain representative locators instead of a full payload copy per node.

Bare/v1/v2 wire and identity remain intact. The selected source valuePath is
separate from the target operation path and survives native History/checkpoints.
Source schema identity and actual TS stored-clone observations are qualified
separately: native public JSON values do not represent JS heap aliases. Mutable
runtime links, structured-field aliases, a TS/native object codec and production
Rust/WASM Client delivery remain separate gates. See the
[nested payload report](reports/rust-d2-payload-2026-11-04/README.md).

'''+needle);p.write_text(s)
p=root/'apps/docs/src/roadmap.md';s=p.read_text();a='Nested payload/field reference graphs and TS/native wire exchange\nremain open.';assert a in s;s=s.replace(a,'''The v3 extension adds nested object/array schema paths and downward descendant
identity with explicit source provenance. Mutable runtime/field reference graphs,
heap-identity transport and TS/native wire exchange remain open.''');p.write_text(s)
