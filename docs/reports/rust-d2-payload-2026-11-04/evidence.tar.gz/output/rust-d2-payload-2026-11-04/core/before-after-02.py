from pathlib import Path
import datetime,hashlib,json,subprocess,shutil,re
root=Path('/Users/user/github/doc-sync'); out=root/'output/rust-d2-payload-2026-11-04/core'; old=root/'output/rust-d2-shared-2026-11-04/core/target/debug/doc-sync-rust-shadow'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'))
assert not (out/'before-after-02.json').exists()
base=root/'output/rust-d2-payload-2026-11-04/baseline.json';baseline=json.loads(base.read_text())
oldsource=root/'output/rust-d2-shared-2026-11-04/core/source-current-01.json';previous=json.loads(oldsource.read_text())
assert all(baseline['files'].get(path)==digest for path,digest in previous.items())
assert sha(old)=='c6e5b488968cee28a214a559eea4a5edc53ffcd0b8bb704cb8debd4f33f9426e'
source={str(p.relative_to(root)):sha(p) for p in sorted((root/'experiments/rust-shadow').rglob('*')) if p.is_file() and (p.suffix=='.rs' and any(part in ['src','tests'] for part in p.parts) or p.name in ['Cargo.toml','Cargo.lock']) and 'target' not in p.parts}
dump(out/'source-current-02.json',source)
current=out/'current-cli-02';shutil.copy2(root/'output/rust-d2-payload-2026-11-04/native-target/debug/doc-sync-rust-shadow',current)
manifest={'root':'doc','marks':[],'markValues':{'source':{'default':{'child':{'a':1,'z':2}}}},'nodes':{'doc':{'shape':'flow','children':['p'],'default':'p'},'p':{'shape':'text','attrs':{'target':{'default':None,'values':[{'z':2,'a':1}]}}}}}
a={'at':['markValues','source'],'source':'default','valuePath':['child']};b={'at':['nodes','p','attrs','target'],'source':'enum','index':0}
groups=[{'representative':b,'slots':sorted([a,b],key=canonical)}]
dto={'format':'doc-sync-runtime-schema-payload-v3','manifest':manifest,'referenceGroups':groups};identity='sha256:'+hashlib.sha256(canonical(dto).encode()).hexdigest()
reference={'path':['value'],'schema':identity,**a}
op={'t':'reference','format':'doc-sync-runtime-reference-op-v1','op':{'t':'set','at':{'lamport':1,'actor':'A'},'ids':[{'lamport':0,'actor':'~root'}],'key':'target','value':{'a':1,'z':2}},'references':[reference]}
requests=[{'cmd':'new','actor':'A','runtimeSchema':dto},{'cmd':'apply','ops':[op]},{'cmd':'snapshot'},{'cmd':'apply','ops':[op]},{'cmd':'state'}]
for request in requests:request.update(replica='a',schema=identity)
wire=''.join(json.dumps(request,ensure_ascii=False,separators=(',',':'))+'\n' for request in requests);fixture=out/'before-after-requests-02.jsonl';fixture.write_text(wire)
runs={}
for name,binary in [('baseline',old),('current',current)]:
 result=subprocess.run([str(binary)],input=wire,text=True,capture_output=True,timeout=30,cwd=root)
 (out/f'{name}-responses-02.jsonl').write_text(result.stdout);(out/f'{name}-stderr-02.log').write_text(result.stderr)
 responses=[json.loads(line) for line in result.stdout.splitlines()]
 assert result.returncode==0 and len(responses)==len(requests)
 assert [response['ok'] for response in responses]==([False]*5 if name=='baseline' else [True]*5)
 if name=='current':
  assert responses[2]['snapshot']['ops']==[op]
  assert responses[1]['state']==responses[3]['state']==responses[4]['state']
  assert responses[1]['state']['model']['children'][0]['attrs']['target'] is None
  assert responses[1]['state']['items'][0]['attrs']['target']['value']=={'a':1,'z':2}
 runs[name]={'binary':str(binary.relative_to(root)),'binarySha256':sha(binary),'exitCode':result.returncode,'responses':len(responses),'ok':sum(response['ok'] for response in responses),'firstResponse':responses[0]}
assert all(sha(root/path)==digest for path,digest in source.items())
log=out/'full-core-02.log';passed=sum(int(x) for x in re.findall(r'test result: ok\. (\d+) passed;',log.read_text()));assert passed==166
receipt={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','baseline':{'manifest':str(base.relative_to(root)),'sha256':sha(base),'head':baseline['head'],'oldSourceReceipt':str(oldsource.relative_to(root)),'oldSourceReceiptSha256':sha(oldsource),'matchingCoreFiles':len(previous),'pinnedBinaryVerified':True},'fixture':{'path':str(fixture.relative_to(root)),'sha256':sha(fixture),'schema':identity,'independentRawJson':True},'runs':runs,'source':{'path':str((out/'source-current-02.json').relative_to(root)),'sha256':sha(out/'source-current-02.json'),'files':len(source)},'tests':{'path':str(log.relative_to(root)),'sha256':sha(log),'passed':passed,'failed':0},'proofBoundary':'Native symbolic schema nested identity and JSON material/provenance. Constrained enum model falls back to null because stored composite is a JSON clone. No JS heap identity or mutable runtime linking claim; desktop/mobile browser NOT_RUN.'}
dump(out/'before-after-02.json',receipt);print(json.dumps({'status':'PASS','tests':passed,'baselineOk':runs['baseline']['ok'],'currentOk':runs['current']['ok'],'receipt':str((out/'before-after-02.json').relative_to(root))}))
