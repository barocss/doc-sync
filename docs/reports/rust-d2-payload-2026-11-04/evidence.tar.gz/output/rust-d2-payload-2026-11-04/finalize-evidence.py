from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-payload-2026-11-04';report=r/'docs/reports/rust-d2-payload-2026-11-04'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
s=read(t/'final-comparison-summary.json');counts={}
doc_changes={x['path']:x for x in read(t/'documentation-whitespace-final.json')['rows']}
def matches(path,expected):
 actual=sha(r/path)
 if actual==expected:return True
 row=doc_changes.get(path)
 return bool(row and expected==row['beforeSha256'] and actual==row['afterSha256'] and hashlib.sha256((r/path).read_bytes()+b'\n').hexdigest()==expected)
for name,m in [('core',read(t/'core/source-current-02.json')),('sdk',read(t/'sdk/source-final-after.json')),('wrapper',read(t/s['regressions']['receipt'])['frozenHashes']),('main',read(t/s['main']['receipt'])['sourceHashes'])]:
 bad=[p for p,h in m.items() if not matches(p,h)];assert not bad,(name,bad);counts[name]=len(m)
program=(r/'experiments/rust-sdk/examples/runtime_payload.rs').read_text();module_comment,body=program.split('\n',1)
assert module_comment.startswith('//! ')
fences=[]
for name in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
 content=(r/name).read_text().split('<!-- runtime-payload-rust-example -->',1)[1]
 fences.append(re.search(r'```rust\n(.*?)```',content,re.S).group(1))
assert fences[0]==fences[1]==body
for name in ['sdk/readme/src/main.rs','sdk/guide/src/main.rs']:assert (t/name).read_text()==body
for row in read(t/s['gzipAudit'])['rows']:
 assert sha(r/row['path'])==row['compressedSha256'];assert row['rawSha256']==row['restoredSha256'];assert row['rawBytes']==row['restoredBytes']
for name in ['nested','grid','shapes','rules','composite','alias','shared']:
 p=r/f'docs/reports/rust-d2-{name}-2026-11-04';seal=read(p/'seal.json')
 for f,h in seal['files'].items():assert sha(p/f)==h,(name,f)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='1cfb7a23611f0a98994a6716cfc2bddfc5ba89f4'
verification={'status':'PASS','sourceMaps':counts,'documentationOnlySupplement':'documentation-whitespace-final.json','documentedCode':{'status':'PASS','consumerSha256':hashlib.sha256(body.encode()).hexdigest(),'exampleSha256':sha(r/'experiments/rust-sdk/examples/runtime_payload.rs'),'onlyDifference':'Example starts with one module documentation comment; both fenced programs and both compiled consumers are byte-identical to the remaining source.'},'gzipCompressedHashes':29,'gzipRoundtripAudit':s['gzipAudit'],'previousReportSeals':7,'head':'1cfb7a23611f0a98994a6716cfc2bddfc5ba89f4'}
(t/'final-source-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
f=read(report/'final-checks.json');f['status']='PASS';f['documentation']={'build':read(t/'docs-build-final-whitespace.json'),'check':read(t/'docs-check-final-whitespace.json'),'pages':55,'internalLinks':2625,'english':True,'localPathsExcluded':True};f['sourceVerification']=verification;f['build']=read(t/'before-full-build.json')
(report/'final-checks.json').write_text(json.dumps(f,indent=2)+'\n')
paragraph='Final integrated verification: **2,114 tests / 2,112 PASS / zero FAIL / two expected platform SKIPs / zero cancelled**. Package build and typecheck pass. Documentation build and checks pass: **55 pages / 2,625 internal links**, English content and local paths excluded. Final source checks match the core, SDK, comparison and main trace maps. Both fenced Rust programs and both compiled consumers are byte-identical; the runnable example adds only one module documentation comment. All seven earlier report seals remain unchanged.\n\n'
p=report/'README.md';text=p.read_text();needle='## Evidence storage\n';assert needle in text;text=text if paragraph in text else text.replace(needle,paragraph+needle,1);p.write_text(text)
p=r/'HANDOFF.md';text=p.read_text();needle='[Source-bound nested-payload report]';assert needle in text;text=text if paragraph in text else text.replace(needle,paragraph+needle,1);p.write_text(text)
print(json.dumps(verification))
