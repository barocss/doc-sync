// Source-only paired access-layer benchmark. No package build or dist imports.
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createHash} from 'node:crypto';
import {readFileSync, writeFileSync} from 'node:fs';
import {Client} from '../output/refactor-2026-11-03/data-baseline/packages/doc-sync/src/client/index.ts';
import {createDataSchema} from '../output/refactor-2026-11-03/data-baseline/packages/doc-sync/src/data/schema.ts';
import {createDataAccess as current} from '../packages/doc-sync/src/data/access.ts';
import {createDataAccess as baseline} from '../output/refactor-2026-11-03/data-baseline/packages/doc-sync/src/data/access.ts';
const out = new URL('../output/refactor-2026-11-03/', import.meta.url);
const id = n => `data:00000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const hash = path => createHash('sha256').update(readFileSync(new URL(path, import.meta.url))).digest('hex');
const summarize = values => { const sorted = values.toSorted((a,b)=>a-b); return {count: sorted.length, medianMs: sorted[Math.floor(sorted.length/2)], p95Ms: sorted[Math.ceil(sorted.length*.95)-1]}; };
const sourceHashes = {baseline:hash('../output/refactor-2026-11-03/data-baseline/packages/doc-sync/src/data/access.ts'),current:hash('../packages/doc-sync/src/data/access.ts'),client:hash('../output/refactor-2026-11-03/data-baseline/packages/doc-sync/src/client/index.ts'),benchmark:hash('./data-access-refactor.mjs')};
const results = [];
for (const n of [100, 1000, 10000]) {
    console.log(`prepare N=${n}`);
    const empty = new Client({schema:createDataSchema(),actor:'data-perf'});
    const state = empty.captureState(); empty.dispose();
    // Linear bulk checkpoint seed. Avoid the model editor's repeated insert projection.
    let clock=0;
    const token = (type, dataId, after, attrs={}) => {
        const key=`${++clock}@data-perf`;
        return {i:key,o:after,k:'n',b:type,a:[['$type',type,key],['id',dataId,key],...Object.entries(attrs).map(([name,value])=>[name,value,key])]};
    };
    const head = key => ({i:key,o:null,k:'n',y:'root'});
    const listToken=token('list',id(1),'0@~root'), mapToken=token('map',id(2),listToken.i);
    const line = (parent,offset,isMap) => {
        const key=`0@${parent.i}/body`, items=[head(key)];
        for(let i=0;i<n;i++) items.push(token('entry',id(offset+i),items.at(-1).i,{...(isMap?{key:`key-${i}`}:{ }),value:{scalar:i}}));
        return {key,owner:parent.i,slot:'body',items};
    };
    const lines=[{key:'0@~root',owner:null,slot:'',items:[head('0@~root'),listToken,mapToken]},line(listToken,10,false),line(mapToken,10+n,true)];
    state.engine.document={format:2,capabilities:[],lamport:clock,lines};
    state.engine.revision=clock;
    const client=Client.fromState(state,{schema:createDataSchema()});
    console.log(`seeded N=${n}`);
    const access = [baseline(client, ()=>{}, ()=>{}), current(client, ()=>{}, ()=>{})];
    const samples = Object.fromEntries(['firstRead','cachedListAt','cachedMapSize','editAndRead'].map(k=>[k,[[],[]]]));
    let revision = 0;
    for (let round=0; round<5; round++) for (const lane of [0,1,1,0]) {
        console.log(`sample N=${n} round=${round} lane=${lane}`);
        globalThis.gc?.();
        const fresh = [baseline,current][lane](client, ()=>{}, ()=>{});
        let start = performance.now();
        const list = fresh.getList(id(1)), map = fresh.getMap(id(2));
        const first = list.at(n-1); const size = map.size;
        samples.firstRead[lane].push(performance.now()-start);
        assert.deepEqual(first,{id:id(9+n),value:n-1}); assert.equal(size,n);
        const data = access[lane], cachedList = data.getList(id(1)), cachedMap = data.getMap(id(2));
        // Warm each cached projection before timing.
        cachedList.at(0); void cachedMap.size;
        start=performance.now();
        for(let i=0;i<3;i++) { const value=cachedList.at(n-1); assert.equal(value.id,id(9+n)); assert.equal(value.value,n-1); }
        samples.cachedListAt[lane].push((performance.now()-start)/3);
        start=performance.now();
        for(let i=0;i<3;i++) assert.equal(cachedMap.size,n);
        samples.cachedMapSize[lane].push((performance.now()-start)/3);
        start=performance.now();
        client.edit([{op:'update',at:[0,0],attrs:{value:{scalar:++revision}}}],null);
        const edited=cachedList.at(0); const afterSize=cachedMap.size;
        samples.editAndRead[lane].push(performance.now()-start);
        assert.deepEqual(edited,{id:id(10),value:revision}); assert.equal(afterSize,n);
    }
    results.push({n,metrics:Object.fromEntries(Object.entries(samples).map(([key,lanes])=>[key,{baseline:summarize(lanes[0]),current:summarize(lanes[1])}]))});
    client.dispose();
}
const report={node:process.version, gc:!!globalThis.gc, order:'ABBA x 5', unit:'milliseconds per operation', cachedBatch:3, baselineCommit:'ec9622571a04a7d7ea3f967bb3e6423b17ce5194', hashes:sourceHashes, scope:'Baseline and current source access layers use the same prepared public Client state. FirstRead includes projection; editAndRead includes edit plus projection. Assertions outside projection timings; cached assertion overhead included equally. Heap allocations not inferred from retained heap.', results};
const name=process.argv[2]??'data-perf.json';
writeFileSync(new URL(name,out), JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
