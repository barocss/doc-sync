# Bot startup policy follow-up

## Result and scope

PASS: Bot startup provenance tests 3/3. Test command exited 0 on Node v24.22.1.
HEAD: 0de9f0ffc06d8be94e448222c0575a99d6ae9a66.

This follow-up changed only apps/bot/test/mcp-startup.test.ts and this report.
apps/bot/src/runner.ts was inspected but not edited. Root's restored forced-empty DOC_SYNC_SCHEMA is retained. Its bounded known-phase parser remains in place. Transport spawn options and production schema-discovery behavior are unchanged by this follow-up. No production environment option or test seam was added.
Foreign MCP main/helper/test edits were not modified. No native collaboration calls or OMX injection were used.

## Test injection

Each scenario runs one isolated driver and its SDK-spawned actual project MCP main. NODE_OPTIONS=--import=<absolute preload URL> is set only in the driver's test environment. The preload checks process.argv[1] against the actual project MCP main path before overriding NodeHttpTransport.prototype.getSchema. The driver is not patched. The transport module is resolved with createRequire(import.meta.url).resolve("@barocss/doc-sync/node") from the project test and imported with an absolute file URL. This avoids bare-package resolution from /tmp and patches the same export as main.

Each case supplies an ambient DOC_SYNC_SCHEMA pointing to a module that writes a sentinel then throws. All three assert that its sentinel does not exist. The MCP PID file is written only when the patched getSchema executes. No HTTP server or arbitrary mission retry is used.

### Cases

1. schema discovery failure: getSchema writes raw private stderr and throws an Error containing a private canary. It does not write a startup marker. The real main catch emits its schema-discovery startup marker. The mission retains only the known schema-discovery phase.
2. split known marker: getSchema writes the known schema-discovery marker in two writes separated by 75 ms, then exits 1. The mission retains the known phase. This exercises the parser through the real SDK stderr pipe; OS chunk boundaries are not directly instrumented.
3. unknown and oversized stderr: getSchema writes a 256 KiB line prefix followed by a known marker on that same oversized line, then an unknown-phase marker on a new line, and private stderr. The mission error stays exactly "MCP error -32000: Connection closed". No known or unknown phase is attached.

### Assertions retained in every case

- Planner calls: 0; mission status: needs_attention.
- pending: null; history: []; steps: [].
- Persisted mission equals the returned mission.
- Private canary and raw-stderr label absent from persisted mission, returned mission JSON, and captured driver diagnostics.
- Existing foreign mission/pending/history sentinel and journal sentinel remain byte-for-byte identical.
- Ambient executable schema never runs.
- SDK child PID exists as test evidence, then process.kill(pid, 0) fails with ESRCH after mission return.
- A 25-second watchdog is limited to the driver's owned detached process group. Temporary files are removed in finally.

## Source freeze

The following SHA-256 values were captured before and after the test run. All four matched. main/helper were read-only lease inputs, not owned edits.

```text
00def7fe5034a94ef8ce45d1236e55f76ddb6f2de3ca07ba6097dfedebd83d87  apps/bot/src/runner.ts
0f74612f6e6dbaeba0f4aebcaa7089fb956fdd122e4c821ca08c42258c29fc2a  apps/bot/test/mcp-startup.test.ts
706d5e383856b3b43a445debf14b0f1644b682071c403ceab2eda75d806f47e2  apps/mcp/src/main.ts
c5d701545fc32ba56466656e76f721c1f060f7017e1961ce9eef717ff2fe47b8  apps/mcp/src/stdio-lifetime.ts
```

## Fresh proof

Command (no npm lifecycle build):

```sh
PATH=/Users/user/.nvm/versions/node/v24.22.1/bin:$PATH node --test apps/bot/test/mcp-startup.test.ts
```

Output:

```text
v24.22.1
✔ mission startup provenance: schema discovery failure (513.748ms)
✔ mission startup provenance: split known marker (457.66475ms)
✔ mission startup provenance: unknown and oversized stderr (346.481208ms)
ℹ tests 3
ℹ suites 0
ℹ pass 3
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1385.353417
```

Scoped git diff --check for runner: PASS (exit 0). Root typecheck: NOT_RUN (optional; not needed for this focused proof).

## Evidence limits and preserved records

The earlier output/mcp-startup-proof/bot-test.log and bot-root-tsc.log were not overwritten or removed. The old Bot 3/3 log used the superseded ambient-schema policy and is NOT final policy proof. The fresh test output above is the proof for the restored forced-empty policy.

Full affected MCP/Bot/restart validation: NOT_RUN here; reserved for root after all workers finish. Global build, full tests, browser, mobile, commit, push, and release: NOT_RUN. Existing pending/history preservation is proven by the sentinel assertions only; it is not a broader restart qualification.

This report is distinct from the CLI final .final.md. No other proof artifacts were written by this follow-up.
