# MCP input lifetime implementation plan

Scope: main.ts and one stdio-lifetime.ts helper only. Preserve foreign edits.
No commit, push, full build, workspace tests, browser, or mobile checks.

1. Before the first bootstrap await, pipe stdin bytes into a PassThrough with
   an explicit 64 KiB high-water mark. Do not decode or parse input. Standard
   pipe backpressure pauses stdin when the proxy fills. The SDK receives this
   proxy through its supported constructor only after session.start completes.
   This preserves early initialize bytes without admitting tools before recovery.
2. Own raw stdin end, close, and error, plus proxy errors and SIGINT/SIGTERM.
   EOF requests closure even when the SDK has not attached an end handler.
   Closure unpipes and pauses raw input and destroys the proxy. Remove only
   application-owned listeners. No timer-based keepalive or new timeout.
3. Cancellation is sticky. Check it before and after each bootstrap await and
   before each new outer resource acquisition. Do not race cleanup against an
   unfinished journal.open or session.start. Defer final resource cleanup until
   bootstrap settles; close any late journal immediately at the next boundary.
   An in-flight DocumentSession.start is atomic at this ownership boundary:
   its internal awaits cannot be cancelled without expanding the allowed scope.
4. Use one idempotent cleanup promise. Stop MCP admission first. Always attempt
   session/journal cleanup even if SDK close fails. Startup failure or cancellation
   before readiness closes local session only (no uncertain actor leave).
   Ready-session closure uses shutdownSession's drain and settled-only leave
   rules. If drain fails, still close local resources, without calling leave.
   Never clear journals, remove locks, release protected reservations, or replay.
5. Record bounded phase + original error diagnostics on stderr. Report cleanup
   failures separately, without masking the bootstrap error. Do not log request
   bytes, schema contents, credentials, or document data.
6. Run root npx tsc once only. Test worker supplies focused runtime receipts.
   Report exact hashes and remaining evidence gaps. Historical cause remains
   NOT_PROVEN; hypothetical journal waits are not normal-code reproductions.
