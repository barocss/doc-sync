# STARTUP lane: read-only analysis

## Boundary

Checkout: `/Users/user/github/doc-sync`, HEAD `0de9f0f`, branch `main`.
The initial tracked tree was clean. No source, test, HANDOFF, old report, or dist
file was changed. No server, mission, build, regression suite, or browser ran.
Only new evidence files under `output/mcp-startup-proof/` were written.
Node internal-source inspection used v24.22.1 at the specified absolute path.
No collaboration transport was invoked. No test child or server was created.
`omx explore --prompt` failed with a permission error in its installation;
bounded direct source reads supplied the evidence instead.

## Conclusion

**Root cause: NOT_PROVEN.** The proposed ordinary exit-0 gap is not supported by
the inspected normal startup chain. An unawaited `main().catch(...)` does not
itself prove an event-loop gap. There are real unreferenced resources after
schema discovery, but the subsequent journal operations issue asynchronous
filesystem requests. There is no identified application await of a promise
backed only by an unreferenced timer during normal clean journal bootstrap.
This is a source-level finding, not an active-resource trace of the failed run.
Do not label a passing rerun as a fix.

## Exact startup chain

1. `apps/mcp/src/main.ts:26-31`: schema discovery awaits `probe.getSchema()`.
   `packages/doc-sync/src/sync/node-http-transport.ts:149-156` awaits fetch,
   consumes JSON, and validates the schema fingerprint.
2. `main.ts:35-38` awaits `IntentJournal.open` unless journaling is off.
   `apps/mcp/src/journal.ts:126-145` validates arguments, awaits mkdir and
   realpath, then awaits `openWriterLock`, journal load and checkpoint load.
3. `apps/mcp/src/kernel-lock.ts:18-55`: Darwin uses nonblocking exclusive
   open; Linux uses a synchronous bounded flock helper. There is no timer-based
   lock retry, unref call, background worker, or unresolved lock waiter here.
   Busy lock acquisition throws. The lock descriptor alone does not keep Node
   alive, but each outstanding asynchronous filesystem operation has its own
   request. After a callback resolves, the next await is reached by microtasks.
4. `journal.ts:155-188`: record/checkpoint loads await file open, stat,
   read and close. ENOENT returns null; invalid data throws without deletion.
   Open failure after lock acquisition closes the lock (`journal.ts:145`).
5. `main.ts:39-45` rereads journal and checkpoint, creates the transport and
   DocumentSession. These reads again use filesystem requests, not idle waits.
6. `apps/mcp/src/session.ts:69-95` rereads both records. A fresh session calls
   `client.connect()` then waits for the first epoch. `packages/doc-sync/src/
   sync/client.ts:386-424` synchronously calls transport.subscribe.
7. `node-http-transport.ts:43-69,120-122` starts the async SSE fetch immediately.
   `session.ts:250-256` maintains an ordinary referenced 20ms polling timeout
   until an epoch or error/deadline. Failed stream reconnect uses an ordinary
   referenced 1000ms timeout (`node-http-transport.ts:108-115`).
8. `session.ts:92-95` requests recovery generation and establishes a reservation
   when supported; these occur after the first SSE hello, not in the reported
   schema-only window.
9. `main.ts:47-50` creates MCP server and stdio, awaits connect, then installs
   server onclose. SDK `dist/esm/shared/protocol.js:219-250` wires callbacks and
   awaits transport.start. SDK `dist/esm/server/stdio.js:32-39` installs stdin
   data/error listeners. Only at this point does stdio read client requests.
10. `main.ts:53` catches main rejection, prints the message to stderr and sets
    exitCode=1. It does not deliberately exit 0. It loses the error stack/cause.

## Concrete unref chain and its limits

The receipt `startup-node24-internals.txt` contains exact source extracted from
this Node binary, not a web claim or a runtime test:

- `NodeHttpTransport.getSchema` passes `AbortSignal.timeout(10000)`.
  Node `internal/abort_controller:215` explicitly unreferences that timer.
- Fetch's bundled Undici HTTP/1 client unreferences a socket when its queue
  size is zero (`internal/deps/undici/undici:7937-7946`). It references that socket
  again for work. A completed schema request can therefore leave only an idle
  unreferenced socket; its existence is not a startup liveness guarantee.
- Node `internal/fs/promises:1341-1349` calls binding.openFileHandle with
  promise mode. The journal chain does not substitute an unreferenced delay
  for these filesystem operations.

**Inference:** idle fetch and the timeout signal cannot keep a stalled arbitrary
promise alive. **Unknown:** whether the original process was actually waiting
on such a promise, exited normally, was killed, failed journal initialization,
or had stderr omitted. The observed schema-only HTTP trace alone cannot decide.
With journaling off, the clean path proceeds from schema validation to SSE in
microtasks; the first-SSE polling timer then provides a referenced handle.

## Separate production lifecycle gaps (not proof of the incident)

- `main.ts:39-45`: errors after successful journal.open and before session.start
  are outside the existing session cleanup catch. This includes failed rereads,
  constructor failure, and mission-bridge-without-journal validation. The latter
  has no lock, but the other journal-enabled failures can retain a lock until
  process exit.
- `main.ts:47-50`: createServer/connect failures have no encompassing session
  cleanup. With an SSE stream still active, exitCode=1 alone need not terminate
  the process. Cleanup failure in the session.start catch can mask its primary
  startup error (`main.ts:46`).
- SDK stdio start installs data/error listeners but no stdin end/close listener
  (`server/stdio.js:32-39`). EOF alone does not call transport.close. The app has
  no explicit EOF listener either. Therefore the app's server onclose callback
  is not a sufficient EOF ownership contract. SSE can remain open after a
  client closes its input. This predicts leaked lifetime, not pre-SSE exit 0.
- `main.ts:50` starts shutdown without handling rejection. It also installs the
  app callback only after connect returns. There are no app signal handlers.
- `shutdown.ts:6-9` protects unresolved work: drain first, classify settled,
  close local session, send leave only if pending=0, conditionalPending=false,
  and recoveryRequired=false. `session.ts:242-245` disconnects and closes the
  journal lock; `journal.ts:340-347` drains queued storage first. Closing does
  not delete journal/checkpoint or unlink its lock inode.

## Smallest safe production change to evaluate after synthesis

Do not replace main().catch with top-level await as an asserted root-cause fix.
Top-level await can expose an unsettled promise (exit 13) but is not a liveness
resource and does not repair EOF or cleanup ownership.

Prefer one explicit startup/lifetime owner around existing behavior:

1. Establish EOF/error/signal ownership before asynchronous bootstrap, without
   consuming protocol data or losing requests before SDK listeners exist.
2. Cover the entire acquired journal/session/server lifetime with one idempotent
   cleanup path. If only a journal exists, close it. If a session exists, drain
   admitted work and use the existing pending-safe shutdown contract. Close
   stdio/server and remove only listeners owned by this app. Preserve the primary
   initialization error and report cleanup errors separately to stderr.
3. Handle cleanup rejection explicitly and set a nonzero exit status on failure.
   Install app close ownership before connect, not after it.
4. If a deterministic active-resource test establishes a real startup gap, add
   a narrowly scoped referenced bootstrap lease released on readiness/failure/
   EOF. Do not add an indefinite keepalive or increase a deadline on speculation.
   A timer lease must be paired with cancellation ownership, not mask a hang.
5. Never clear pending records/checkpoints or release recovery history merely
   because startup/EOF occurred. Preserve the existing settled-state gate.
   Never unlink the kernel lock path. No automatic mission retry is warranted.

## Deterministic evidence plan (NOT_RUN)

All artifacts must stay in this output directory. Use one parent-owned watchdog
of at most 120s, exact child PID capture, and guaranteed final reaping. Use an
isolated journal directory and an owned ephemeral HTTP endpoint, never user data.
Do not let diagnostic timers, inherited stdin, or the parent HTTP server keep
the child alive; a referenced timer in the observed child would mask the test.

A. Run the actual main entrypoint in a child with piped stdin, held open but
   not consumed by a diagnostic listener. Preload passive stderr diagnostics for
   beforeExit/exit, uncaught errors, filesystem async resource lifecycle, fetch
   stages, active resources and handles. Record child exit code AND signal.
   async_hooks callbacks must not perform recursive async logging.
B. Real schema endpoint returns one valid response, then hold the first SSE
   response. Expect the referenced session.until timer until the existing 10s
   deadline; assert exit 1 with startup diagnostic and no remaining owned child.
   Record actual filesystem resources between schema completion and subscribe.
C. Test journal bootstrap deterministically: fresh dir, existing empty/valid
   checkpoint, corrupt record, corrupt checkpoint, private invalid lock, busy
   lock held by a specifically tracked child. Each refusal must be nonzero with
   stage/error diagnostic, no SSE on pre-connect refusal, unchanged record
   hashes, and lock reacquisition once its actual owner closes.
D. To calibrate the premise, use an output-only fixture that awaits only an
   unreferenced timer after schema completion. Without a bootstrap lease it must
   exit before continuation (main.catch style); with explicit top-level await it
   should report unsettled-await behavior rather than demonstrate a repair.
   This is a harness calibration, NOT a reproduction of the real journal path.
E. Fault-inject initialization errors after journal acquisition and after
   session.start. Assert failure status, primary error retained, owned stream
   closed, and immediate lock reacquisition. Fault injection must not edit source.
F. Close stdin at three barriers: schema response held, journal bootstrap,
   after MCP initialize. Assert bounded cleanup and no retained test child. For
   EOF during active editing, first establish a known durable pending intent;
   assert unchanged journal/checkpoint hashes and no leave/release request.
   Pending restoration must remain fail-closed and must not resend automatically.
G. Only after root selects a change, run assigned focused startup/restart
   regressions with original deadlines. Historical passing counts are not new
   evidence and neither retries nor a full build/browser are needed in this lane.

## Handoff status

Source investigation complete. Implementation and runtime probes NOT_RUN.
Root-cause claim NOT_PROVEN. Lifecycle-hardening proposal is distinct from a
verified fix for the original intermittent initial closure.
