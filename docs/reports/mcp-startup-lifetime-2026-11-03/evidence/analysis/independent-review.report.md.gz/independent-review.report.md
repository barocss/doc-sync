# Independent MCP startup review

## Verdict

**No additional concrete source blocker found in the reviewed follow-up snapshot.**
This is a read-only source review, not a new test PASS or source-freeze approval.
The original historical discovery-mode closure cause remains **NOT_PROVEN**.

The real large-input failure is not hypothetical. The pre-lease probe records an
8-byte client name connecting to 13 tools, while a valid 262144-byte name produces
MCP -32000, natural child exit 0, and empty stderr. That earlier helper was not
sufficient. The reviewed follow-up now owns a separate startup lease.

**Integration evidence gate:** the prior six-case receipt does not qualify the
lease patch or the currently changing test/fixture. Root must match the final
source hashes to the follow-up regression receipts before claiming final PASS.
No new runtime tests, builds, browser checks, or typechecks were run by this reviewer.

## Snapshot and method

HEAD: `0de9f0ffc06d8be94e448222c0575a99d6ae9a66`.
Read main/helper, session/shutdown/journal, createServer, installed SDK transport
and protocol close paths, Bot runner/parser, both new test files, lifecycle
fixture, and the requested implementation/test/diagnostic reports. Read the
follow-up source after one bounded wait and the follow-up report when present.
Other workers were still changing the lifecycle tests during review.

Reviewed production SHA-256:

- main.ts: `706d5e383856b3b43a445debf14b0f1644b682071c403ceab2eda75d806f47e2`
- stdio-lifetime.ts: `c5d701545fc32ba56466656e76f721c1f060f7017e1961ce9eef717ff2fe47b8`
- Bot runner.ts: `401c9b0202437dbf23c1327caa1d1ad2f3f16b74d9ce6a7902838c2b18833325`
- Bot mcp-startup.test.ts: `151cd727784e90b1ab0138d1dfb197f2e3da80b68803846e43a6735a0cca17e0`

Last observed lifecycle test/fixture hashes (not a freeze):

- startup-lifecycle.test.ts: `cff46554ea7dda8598bd9c325e503ad003e7efef4c5514093da8fa72b404df9b`
- startup-lifecycle-fixture.mjs: `d3eae26e53b647f344494d056fd23786bb6e30e518724af989f64a941be8cacc`

## Review findings by risk

### Raw bytes, backpressure, and lease ownership

`apps/mcp/src/stdio-lifetime.ts:5-16` keeps the 64 KiB raw PassThrough and normal
pipe backpressure. It does not decode or copy protocol data into diagnostics.
The referenced interval at lines 6-9 survives a paused stdin. Its callback does
no work. It is a liveness lease, not a new deadline or readiness delay.

`apps/mcp/src/main.ts:128-140` starts the SDK only after session.start settles,
checks cancellation again, and releases the lease after SDK connection succeeds.
The helper releases it on observed end/close/error and every close invocation
(lines 9-11, 20-28). Failure, signals, SDK closure, and final cleanup reach close
through main.ts:40-81, 143-148. Repeated release is safe.

The lease does not detect kernel EOF independently. If input is paused, Node can
defer end until data is consumed. An executable module that never settles with
open or backpressured input can retain the lease indefinitely. No internal module
cancellation or new timeout was requested or implemented. Do not claim immediate
EOF cancellation under all backpressure conditions.

### Cancellation, cleanup reentry, and journal ownership

`apps/mcp/src/main.ts:39,45-82,85-137` makes cancellation sticky and checks it at
outer acquisition boundaries. Cleanup waits for bootstrap settlement before
closing the journal. It does not race lock acquisition or session initialization.
Cancellation inside DocumentSession.start is not immediate; that sequence remains
atomic at this ownership boundary (`apps/mcp/src/session.ts:69-95`).

The SDK close callback calls a void requestClose, not an awaited clean promise
(main.ts:134; installed SDK shared/protocol.js:252-272 and server/stdio.js:54-67).
Thus closing the SDK during cleanup does not await the same cleanup promise.
The single cleanup promise (main.ts:55-82) prevents duplicate resource cleanup.
No bootstrap/cleanup await cycle was found.

Cleanup attempts local session cleanup even after SDK close failure. A failed
session drain falls back to disconnect, then attempts journal close
(main.ts:64-76). Journal.close itself is idempotent and waits for its own queue
before closing the kernel lock (`apps/mcp/src/journal.ts:340-348`). No lock-file
unlink or foreign resource cleanup was added.

### Pending intent, uncertain outcome, and duplicate prevention

Startup failure or cancellation before readiness uses local session.close only
(main.ts:68-69). Ready shutdown uses shutdownSession, which drains first and
sends leave only if ordinary pending, conditional pending, and recoveryRequired
are all clear (`apps/mcp/src/shutdown.ts:6-9`). A drain failure does not fall
through to leave. Session.close disconnects and closes the journal, but does not
clear intent (`apps/mcp/src/session.ts:242-248`).

The follow-up does not add retry, replay, intent deletion, reservation release,
or actor leave to failure handling. Existing recovery remains authoritative.
The durable-unknown test checks exact pending bytes, no leave, no duplicate
conditional request, blocked edits, and foreign preservation. The accepted-intent
case checks receipt reconciliation and actor-local undo/redo. These assertions
are stronger than a successful reconnect alone.

### Bot startup phase privacy

`apps/bot/src/runner.ts:30-55` retains at most a 96-byte line prefix, accepts only
an anchored startup marker plus a fixed phase whitelist, and emits only the known
phase. Oversized lines cannot turn a suffix into a new marker. Chunk-split markers
and a final non-newline prefix are supported. Raw stderr is still drained after
parsing stops (runner.ts:247-256), but is not appended to mission errors.

`apps/bot/test/mcp-startup.test.ts:27-33,68-89` checks real import failure, split
markers, oversized/unknown stderr, canary exclusion, no planner execution, and
unchanged foreign files. No automatic startup retry was added.

This does not establish a general privacy guarantee for MCP stderr itself:
main.ts:17-22 bounds and partially redacts external error messages; arbitrary
schema-thrown text can still contain private content. The reviewed Bot boundary
specifically excludes that raw text from mission persistence.

## Evidence boundaries

- Prior `test-report.md` and `test-current/source.json`: six-case PASS applies to
  main `bcc468...` and helper `3921f8...`, not the lease snapshot above.
- Prior Bot log: 3/3 PASS. This reviewer read the assertions and log, but did not
  rerun them against the lease snapshot.
- `backpressure-probe.log`: real pre-lease small/large input differential failure.
- `backpressure-1793711665332/results.json`: both sizes now handshake and list 13
  tools with empty stderr. Probe cleanup uses SDK.close, so it does not prove
  natural EOF, journal reacquisition, or the entire shutdown path.
- `lifetime-followup.report.md`: reports the probe PASS and root tsc PASS. Those
  are worker receipts, not checks executed by this reviewer.
- New lifecycle source adds the two size cases and buffered-large-input EOF case
  (test lines 179-239). It checks actual proxy backpressure before schema/SDK
  readiness, exact client-name hash after SDK parsing, read-only model/sequence,
  natural exit, SSE closure, writer reacquisition, and restart. The observation
  fixture delegates original pipe/pause/start methods and adds no timer or stdin
  consumer (fixture lines 15-43). Final matching runtime receipts were not yet
  available in the inspected report set. Keep them pending rather than borrowing
  the old six-case PASS.

Only this requested output report was written. No source, test, implementation
plan, existing proof, user journal, or foreign worker file was changed. No commit,
push, process signal, collaboration MCP, injection, build, full test, browser, or
mobile action was performed by this reviewer.
