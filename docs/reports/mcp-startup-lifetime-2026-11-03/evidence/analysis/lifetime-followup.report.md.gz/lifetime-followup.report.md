# Bootstrap lifetime follow-up

## Result and proof boundary

- Supported async schema plus backpressured initialize: **PASS** after the change.
- Root TypeScript check: **PASS**, exit 0, 5.256 seconds.
- Original historical discovery-mode closure cause: **NOT_PROVEN**.
- The old small-input-only fix was insufficient. Owning and piping raw stdin does
  not ensure a referenced event-loop handle when PassThrough backpressure pauses it.
- This follow-up changed only `apps/mcp/src/stdio-lifetime.ts`,
  `apps/mcp/src/main.ts`, and this report. The existing root probe created its own
  private output directory. Test-worker and Bot-runner files were not edited.
- No commit, push, global build, full tests, browser, mobile, collaboration MCP,
  injection, broad kill, retry extension, or deadline extension.

## Read evidence

Read the actual helper and main source, `test-report.md`, `implementation-plan.md`,
`bot-diagnostic.report.md`, `backpressure-probe.mjs`, and `backpressure-probe.log`.
The previous implementation plan's no-timer constraint is superseded only by the
explicit startup-lease request in this follow-up. The previous test report excludes
saturated bootstrap input; its six passing cases do not qualify this new patch.

Before this patch, the existing root probe recorded:

| Initialize client name | Result | Before cleanup | stderr |
| --- | --- | --- | --- |
| 8 bytes | Connected; 13 tools | Not a failure | Empty |
| 262144 bytes | MCP -32000 Connection closed | Child exit 0, no signal | Empty |

The probe uses the supported `DOC_SYNC_SCHEMA` module path. Its schema module
awaits a 700 ms unreferenced timer, then exports the real demo schema. This is a
reachable executable-module startup gap, not a hypothetical journal hook and not
proof of the historical incident's trigger.

## Exact patch and lifecycle

The helper creates one referenced `setInterval` with a no-op callback and a
60000 ms interval before input is piped. This is a startup liveness lease, not a
new timeout, readiness sleep, retry, or scheduling delay. No code awaits a tick.

The helper exposes `releaseBootstrap()`. Clearing the same interval more than
once is safe. The lease is released on these paths:

1. Ready: main calls `input.releaseBootstrap()` after `await server.connect(stdio)`,
   the cancellation check, and readiness assignment. The SDK has started stdio.
2. Raw input end or close: the helper releases it before notifying main.
3. Raw input or proxy error: the helper releases it before notifying main.
4. Startup failure, SIGINT, SIGTERM, and SDK close: existing `requestClose()` calls
   `input.close()`, which releases it before unpipe/pause/destroy.
5. Final cleanup: existing `finally` calls `input.close()` again safely.

The 64 KiB PassThrough and normal backpressure remain unchanged. No raw request
bytes are parsed or logged. Early initialize bytes remain buffered. The SDK still
connects only after `DocumentSession.start()` completes, so this patch adds no
pre-session tool admission.

Pending-safe cleanup still waits for bootstrap settlement before closing late
resources. The existing idempotent cleanup promise, primary startup diagnostics,
cleanup diagnostics, and stage markers are unchanged. No Bot whitelist changes
were needed. Production stdout has no added output.

## Verification performed in this follow-up

Runtime: `/Users/user/.nvm/versions/node/v24.22.1/bin` first in PATH.
HEAD remains `0de9f0ffc06d8be94e448222c0575a99d6ae9a66` with inherited uncommitted work.

Command, run once after the patch:

```sh
PATH=/Users/user/.nvm/versions/node/v24.22.1/bin:$PATH \
  node output/mcp-startup-proof/backpressure-probe.mjs
```

Exit 0. Output evidence:
`output/mcp-startup-proof/backpressure-1793711665332/results.json`.

| Initialize client name | Handshake | Tools | stderr |
| --- | --- | --- | --- |
| 8 bytes | PASS | 13 | Empty |
| 262144 bytes | PASS | 13 | Empty |

The existing probe retains its 4000 ms connect deadline, 5000 ms server deadline,
and 20000 ms guard. It tracks only its own ChildProcess objects and cleans those
children with exact-PID signals. This passing result proves initialization and
tool listing, not natural ready-EOF shutdown: probe cleanup uses SDK close.

Root typecheck, run once through a Python subprocess watchdog:

```sh
npx --no-install tsc -p tsconfig.json
```

Exit 0; 5.256 seconds; no diagnostics. The watchdog limit was 110 seconds and did
not fire. Its timeout branch enumerates only descendants of its own npx PID and
signals exact PIDs. No npm lifecycle script or build ran.

The independent test worker owns the large-initialize regression. This lane did
not add or run that worker's test. Existing six-case and Bot three-case receipts
are prior evidence, not new runtime verification of this final patch.

## Source identities after verification

SHA-256:

- main.ts: `706d5e383856b3b43a445debf14b0f1644b682071c403ceab2eda75d806f47e2`
- stdio-lifetime.ts: `c5d701545fc32ba56466656e76f721c1f060f7017e1961ce9eef717ff2fe47b8`
- startup-lifecycle.test.ts: `73b5b084d598e1d46a4c5ac37a644cace6f3e8d0ecb12875c3431dc589ae9fb9`
- startup-lifecycle-fixture.mjs: `7e7e79f7461cebf28b7fc00b8fbdaedf1b58333495b152139cdbe39181c2324a`
- Bot runner.ts: `401c9b0202437dbf23c1327caa1d1ad2f3f16b74d9ce6a7902838c2b18833325`
- Bot mcp-startup.test.ts: `151cd727784e90b1ab0138d1dfb197f2e3da80b68803846e43a6735a0cca17e0`

The lifecycle test and fixture match the prior test report hashes. Foreign files
remain pending. No source baseline, report, or foreign edits were overwritten.

## Remaining limits

- No claim that arbitrary executable schema modules that never settle can be
  cancelled internally. The lease has no new expiry; observed lifecycle closure
  releases it, while an open-input module that never settles can remain pending.
- A paused Node readable may defer its end event until buffered input is consumed.
  This patch releases the lease when end/close is observed; it does not implement
  an independent kernel-level EOF detector or bypass bounded backpressure.
- No cancellation was added inside the atomic DocumentSession.start sequence.
- No whole-project, packaged-product, remote, or historical-cause acceptance.
