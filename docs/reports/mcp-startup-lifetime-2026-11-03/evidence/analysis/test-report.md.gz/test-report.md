# MCP startup lifecycle test handoff

## Result and proof boundary

- Final current-source focused regression: **PASS 6/6**, 0 skipped, 0 cancelled.
- Same final test and fixture against archived HEAD
  `0de9f0ffc06d8be94e448222c0575a99d6ae9a66`: **FAIL 4/6**, PASS 2/6.
- Focused TypeScript check: **PASS** (new test entry and its imported dependency
  graph only). No full-workspace check or build was run by this lane.
- Historical initial-closure cause: **NOT_PROVEN**. Passing retries are not fixes.
- Production changes belong to the production worker. This lane changed only
  the two new lifecycle files and the requested output evidence/plan.
- Existing tests, production files, and docs/HANDOFF were not edited by this lane.
  Foreign runner/main/helper/bot-test edits were preserved.
- No browser, mobile, AI request, commit, or push.

## Final identical-test matrix

| Scenario | Archived HEAD | Current source |
| --- | --- | --- |
| Supported async DOC_SYNC_SCHEMA; early SDK initialize; tools/read | FAIL: -32000; actual main exits 0 before schema export | PASS: initialize, listTools and read_document, then natural EOF exit 0 |
| Actual StdioServerTransport.start rejects after real live SSE and journal | FAIL: natural-exit deadline; activeStreams=1 before exact-PID cleanup | PASS: nonzero natural exit, original error plus production stdio-connect phase, closed SSE, writer reacquisition |
| EOF while async schema module is awaiting export | PASS: no upstream edit or retained SSE | PASS: no upstream edit or retained SSE |
| Durable unknown intent/checkpoint, failed startup, EOF and restart | PASS | PASS: exact intent and checkpoint bytes, no automatic conditional replay or leave, blocked new edit, preserved foreign accepted edit |
| Durable accepted intent, failed startup, EOF and restart | FAIL: restart-fault natural-exit deadline with live SSE | PASS: receipt reconciliation, no duplicate conditional, preserved foreign edit, actor undo/redo touches only AI edit |
| Ready EOF with admitted work and accepted response held upstream | FAIL: natural-exit deadline | PASS: EOF is observed before releasing response; admitted work settles, natural exit, closed SSE, reacquired writer, clear restart and no duplicate |

The bootstrap EOF case passing on HEAD does not establish HEAD input ownership:
HEAD can abandon the unfinished schema import. The separate open-stdin handshake
case is the negative liveness oracle. EOF tests do not claim arbitrary executable
modules that never settle can be cancelled or that all internal session-start
acquisitions are cancelled immediately.

## Real components and fault boundary

The parent uses the installed SDK Client and StdioClientTransport. Each server
child runs the real selected main.ts. Each scenario has a private mkdtemp journal
and a real demo server plus an ephemeral parent HTTP proxy. Readiness comes from
SDK initialize, tool/read responses, or named stream/conditional/schema barriers,
not from a fixed readiness sleep. Short bounded polls only inspect those barriers.

`startup-lifecycle-fixture.mjs` is installed with --import only in these test
children. It wraps real DocumentSession.start to report completion and actual
StdioServerTransport.start to reject at the selected boundary. It does not replace
session startup, journal, transport implementation, or SDK initialization. Its
stdin end observer neither resumes nor consumes input and does not close anything.
The test-only SDK `_process` access permits EOF without SDK.close's kill escalation;
these receipts use the installed SDK version, not a general private-field API claim.

The async schema is a real supported DOC_SYNC_SCHEMA module. It awaits one bounded
250 ms unreferenced timer before exporting a valid schema. No journal/lock wait
is changed. **There is no claim that normal journal code has an unref wait or that
this reproduces the historical trigger.**

The durable inputs are produced by real edit_document admission and durable
prepare before an observed conditional HTTP barrier. A deliberate exact-PID crash
creates the existing recovery input; it is not the startup-failure trigger. The
unknown intent must remain byte-for-byte intact. The accepted intent may be
reconciled into a checkpoint and cleared only by existing receipt recovery.
The subsequent real foreign edit and actor undo/redo provide semantic data-loss
and duplicate checks. No synthetic user log is deleted, and no user log is used.

## Source identity

Final receipts use Node v24.22.1. Baseline source was archived from Git HEAD into
an external private directory before production edits; its location is recorded
in `test-baseline-path.txt`. node_modules is shared through a symlink; this is a
source baseline using the same installed runtime dependencies, not a rebuilt
historical package baseline.

Current source SHA-256:

- main.ts: `bcc468018bea3cf49fa7c2912400c6030d01a1076a90b17b90609b64ed3effba`
- stdio-lifetime.ts: `3921f8268c9d2d86cfaf06112ef82cb82ed72c4611d6a531e95a60e8d1032ba8`
- startup-lifecycle.test.ts: `73b5b084d598e1d46a4c5ac37a644cace6f3e8d0ecb12875c3431dc589ae9fb9`
- startup-lifecycle-fixture.mjs: `7e7e79f7461cebf28b7fc00b8fbdaedf1b58333495b152139cdbe39181c2324a`

Both final source manifests match the files after execution. See each run's
`source.json` for entry, fixture, test, session, journal and helper hashes.

## Commands and process safety

Run only the new file:

```sh
python3 output/mcp-startup-proof/test-watchdog.py baseline
python3 output/mcp-startup-proof/test-watchdog.py current
PATH=/Users/user/.nvm/versions/node/v24.22.1/bin:$PATH \
  node node_modules/typescript/bin/tsc -p output/mcp-startup-proof/test-tsconfig.json
```

The external watchdog sets Node24 PATH and invokes:
`node --test --test-concurrency=1 apps/mcp/test/startup-lifecycle.test.ts`.
DOC_SYNC_TEST_MCP_ENTRYPOINT selects the archived entry only in tests. It does
not add a production environment switch.

Each scenario retains existing short operation deadlines. A natural-exit deadline
failure stays FAIL even if finally must stop the child. Each child is tracked and
reaped with exact-PID SIGTERM then bounded SIGKILL fallback. The external watchdog
is 110 seconds, targets only individually enumerated PIDs in its own session,
and classifies firing as failure. It never fired. No broad kill was used.

- Final baseline: exit 1, 18.748 s, external watchdog not fired.
- Final current: exit 0, 4.984 s, external watchdog not fired.
- All 35 server/MCP PIDs recorded by both final runs are absent.
- External root/group PID inventories also have no remaining process.
- Proxy connections close in finally. Private synthetic data and logs remain for
  inspection. The baseline archive remains available; nothing was deleted.

## Evidence and development runs

Authoritative final evidence:

- `test-baseline/tap.txt`, `source.json`, `watchdog.json`, `case-*.json`.
- `test-current/tap.txt`, `source.json`, `watchdog.json`, `case-*.json`.
- `test-verification.json`: post-run hash equality, all recorded PIDs absent,
  and foreign Git status captured without altering it.
- `test-typecheck.txt`: empty error output; focused tsc exited 0.

Earlier development receipts remain in `test-baseline-initial-five`,
`test-baseline-six-preliminary`, `test-baseline-before-type-annotation`, and
`test-current-before-type-annotation`. The first baseline failure was recorded
before the current-source qualification. The sixth admitted-work case and stronger
artifact/phase assertions were then added. After a type-only scope/annotation
correction, both final runs used the same unchanged final test/fixture hashes.
These are transparent harness-development runs, not a fail-then-retry mission or
an assertion that a passing rerun establishes the original cause.

## Remaining scope

No whole-project acceptance is claimed. This lane does not cover an executable
schema module that never settles, saturated bootstrap input buffers, cancellation
inside the atomic DocumentSession.start sequence, or the original unobserved
incident. Root should combine these receipts with the production report and
separate runner diagnostics before updating English docs/HANDOFF.
