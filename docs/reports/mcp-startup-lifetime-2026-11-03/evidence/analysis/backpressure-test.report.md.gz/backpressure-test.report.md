# Bootstrap backpressure regression handoff

## Result and boundary

- Current source: **PASS 9/9**, no skip or cancellation. This includes all six inherited lifecycle scenarios and three new scenarios.
- Archived HEAD `0de9f0ffc06d8be94e448222c0575a99d6ae9a66`: **FAIL 7/9**, PASS 2/9.
- PassThrough-only negative control: **FAIL 1/9**, PASS 8/9. Only the large early initialize test fails, with SDK `MCP -32000: Connection closed` and natural child exit 0 before schema export.
- Focused test dependency-graph TypeScript check: **PASS**, exit 0.
- Historical original discovery-mode closure: **NOT_PROVEN**. The supported async-schema/backpressure defect is a separate confirmed reproduction.
- No global build, full test suite, browser, mobile, AI request, commit, or push. No collaboration MCP, injection, or broad process kill.

This lane edited only `apps/mcp/test/startup-lifecycle.test.ts`, `apps/mcp/test/startup-lifecycle-fixture.mjs`, and new proof artifacts. Production main/helper and Bot changes belong to other workers. This lane did not edit them. Existing pending-intent, foreign-edit, accepted-receipt, undo/redo, and admitted-drain assertions remain present and passed. Old six-test receipts, baseline failures, probe logs, and other reports remain unchanged.

## New scenarios

| Scenario | Archived HEAD | PassThrough only | Current lease |
| --- | --- | --- | --- |
| Valid SDK initialize, client name 8 bytes, supported async schema | FAIL: -32000 | PASS | PASS |
| Same module and initialization path, client name 262144 bytes | FAIL: -32000 | FAIL: -32000, child exit 0 | PASS |
| Buffered large initialize, stdin ended during schema wait; natural exit and restart | FAIL: no proxy saturation barrier | PASS: early process abandonment | PASS: EOF cleanup and clean restart |

Both initialize sizes use the same generated, supported `DOC_SYNC_SCHEMA` module. It exports the real demo schema after one 700 ms **unreferenced** timer. This matches the root probe; it does not alter journal code. The inherited cases retain their original 250 ms default. No operation deadline was increased and no body-size limit was changed.

The SDK Client and StdioClientTransport launch the selected real main entry. Large-name content is deterministic ASCII (`01234567` repeated). The fixture observes the real SDK transport's parsed initialize message and records only the name length and SHA-256, then forwards the original message unchanged. The expected 262144-byte name hash is:

`6e184a7b0b1ed25bfbef6e9ba87edecf46137e349b1a7833a192d9be68abdd65`

The fixture also wraps raw stdin's existing `pipe` and `pause` methods to inspect the destination's buffer lengths. It calls the original methods. It adds no data listener, stdin resume, timer, or referenced handle. The large-case assertion requires a real 64 KiB saturation pause **before schema export and before SDK start**. Current evidence records `lifecycle:backpressure:65536:65536`. The negative control still exits early with this observation enabled, so the observer does not mask this reproduction.

Readiness is semantic: successful real SDK initialize, exact parsed-name hash, **13 tools**, and successful `read_document` with an epoch. The upstream model and server sequence must remain unchanged; conditional-edit count must remain zero. Natural EOF exit 0, zero retained SSE streams, and writer reacquisition complete the checks. Test cleanup is not accepted as natural-exit proof.

## EOF scope and lease release

The new buffered-EOF case first observes saturation and confirms schema export has not occurred. It then ends the child's stdin. It requires natural exit 0 under the existing 5 s natural-exit bound, zero retained streams, no conditional edit, unchanged model/sequence, writer reacquisition if session startup occurred, and a clean real SDK restart with 13 tools and clear recovery status. Restart also exits naturally. This catches a bootstrap lease that remains referenced after cleanup.

**Important limit:** when raw stdin is paused, EOF can be hidden behind buffered input. The current receipt shows schema export and session startup, followed by SDK consumption and then the stdin-end observation. This case does not claim immediate pre-session cancellation, cancellation of a schema module that never settles, or refusal of every pipelined tool request after a peer has sent EOF but before Node can observe it. No tool request is queued in this EOF case. The inherited unsaturated EOF test still checks no upstream edit and no retained SSE. The inherited pending tests retain exact-byte and foreign-edit protection; this new EOF case does not substitute a synthetic pending record for those assertions.

The first development run incorrectly required the intentionally interrupted SDK `connect()` promise to settle after EOF. Current server cleanup already exited 0 with no retained SSE, but SDK initialized-notification `send()` can wait for `drain` after the parent has ended its writable pipe. The test-only SDK implementation resolves that write on `drain`, not on close. That extra assertion hit its existing 5 s deadline. It was removed; no server assertion or deadline was weakened. The test now checks server exit and resource/restart state, not completion of a client notification sent after intentional EOF. All three development receipts remain under `backpressure-test-*-initial-sdk-eof-assertion`.

## Source controls

Before launching current-source tests, this lane inspected the root worker's helper and main:

- helper creates a referenced startup lease, exposes `releaseBootstrap`, and releases on end, error, and close;
- main calls `input.releaseBootstrap()` after successful SDK connection/readiness;
- startup failure uses existing cleanup, which calls input close.

The PassThrough-only negative control is a private copy of current `apps/mcp/src` and fixtures. Its only code change replaces the bootstrap interval and its clearing callback with a no-op `releaseBootstrap`. It retains the same 64 KiB proxy, main, recovery, and close logic. This isolates the startup-reference defect from the older raw-stdin implementation. It is not a historical commit or a shipped variant.

Snapshot: `/tmp/doc-sync-pass-through-only-9sPrL2`.
Preserved source archive: `backpressure-pass-through-only-source.tar.gz` (source and fixtures only; restored copies need the same node_modules symlink). Baseline remains at the path in `test-baseline-path.txt`. Both archives use the same installed dependencies as current source, not historical package builds.

Final SHA-256:

- test: `3113200212fed588843e7202a84aa20fffe125bb37536cddd2e9fa70c867b5cc`
- fixture: `d3eae26e53b647f344494d056fd23786bb6e30e518724af989f64a941be8cacc`
- current main: `706d5e383856b3b43a445debf14b0f1644b682071c403ceab2eda75d806f47e2`
- current helper: `c5d701545fc32ba56466656e76f721c1f060f7017e1961ce9eef717ff2fe47b8`

All three final receipts use the same final test and fixture. Each source manifest matches disk after execution. `backpressure-test-verification.json` records this check and shows all 74 recorded demo/MCP child PIDs absent. No tested source changed between the final run and that verification.

## Commands, runtime, and evidence

Node v24.22.1; PATH starts with `/Users/user/.nvm/versions/node/v24.22.1/bin`.

```sh
python3 output/mcp-startup-proof/backpressure-test-watchdog.py baseline
python3 output/mcp-startup-proof/backpressure-test-watchdog.py pass-through-only
python3 output/mcp-startup-proof/backpressure-test-watchdog.py current
PATH=/Users/user/.nvm/versions/node/v24.22.1/bin:$PATH \
  node node_modules/typescript/bin/tsc -p output/mcp-startup-proof/test-tsconfig.json
```

The external watchdog runs only `node --test --test-concurrency=1 apps/mcp/test/startup-lifecycle.test.ts`. It preserves existing 110 s bounds, tracks only its new process session, and signals individually enumerated owned PIDs. Each test child has exact-PID SIGTERM and bounded SIGKILL fallback. Deadline failures remain failures even if cleanup succeeds.

| Final run | Exit | External elapsed | Watchdog fired | Remaining session PIDs |
| --- | --- | --- | --- | --- |
| baseline | 1 | 24.627 s | no | 0 |
| pass-through-only | 1 | 6.588 s | no | 0 |
| current | 0 | 8.207 s | no | 0 |

Final authoritative directories are `backpressure-test-baseline`, `backpressure-test-pass-through-only`, and `backpressure-test-current`. Each includes TAP/text output, source hashes, watchdog result, and per-child/server JSON with natural-exit state before cleanup, stderr, private data paths, and upstream counters. The focused typecheck output is `backpressure-test-typecheck.txt` (empty, exit 0).

This report is the detailed handoff, not the short CLI completion message. Whole-project acceptance and the historical incident cause remain outside this proof.
