# STDIO lane: source investigation

## Verdict

ROOT_CAUSE_NOT_PROVEN. Source inspection only. No source edits, builds, tests, browser runs, mission retries, or test processes were started by this lane.

The literal proposed mechanism (bootstrap waits on an unref-only owner-lock timer) is not present in the inspected project startup path. This does not prove that Node cannot exit during bootstrap. It means this specific theory is not supported by current source. An unobserved runtime failure remains possible.

## Scope and baseline

- Workspace: /Users/user/github/doc-sync.
- Inspected HEAD: 0de9f0ffc06d8be94e448222c0575a99d6ae9a66.
- Initial git status was clean. HANDOFF.md section 5.131 was read.
- Installed MCP SDK: 1.32.2, not the minimum package range 1.29.0.
- Existing HANDOFF evidence remains unchanged. Prior passing retries do not establish a fix.
- The project MCP child is separate from OMX coordination transport.

## Evidence: startup sequence

1. apps/bot/src/runner.ts:216-223 creates a fresh StdioClientTransport and awaits Client.connect. The command is process.execPath; the target is apps/mcp/src/main.ts (runner.ts:26). Thus the project child uses the invoking worker's Node executable. No detached spawn or pipe unref occurs here.
2. SDK client/stdio.js:64-105 spawns the child with stdin/stdout pipes, registers process error/spawn/close and pipe data/error listeners, and resolves start on the spawn event. Spawn is NOT server readiness.
3. SDK shared/protocol.js:219-250 installs protocol callbacks before transport.start. SDK client/index.js:274-305 then sends initialize and awaits its reply. The client can therefore queue initialize while application bootstrap has not yet installed a stdin reader.
4. apps/mcp/src/main.ts:21-49 performs optional schema import/discovery, journal open/read/checkpoint, and DocumentSession.start BEFORE constructing and connecting StdioServerTransport. In the observed discovery configuration, schema GET is first (26-31). Initial MCP readiness is downstream of session startup, not just child spawn.
5. SDK server/stdio.js:9-38 does not read stdin until start attaches a data listener. It has no bootstrap keepalive. No project code reads or discards child stdin before this point in the inspected path. An early initialize remains buffered in the pipe; there is no source evidence that a normal early request is dropped.

## Evidence: owner-lock / event-loop theory

- apps/mcp/src/journal.ts:126-145 calls openWriterLock, then loads durable records. The lock is a FileHandle, not an unref timer or persistent helper process.
- apps/mcp/src/kernel-lock.ts:18-55 opens/stats the lock asynchronously. Darwin uses O_EXLOCK with O_NONBLOCK. Linux uses a synchronous, bounded /usr/bin/flock helper and retains the same descriptor. There is no unref call or timer await in this code.
- apps/bot/src/profiles.ts:28-34 uses the same kernel-lock function for the OUTER bot's profile claim. This is not a child MCP startup timer.
- apps/mcp/src/session.ts:69-95 starts the HTTP/SSE client for a fresh session. Its startup wait uses an ordinary referenced 20 ms timer at 250-255.
- packages/doc-sync/src/sync/node-http-transport.ts:43-122 uses a live SSE request/reader or an ordinary referenced 1000 ms reconnect timer (111-115). There is no unref call in this transport.
- Schema discovery uses fetch followed by response.json and fingerprint validation (node-http-transport.ts:149-156). AbortSignal.timeout is a deadline, not an application owner-lock wait.

Inference, medium confidence: the intended fresh startup path advances through network work, filesystem work, and referenced polling/reconnect timers. No explicit wait on only an unref owner-lock timer explains a clean child exit in this path. This is not a native-handle trace. A stalled body, runtime bug, process termination, or bootstrap rejection cannot be excluded from source alone.

## Evidence: close, EOF, and error provenance

- SDK client/stdio.js:83-86 maps CHILD PROCESS close to transport.onclose but discards code/signal. SDK shared/protocol.js:252-272 clears outstanding response handlers and rejects them with Connection closed. This erases the causal exit detail from the mission's error.
- runner.ts:220-221 deliberately drains and discards nested stderr. The kill-worker fixture now forwards it first (apps/bot/test/kill-worker.ts:4-10). Thus the original failure has an evidence gap that the current fixture can reduce.
- SDK client/stdio.js:143-175 ends child stdin only during explicit transport.close, then uses its existing 2 s SIGTERM / 2 s SIGKILL escalation. The only unref timers in this client lifecycle are shutdown waits, not child bootstrap waits.
- Client initialization failure invokes void this.close() (SDK client/index.js:312-315). runner.ts:323 also closes the client in finally. Those cleanup actions can follow a failure; their later stdin EOF is not evidence that EOF caused the original failure.
- SDK server/stdio.js:32-39 listens to data/error, NOT end/close. Parent EOF alone does not call server transport.close or its onclose callback in this installed implementation. EOF can remove stdin's liveness while an active SSE stream still keeps the app alive. This is a separate shutdown robustness concern, not proof of initial closure.
- SDK server/stdio.js:54-67 explicitly removes its listeners and pauses stdin only on transport.close. No server bootstrap path calls this method before session.start.
- apps/mcp/src/main.ts:46 closes the session on session.start rejection. main.ts:53 logs any bootstrap error and sets exitCode=1. Import, schema validation, journal filesystem/lock/corruption, or session startup errors can therefore produce an initial connection closure with an stderr message. Whether such an error happened in the original failure is UNKNOWN.
- main.ts:49-50 installs the session shutdown callback after server.connect. SDK transport EOF does not itself trigger it; do not treat this callback as general parent-death protection.
- apps/bot/test/runner.test.ts:168 gives the OUTER worker ignored stdin/stdout. This does not give the nested MCP child ignored stdin: the nested SDK independently creates pipe stdin/stdout. The outer fixture only SIGKILLs the worker after the conditional barrier (190), so the intended barrier kill cannot explain a failure before that barrier. Unrecorded external termination remains unknown.

## Ranked interpretations

1. Early bootstrap failure or child termination: compatible with Connection closed and schema-only proxy traffic; exact cause UNKNOWN. The error reports only protocol closure, not exit cause.
2. Missing nested child exit/stage/stderr diagnostics: CONFIRMED observability gap in the original report and production runner. This explains why the cause cannot be selected, not why the child exited.
3. Unref-only owner-lock bootstrap wait: NOT SUPPORTED by the current project source. A broader runtime liveness defect is NOT RULED OUT without child beforeExit/exit and active-resource evidence.
4. SSE reconnect accidentally closes MCP pipes: no direct coupling found. The transport reconnects HTTP only, fences stale subscriptions, and never touches process stdin/stdout.
5. Early request lost before server subscription: NOT SUPPORTED. Client callbacks precede spawn; server attaches its reader later; pipe buffering bridges the gap. This says nothing about runtime process liveness.

## Candidate changes for owner review (not implemented)

A. Evidence-first child lifecycle capture, preferred before selecting a root-cause fix:
- Capture bounded child stderr in the test fixture and child exit code/signal.
- Record stage markers before/after schema discovery, journal open, session.start and stdio attach.
- Record beforeExit/exit plus resource type names only. Do not include document content, credentials, or raw request bodies. Parent timers do not prove CHILD liveness.
- Preserve the first failure. No retry, timeout increase, or success-on-retry classification.

B. If a child idle exit is demonstrated, a narrow bootstrap lifetime guard is safer than moving the full server connection ahead of recovery:
- Hold one referenced, non-reading bootstrap guard before the first async operation. Release it only after stdio starts or bootstrap fails. Keep all existing deadlines unchanged.
- Do NOT add a data listener or resume stdin early just to keep it alive: it can consume initialize before the MCP transport owns the bytes.
- Do NOT connect the full MCP server before session.start unless tool admission is explicitly gated. Otherwise requests can run before journal/recovery/schema ownership is ready.
- A guard can mask an unresolved await, so it needs the existing operation deadline/fail-closed cleanup. It is only a candidate hardening change until the original failure mechanism is reproduced.

C. Treat EOF/shutdown separately:
- If adding stdin EOF/close handling, handle EOF that occurs before bootstrap completes. Stop admission and close only this session/journal/transport.
- Preserve shutdownSession's drain and settled-only leave rule (apps/mcp/src/shutdown.ts:6-9). Do not release an actor with unconfirmed work.
- Prevent multiple cleanup paths from racing; release the bootstrap guard in all failure paths. A stdin keepalive without cleanup can leave a bootstrap-failed process alive until the parent kill escalation.

## Pending and duplicate-replay safety

- runner.ts:236-250 performs schema verification and settled reads before planner work.
- runner.ts:290 rejects an identical last confirmed edit at the guarded revision.
- runner.ts:295-309 persists mission.pending BEFORE edit_document, clears it only after confirmed or explicitly stale rejection, and records confirmed history.
- runner.ts:317-323 records needs_attention without clearing uncertain pending state and closes the client. There is no automatic retry of Client.connect or the mission in this path.
- session.ts:48-65 journals exact prepared evidence and the optional mission bridge BEFORE conditional submission. A startup/liveness change must leave that ordering intact.
- session.ts:85-88 does not connect a recovered pending actor automatically. A restart must not turn bootstrap failure into duplicate replay.
- A schema-only/no-pending observation places the observed failure before planner edit submission, but does not distinguish schema response failure, journal failure, or process idle/kill.

## Verification boundary

STATIC_INSPECTION_COMPLETE. ROOT_CAUSE_NOT_PROVEN. RUNTIME_PROBE_NOT_RUN. REGRESSION_TESTS_NOT_RUN. No fix or passing retry is claimed. No commit/push. Only evidence files under output/mcp-startup-proof were written by this lane.
