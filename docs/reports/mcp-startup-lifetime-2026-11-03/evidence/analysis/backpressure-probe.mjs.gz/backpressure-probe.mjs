import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StdioClientTransport} from '@modelcontextprotocol/sdk/client/stdio.js';
const dir=resolve('output/mcp-startup-proof/backpressure-'+Date.now());await mkdir(dir,{recursive:true});
const owned=new Set(), results=[];let server;
async function stop(p){if(!p||p.exitCode!==null||p.signalCode!==null)return;const done=once(p,'close');p.kill('SIGTERM');const t=setTimeout(()=>p.kill('SIGKILL'),1000);try{await done;}finally{clearTimeout(t);}}
const guard=setTimeout(()=>{for(const p of owned)p.kill('SIGKILL');process.exitCode=1;},20000);
try{
 server=spawn(process.execPath,[resolve('apps/demo/server.ts')],{env:{...process.env,PORT:'0',DATA_DIR:join(dir,'server')},stdio:['ignore','pipe','pipe']});owned.add(server);server.stderr.resume();let out='';
 const origin=await new Promise((ok,fail)=>{const t=setTimeout(()=>fail(Error('server deadline')),5000);server.stdout.on('data',b=>{out+=b;const m=out.match(/http:\/\/localhost:(\d+)/);if(m){clearTimeout(t);ok('http://127.0.0.1:'+m[1]);}});server.once('error',fail);});
 const schema=join(dir,'schema.mjs');await writeFile(schema,`import {DEMO_SCHEMA} from ${JSON.stringify(pathToFileURL(resolve('fixtures/demo-schema.ts')).href)};await new Promise(resolve=>setTimeout(resolve,700).unref());export const schema=DEMO_SCHEMA;\n`);
 for(const bytes of [8,262144]){
  const client=new Client({name:'p'.repeat(bytes),version:'1'});const transport=new StdioClientTransport({command:process.execPath,args:[resolve('apps/mcp/src/main.ts')],stderr:'pipe',env:{...process.env,DOC_SYNC_URL:origin,DOC_SYNC_DOCUMENT:'backpressure-'+bytes,DOC_SYNC_ACTOR:'probe',DOC_SYNC_JOURNAL:'off',DOC_SYNC_SCHEMA:schema}});let errors='', child;
  transport.stderr.on('data',b=>errors+=b);
  const start=transport.start.bind(transport);transport.start=async()=>{await start();child=transport._process;owned.add(child);};
  const result={initializeNameBytes:bytes};let deadline;
  try{await Promise.race([client.connect(transport),new Promise((_,no)=>{deadline=setTimeout(()=>no(Error('connect deadline')),4000);})]);result.handshake=true;result.tools=(await client.listTools()).tools.length;}
  catch(e){result.handshake=false;result.error=String(e);result.exitBeforeCleanup=child?.exitCode;result.signalBeforeCleanup=child?.signalCode;}
  finally{clearTimeout(deadline);await client.close().catch(()=>{});await transport.close().catch(()=>{});await stop(child);result.stderr=errors;results.push(result);}
 }
 await writeFile(join(dir,'results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify({dir,results}));
}finally{clearTimeout(guard);for(const p of owned)await stop(p);}
