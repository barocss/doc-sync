"""External watchdog. Exact owned PIDs only; timeout is always failure."""
import os, sys, time, signal, subprocess, json
from pathlib import Path
label = sys.argv[1]
root = Path.cwd()
folder = root / 'output/mcp-startup-proof' / ('backpressure-test-' + label)
folder.mkdir(exist_ok=True)
env = dict(os.environ)
env['PATH'] = '/Users/user/.nvm/versions/node/v24.22.1/bin:' + env['PATH']
env['DOC_SYNC_TEST_EVIDENCE'] = str(folder)
entries = {
    'baseline': (root / 'output/mcp-startup-proof/test-baseline-path.txt').read_text().strip() + '/apps/mcp/src/main.ts',
    'pass-through-only': '/tmp/doc-sync-pass-through-only-9sPrL2/apps/mcp/src/main.ts',
}
if label in entries:
    env['DOC_SYNC_TEST_MCP_ENTRYPOINT'] = entries[label]
    env['DOC_SYNC_TEST_SOURCE_LABEL'] = label
else:
    env.pop('DOC_SYNC_TEST_MCP_ENTRYPOINT', None)
    env['DOC_SYNC_TEST_SOURCE_LABEL'] = 'current with bootstrap lease'
start = time.monotonic()
known = set()
fired = False
with (folder / 'tap.txt').open('w') as out:
    proc = subprocess.Popen(['node', '--test', '--test-concurrency=1', 'apps/mcp/test/startup-lifecycle.test.ts'], env=env, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        while proc.poll() is None:
            # Unique process group identifies this run, but each signal targets one exact PID.
            table = subprocess.check_output(['ps', '-axo', 'pid=,pgid='], text=True)
            for line in table.splitlines():
                pid, group = map(int, line.split())
                if group == proc.pid: known.add(pid)
            if time.monotonic() - start > 110:
                fired = True
                break
            time.sleep(.1)
    finally:
        for pid in sorted(known - {proc.pid}, reverse=True):
            try:
                if os.getpgid(pid) == proc.pid: os.kill(pid, signal.SIGKILL)
            except ProcessLookupError: pass
        if proc.poll() is None:
            proc.kill()
        proc.wait(timeout=3)
remaining = []
for pid in known:
    try:
        if os.getpgid(pid) == proc.pid: remaining.append(pid)
    except ProcessLookupError: pass
result = dict(root_pid=proc.pid, owned_pids=sorted(known), remaining_pids=remaining, returncode=proc.returncode, watchdog_fired=fired, elapsed_seconds=round(time.monotonic()-start, 3))
(folder / 'watchdog.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
sys.exit(124 if fired else proc.returncode or bool(remaining))
