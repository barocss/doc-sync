import fs from 'node:fs/promises';
import {syncBuiltinESMExports} from 'node:module';
import {pbkdf2} from 'node:crypto';
import {StdioServerTransport} from '@modelcontextprotocol/sdk/server/stdio.js';
const mode=process.env.REPRO_MODE;
const emit=(phase,extra={})=>process.stderr.write(JSON.stringify({at:Date.now(),pid:process.pid,phase,...extra})+'\n');
const state=()=>({handles:process._getActiveHandles().map(h=>({type:h.constructor.name,hasRef:h.hasRef?.()})),requests:process._getActiveRequests().map(h=>h.constructor.name),resources:process.getActiveResourcesInfo()});
process.on('beforeExit',code=>emit('beforeExit',{code,...state()}));
process.on('exit',code=>emit('exit',{code,...state()}));
const originalStart=StdioServerTransport.prototype.start;
StdioServerTransport.prototype.start=async function(...args){emit('stdio-start');return originalStart.apply(this,args);};
const original=fs.open;
fs.open=async function(path,...args){
 if(String(path).endsWith('.json.lock')){
  emit('lock-open-enter',{path:String(path),mode,...state()});
  if(mode==='ref-delay'||mode==='unref-delay')await new Promise(resolve=>{
   const timer=setTimeout(()=>{emit('delay-complete');resolve();},1500);
   if(mode==='unref-delay')timer.unref();
   emit('delay-installed',{referenced:timer.hasRef(),...state()});
  });
  if(mode==='real-fs-delay'){
   // UV_THREADPOOL_SIZE=1. Queue real fs.open behind a bounded crypto job.
   // Both jobs are real active libuv requests; there is no synthetic wait Promise.
   pbkdf2('repro','salt',4000000,32,'sha256',()=>emit('threadpool-released'));
   emit('threadpool-occupied');
  }
 }
 const file=await original.call(this,path,...args);
 if(String(path).endsWith('.json.lock'))emit('lock-open-complete',{...state()});
 return file;
};
syncBuiltinESMExports();
emit('hook-ready',{mode});
