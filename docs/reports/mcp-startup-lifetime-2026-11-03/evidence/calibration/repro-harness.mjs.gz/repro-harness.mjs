import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {createServer} from 'node:http';
import fs from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StdioClientTransport} from '@modelcontextprotocol/sdk/client/stdio.js';
import {IntentJournal} from '../../../apps/mcp/src/journal.ts';
const root=fileURLToPath(new URL('.',import.meta.url));
const run=join(root,'repro-run-'+Date.now());await fs.mkdir(run,{recursive:true});
const events=[];const results=[];const children=new Set();let server,proxy;
const log=(phase,data={})=>{events.push({at:Date.now(),phase,...data});};
async function stop(child){if(!child||child.exitCode!==null||child.signalCode!==null)return;const closed=once(child,'close');child.kill('SIGTERM');const kill=setTimeout(()=>child.kill('SIGKILL'),1000);try{await closed;}finally{clearTimeout(kill);}}
const watchdog=setTimeout(()=>{log('watchdog');for(const child of children)if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');proxy?.closeAllConnections();proxy?.close();process.exitCode=1;},100000);
try{
 server=spawn(process.execPath,[resolve('apps/demo/server.ts')],{env:{...process.env,PORT:'0',DATA_DIR:join(run,'repro-server-data'),NO_SCHEMA:''},stdio:['ignore','pipe','pipe']});children.add(server);log('server-spawn',{pid:server.pid});
 let serverOut='',serverErr='';server.stderr.on('data',b=>serverErr+=b);
 const origin=await new Promise((yes,no)=>{const timer=setTimeout(()=>no(Error('server startup timeout')),10000);server.once('error',no);server.once('exit',code=>{clearTimeout(timer);no(Error('server exited '+code));});server.stdout.on('data',b=>{serverOut+=b;const m=serverOut.match(/http:\/\/localhost:(\d+)/);if(m){clearTimeout(timer);yes('http://127.0.0.1:'+m[1]);}});});
 let current;
 proxy=createServer(async(req,res)=>{const record={at:Date.now(),method:req.method,url:req.url};current?.requests.push(record);try{const chunks=[];for await(const b of req)chunks.push(b);const headers={...req.headers};delete headers.host;const response=await fetch(origin+req.url,{method:req.method,headers,...(chunks.length?{body:Buffer.concat(chunks)}:{})});record.status=response.status;res.writeHead(response.status,Object.fromEntries(response.headers));if(response.body){for await(const b of response.body){if(res.destroyed)break;res.write(b);}}res.end();record.completeAt=Date.now();}catch(error){record.error=String(error);if(!res.headersSent)res.writeHead(502);res.end();}});
 await new Promise(r=>proxy.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+proxy.address().port;
 for(const mode of ['baseline','ref-delay','unref-delay','real-fs-delay','lock-held']){
  const dir=join(run,'repro-'+mode);await fs.mkdir(dir);const r={mode,requests:[],startAt:Date.now()};results.push(r);current=r;
  let lock;if(mode==='lock-held')lock=await IntentJournal.open(join(dir,'repro-doc.json'),{document:'repro-doc',actor:'repro-actor'});
  const client=new Client({name:'repro',version:'1'});
  const transport=new StdioClientTransport({command:process.execPath,args:['--import',join(root,'repro-hook.mjs'),resolve('apps/mcp/src/main.ts')],stderr:'pipe',env:{...process.env,UV_THREADPOOL_SIZE:'1',REPRO_MODE:mode,DOC_SYNC_URL:url,DOC_SYNC_DOCUMENT:'repro-doc',DOC_SYNC_ACTOR:'repro-actor',DOC_SYNC_DISCOVER_SCHEMA:'on',DOC_SYNC_JOURNAL:'on',DOC_SYNC_JOURNAL_DIR:dir}});
  let errors='',stdout='';transport.stderr.on('data',b=>errors+=b);
  const start=transport.start.bind(transport);let child,closed;
  transport.start=async()=>{await start();child=transport._process;children.add(child);r.pid=child.pid;closed=once(child,'close');child.stdout.on('data',b=>stdout+=b);child.on('exit',(code,signal)=>{r.exit={code,signal,at:Date.now()};});};
  try{await client.connect(transport);r.connect='PASS';r.tools=(await client.listTools()).tools.map(t=>t.name);}
  catch(error){r.connect='FAIL';r.error={name:error.name,message:error.message,code:error.code};}
  finally{r.outcomeAt=Date.now();r.exitBeforeCleanup=r.exit??null;await client.close().catch(e=>r.cleanupError=String(e));await transport.close().catch(e=>r.cleanupError=String(e));await stop(child);if(closed)await closed;await lock?.close();await fs.writeFile(join(dir,'repro-stderr.log'),errors);await fs.writeFile(join(dir,'repro-stdout.log'),stdout);await fs.writeFile(join(dir,'repro-result.json'),JSON.stringify(r,null,2));}
 }
 await fs.writeFile(join(run,'repro-server-stdout.log'),serverOut);await fs.writeFile(join(run,'repro-server-stderr.log'),serverErr);
}finally{
 await Promise.all([...children].map(stop));proxy?.closeAllConnections();if(proxy)await new Promise(r=>proxy.close(r));clearTimeout(watchdog);
 log('owned-children-closed',{children:[...children].map(c=>({pid:c.pid,exitCode:c.exitCode,signalCode:c.signalCode}))});
 await fs.writeFile(join(run,'repro-events.json'),JSON.stringify(events,null,2));await fs.writeFile(join(run,'repro-results.json'),JSON.stringify(results,null,2));console.log(JSON.stringify({run,results},null,2));
}

const expected={baseline:'PASS','ref-delay':'PASS','unref-delay':'FAIL','real-fs-delay':'PASS','lock-held':'FAIL'};
for(const r of results){
 if(r.connect!==expected[r.mode])throw Error('Unexpected connection result: '+JSON.stringify(r));
 if(r.mode==='unref-delay'&&(r.exitBeforeCleanup?.code!==0||r.error?.code!==-32000||r.requests.length!==1))throw Error('Silent-exit signature missing');
 if(r.mode==='lock-held'&&(r.exitBeforeCleanup?.code!==1||r.error?.code!==-32000||r.requests.length!==1))throw Error('Lock rejection signature missing');
}
if(results.length!==5)throw Error('Incomplete matrix');
