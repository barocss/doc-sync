"""External 110 s watchdog. Its process group contains only this owned harness tree."""
import json, os, pathlib, signal, subprocess, time
root=pathlib.Path(__file__).resolve().parent
stamp=str(time.time_ns())
record={'started':time.time(),'deadline_seconds':110,'automatic_retries':0}
with (root/('repro-external-'+stamp+'.stdout.log')).open('w') as out, (root/('repro-external-'+stamp+'.stderr.log')).open('w') as err:
    child=subprocess.Popen(['/Users/user/.nvm/versions/node/v24.22.1/bin/node',str(root/'repro-harness.mjs')],stdout=out,stderr=err,start_new_session=True)
    record['pid']=child.pid
    try:
        record['returncode']=child.wait(timeout=110)
        record['watchdog_fired']=False
    except subprocess.TimeoutExpired:
        record['watchdog_fired']=True
        os.killpg(child.pid,signal.SIGKILL)
        record['returncode']=child.wait()
record['finished']=time.time()
(root/('repro-external-'+stamp+'.json')).write_text(json.dumps(record,indent=2))
print(json.dumps(record))
raise SystemExit(1 if record['watchdog_fired'] else record['returncode'])
