# REPRO lane: MCP startup closure

## Result

**Historical root cause: NOT_PROVEN. Production fix: NOT_IMPLEMENTED.**

A controlled unreferenced wait at the real journal lock-open boundary reproduces
MCP `-32000: Connection closed`, exit code 0, no stdio startup, and schema GET as
the only HTTP request. This is a fault-injection result. The current production
journal/lock code does not contain that wait or an unreferenced timer. Do not
report this result as a reproduction of the original trigger or as a fix.

A real held writer lock also reproduces schema-only MCP closure. It exits 1 and
prints `Journal already has an active writer`. This is expected fail-closed lock
behavior, not a reason to weaken writer exclusion.

## Scope and environment

- Workspace: `/Users/user/github/doc-sync`.
- HEAD: `0de9f0ffc06d8be94e448222c0575a99d6ae9a66`.
- Node v24.22.1; Darwin arm64; installed MCP SDK 1.32.2.
- Read HANDOFF.md section 5.131 and current application code.
- Real `apps/mcp/src/main.ts`, `IntentJournal`, kernel writer lock, demo HTTP
  server, NodeHttpTransport, SDK Client, and SDK StdioClientTransport.
- Only output files in this lane's `repro-*` directory were written.
- No source, test-source, tracked docs, commit, push, build, broad tests, or
  browser/mobile execution. Existing dist was used.
- Cases ran sequentially. One owned demo server and at most one MCP child ran
  at once. The proxy ran in the harness process. No mission retry was used.

## Controlled matrix

| Case | Change at lock-open boundary | Connect | Exit before cleanup | HTTP before failure |
| --- | --- | --- | --- | --- |
| baseline | Instrumentation only | PASS | None | Not applicable |
| ref-delay | 1500 ms referenced timer before real open | PASS | None | Not applicable |
| unref-delay | Same timer with `.unref()` | FAIL, -32000 | 0, no signal | Schema GET 200 only |
| real-fs-delay | Queue real open behind bounded PBKDF2 work with UV_THREADPOOL_SIZE=1 | PASS | None | Not applicable |
| lock-held | Parent holds the same real IntentJournal writer lock | FAIL, -32000 | 1, no signal | Schema GET 200 only |

Successful cases also completed SDK `listTools` and returned 13 tools. Successful
children were terminated during SDK cleanup; their final SIGTERM is not a startup
failure. Failed children exited before cleanup. No edits were submitted. There
was no conditional POST in either failed case.

## Evidence and interpretation

1. **Evidence:** `apps/mcp/src/main.ts:26-38` discovers schema before journal open.
   It does not attach stdio until after journal recovery and session startup
   (`:39-49`). `main().catch(...)` is detached (`:53`).
2. **Evidence:** `apps/mcp/src/journal.ts:133-136` awaits real mkdir, realpath, and
   writer-lock open. `apps/mcp/src/kernel-lock.ts:24-28` uses nonblocking native
   lock acquisition and throws on an active writer. These paths do not contain
   an unreferenced readiness timer.
3. **Evidence:** the hook pauses `node:fs/promises.open` only for `.json.lock`,
   before the original real open. It does not replace the main function, journal
   implementation, SDK handshake, or server behavior. Baseline uses the same
   instrumentation without a delay. The real-fs case queues the original open
   immediately behind a real libuv crypto job, rather than awaiting a fake timer.
4. **Evidence:** the unref case records `delay-installed` with referenced=false,
   then `beforeExit` and `exit` at code 0 with no active requests. It never records
   `delay-complete`, `lock-open-complete`, or `stdio-start`. Raw protocol stdout is
   empty. The referenced control completes the delay and starts stdio.
5. **Inference:** a startup Promise that depends only on an unreferenced timer
   can be abandoned before stdio begins. An open parent stdin pipe alone does
   not prevent the observed exit. This proves a conditional liveness gap, not
   that production reaches this condition without the hook.
6. **Evidence:** delayed real fs work completes and connects. A real occupied
   writer lock rejects with a nonzero exit and explicit diagnostic. Thus slow
   fs readiness is not equivalent to the injected unreferenced wait, and schema
   GET alone cannot distinguish a silent exit from a normal startup exception.
7. **Unknown:** the historical child exit code, stderr, and last journal phase
   are unavailable. Neither injection proves the original incident's trigger.
   Passing control cases or later tests must not be called a production fix.

## Runs and watchdog boundary

- Exploratory run: `repro-run-1793710556907/`. It completed in about 10 seconds.
  It had an in-process 115-second watchdog, **not the requested external watchdog**.
  This procedural limit is retained explicitly; these raw files were not changed.
- Qualification run: `repro-run-1793710620197/`. The corrected harness ran under
  `repro-watchdog.py`, an external 110-second watchdog. Its separate process group
  contains only this owned harness and its children. The in-process guard was
  reduced to 100 seconds. External result: exit 0, watchdog not fired, 9.51 seconds.
- The qualification run asserts the five expected connect results, both failed
  exit codes, error -32000, and schema-only request counts. This was a controlled
  harness revalidation after adding the missing external guard, not an automatic
  mission retry or a blind suite repeat. Both raw runs remain available.
- All 12 recorded demo/MCP PIDs from both runs were checked absent. The local
  proxy was closed. No foreign process was signaled.

## Commands and artifacts

Run from the workspace root:

```sh
PATH=/Users/user/.nvm/versions/node/v24.22.1/bin:$PATH \
  python3 output/mcp-startup-proof/repro-boundary-20261103/repro-watchdog.py
```

The external watchdog invokes `repro-harness.mjs`. That harness spawns the real
MCP entrypoint with `--import .../repro-hook.mjs`. Each invocation creates a new
`repro-run-<timestamp>/` directory and does not overwrite prior results.

- `repro-hook.mjs`: boundary injection and child phase/handle/request logging.
- `repro-harness.mjs`: server, proxy, real SDK clients, assertions, owned cleanup.
- `repro-watchdog.py`: external bounded execution; no retries.
- `repro-external-*.json`: external PID, duration, return code, watchdog result.
- `repro-run-*/repro-results.json`: consolidated request, exit, and SDK outcomes.
- `repro-run-*/repro-*/repro-stderr.log`: raw child phase and diagnostic output.
- `repro-run-*/repro-*/repro-stdout.log`: raw protocol output.
- `repro-run-*/repro-events.json`: server PID and all owned child exit records.
- `repro-verification.json`: source hashes, HEAD, clean Git status, and PID checks.

## Handoff

Use the synthetic silent-exit case as a focused negative oracle if a startup
liveness change is proposed. Keep the real-fs control and lock-held rejection
case. Do not infer that adding a keepalive or top-level await fixes the historical
incident. A production fix still needs a reachable trigger and matching evidence.
