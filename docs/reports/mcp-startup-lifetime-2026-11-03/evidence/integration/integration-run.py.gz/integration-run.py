from pathlib import Path
import os,sys,json,subprocess,time,signal
root=Path('/Users/user/github/doc-sync'); out=root/'output/mcp-startup-proof'
stage=sys.argv[1]
commands={
 'mcp':['npm','test','--workspace','@doc-sync/mcp'],
 'bot':['npm','test','--workspace','@doc-sync/bot'],
 'demo-recovery':['node','--test','apps/demo/test/bot-recovery-start.test.ts'],
 'docs':['npm','test','--workspace','@doc-sync/docs'],
 'types':['npx','tsc','--noEmit'],
}
cmd=commands[stage]; env=dict(os.environ);env['PATH']='/Users/user/.nvm/versions/node/v24.22.1/bin:'+env.get('PATH','')
log=out/('integration-'+stage+'.log'); start=time.monotonic();expired=False
with log.open('wb') as f:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  expired=True
  os.killpg(p.pid,signal.SIGINT)
  try:code=p.wait(timeout=3)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);code=p.wait()
receipt={'stage':stage,'command':cmd,'cwd':str(root),'pid':p.pid,'group':p.pid,'externalWatchdogSeconds':180,'watchdogTriggered':expired,'exit':code,'seconds':round(time.monotonic()-start,3),'status':'PASS' if code==0 and not expired else 'FAIL'}
(out/('integration-'+stage+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(0 if receipt['status']=='PASS' else 1)
