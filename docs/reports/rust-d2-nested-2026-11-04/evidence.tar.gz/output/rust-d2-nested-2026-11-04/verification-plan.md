# D2 recursive Document verification scope

Base: main1cfb7a23611f0a98994a6716cfc2bddfc5ba89f4. No commit or publication is
part of this implementation request. Runtime tree storage and the typed SDK
are private native Cargo experiments; TypeScript remains the production engine.

This slice adds recursively nested flow/text/atom descriptors, flow-specific
defaults and children, owned schema identity, and parent-aware native editing.
Flat runtime and fixed-preset behavior must stay compatible. Grid/table,
group/inline/span, value marks, structured Document attributes, cardinality,
computed rules, live schema transition and full WASM/client delivery remain
outside this slice and must reject explicitly or retain their existing limits.
Do not mark full D2 or product Word/Notion/presentation compatibility complete.

Acceptance requires the unsupported-before control, native core/SDK full tests,
independent native/TS authoring across at least two renamed schemas, complete
normalized models and History, exact operations where the existing wire contract
allows it, concurrent foreign writes/deletes/moves, undo/redo order, no clock
consumption for derived empty-flow state, anchored selections, invalid-input
atomicity, checkpoint/pending round trip and duplicate exact replay/acknowledge.
State every normalization and unqualified wire/transport boundary. Preserve all
failed probes and bind source/binary hashes before and after each final trace.

The existing Graphic, sparse-sheet and flat runtime comparisons remain regression
controls. Run them on frozen final sources, followed by the affected Node/docs
checks. No mobile testing or new browser, server, MCP or WASM qualification is
implied. No new performance or heap claim follows from semantic passes.
