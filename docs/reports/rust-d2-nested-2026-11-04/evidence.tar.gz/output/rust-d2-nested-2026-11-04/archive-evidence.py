from pathlib import Path
import json,hashlib,tarfile,re
root=Path('/Users/user/github/doc-sync'); task=root/'output/rust-d2-nested-2026-11-04'; report=root/'docs/reports/rust-d2-nested-2026-11-04'
selected=set()
for directory in ['compare','sdk-final','legacy-runtime','docs-example','workspace-investigation']:
 d=task/directory
 for p in d.rglob('*'):
  if p.is_file() and 'target' not in p.parts and p.suffix in {'.json','.log','.rs','.toml','.lock','.mjs','.stderr'}:
   selected.add(p)
for n in ['core-receipt.json','core-tests.log','placements-before.log','baseline.json','baseline.tar.gz','verification-plan.md','final-source-verification.json','archive-evidence.py']:
 selected.add(task/n)
for p in (root/'output/refactor-2026-11-03').glob('rust-d2-*'):
 if p.is_file() and p.suffix in {'.json','.log'}:selected.add(p)
for directory in ['experiments/rust-sdk','experiments/rust-shadow']:
 for p in (root/directory).rglob('*'):
  if p.is_file() and 'target' not in p.relative_to(root).parts and p.suffix in {'.rs','.toml','.lock'}:selected.add(p)
for n in ['experiments/runtime-document-nested/compare.mjs','experiments/runtime-document-nested/fixtures.mjs','experiments/runtime-schema-native/compare.mjs','README.md','HANDOFF.md','experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md','apps/docs/src/schemas/custom.md','apps/docs/src/roadmap.md','docs/rust-roadmap.md']:
 selected.add(root/n)
# Exclude previous build targets in case a consumer used a nonstandard target directory.
selected={p for p in selected if p.exists() and not any(x=='target' or x.endswith('-target') or x.startswith('target-') for x in p.relative_to(root).parts)}
files=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(selected)]
with tarfile.open(report/'evidence.tar.gz','w:gz') as tar:
 for p in sorted(selected):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
archive=report/'evidence.tar.gz'
manifest={'status':'SELECTED_EVIDENCE_SEALED','sourceBase':'1cfb7a23611f0a98994a6716cfc2bddfc5ba89f4','scope':'Recursive runtime flow/text/atom native slice; full D2/D3 remain open','archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'excluded':['Cargo targets and native binaries','duplicate native stdout','older superseded before-moved-anchor-repair traces'],'files':files}
(report/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Read every member back and check its recorded digest.
with tarfile.open(archive,'r:gz') as tar:
 for f in files:assert hashlib.sha256(tar.extractfile(f['path']).read()).hexdigest()==f['sha256'],f['path']
print(json.dumps({'files':len(files),'archiveBytes':archive.stat().st_size,'readback':'PASS'}))
