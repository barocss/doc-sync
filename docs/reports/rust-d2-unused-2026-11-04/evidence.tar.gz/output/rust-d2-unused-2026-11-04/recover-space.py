from pathlib import Path
import json,hashlib,gzip,os,shutil
root=Path('/Users/user/github/doc-sync');out=root/'output/rust-d2-unused-2026-11-04';base=root/'output/rust-d2-rules-2026-11-04/compare';rows=[]
receipt=out/'space-recovery.json';assert not receipt.exists()
def digest(p,opener=open):
 h=hashlib.sha256();size=0
 with opener(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 return h.hexdigest(),size
files=[p for p in base.rglob('*') if p.is_file() and p.name in {'native-trace.json','typescript-trace.json','native.stdout','raw-failure.json'} and p.stat().st_size>16*1024*1024 and not p.with_name(p.name+'.gz').exists()]
free=shutil.disk_usage(root).free
for p in sorted(files,key=lambda p:p.stat().st_size,reverse=True):
 z=p.with_name(p.name+'.gz');tmp=z.with_name(z.name+'.partial');original_hash,original_size=digest(p)
 with p.open('rb') as src,tmp.open('xb') as target:
  with gzip.GzipFile(filename='',mode='wb',fileobj=target,compresslevel=1,mtime=0) as stream:
   for b in iter(lambda:src.read(1048576),b''):stream.write(b)
 restored_hash,restored_size=digest(tmp,gzip.open);assert (restored_hash,restored_size)==(original_hash,original_size)
 assert digest(p)==(original_hash,original_size),'source changed during compression'
 tmp.rename(z);compressed_hash,compressed_size=digest(z)
 rows.append({'original':str(p.relative_to(root)),'compressed':str(z.relative_to(root)),'originalSha256':original_hash,'originalBytes':original_size,'compressedSha256':compressed_hash,'compressedBytes':compressed_size,'restoredSha256':restored_hash,'restoredBytes':restored_size,'status':'PASS','rawRemoved':False})
 receipt.write_text(json.dumps({'status':'IN_PROGRESS','scope':'Completed owned rules comparison traces only; source/executables/sealed reports unchanged','freeBefore':free,'files':rows},indent=2)+'\n')
 p.unlink();rows[-1]['rawRemoved']=True
 receipt.write_text(json.dumps({'status':'IN_PROGRESS','scope':'Completed owned rules comparison traces only; source/executables/sealed reports unchanged','freeBefore':free,'files':rows},indent=2)+'\n')
record={'status':'PASS','scope':'Completed owned rules comparison traces losslessly gzipped; original files restorable. No source, executable, Cargo cache or sealed report cleanup.','freeBefore':free,'freeAfter':shutil.disk_usage(root).free,'files':rows,'originalBytes':sum(x['originalBytes'] for x in rows),'compressedBytes':sum(x['compressedBytes'] for x in rows)};receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['status','freeBefore','freeAfter','originalBytes','compressedBytes']}))
