from pathlib import Path
import json,hashlib,gzip,re,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-unused-2026-11-04'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
s=read(t/'compare-summary.json');assert s['status']=='BOUNDED_PASS_WITH_D3_OBSERVATIONS';rec={n:read(t/p) for n,p in s['receipts'].items()}
assert all(rec[n]['status']=='PASS' for n in ['main','inheritedTextfalse','oracle','product']);assert rec['compiler']['status']=='OBSERVED'
maps={'main':rec['main']['sourceHashes'],'inheritedTextfalse':rec['inheritedTextfalse']['sourceHashes'],'oracle':rec['oracle']['hashesBefore'],'product':rec['product']['hashesBefore'],'compilerObservations':rec['compiler']['hashesBefore'],'sdk':read(t/'sdk-unused-summary.json')['sourceSha256'],'inheritedTsIntegration':read(t/'inherited-ts-integration-source.json')['files']};counts={}
for label,files in maps.items():
 bad=[n for n,h in files.items() if sha(Path(n) if Path(n).is_absolute() else r/n)!=h];assert not bad,(label,bad);counts[label]=len(files)
for n in ['oracle','product','compiler']:assert rec[n]['hashesBefore']==rec[n]['hashesAfter']
for n in ['main','inheritedTextfalse']:assert all(a['status']=='PASS' and a['hashesBefore']==a['hashesAfter'] for a in rec[n]['attempts'])
base=read(t/'baseline.json');allowed={'HANDOFF.md','README.md','docs/rust-roadmap.md','apps/docs/src/roadmap.md','apps/docs/src/guide/rust.md','apps/docs/src/guide/document-rules.md','apps/docs/src/schemas/custom.md','apps/docs/src/schemas/document.md','experiments/rust-sdk/README.md','experiments/rust-shadow/src/runtime_schema.rs'};changed=[n for n,h in base['files'].items() if sha(r/n)!=h];assert set(changed)<=allowed,changed
for row in read(t/'earlier-seals.json'):
 p=r/row['report'];assert sha(p/'seal.json')==row['sealSha256']
 for n,h in read(p/'seal.json')['files'].items():assert sha(p/n)==h
old=read(r/'output/rust-d2-fieldrefs-2026-11-04/compare-regressions/run-2026-11-04T07-07-06.074Z-60037/receipt.json')['frozenHashes'];oldbins={n:h for n,h in old.items() if n.startswith('output/')}
for n,h in oldbins.items():assert sha(r/n)==h,n
manifest=read(r/'experiments/runtime-document-unused/product-schemas.manifest.json');assert sha(r/manifest['source'])==manifest['sourceSha256'];assert sha(r/'experiments/runtime-document-unused/product-schemas.json')==manifest['snapshotSha256'];assert manifest['schemas']['word']['nodes']==23 and manifest['schemas']['presentation']['nodes']==27
body=(r/'experiments/rust-sdk/examples/runtime_unused.rs').read_text()
for n in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
 text=(r/n).read_text().split('### Unused node declarations',1)[1];assert re.search(r'```rust\n(.*?)```',text,re.S).group(1)==body,n
for n in ['consumer-readme/src/main.rs','consumer-guide/src/main.rs']:assert (t/n).read_text()==body,n
compression=[]
for row in read(t/'compare-compression.json'):
 p=t/row['compressed'];h=hashlib.sha256();size=0
 with gzip.open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 assert h.hexdigest()==row['sha256'] and size==row['bytes'];compression.append({**row,'compressedSha256':sha(p)})
(t/'compression-current.json').write_text(json.dumps({'status':'PASS','files':compression},indent=2)+'\n')
recovery=read(t/'space-recovery.json');assert recovery['status']=='PASS'
for row in recovery['files']:
 assert sha(r/row['compressed'])==row['compressedSha256'];assert row['originalSha256']==row['restoredSha256'] and row['originalBytes']==row['restoredBytes']
for n,total in [('core-cargo-test-final.log',189),('sdk-test-final.log',120)]:
 numbers=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',(t/n).read_text());assert sum(int(x) for x,y in numbers)==total and all(y=='0' for x,y in numbers),(n,numbers)
trace=json.load(gzip.open((t/s['receipts']['main']).parent/'typescript-trace.json.gz','rt'));rows=[x for d in trace['documents'] for x in d['trace']];assert len(rows)==84 and all('A' in x and 'B' in x for x in rows)
raw=sum(bool(x['editAdmission'] and x['editAdmission'].get('route','').startswith('Doc.emit')) for x in rows);actual=sum(x['editAdmission'] is not None for x in rows)-raw;assert (actual,raw)==(24,4)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head==base['head']
d={'status':'PASS','scope':'Source/integrity verification; product comparison remains bounded with D3 observations','sourceMaps':counts,'baselineChangesWithinOwnedScope':changed,'oldReportSeals':11,'oldTargetBinariesUnchanged':len(oldbins),'documentedBodySha256':hashlib.sha256(body.encode()).hexdigest(),'mainRows':84,'actorStates':168,'actualDocEdits':24,'rawWireAuthorings':4,'traceRoundTrips':len(compression),'traceRawBytes':sum(x['bytes'] for x in compression),'historicalTraceGzipFiles':len(recovery['files']),'historicalRawBytes':recovery['originalBytes'],'historicalCompressedBytes':recovery['compressedBytes'],'head':head}
(t/'final-source-verification.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
