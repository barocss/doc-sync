from pathlib import Path
import json,subprocess
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d2-unused-2026-11-04';report=r/'docs/reports/rust-d2-unused-2026-11-04'
def read(p):return json.loads(p.read_text())
s=read(t/'compare-summary.json');assert s['status']=='BOUNDED_PASS_WITH_D3_OBSERVATIONS';cases={n:{'status':read(t/p)['status'],'receipt':p} for n,p in s['receipts'].items()}
summary={'status':s['status'],'scope':'Original Word/Presentation bounded edit/History/recovery; D3 observations remain separate','main':cases['main'],'cases':cases,'sdk':'sdk-unused-summary.json','comparison':'compare-summary.json','sourceVerification':'final-source-verification.json','compression':'compression-current.json','spaceRecovery':'space-recovery.json'}
(t/'final-comparison-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paragraph='''Final bounded verification: native core **189 PASS**, SDK **120 PASS**. Original
Word (23 nodes) and presentation (27 nodes) retain their complete registries.
The main passes **84 actions / 168 actor states**, with **24 actual staged
Doc.edit authorings** and **four raw Doc.emit authorings**. The inherited complete
text-disabled corpus passes **90 actions**. Oracle coverage: **14 schema cases /
20 placement and atomicity cases / three exact native-model metamorphic variants**.
Seven D3 compiler observations remain separate; the summary status is
**BOUNDED_PASS_WITH_D3_OBSERVATIONS**, not full product-command parity.

The final workspace command `npm run test --workspaces --if-present` passes
**2,114 tests / 2,112 PASS / two expected platform SKIPs / zero FAIL / zero
cancelled** in 121.594 seconds. It uses the initial completed package build;
no production TypeScript source changed. Initial `npm test` had 2,110 PASS,
two FAIL and two SKIPs. The two failed MCP tests both pass focused reruns, with
no MCP source change. Typecheck and documentation build pass. Docs checks pass
**55 pages / 2,645 internal links**, English content and local paths excluded.
Both documentation programs match the entire runnable source and both compiled
independent consumers byte-for-byte.

Final source maps match main151, inherited146, oracle6, product4, compiler4,
SDK10 and inherited TS/integration31 entries. Eleven older report seals and
14 prior target binaries remain unchanged. Twelve new trace files restore
150,008,067 raw bytes with SHA checks. Twenty-two completed historical trace
files restore 1,155,686,277 raw bytes from 77,368,431 gzip bytes. Their mapping
records local restoration; earlier sealed evidence remains intact.
'''
p=report/'README.md';text=p.read_text();assert paragraph not in text;text=text.replace('## Resource incident and preserved evidence\n',paragraph+'\n## Resource incident and preserved evidence\n',1);p.write_text(text)
section='''### 5.152 D2 unused node declarations

Three agents implemented the compiler, SDK/docs and original-product comparison.
Baseline is main `1cfb7a2` plus 164 inherited source files. Only runtime_schema.rs
changes native production behavior. SDK production code, TypeScript rules and
original public product fixtures remain unchanged.

Valid supported unused declarations now compile, but all declarations still
undergo shape/attribute/reference/default/required-cycle validation. Removing
the root reachability rejection exposed two new-context bugs: unused grids/groups
switched active flat documents into nested routing, and unused text/atom leaves
could be accepted by flat root classification. Both are fixed. Node-driven
routing follows the root child closure; the global value-mark criterion remains.
Flat root leaves still need root child permission. Nested and graphic admission
remain unchanged. Metamorphic raw native model/History matches exactly without
normalizing away missing attrs. Snapshot/identity/DTO retain unused entries;
adding one changes schema identity and does not migrate an open document.

'''+paragraph+'''
The qualifying trace includes actual Word section/page metadata/default paragraph
text and presentation slide/layout/default title text. Explicit new nested
paragraph insertion still produces TS/native field/reset/ticket/boundary
differences; fresh-slide paragraph insertion can emit wire-invalid style:null
in TS. Failed91 and required-title-alias85 traces are retained. The supported
main does not qualify list/table construction or complete product editing.
Separate raw same-value writer protection passes. No tickets or History are
normalized to hide a compiler mismatch. D3 observations are recorded, not fixed.

The first Cargo parallel link failed errno28. Serial core/SDK reruns passed.
The first workspace run had one explicit ENOSPC failure and one null edit base;
causality for the null base is unproved. Both pass focused reruns and the full
workspace retry passes without source changes. Completed owned rules traces
were losslessly compressed to recover space, with hashes checked before raw
copies were removed. Sources, executables, Cargo caches and old sealed reports
were preserved. The user confirmed additional disk recovery; free-space changes
are not all attributed to trace compression. Initial failure logs remain.

The next product-delivery priority is D3 command compilation for nested paragraph
insertion and default/field resets. Full D2/D3, advanced schema rules, broader
original-product authoring, production Rust/WASM Client/editor integration,
native Map/List, protected GC and native production process/server recovery
remain separate gates. Own checkpoint replay is not mixed-runtime wire or server
durability qualification. No Chrome, mobile or performance benchmark was run.
No commit, push, deployment or registry publication is included.

[Source-bound unused-declaration report](docs/reports/rust-d2-unused-2026-11-04/README.md).
'''
(t/'handoff-section.md').write_text(section)
p=r/'HANDOFF.md';text=p.read_text();assert '### 5.152 D2 unused node declarations' not in text
intro='''Latest **§5.152** accepts supported unused registry entries while preserving
all-node validation and parent placement. Core189/SDK120 PASS; original Word/
presentation bounded84 actions/168 states and inherited textfalse90 PASS.
D3 nested-paragraph compiler differences remain observed. Final workspace
2,112 PASS/two expected SKIPs/zero failures; docs55 pages/2,645 links PASS.
Initial disk/MCP failures and successful retries are retained. Full product
editing and production Rust/WASM delivery remain open. See
`docs/reports/rust-d2-unused-2026-11-04/`. No commit/push/publication included.

'''
text=text.replace('# Handoff — @barocss/doc-sync\n\n','# Handoff — @barocss/doc-sync\n\n'+intro,1);p.write_text(text.rstrip()+'\n\n'+section)
subprocess.run(['python3',str(t/'verify-final.py')],cwd=r,check=True)
checks={'status':'BOUNDED_PASS_WITH_D3_OBSERVATIONS','nativeCore':{'passed':189,'log':'core-cargo-test-final.log'},'nativeSdk':{'passed':120,'receipt':'sdk-unused-summary.json'},'comparison':s,'main':{'originalSchemas':2,'actions':84,'actorStates':168,'actualDocEdits':24,'rawWireAuthorings':4},'workspace':{**read(t/'workspace-test-final.json'),**read(t/'workspace-test-totals.json')['workspace-test-final']},'initialWorkspace':{**read(t/'workspace-test-01.json'),**read(t/'workspace-test-totals.json')['workspace-test-01']},'focusedMcpRetry':read(t/'mcp-failed-focused-01.json'),'typecheck':read(t/'typecheck-01.json'),'documentation':{'build':read(t/'docs-build-01.json'),'check':read(t/'docs-check-01.json'),'pages':55,'internalLinks':2645,'english':True,'localPathsExcluded':True},'sourceVerification':read(t/'final-source-verification.json'),'legacyFull23Drivers':'NOT_RERUN_THIS_TASK','chrome':'NOT_RUN','mobile':'NOT_RUN','performance':'NOT_RUN','fullProductCommandParity':'NOT_QUALIFIED','publication':'NOT_REQUESTED'}
(report/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n');print('Final metadata and HANDOFF assembled')
