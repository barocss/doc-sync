import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {resolve,join,relative} from 'node:path';
import {createHash} from 'node:crypto';
const out=import.meta.dirname,root=resolve(out,'../..'),live=join(root,'packages/doc-sync/src'),candidate=join(out,'candidate-src');
assert.match(process.version,/^v24\./);
const initial=JSON.parse(await readFile(join(out,'proof-implementation-source-initial.json'),'utf8'));
async function verify(){async function names(dir,prefix=''){const result=[];for(const e of await readdir(dir,{withFileTypes:true})){const name=prefix+e.name;if(e.isDirectory())result.push(...await names(join(dir,e.name),name+'/'));else result.push(name);}return result.sort();}
assert.deepEqual(await names(live),Object.keys(initial.hashes).sort(),'exact production file inventory');
assert.deepEqual((await names(candidate)).filter(name=>name!=='package.json'),Object.keys(initial.hashes).sort(),'exact candidate Core file inventory');
const rows=[];for(const [name,sha]of Object.entries(initial.hashes)){const hash=async path=>createHash('sha256').update(await readFile(path)).digest('hex');const current=await hash(join(live,name)),copied=await hash(join(candidate,name));rows.push({name,initial:sha,live:current,candidate:copied,liveUnchanged:current===sha,candidateUnchanged:copied===sha});}return {count:rows.length,liveUnchanged:rows.every(r=>r.liveUnchanged),candidateUnchanged:rows.every(r=>r.candidateUnchanged),rows};}
function run(label,tree,script,args=[]){const core=tree==='baseline'?live:candidate;const r=spawnSync(process.execPath,[join(out,script),...args],{env:{...process.env,DOC_SYNC_CORE_ROOT:core},encoding:'utf8',timeout:30000});return {label,tree,status:r.status,signal:r.signal,error:r.error?.message,stdout:r.stdout??'',stderr:r.stderr??''};}
function canonical(value){const result=structuredClone(value);delete result.core;for(const row of result.results??[])for(const group of [...(row.history?.undo??[]),...(row.history?.redo??[])]){if(typeof group.at==='number')group.at='<history wall-clock>'; }return result;}
const cases=[['projection-capability','proof-implementation-projection-capability.mjs',[]],['controls','proof-implementation-controls.mjs',[]],['construction','proof-implementation-construction.mjs',[]],['ordering','proof-implementation-ordering.mjs',[]],['preload-model','proof-implementation-preload.mjs',['model']],['preload-clock','proof-implementation-preload.mjs',['clock']],['preload-model-valid','proof-implementation-preload.mjs',['model-valid']],['clone-order','proof-implementation-preload.mjs',['clone-order']],['species','proof-implementation-preload.mjs',['species']],['smoke','proof-implementation-smoke.mjs',[]]];
const selected=process.argv.slice(2);
const previous=selected.length?JSON.parse(await readFile(join(out,'proof-implementation-receipt.json'),'utf8')):null;
const receipt={node:process.version,scope:'small output-only controls and STOP evidence, not an optimized proof or broad qualification',cases:[]};
assert.ok((await verify()).liveUnchanged,'production changed before controls');
for(const [label,script,args]of cases){if(selected.length&&!selected.includes(label))continue;const pair=[];for(const tree of ['baseline','candidate']){const r=run(label,tree,script,args);await writeFile(join(out,`proof-implementation-${label}.${tree}.json`),r.stdout);await writeFile(join(out,`proof-implementation-${label}.${tree}.stderr.log`),r.stderr);let parsed,error;try{assert.equal(r.status,0,r.stderr);parsed=JSON.parse(r.stdout);}catch(e){error=e.message;}pair.push({tree,status:r.status,signal:r.signal,error,result:parsed});}let same=false,comparisonError;try{assert.deepEqual(canonical(pair[0].result),canonical(pair[1].result));same=true;}catch(e){comparisonError=e.message;}receipt.cases.push({label,baselineExit:pair[0].status,candidateExit:pair[1].status,baselineError:pair[0].error,candidateError:pair[1].error,exactAfterDeclaredHistoryTimestampNormalization:same,comparisonError});}
if(previous){const updated=new Set(receipt.cases.map(c=>c.label));receipt.cases=[...previous.cases.filter(c=>!updated.has(c.label)),...receipt.cases];}
const final=await verify();await writeFile(join(out,'proof-implementation-source-final.json'),JSON.stringify(final,null,2)+'\n');
receipt.sourcePreservation={count:final.count,liveUnchanged:final.liveUnchanged,candidateUnchanged:final.candidateUnchanged};
receipt.controlPass=receipt.cases.every(c=>c.baselineExit===0&&c.candidateExit===0&&c.exactAfterDeclaredHistoryTimestampNormalization)&&final.liveUnchanged&&final.candidateUnchanged;
receipt.optimizedProof='NOT_IMPLEMENTED; HOLD';await writeFile(join(out,'proof-implementation-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));if(!receipt.controlPass)process.exitCode=1;
