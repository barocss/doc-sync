#!/usr/bin/env python3
"""Exercise actual orchestration main/finally with synthetic child JSON only."""
import hashlib
import json
from pathlib import Path
import runpy
import sys

HERE = Path(__file__).resolve().parent
OUT = HERE / 'mock-main-checks-01'
if OUT.exists():
    raise SystemExit('Refusing existing mock evidence directory')
OUT.mkdir()
module = runpy.run_path(str(HERE / 'run-abba.py'))
globals_ = module['main'].__globals__
original_writer = globals_['write_new']
original_argv = sys.argv[:]
results = []


def labeled_write(path, value):
    original_writer(path, {**value, 'evidenceKind': 'MOCK_NOT_TIMING', 'timing': 'NOT_RUN'})


def prohibited_subprocess(*args, **kwargs):
    raise AssertionError('No real process may run during mock-main checks')


def mock_child(group, lane, slot, outdir, run_id, timeout, script_sha):
    name = f'{group["name"]}-{slot}-{lane}'
    process = {'name': name, 'lane': lane, 'returncode': 1 if case == 'process-error' else 0,
               'status': 'FAIL' if case == 'process-error' else 'PASS', 'evidenceKind': 'MOCK_NOT_TIMING'}
    labeled_write(outdir / f'{name}.process.json', process)
    if case == 'process-error':
        raise ValueError('MOCK_NOT_TIMING: synthetic child process error')
    # Both lanes have equal totals: the mandatory 20k >=5% improvement gate fails.
    report = {'samples': 5, 'warmup': 2, 'mode': 'timing', 'sourceUnchangedAtEnd': True,
              'fixtureSHA': 'synthetic-fixed', 'fixtureKind': group['fixture'], 'records': group['records'],
              'scenarios': [{'name': name, 'oracle': {'synthetic': 'PASS'},
                             'authoredFixtureSHA': 'synthetic-authored', 'finalCheckpointSHA': 'synthetic-checkpoint',
                             'retainedMoves': 1, 'target': 'synthetic-target',
                             'timing': [{'setMs': 10, 'nextReadMs': 1, 'totalMs': 11} for _ in range(5)]}
                            for name in globals_['DATA_NAMES']]}
    labeled_write(outdir / f'{name}.mock-child.json', report)
    return report, process


globals_['write_new'] = labeled_write
globals_['run_child'] = mock_child
globals_['subprocess'].run = prohibited_subprocess
try:
    for case in ['mandatory-failure', 'process-error']:
        directory = OUT / case
        sys.argv = ['run-abba.py', '--output-dir', str(directory)]
        code = globals_['main']()
        assert code == 1
        summary = json.loads((directory / 'summary.json').read_text())
        assert summary['evidenceKind'] == 'MOCK_NOT_TIMING' and summary['timing'] == 'NOT_RUN'
        assert summary['status'] == 'FAIL'
        assert summary['sourceAfter'] == summary['sourceBefore']
        assert 'integrityErrors' not in summary
        assert summary['groups'][0]['status'] == 'FAIL'
        assert all(g['status'] == 'NOT_RUN' for g in summary['groups'][1:])
        if case == 'mandatory-failure':
            assert len(summary['groups'][0]['processes']) == 4
            assert summary['firstFailure']['cell'] == 'existing-root-map-overwrite.totalMs'
        else:
            assert summary['firstFailure']['kind'] == 'process-or-equivalence'
            assert 'synthetic child process error' in summary['firstFailure']['error']
            assert len(summary['groups'][0]['processRecordFiles']) == 1
        results.append({'case': case, 'status': 'PASS', 'summary': str(directory / 'summary.json'),
                        'sourceAfterEqualsBefore': True, 'integrityErrors': 'ABSENT', 'laterGroups': 'NOT_RUN',
                        'sha256': hashlib.sha256((directory / 'summary.json').read_bytes()).hexdigest()})
finally:
    sys.argv = original_argv
labeled_write(OUT / 'receipt.json', {'status': 'PASS', 'orchestratorSHA': globals_['digest'](HERE / 'run-abba.py'),
                                  'checkSHA': globals_['digest'](__file__), 'cases': results,
                                  'processPolicy': 'subprocess.run replaced by fail-closed exception; run_child mocked'})
print('PASS: actual main/finally mandatory-failure and process-error; MOCK_NOT_TIMING; Node NOT_RUN')
