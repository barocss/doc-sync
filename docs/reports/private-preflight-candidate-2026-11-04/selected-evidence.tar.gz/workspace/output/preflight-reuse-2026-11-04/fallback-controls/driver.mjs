// Source-only public Client controls. Timing requires later independent proof approval.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {existsSync, readFileSync, readdirSync, realpathSync, writeFileSync} from 'node:fs';
import {registerHooks} from 'node:module';
import {resolve, join, sep} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';
import {loadavg, platform, arch, release} from 'node:os';
const usage = 'driver.mjs --source-root PATH --label NAME --output NEW.json [--mode smoke|counts|timing] [--records 200] [--samples 5] [--warmup 2]';
if (process.argv.length === 3 && process.argv[2] === '--help') { console.log(usage); process.exit(0); }
const args = {};
for (let i = 2; i < process.argv.length; i += 2) {
    const key = process.argv[i], value = process.argv[i + 1];
    assert(['--source-root', '--label', '--output', '--mode', '--records', '--samples', '--warmup'].includes(key) && value && !value.startsWith('--') && !(key in args), `Invalid option ${key}; ${usage}`);
    args[key] = value;
}
for (const key of ['--source-root', '--label', '--output']) assert(args[key], `Required ${key}`);
const integer = (v, min, max) => { assert(/^\d+$/.test(v) && Number.isSafeInteger(+v) && +v >= min && +v <= max, `Invalid integer ${v}`); return +v; };
const mode = args['--mode'] ?? 'smoke';
assert(['smoke', 'counts', 'timing'].includes(mode), 'Invalid mode');
const records = integer(args['--records'] ?? '200', 6, 2000);
const samples = integer(args['--samples'] ?? '5', 1, 30), warmup = integer(args['--warmup'] ?? '2', 0, 10);
assert(mode !== 'smoke' || records <= 200, 'Smoke requires <=200 entries');
assert.equal(process.version, 'v24.22.1', 'Use pinned Node 24.22.1');
assert(process.execArgv.length === 0 && !process.env.NODE_OPTIONS, 'No execArgv/NODE_OPTIONS; use stock Node strip-only');
const root = realpathSync(resolve(args['--source-root'])), source = realpathSync(join(root, 'packages/doc-sync/src'));
const output = resolve(args['--output']);
assert(output.endsWith('.json'), 'Output must end in .json');
assert(!existsSync(output), 'Refusing to overwrite output');
assert(!output.startsWith(source + sep) && !output.startsWith(join(root, 'packages') + sep) && !output.startsWith(join(root, 'benchmarks') + sep) && !output.split(sep).includes('dist'), 'No source/code/dist output');
const sha = x => createHash('sha256').update(x).digest('hex');
const driver = realpathSync(fileURLToPath(import.meta.url)), driverSHA = sha(readFileSync(driver));
const inventory = () => Object.fromEntries(readdirSync(source, {recursive:true}).filter(p => p.endsWith('.ts')).sort().map(p => [p, sha(readFileSync(join(source,p)))]));
const before = inventory(), sourceSHA = sha(Object.entries(before).map(([p,h]) => `${h}  ${p}\n`).join(''));
const loaded = new Set();
registerHooks({resolve(specifier, context, next) {
    const r = next(specifier, context);
    if (r.url.startsWith('file:')) {
        const p = realpathSync(fileURLToPath(r.url));
        assert(p.startsWith(source + sep) && p.endsWith('.ts'), `Import outside selected source: ${p}`);
        loaded.add(p.slice(source.length + 1));
    } else assert(r.url.startsWith('node:'), `Non-source dependency ${r.url}`);
    return r;
}});
const load = p => import(pathToFileURL(join(source,p)).href);
const {Client, clientOwner} = await load('client/index.ts');
const {createDataSchema} = await load('data/schema.ts');
const {typescriptClientEngineFactory: factory} = await load('engine/typescript-client.ts');
const actor = 'fallback-control-fixed';
const id = n => `data:00000000-0000-4000-8000-${n.toString(16).padStart(12,'0')}`;
const entry = (n, value = n) => ({type:'entry', attrs:{id:id(n+1), key:`key-${n}`, value:{scalar:value}}});
const originalModel = {type:'data', children:Array.from({length:records}, (_,i) => entry(i))};
function schema(custom) {
    const s = createDataSchema();
    // Valid equivalent storage/value schema. Extra unused atom prevents exact-default eligibility.
    if (custom) s.nodes.unusedControlAtom = {shape:'atom', attrs:{tag:{default:''}}};
    return s;
}
function normalized(client) {
    const state = client.captureState();
    for (const side of ['undo','redo']) for (const group of state.engine.history[side]) group.at = 0;
    return state;
}
const seedStates = [false,true].map(custom => {
    const c = new Client({actor, schema:schema(custom)});
    c.edit([{op:'insert',at:[0],content:structuredClone(originalModel.children)}],null);
    c.clearHistory(); assert.deepEqual(c.model(), originalModel);
    const state = normalized(c); c.dispose(); return state;
});
assert.notEqual(seedStates[0].schemaVersion,seedStates[1].schemaVersion,'Custom schema must have a different validated fingerprint');
const fixtureSHA = sha(JSON.stringify({actor,records,model:originalModel,states:seedStates}));
function fixture(custom) { return Client.fromState(seedStates[custom ? 1 : 0], {schema:schema(custom)}); }
const specs = [
    {name:'default-structural-insert', custom:false, edit:{op:'insert',at:[Math.floor(records/2)],content:[entry(records)]}, expected: rows => rows.splice(Math.floor(records/2),0,entry(records))},
    {name:'default-structural-delete', custom:false, edit:{op:'delete',at:[Math.floor(records/2)],count:1}, expected: rows => rows.splice(Math.floor(records/2),1)},
    {name:'default-structural-move', custom:false, edit:{op:'move',from:[Math.floor(records/2)],at:[1]}, expected: rows => rows.splice(1,0,rows.splice(Math.floor(records/2),1)[0])},
    {name:'custom-schema-value-update', custom:true, edit:{op:'update',at:[Math.floor(records/2)],attrs:{value:{scalar:'control-한글🙂'}}}, expected: rows => { rows[Math.floor(records/2)].attrs.value = {scalar:'control-한글🙂'}; }},
];
function publicOracle(client, expected) {
    assert.deepEqual(client.model(),expected);
    // Complete detached checkpoint roundtrip, outside timing.
    const state = normalized(client), restored = Client.fromState(state,{schema:client.schema});
    assert.deepEqual(restored.model(),expected);
    assert.deepEqual(restored.snapshot(),client.snapshot());
    const roundtrip = normalized(restored);
    assert.deepEqual(roundtrip.engine.history,state.engine.history);
    assert.deepEqual(roundtrip.engine.identity,state.engine.identity);
    // Restore reconstructs document revision; preserve the live revision in semantic evidence.
    restored.dispose();
    return state;
}
function verify(client, spec, ops) {
    const expected = structuredClone(originalModel); spec.expected(expected.children);
    assert(ops.length > 0 && ops.every(op => typeof op.t === 'string'), 'Expected emitted operations');
    const after = publicOracle(client,expected), snapshot = client.snapshot();
    assert.equal(client.historyStatus().canUndo,true);
    client.undo(); assert.deepEqual(client.model(),originalModel); assert.equal(client.historyStatus().canRedo,true);
    client.redo(); assert.deepEqual(client.model(),expected);
    assert.deepEqual(client.snapshot().lines.map(l=>l.items.filter(i=>!i.z).map(i=>i.b)),snapshot.lines.map(l=>l.items.filter(i=>!i.z).map(i=>i.b)));
    // An unchanged first entry is a foreign-write preservation sentinel for all controls.
    const engine = clientOwner(client).engine, doc = engine.typescriptDocument();
    const target = doc.snapshot().lines.flatMap(line => doc.get(line.key).line.items).find(item => item.attrs.get('id')?.value === id(1));
    assert(target);
    const lamport = doc.clock.lamport + 100;
    engine.receive('foreign-control',[{t:'set',at:{lamport,actor:'foreign-control'},ids:[target.id],key:'value',value:{scalar:'foreign'}}]);
    client.undo(); client.redo();
    expected.children.find(n=>n.attrs.id === id(1)).attrs.value = {scalar:'foreign'};
    assert.deepEqual(client.model(),expected);
    engine.receive('foreign-control',[{t:'del',at:{lamport:lamport+1,actor:'foreign-control'},ids:[target.id]}]);
    client.undo(); client.redo();
    expected.children = expected.children.filter(n=>n.attrs.id !== id(1));
    publicOracle(client,expected);
    return {ops,after,final:normalized(client),oracle:{fullModel:'PASS',snapshotRoundtrip:'PASS',fullHistory:'PASS',undoRedo:'PASS',foreignWriteAndDeletePreserved:'PASS'}};
}
// Receiver/domain guard is deliberately separate and untimed, in all modes.
function factoryGuard() {
    let creates = 0, methodCalls = 0;
    const transport = {subscribe(){return ()=>{};},send(){},sendPresence(){}};
    const custom = {...factory,create(...args) {
        assert.equal(this,custom); creates++;
        const engine = factory.create(...args);
        return new Proxy(engine,{get(target,key,receiver) {
            const value = Reflect.get(target,key,target);
            return typeof value === 'function' ? function(...a) { assert.equal(this,receiver); methodCalls++; return value.apply(target,a); } : value;
        }});
    }};
    // Omitted domain must keep the legacy document flow, with the custom factory.
    const documentSchema = {root:'doc',marks:[],nodes:{doc:{shape:'flow',children:['paragraph'],default:'paragraph'},paragraph:{shape:'text'}}};
    const c = new Client({actor:'factory-guard-fixed',transport,schema:documentSchema,syncOptions:{engineFactory:custom}});
    const ops = c.edit([{op:'insert',at:[0,0],content:'guard'}]);
    assert.deepEqual(c.model(),{type:'doc',children:[{type:'paragraph',runs:[{text:'guard',marks:{}}]}]});
    assert.equal(c.schema.domain,undefined); assert.equal(creates,1); assert(methodCalls > 0);
    const checkpoint = clientOwner(c).engine.checkpoint();
    for (const side of ['undo','redo']) for (const group of checkpoint.history[side]) group.at = 0;
    c.undo(); c.redo(); assert.equal(c.model().children[0].runs[0].text,'guard');
    // This isolated sync fixture has unsent local history; release its engine directly.
    c.disconnect(); clientOwner(c).engine.dispose();
    return {status:'PASS',domain:'omitted legacy document domain',factoryReceiver:'PASS',engineMethodReceiver:'PASS',creates,methodCalls,ops,checkpoint};
}
const hostBefore = {loadavg:loadavg(),cpuUsage:process.cpuUsage()}, scenarios = [];
for (const spec of specs) {
    const runs = [], semantics = [];
    for (let n=0;n<warmup+samples;n++) {
        const client = fixture(spec.custom), edits = [structuredClone(spec.edit)];
        assert.deepEqual(client.model(),originalModel); assert.deepEqual(client.historyStatus(),{canUndo:false,canRedo:false});
        let ops, elapsed = null;
        if (mode === 'timing' && n >= warmup) {
            const start = performance.now();
            ops = client.edit(edits);
            elapsed = performance.now() - start;
        } else ops = client.edit(edits); // Smoke/counts never read any harness clock.
        const verified = verify(client,spec,ops); client.dispose();
        if (n>=warmup) {if (mode === 'timing') runs.push(elapsed); semantics.push(sha(JSON.stringify(verified)));}
        assert.equal(sha(JSON.stringify(verified)),semantics[0] ?? sha(JSON.stringify(verified)), 'Sample semantic drift');
    }
    scenarios.push({name:spec.name,schema:spec.custom?'equivalent custom schema with unused atom':'exact createDataSchema default',fallbackReason:spec.custom?'nondefault schema fingerprint':'structural edit is not one value update',fixtureSHA,semanticSHA:semantics[0],samplesVerified:semantics.length,timingMs:mode==='timing'?runs:null,schemaVersion:seedStates[spec.custom ? 1 : 0].schemaVersion,oracle:'PASS: full ops/checkpoint/History/model, undo-redo and foreign set/delete preservation'});
}
const guards = factoryGuard(), after = inventory();
assert.deepEqual(after,before,'Source changed during run'); assert.equal(sha(readFileSync(driver)),driverSHA,'Driver changed during run');
const result = {label:args['--label'],mode,root,source,sourceSHA,before,after,sourceUnchanged:true,loaded:[...loaded].sort(),driver,driverSHA,fixtureSHA,records,samples,warmup,actor,node:process.version,executable:process.execPath,argv:process.argv.slice(2),scenarios,guards,
    timer:mode==='timing'?'performance.now around complete public Client.edit only; fixture, input copy, full model/snapshot/History assertions, undo-redo, foreign operations outside':'NOT_RUN: smoke/counts do not read harness clock',
    instrumentation:'NONE: stock intrinsics, no clone hooks/prototype/source instrumentation; counts mode supplies semantic counts only',
    counts:mode==='counts'?{scenarioSamples:scenarios.length*samples,publicTimedOperationKind:'Client.edit',factoryGuards:1}:null,
    acceptance:'Parent only: <=3% pooled lane median regression per control and cycle; 0.25ms absolute allowance only for sub-millisecond control cells. No allowance for main Data cells.',
    host:{platform:platform(),arch:arch(),release:release(),before:hostBefore,after:{loadavg:loadavg(),cpuUsage:process.cpuUsage()},isolation:'not asserted'},
    scope:'Source-only controls; no speed/proof approval/production/build/dist/browser/mobile/heap/release claim. Direct Doc 100k control is separate existing harness.'};
writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,mode,sourceSHA,driverSHA,fixtureSHA,oracles:'PASS',timing:mode==='timing'?'recorded':'NOT_RUN'}));
