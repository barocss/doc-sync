#!/usr/bin/env python3
"""Serial prospective gate. Preparation self-test uses synthetic JSON only."""
import argparse
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import statistics
import subprocess
import sys
import time
import uuid

WORKSPACE = Path(__file__).resolve().parents[3]
OWN = Path(__file__).resolve().parent
NODE = Path('/Users/user/.nvm/versions/node/v24.22.1/bin/node')
ROOTS = {
    'A': WORKSPACE / 'output/refactor-2026-11-03/post-refactor-baseline',
    'B': WORKSPACE / 'output/preflight-reuse-2026-11-04/candidate-v2',
}
SOURCE_SHA = {
    'A': '8b532beb32d4ef0e7d69e54ac9a989d269d0c590e11d6ef8f3f0545b362c4a51',
    'B': 'd6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab',
}
DRIVERS = {
    'data': WORKSPACE / 'output/preflight-reuse-2026-11-04/data-tests-v2/performance-driver.mjs',
    'fallback': OWN / 'driver.mjs',
    'doc': WORKSPACE / 'benchmarks/doc-trace-control.mjs',
}
DRIVER_SHA = {
    'data': 'b3accded2d3a00c3cd85799773bc4a813075ea339790cf300dea9a78c4f6302e',
    'fallback': '2fb6ded590abdd81aaec001aa27d3b9ddc2fc49ecc576c92eee382b45c4b1fb3',
    'doc': 'de905d02666989f8ec37180d85bd511c29a40b77ce768ab138645f41892b547c',
}
DATA_NAMES = ['existing-root-map-overwrite', 'existing-nested-map-overwrite', 'existing-list-item-set']
FALLBACK_NAMES = ['default-structural-insert', 'default-structural-delete', 'default-structural-move', 'custom-schema-value-update']
DOC_METRICS = ['localEditMs', 'localColdToJSONMs', 'remoteApplyMs', 'remoteColdToJSONMs', 'localEditAndReadMs', 'remoteApplyAndReadMs']
DOC_ORACLES = ['schema', 'utf16TextAndModel', 'exactOperations', 'exactSnapshotLinesTokensClock', 'replicaConvergence']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# Finalization records actual source hashes even when an expected-hash check fails.
def source_inventory(lane, enforce=True):
    directory = ROOTS[lane] / 'packages/doc-sync/src'
    files = {str(p.relative_to(directory)): digest(p) for p in sorted(directory.rglob('*.ts'))}
    closure = hashlib.sha256(''.join(f'{h}  {p}\n' for p, h in files.items()).encode()).hexdigest()
    if enforce:
        require(closure == SOURCE_SHA[lane], f'{lane}: frozen source closure changed: {closure}')
    return {'sha256': closure, 'files': files}


def host():
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return {'loadavg': list(os.getloadavg()), 'selfCPUSeconds': {'user': usage.ru_utime, 'system': usage.ru_stime},
            'isolation': 'NOT_ASSERTED: other host activity is not controlled'}


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_new(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def plan():
    groups = []
    for cycle in range(1, 4):
        for fixture, size in [('normal', 20000), ('normal', 2000), ('legacy-no-moves', 20000), ('legacy-no-moves', 2000)]:
            groups.append({'cycle': cycle, 'kind': 'data', 'fixture': fixture, 'records': size,
                           'name': f'cycle{cycle}-{fixture}-{size}', 'status': 'NOT_RUN'})
        for kind in ['fallback', 'doc']:
            groups.append({'cycle': cycle, 'kind': kind, 'name': f'cycle{cycle}-{kind}', 'status': 'NOT_RUN'})
    return groups


def samples(values):
    require(isinstance(values, list) and len(values) == 5, 'Expected exactly five measured samples')
    require(all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v >= 0 for v in values), 'Invalid timing samples')
    return values


def gate(name, a, b, rule):
    require(a > 0 and math.isfinite(a) and math.isfinite(b), 'Invalid median')
    threshold = a * (0.95 if rule == 'improve5' else 1.03)
    allowance = 0.25 if rule == 'control3' and a < 1 else 0
    if allowance:
        threshold = max(threshold, a + allowance)
    passed = b <= threshold
    return {'cell': name, 'baselineMedianMs': a, 'candidateMedianMs': b,
            'candidateChangePercent': (b / a - 1) * 100, 'maximumCandidateMedianMs': threshold,
            'rule': rule, 'absoluteAllowanceMs': allowance, 'status': 'PASS' if passed else 'FAIL'}


def validate_reports(kind, reports):
    require(len(reports) == 4, 'Incomplete ABBA group')
    require(all(r['samples'] == 5 and r['warmup'] == 2 and r['mode'] == 'timing' for r in reports), 'Wrong mode/sample/warmup')
    reference = reports[0]
    if kind == 'data':
        names = DATA_NAMES
        for report in reports:
            require(report['sourceUnchangedAtEnd'] is True, 'Data source stability failure')
            require(report['fixtureSHA'] == reference['fixtureSHA'], 'Data fixture SHA mismatch')
            require(report['fixtureKind'] == reference['fixtureKind'] and report['records'] == reference['records'], 'Data fixture/size mismatch')
            require([s['name'] for s in report['scenarios']] == names, 'Unexpected Data scenarios')
            for index, s in enumerate(report['scenarios']):
                require(all(v == 'PASS' for v in s['oracle'].values()), 'Data oracle failure')
                for key in ['authoredFixtureSHA', 'finalCheckpointSHA', 'retainedMoves', 'target']:
                    require(s[key] == reference['scenarios'][index][key], f'Data {s["name"]}: {key} mismatch')
                for metric in ['setMs', 'nextReadMs', 'totalMs']:
                    samples([v[metric] for v in s['timing']])
    elif kind == 'fallback':
        for report in reports:
            require(report['sourceUnchanged'] is True, 'Fallback source stability failure')
            require(report['fixtureSHA'] == reference['fixtureSHA'], 'Fallback fixture mismatch')
            require([s['name'] for s in report['scenarios']] == FALLBACK_NAMES, 'Unexpected fallback scenarios')
            require(report['guards'] == reference['guards'] and report['guards']['status'] == 'PASS', 'Factory/domain guard mismatch')
            for index, s in enumerate(report['scenarios']):
                require(s['oracle'].startswith('PASS:'), 'Fallback oracle failure')
                for key in ['fixtureSHA', 'semanticSHA', 'schemaVersion']:
                    require(s[key] == reference['scenarios'][index][key], f'Fallback {key} mismatch')
                samples(s['timingMs'])
    else:
        for report in reports:
            require(report['status'] == 'PASS' and report['sourceUnchangedAtEnd'] is True, 'Doc source/oracle failure')
            require(report['charsUTF16'] == 100000, 'Doc must use 100k UTF16 units')
            require(all(report['oracle'][key] == 'PASS' for key in DOC_ORACLES), 'Doc mandatory oracle failure')
            require(report['oracle']['undoRedo'].startswith('NOT_RUN:'), 'Unexpected direct-Doc History contract')
            for key in ['fixtureSHA', 'schemaSHA', 'workloadSHA', 'expectedOperationSHA', 'expectedModelSHA', 'expectedSnapshotSHA']:
                require(report[key] == reference[key], f'Doc {key} mismatch')
            require([r['hashes'] for r in report['runs']] == [r['hashes'] for r in reference['runs']], 'Doc sample semantic mismatch')
            for metric in DOC_METRICS:
                samples([r[metric] for r in report['runs']])


def evaluate(group, reports):
    validate_reports(group['kind'], reports)
    kind, cells = group['kind'], []
    if kind == 'data':
        for index, name in enumerate(DATA_NAMES):
            for metric in ['totalMs', 'setMs', 'nextReadMs']:
                pools = [[row[metric] for process in lane for row in process['scenarios'][index]['timing']]
                         for lane in [[reports[0], reports[3]], [reports[1], reports[2]]]]
                a, b = (statistics.median(pool) for pool in pools)
                rule = 'improve5' if metric == 'totalMs' and group['records'] == 20000 else 'regress3'
                cell = gate(f'{name}.{metric}', a, b, rule)
                cell['mandatory'] = metric != 'nextReadMs'
                if not cell['mandatory']:
                    cell['status'] = 'OBSERVATION'
                cells.append(cell)
    elif kind == 'fallback':
        for index, name in enumerate(FALLBACK_NAMES):
            a, b = [statistics.median([v for p in lane for v in p['scenarios'][index]['timingMs']])
                    for lane in [[reports[0], reports[3]], [reports[1], reports[2]]]]
            cells.append({**gate(name, a, b, 'control3'), 'mandatory': True})
    else:
        for metric in DOC_METRICS:
            a, b = [statistics.median([row[metric] for p in lane for row in p['runs']])
                    for lane in [[reports[0], reports[3]], [reports[1], reports[2]]]]
            cells.append({**gate(metric, a, b, 'control3'), 'mandatory': True})
    return cells


def run_child(group, lane, slot, outdir, run_id, timeout, script_sha):
    kind = group['kind']
    name = f'{group["name"]}-{slot}-{lane}'
    local_output = outdir / f'{name}.json'
    actual_output = (WORKSPACE / 'output/data-cache-2026-11-04' / f'doc-trace-control.{run_id}.{name}.json') if kind == 'doc' else local_output
    require(not actual_output.exists(), f'Existing child output: {actual_output}')
    command = [str(NODE), str(DRIVERS[kind]), '--source-root', str(ROOTS[lane]), '--label', name,
               '--output', str(actual_output), '--mode', 'timing', '--samples', '5', '--warmup', '2']
    if kind == 'data':
        command += ['--records', str(group['records']), '--fixture', group['fixture']]
    elif kind == 'fallback':
        command += ['--records', '200']
    else:
        command += ['--chars', '100000']
    require(digest(DRIVERS[kind]) == DRIVER_SHA[kind] and digest(__file__) == script_sha, 'Harness changed')
    before = source_inventory(lane)
    process = {'name': name, 'lane': lane, 'command': command, 'actualOutput': str(actual_output),
               'localOutput': str(local_output), 'startedUTC': stamp(), 'hostBefore': host(), 'sourceBefore': before,
               'driverSHA': DRIVER_SHA[kind], 'timeoutSeconds': timeout}
    print(json.dumps({'status': 'START', 'process': name, 'output': str(actual_output)}), flush=True)
    started = time.monotonic()
    with (outdir / f'{name}.stdout.log').open('xb') as stdout, (outdir / f'{name}.stderr.log').open('xb') as stderr:
        try:
            completed = subprocess.run(command, cwd=WORKSPACE, stdout=stdout, stderr=stderr, timeout=timeout, check=False)
            process['returncode'] = completed.returncode
            process['watchdog'] = 'NOT_TRIGGERED'
        except subprocess.TimeoutExpired:
            process['returncode'] = None
            process['watchdog'] = 'TIMEOUT: only this owned child was stopped by subprocess.run'
    process.update(elapsedSeconds=time.monotonic() - started, endedUTC=stamp(), hostAfter=host())
    try:
        process['sourceAfter'] = source_inventory(lane, enforce=False)
        require(process['sourceAfter'] == before, 'Source changed during child')
        require(digest(DRIVERS[kind]) == DRIVER_SHA[kind] and digest(__file__) == script_sha, 'Harness changed during child')
        if actual_output.exists():
            raw = actual_output.read_bytes()
            process['outputSHA'] = hashlib.sha256(raw).hexdigest()
            if kind == 'doc':
                with local_output.open('xb') as stream:
                    stream.write(raw)
        require(process['returncode'] == 0, f'Child failed with returncode {process["returncode"]}; {process["watchdog"]}')
        require(actual_output.exists(), 'Child emitted no receipt')
        report = json.loads(raw)
        reported_files = report['before'] if kind == 'fallback' else report['sourceFiles']
        require(reported_files == before['files'], 'Child source inventory mismatch')
        if kind == 'doc':
            require(report['sourceFilesAtEnd'] == before['files'], 'Doc final source inventory mismatch')
        if kind == 'fallback':
            require(report['after'] == before['files'], 'Fallback final source inventory mismatch')
        reported_driver = report['benchmarkSHA'] if kind == 'doc' else report['driverSHA']
        require(reported_driver == DRIVER_SHA[kind], 'Child driver SHA mismatch')
        process.update(status='PASS', outputSHA=hashlib.sha256(raw).hexdigest())
    except Exception as error:
        process.update(status='FAIL', error=str(error))
        write_new(outdir / f'{name}.process.json', process)
        raise
    write_new(outdir / f'{name}.process.json', process)
    print(json.dumps({'status': 'FINISH', 'process': name, 'elapsedSeconds': process['elapsedSeconds'], 'returncode': process['returncode']}), flush=True)
    return report, process


def self_test():
    require(gate('a', 10, 9.5, 'improve5')['status'] == 'PASS', '5% boundary')
    require(gate('a', 10, 9.51, 'improve5')['status'] == 'FAIL', '5% failure')
    require(gate('a', 10, 10.3, 'regress3')['status'] == 'PASS', '3% boundary')
    require(gate('a', 10, 10.31, 'regress3')['status'] == 'FAIL', '3% failure')
    require(gate('a', .5, .75, 'control3')['status'] == 'PASS', 'Sub-ms allowance')
    require(gate('a', .5, .751, 'control3')['status'] == 'FAIL', 'Sub-ms allowance boundary')
    require(gate('a', 1, 1.04, 'control3')['status'] == 'FAIL', 'No allowance at 1ms')
    require(gate('a', .5, .52, 'regress3')['status'] == 'FAIL', 'No main allowance')
    reports = []
    for lane in ['A', 'B', 'B', 'A']:
        reports.append({'samples': 5, 'warmup': 2, 'mode': 'timing', 'sourceUnchangedAtEnd': True,
                        'fixtureSHA': 'fixed', 'fixtureKind': 'normal', 'records': 20000,
                        'scenarios': [{'name': name, 'oracle': {'full': 'PASS'}, 'authoredFixtureSHA': 'authored',
                                       'finalCheckpointSHA': 'checkpoint', 'retainedMoves': 1, 'target': 'target',
                                       'timing': [{'setMs': 10 if lane == 'A' else 9, 'nextReadMs': 1, 'totalMs': 11 if lane == 'A' else 10} for _ in range(5)]}
                                      for name in DATA_NAMES]})
    cells = evaluate({'kind': 'data', 'records': 20000}, reports)
    require(all(c['status'] == 'PASS' for c in cells if c['mandatory']), 'Synthetic main evaluation')
    reports[1]['scenarios'][0]['finalCheckpointSHA'] = 'wrong'
    try:
        evaluate({'kind': 'data', 'records': 20000}, reports)
    except ValueError:
        pass
    else:
        raise ValueError('Checkpoint mismatch was accepted')
    groups = plan()
    require(len(groups) == 18 and groups[0]['records'] == 20000 and groups[4]['kind'] == 'fallback', 'Plan order')
    require(all(g['status'] == 'NOT_RUN' for g in groups), 'Initial statuses')
    print('PASS: synthetic JSON/gates/checkpoint rejection/18-group order; timing NOT_RUN')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--timeout-seconds', type=int, default=600)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        require(args.output_dir is None, 'Self-test does not write output')
        self_test()
        return 0
    require(args.output_dir is not None, '--output-dir is required')
    require(30 <= args.timeout_seconds <= 3600, 'Timeout must be 30..3600 seconds')
    require(not os.environ.get('NODE_OPTIONS'), 'Unset NODE_OPTIONS')
    outdir = args.output_dir.resolve()
    require(not outdir.exists(), 'Refusing existing output directory')
    require(outdir.is_relative_to(OWN), 'Output directory must be below fallback-controls')
    # Child drivers independently verify Node version and executable/arguments.
    require(NODE.is_file(), 'Pinned Node missing')
    require((WORKSPACE / 'output/data-cache-2026-11-04').is_dir(), 'Owned Doc output directory missing')
    for kind, path in DRIVERS.items():
        require(digest(path) == DRIVER_SHA[kind], f'{kind} driver hash mismatch')
    sources = {lane: source_inventory(lane) for lane in ROOTS}
    script_sha = digest(__file__)
    outdir.mkdir(parents=True, exist_ok=False)
    summary = {'status': 'RUNNING', 'startedUTC': stamp(), 'runId': uuid.uuid4().hex,
               'orchestratorSHA': script_sha, 'driverSHA': DRIVER_SHA, 'sourceBefore': sources,
               'samples': 5, 'warmup': 2, 'sequence': 'Per cycle: normal20k, normal2k, legacy20k, legacy2k, fallback, Doc; each ABBA',
               'hostBefore': host(), 'groups': plan(), 'firstFailure': None,
               'limits': 'Node source-only measurements; no host isolation, heap, browser, production, or release acceptance'}
    write_new(outdir / 'plan.json', summary)
    try:
        for index, group in enumerate(summary['groups']):
            group['status'] = 'RUNNING'
            reports, processes = [], []
            group['processes'] = processes
            for slot, lane in enumerate(['A', 'B', 'B', 'A'], 1):
                report, process = run_child(group, lane, slot, outdir, summary['runId'], args.timeout_seconds, script_sha)
                reports.append(report)
                processes.append(process)
            group['cells'] = evaluate(group, reports)
            failures = [c for c in group['cells'] if c['mandatory'] and c['status'] == 'FAIL']
            group['status'] = 'FAIL' if failures else 'PASS'
            write_new(outdir / f'{group["name"]}.group.json', group)
            write_new(outdir / f'progress-{index+1:02}.json', summary)
            if failures:
                summary['firstFailure'] = {'group': group['name'], **failures[0]}
                summary['status'] = 'FAIL'
                break
        else:
            summary['status'] = 'PASS'
    except Exception as error:
        summary['status'] = 'FAIL'
        group['status'] = 'FAIL'
        group['processRecordFiles'] = [str(p) for p in sorted(outdir.glob(f'{group["name"]}-*.process.json'))]
        summary['firstFailure'] = {'group': group['name'], 'kind': 'process-or-equivalence', 'error': str(error)}
    finally:
        summary.update(endedUTC=stamp(), hostAfter=host())
        try:
            summary['sourceAfter'] = {lane: source_inventory(lane, enforce=False) for lane in ROOTS}
            require(summary['sourceAfter'] == sources, 'End source closure mismatch')
            require(digest(__file__) == script_sha, 'Orchestrator changed during run')
        except Exception as error:
            summary['status'] = 'FAIL'
            summary.setdefault('integrityErrors', []).append(str(error))
        write_new(outdir / 'summary.json', summary)
        print(json.dumps({'status': summary['status'], 'firstFailure': summary['firstFailure'], 'summary': str(outdir / 'summary.json')}), flush=True)
    return 0 if summary['status'] == 'PASS' else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
