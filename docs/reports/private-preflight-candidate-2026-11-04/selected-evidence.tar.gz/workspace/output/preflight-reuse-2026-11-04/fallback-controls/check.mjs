// Small semantic/CLI checks only. No timing, clock reads, build or instrumentation.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync,readFileSync,writeFileSync,realpathSync,mkdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
const node = '/Users/user/.nvm/versions/node/v24.22.1/bin/node';
assert.equal(process.execPath,node);
const dir = import.meta.dirname, driver = join(dir,'driver.mjs');
const evidence = resolve(process.argv[2] ?? join(dir,'smoke-checks'));
assert(!existsSync(evidence),'Refusing to overwrite evidence directory'); mkdirSync(evidence);
const receiptPath = join(evidence,'smoke-checks.json');
assert(!existsSync(receiptPath),'Refusing overwrite');
const sha = x => createHash('sha256').update(x).digest('hex');
const harnessSHA = sha(readFileSync(driver)), checkSHA = sha(readFileSync(import.meta.filename));
const lanes = [['baseline',resolve(dir,'../../refactor-2026-11-03/post-refactor-baseline')],['candidate',resolve(dir,'../candidate-v2')]];
const reports = [], checks = [];
function invoke(name,args,okay,match) {
    const r=spawnSync(node,[driver,...args],{encoding:'utf8',maxBuffer:2*1024*1024,env:{...process.env,NODE_OPTIONS:''}});
    for (const [suffix,data] of [['stdout.log',r.stdout],['stderr.log',r.stderr]]) writeFileSync(join(evidence,`${name}.${suffix}`),data,{flag:'wx'});
    assert.equal(r.error,undefined); assert.equal(r.status===0,okay,`${name}: ${r.stderr.slice(0,1000)}`);
    if (match) assert.match(r.stderr,match);
    checks.push({name,status:'PASS',exit:r.status});
}
for (const [label,root] of lanes) {
    const output=join(evidence,`${label}-smoke-final.json`);
    const args=['--source-root',root,'--label',label,'--output',output,'--mode','smoke'];
    invoke(`${label}-smoke-final`,args,true);
    reports.push(JSON.parse(readFileSync(output)));
    invoke(`${label}-overwrite-rejected`,args,false,/Refusing to overwrite output/);
    invoke(`${label}-counts`,['--source-root',root,'--label',label,'--output',join(evidence,`${label}-counts.json`),'--mode','counts','--samples','1','--warmup','0'],true);
}
assert.equal(reports[0].fixtureSHA,reports[1].fixtureSHA);
assert.deepEqual(reports[0].scenarios.map(s=>[s.name,s.fixtureSHA,s.semanticSHA,s.schemaVersion]),reports[1].scenarios.map(s=>[s.name,s.fixtureSHA,s.semanticSHA,s.schemaVersion]));
assert.deepEqual(reports[0].guards,reports[1].guards);
for (const [label] of lanes) {
    const count=JSON.parse(readFileSync(join(evidence,`${label}-counts.json`)));
    assert.equal(count.fixtureSHA,reports[0].fixtureSHA);
    assert.deepEqual(count.scenarios.map(s=>s.semanticSHA),reports[0].scenarios.map(s=>s.semanticSHA));
}
checks.push({name:'both-lane-full-semantic-hashes-and-guard-equivalence',status:'PASS'});
const common=['--source-root',lanes[0][1],'--label','invalid','--output',join(evidence,'invalid-must-not-exist.json')];
for (const [name,extra,match] of [
    ['unknown-option',['--wat','1'],/Invalid option/],['invalid-mode',['--mode','fast'],/Invalid mode/],
    ['bad-samples',['--samples','0'],/Invalid integer/],['duplicate-label',['--label','twice'],/Invalid option/],
    ['too-large-smoke',['--records','201'],/Smoke requires/],['odd-option',['--mode'],/Invalid option/],
]) invoke(name,[...common,...extra],false,match);
invoke('missing-source-root',['--label','missing','--output',join(evidence,'invalid-must-not-exist.json')],false,/Required --source-root/);
assert(!existsSync(join(evidence,'invalid-must-not-exist.json')));
assert.equal(sha(readFileSync(driver)),harnessSHA);
const receipt={status:'PASS',timing:'NOT_RUN',harnessSHA,checkSHA,node:process.version,executable:realpathSync(process.execPath),checks,fixtureSHA:reports[0].fixtureSHA,sources:reports.map(r=>({label:r.label,root:r.root,sourceSHA:r.sourceSHA,files:Object.keys(r.before).length,unchanged:r.sourceUnchanged})),scenarios:reports[0].scenarios.map(({name,semanticSHA,schemaVersion})=>({name,semanticSHA,schemaVersion})),defaults:{records:200,samples:5,warmup:2},scope:'Small smoke, clock-free semantic counts, CLI failures only; no proof approval or speed claim'};
writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
