# Source-only fallback controls

Status: harness smoke PASS; timing NOT_RUN. The parent must obtain independent exact-source proof approval before it runs timing. This harness does not grant that approval.

`driver.mjs` uses only the explicitly selected `packages/doc-sync/src` closure. Labels do not select behavior. Node must be `/Users/user/.nvm/versions/node/v24.22.1/bin/node` v24.22.1, with no NODE_OPTIONS or execArgv. It does not build, use dist, or load package aliases.

Four controls each start with 200 deterministic stored entries by default:

- Exact default Data schema: insert one entry at the middle.
- Exact default Data schema: delete one entry at the middle.
- Exact default Data schema: move a middle entry to index 1.
- Equivalent custom storage/value schema: update one middle entry value. A valid unused atom with an ordinary tag AttrSpec changes the validated schema fingerprint. An explicit assertion checks that the custom schemaVersion differs from the default before any timer. Merely cloning the exact default schema is not a custom control.

Each sample uses a fresh public Client.fromState fixture. The fixture actor, IDs, initial tickets, stored entries, retained public placements, and input edit are deterministic. Fixtures use normal public seed edits outside timing. The combined fixture SHA includes both validated schema states and is identical across lanes.

The timer contains one complete public Client.edit call. Input copies, fixture setup, warmups, model reads, full checkpoint/snapshot/History checks, returned-op checks, undo/redo and foreign-write checks are outside it. Timing mode uses five measured samples and two untimed warmups by default. Stock intrinsics remain installed. No source, clone, prototype or method instrumentation is used. Smoke/counts branches do not call the harness clock. Existing library History timestamp behavior is unchanged; comparison normalizes only History group `at` timestamps to zero.

Each sample checks the full independent model, detached snapshot and History roundtrip, undo/redo, and preservation of a foreign set and foreign deletion through undo/redo. Full returned ops, full normalized captured live states, and final states feed the sample semantic SHA. Cross-lane checks compare all four SHA values. A restore reconstructs the document revision, so roundtrip checks compare full snapshots, full History and engine identity; cross-lane semantic SHA values still include the exact live revision.

A separate untimed guard uses a custom engine factory with receiver checks on factory.create and every proxied engine method. It edits through public Client with an omitted-domain document schema. It checks legacy document-domain behavior and undo/redo. This guard runs in every mode. It is not a fifth performance cell. The isolated sync fixture has unsent local history; after assertions it disconnects and releases its standalone engine directly.

Run a fresh small check set (the evidence directory must not exist):

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/fallback-controls/check.mjs output/preflight-reuse-2026-11-04/fallback-controls/NEW-CHECK-DIR
```

The final preparation evidence is `checks-final/smoke-checks.json`. It binds driver/check hashes, fixture SHA, source closures and per-control semantic hashes. Each lane output includes complete source inventories before and after, selected loaded modules and source stability. Counts mode counts verified public samples only. It makes no private snapshot/restore/compiler or allocation census claim.

Only after independent proof approval, the parent may run one serial process per ABBA slot, for example:

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/fallback-controls/driver.mjs --source-root /Users/user/github/doc-sync/output/refactor-2026-11-03/post-refactor-baseline --label cycle1-A1 --output output/preflight-reuse-2026-11-04/fallback-controls/NEW-cycle1-A1.json --mode timing --records 200 --samples 5 --warmup 2
```

For B slots, set source-root to `/Users/user/github/doc-sync/output/preflight-reuse-2026-11-04/candidate-v2` and use a new label/output. A is the qualified archive, never HEAD. The driver rejects existing output files, unknown/duplicate/missing options, invalid sizes and invalid sample counts. It emits every timing sample, with no median pooling or gate decision.

The parent applies three prospective ABBA cycles and stops at the first mandatory failure. Compare pooled lane medians for each control within each cycle. The plan allows at most 3% median regression, with a predeclared 0.25 ms absolute allowance only for sub-millisecond control cells. No allowance applies to main Data cells. Use the parent's existing `benchmarks/doc-trace-control.mjs` for direct public Doc 100k text controls. This harness does not duplicate that control.

No timing, speed, heap, production, build/package, browser/mobile, Git or release claim follows from preparation smoke. Initial failed fixture assertions and superseded receipts remain preserved beside final evidence.

# Serial ABBA orchestration

`run-abba.py` is prepared for the parent to run after its final readiness decision. Preparation did not execute timing. This addition does not change the three frozen JavaScript drivers. The earlier final-manifest README hash describes the README before this orchestration section was appended.

Run from the repository with a new directory below fallback-controls:

```sh
python3 output/preflight-reuse-2026-11-04/fallback-controls/run-abba.py --output-dir output/preflight-reuse-2026-11-04/fallback-controls/abba-final-01 --timeout-seconds 600
```

It runs three cycles, in this order per cycle: normal 20k, normal 2k, legacy-no-moves 20k, legacy-no-moves 2k, fallback controls, direct Doc controls. Each group is serial A-B-B-A. Each child uses pinned Node 24.22.1, five measured samples and two warmups. There is one active child at a time. No source reader or writer overlaps that child's execution in this orchestrator. Host activity outside the process remains uncontrolled and is recorded.

The script pools the ten raw samples per lane for each cell within each cycle. For each 20k main scenario, total setter plus first read must improve by at least 5%. Every main setter and every 2k main total must regress by at most 3%. Next-read medians are observations. All four standalone fallback control cells and all six direct Doc local/remote metrics must regress by at most 3%, with a 0.25 ms allowance only when the baseline control median is below 1 ms. Main cells receive no allowance.

A performance failure stops after that complete ABBA group. A child error, timeout, oracle failure or source/fixture/checkpoint mismatch stops immediately as an invalid group. Every later group remains NOT_RUN. There is no retry or failed-cycle pooling. Gate order within each main group is root, nested map, list; each checks total, setter, then the read observation. `summary.json` names the first mandatory failed cell. Each completed group also has an individual JSON receipt. Process errors preserve the exact error and process-record references.

The script checks pinned source and driver hashes before it starts and before/after each child. It compares all four main fixture SHAs, authored fixture SHAs, final checkpoint SHAs, targets, retained move counts and all declared PASS oracles. Fallback semantic hashes and factory/domain guards must match. Doc fixture/workload/model/op/snapshot hashes and sample semantic hashes must match; its explicit no-History undoRedo NOT_RUN remains the declared direct-Doc boundary.

Each child has a new stdout/stderr log and process JSON with command, return code, elapsed time, watchdog status, host CPU/load observations and before/after source inventories. Doc's immutable driver writes its required `output/data-cache-2026-11-04/doc-trace-control.*.json` filename with a unique UUID prefix; the script preserves that original and copies its bytes into the new run directory. Both paths and the SHA are recorded. The 600-second watchdog stops only its own child if triggered. No other process is killed.

`plan.json` records all 18 planned groups before execution. Numbered progress receipts retain completed group boundaries. `summary.json` is written once at the end. Existing run directories and outputs are refused.

The following preparation check uses only synthetic timing JSON; it starts no Node child and reads no benchmark clock:

```sh
python3 output/preflight-reuse-2026-11-04/fallback-controls/run-abba.py --self-test
```

Synthetic gate boundaries, the main JSON parser, checkpoint-mismatch rejection and group order passed. The source closure and all three driver hashes were also checked without executing a benchmark. This is orchestration validation, not performance evidence.

The added `mock-main-check.py` also executed the actual orchestration `main` and `finally` paths with a mocked `run_child`. Real subprocess execution was replaced by an exception. Its two cases were a completed first ABBA group with a mandatory performance failure and a first-child process error. Both passed: final sourceAfter equals sourceBefore, no integrity error exists, and all 17 later groups remain NOT_RUN. The synthetic FAIL statuses are expected test inputs. Every saved JSON file is labeled `MOCK_NOT_TIMING`; no Node or timing ran. Evidence: `mock-main-checks-01/receipt.json` and its two case summaries. This checker refuses an existing evidence directory.

The final `source_inventory(lane, enforce=True)` signature accepts the `enforce=False` finalization calls. The added comment explains why finalization records actual hashes even if the expected-source check fails. The initial synthetic gate self-test did not cover this finalization path; the separate mock checker now covers both failure exits.
