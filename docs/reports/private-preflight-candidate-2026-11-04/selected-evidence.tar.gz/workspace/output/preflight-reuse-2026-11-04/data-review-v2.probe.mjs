// Read-only bounded reviewer probe. Each child uses one complete source tree.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
assert.equal(process.version, 'v24.22.1');
const out = import.meta.dirname;
const repo = path.resolve(out, '../..');
const baseline = path.join(repo, 'output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src');
const candidate = path.join(out, 'candidate-v2/packages/doc-sync/src');
const sha = x => crypto.createHash('sha256').update(x).digest('hex');
function manifest(root) {
  const files = {};
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, {withFileTypes: true}).sort((a,b) => a.name < b.name ? -1 : 1)) {
      const file = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(file);
      else files[path.relative(root, file)] = sha(fs.readFileSync(file));
    }
  }
  walk(root);
  return files;
}
const closure = files => sha(Object.entries(files).map(([p,h]) => `${h}  ${p}\n`).join(''));
const before = manifest(candidate), liveBefore = manifest(path.join(repo, 'packages/doc-sync/src'));
const rows = [];
const deadline = Date.now() + 9000; // Execution bound only, not a performance measurement.
for (const kind of ['root', 'nested', 'list']) {
  const results = [];
  for (const tree of [baseline, candidate]) {
    assert.ok(Date.now() < deadline, 'review probe execution bound');
    const child = spawnSync(process.execPath, [path.join(out, 'data-tests-v2/extra-child.mjs'), tree, `normal:${kind}`], {encoding:'utf8', timeout:Math.max(1, deadline-Date.now()), maxBuffer:4*1024*1024});
    assert.equal(child.status, 0, child.stderr);
    results.push(JSON.parse(child.stdout));
  }
  const [b,c] = results.map(x => x.observation);
  assert.equal(b.retainedMoves, kind === 'root' ? 1 : 3);
  assert.deepEqual([b.compilerCalls,b.liveSnapshots,b.snapshotScalars,b.restoreScalars], [4,2,3,3]);
  assert.deepEqual([c.compilerCalls,c.liveSnapshots,c.snapshotScalars,c.restoreScalars], [3,2,2,2]);
  for (const x of results) for (const key of ['compilerCalls','liveSnapshots','snapshotScalars','restoreScalars','scalarCopies']) delete x.observation[key];
  assert.deepEqual(results[0], results[1]);
  rows.push({scenario:`normal:${kind}`, semantics:'PASS', retainedMoves:b.retainedMoves, baseline:[3,3,4,2], candidate:[2,2,3,2]});
}
assert.deepEqual(manifest(candidate), before, 'candidate changed during probe');
assert.deepEqual(manifest(path.join(repo, 'packages/doc-sync/src')), liveBefore, 'production changed during probe');
assert.deepEqual(liveBefore, manifest(baseline), 'production differs from frozen archive');
console.log(JSON.stringify({node:process.version, at:new Date().toISOString(), candidateFiles:Object.keys(before).length, candidateClosure:closure(before), productionFiles:Object.keys(liveBefore).length, productionClosure:closure(liveBefore), stable:true, probeHash:sha(fs.readFileSync(import.meta.filename)), rows},null,2));
