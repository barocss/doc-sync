# Data private preflight V2

Disposition: PROOF_READY. Output-only producer handoff; independent tests and High review remain required. Not production or performance approval.

## Actual protocol to implement

The copied engine owns schema input with its existing schemaVersion / plain-JSON copy / recursive freeze factory. The factory records only the exact default createDataSchema fingerprint in a private WeakSet. An externally frozen object cannot enter that set. No registrar, Doc validity bit, public boolean parameter, barrel export, or payload adoption is added.

Only a real engine allocation with unchanged defining-module descriptors can attempt this operation. Unknown/Proxy/borrowed receivers retain the existing expression. One already-copied update must have exactly the ordinary `value` key, no length/type/other operation fields, and an existing entry atom path. Other commands use legacy preflight.

The private operation selects the actual static restore before reading actor; calls the selected source snapshot once with its receiver; reads schema once; invokes the selected restore once. It never retries that sequence. Fallback after this point calls the unchanged staged edit on the same P.

The actual original snapshot builder uses a scoped local certificate. It checks known real Doc/Line/items-array allocation identities and the actual selected native map/default-array route before passing its mapper. Unknown map/species/Proxy routes are marked unsafe before the unchanged selected public call. No returned foreign DTO is inspected for authority. Only actual fresh wrapper allocations, primitive metadata and host-cloned payloads can be certified. Later source getters cannot erase an unsafe observation.

Doc, KeyIndex (including find/join), Placements (including project/values/apply), and Clock descriptors are captured at their defining modules. Before certified restore and the immediate private operation, all transitive dispatch surfaces and exposed empty-collection sentinels must match those originals. A pure/fresh certified snapshot plus the owned pure schema and unchanged call graph establishes no private construction callback. Public fromSnapshot still executes all existing copies and validations and mints no authority.

After successful restoration, a private storage-only guard checks canonical IDs, head/body collisions, fixed Data birth/current types, ordinary attributes, placements, clock space and the exact atom path using a pure Data projection. It does not materialize P heads. Any uncertain or invalid state retains staged legacy preflight. Only after these checks may a one-use, scoped private operation omit P's atomic validation clone. It retains the original before-model read, compiler, applyEdits normalization, emit/run/priors and after-model read. No rollback, clock rewind, prepared-Doc adoption or raw replay is used. The live graphic stage is unchanged.

The final guard also requires unique, nonempty retained Data record IDs, canonical finite scalar metadata or an exact reference/kind pair naming a retained collection of that kind (including `$root`), and canonical old entry values. Mixed scalar/reference objects and uncertain metadata use legacy staging. The snapshot builder retains the literal `line.items.map(...)` expression, including its non-callable TypeError. Its certificate checks registered arrays through own-data descriptors before that expression. ROOT requires exact own-data primitive metadata; no ROOT accessor is invoked by the guard.

The actual implementation changes five copied Core modules (Doc, engine, KeyIndex, Placements, Clock) and adds one private helper. No package export is added. Public fromSnapshot still performs its full original defensive copies and admission checks. See `data-proof-v2-resume.report.md` and `data-proof-v2-resume.final.md` for exact hashes, test receipts, and proof limits.

## Proof obligations

| Obligation | Required evidence |
|---|---|
| Schema provenance | Factory-owned exact default fingerprint; custom/raw/frozen schemas do not qualify |
| Wrapper purity/freshness | Actual builder certificate, native map/default species, allocation identity; foreign returns never gain authority |
| Construction non-escape | No callback-capable input or overridden original/transitive dispatch can receive P/Items/closures |
| Ordering | Compiler success proved before early H; H only deterministic slot heads/private caches; ordinary value U cannot change placement/path/clock allocation or collide with a head |
| Commutation | H;U;final-read and U;H;final-read agree on ops/tickets/priors, model, clock/version, final P storage/caches/errors, including empty sibling Maps/Lists |
| Legacy precedence | Bad path/key/metadata/clock and every unknown route execute unchanged stage on the same P; no deferred new error |
| Integration | Both L snapshots, live atomic stage, pre-live normalization, exact ops/history/undo-redo/notifications/guards and live identities retained |
| Positive usefulness | Actual root/nested Map/List with authored placements and no-move restores reduce 3 pairs to 2 and 4 compilers to 3 |
| Preservation | Production 69 files, candidate-src V1 and all old reports/controls stay byte-identical |

Intrinsic/global replacement (Map/Set/Array/Object and host structuredClone semantics) is outside contract. Public module prototypes and exposed empty sentinel instances are not assumed original: they are checked at the private boundary. Source hooks for tests run before original capture; counters do not replace Doc descriptors.

## Stop and handoff

Stop only for a concrete unresolved counterexample or a required expansion outside this bounded design. A terminal report binds exact candidate hashes and gives PROOF_READY or HOLD. PROOF_READY is only a producer handoff for independent tests/review, never production or performance approval.
