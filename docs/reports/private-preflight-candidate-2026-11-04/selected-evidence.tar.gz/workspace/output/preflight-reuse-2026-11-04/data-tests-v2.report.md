# Independent Data V2 tests — output only

## Decision: HOLD — actual V2 qualification PENDING

The frozen whole-Core baseline passed **90/90 process scenarios**. These include the exact 64 earlier controls and 26 V2 additions. There is no candidate PASS. The producer terminal `data-proof-v2.final.md` was absent at the accepted run. The supplied protocol still said `Disposition: IN_PROGRESS`. The copied candidate tree is not a positive proof. No optimized API, private construction certificate, or private-mode binding is approved by this report.

| Evidence | Result |
|---|---|
| Frozen baseline functional checks | **90 PASS / 0 FAIL** |
| Earlier 64 controls | **64 PASS**, exact existing child drivers reused |
| Added V2 controls | **26 PASS** |
| Candidate executions | **0 — PENDING_PRODUCER** |
| Actual positive reductions | **0 — NOT_PROVED** |
| First accepted-run failure | None; producer handoff is missing |
| Production Core preservation | **69/69 byte-identical to frozen archive** |
| Source / harness stability | Archive, live Core, harness, candidate hash, protocol stable during accepted run |
| Private safety contract / High review | **PENDING**, separate root gate |
| Timing / speed / heap | **NOT_RUN**, no performance claim |
| Build / dist / browser / mobile / Git / further agents | **NOT_RUN** |

Node is pinned to `/Users/user/.nvm/versions/node/v24.22.1/bin/node`, exact `v24.22.1`. Drivers are JavaScript modules. Native Node strip-only imports use one complete Core tree per process. Baseline and candidate classes never share a process or prototype realm.

## Reproduce and receipts

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/data-tests-v2/run.mjs
```

The runner reads `data-protocol-v2.md` and the actual producer terminal disposition before candidate execution. Its default candidate tree is `candidate-v2/packages/doc-sync/src`. If the terminal protocol selects a different physical root, set `DATA_V2_TREE` to that actual source path. Do not point it at V1 or an unchanged control tree.

Accepted receipt: `data-tests-v2/runs/2026-11-03T19-41-04-229Z/receipt.json`.

- Baseline root: `/Users/user/github/doc-sync/output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src`.
- Candidate root selected but not executed: `/Users/user/github/doc-sync/output/preflight-reuse-2026-11-04/candidate-v2/packages/doc-sync/src`.
- Frozen baseline manifest digest: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`.
- Candidate before/after digest: `2a5d07ab363efcecae0c4465704b5c188680e7b3d652620051e646b90b87a6f8`.
- `before.json` and `after.json` retain every Core file SHA-256 and reused/owned JavaScript harness SHA-256. Each process retains separate raw stdout/stderr. Protocol and producer readiness inputs are copied into the run.

A candidate run that changes source, protocol, producer receipt or harness is invalid. It needs a later stable run. Zero candidate failures in this baseline-only receipt does not mean candidate equivalence.

## Added V2 oracles

1. **Exact normal usefulness controls.** Public `Client.data` creates one existing entry in root Map, nested Map and List. The retained move counts are asserted as **1 / 3 / 3** before the actual update. Each control records full returned ops, tickets, priors, before/after snapshots, clock/version, default History, notification sequence, undo/redo and exact live Doc/Line/Item identities. These are not bulk-only seeds.
2. **Real Data empty siblings.** Extend the reused N=20 public fixtures with both an empty Map and empty List. Run root/nested/List with authored moves and their legacy no-move public restores. The original scalar, negative-zero, Hangul, emoji, boolean, null and shared-collection-reference trials and History/foreign-write/deletion checks remain intact.
3. **Public H/U algebra control.** An empty Map and empty List begin without body heads. H creates exactly two Lines and leaves clocks/versions unchanged. Compile U with and without prior H. The compiler itself applies U; the test does not replay its returned ops. Assert identical full ops, priors, final storage/clock/version, public model and `applyEdits` expected model, with empty normalization. This is an algebra control, **not** a witness for private P ownership or all private caches.
4. **Collision and canonical alias.** An occupied generated body-head key is accepted by baseline and must keep the legacy trace/counts, not gain authority. A `01@actor` alias of an existing `1@actor` snapshot token must reject with `Duplicate snapshot token identity`.
5. **Stored DataMeta uncertainty.** A current stored value with mixed `scalar` and `reference` keys follows the baseline behavior. An invalid input scalar attribute and bad path retain the baseline compiler error. Separate sentinel tests assert **zero model reads** before those compiler errors.
6. **Clock boundary.** Final safe allocation at `MAX_SAFE_INTEGER - 1` succeeds with exactly the final safe ticket. Exhausted-clock failure leaves live snapshot/clock/version unchanged.
7. **Copy/restore independence.** Flat JSON shared subobjects remain shared within one copied register and detached from the caller. Separate public restore tests mutate the caller snapshot, restored value, other restored register, live value and returned public snapshot independently. Another fixture saves/reopens a public shared-collection reference and checks History undo/redo.
8. **Actual transient FIND escape.** A source DTO getter installs `KeyIndex.find`, which sees the real range storage and retains an actual Item, then restores itself. Rejected two-op and multi-key edits leave that exposed temporary Item at **2**, while live stays at **1**. This differs from the existing SET escape, whose exposed P remains **1**. Both exact legacy observations are retained; final descriptor equality does not erase the escape.
9. **Placement preload through the engine.** Override defining-module `Placements.project` before Doc/engine import. The real dispatch retains `ownerOf` and self-restores. A valid single-value engine update still lets the retained closure resolve the empty body owner afterward without changing live state. The earlier direct-public-P projection control also remains unchanged in the reused 64 cases.

The reused controls still exercise C1/C2, Array species/Proxy/getters, R4 preload overrides, retained `forEach` re-entry after rejection, input getter rejection with zero reads, exactly one original input clone before guards, guard mutation of the original batch, unknown/Proxy/borrowed/subclass receivers, custom factory receivers, public copy separation, sessions/checkpoint, malformed snapshots and exact error/trap ordering. Their original raw multi-probe outputs are not replaced by new setup.

## Counts, not timing

The positive census observes actual scalar-wrapper `structuredClone` calls. Source-load hooks count the actual `compileEdits` entry and actual live snapshot body. They do not replace public Doc/engine/Clock/KeyIndex/Placement function descriptors or install a producer callback. Every hook has an exact source anchor; an absent anchor fails the child process. Protocol V2 explicitly permits test source hooks before original-function capture.

Baseline positive gates assert **3 snapshot/restore pairs, 4 compiler calls, 2 live snapshots**. Candidate gates require exactly **2 pairs, 3 compiler calls, 2 live snapshots**, or label the exact unchanged counts as legacy fallback. Actual normal reductions remain mandatory. Pure fallback is not functional approval. Uncertain metadata/collision/invalid-value/path/clock cases require legacy count equivalence as well as full result equivalence.

A census alone cannot identify the removed pair. Before any approval, independent High source review must bind the **actual private-mode producer** to only P's atomic V stage. Both public live snapshots and all schema/JSON/identity/move validation must remain. The runner never fabricates a parallel private witness recorder or accepts a public token/flag as authority.

## Open gates — no promotion

- Actual ready V2 producer and stable candidate execution are missing.
- Full candidate/baseline equivalence, negative fallback traces and retained temporary-state equality are therefore PENDING.
- Construction non-escape must be checked against the actual factory and defining-module/transitive dispatch, including retained FIND/iteration/project closures and real schema copy/freeze provenance.
- Public H/U control does not prove invisible private caches, every collision or all error states. Those need the actual implementation plus the independent High contract review.
- The 90 cases do not independently enumerate every text/field/annotation/cardinality/grid/group/schema-transition permutation. Default/custom-schema restrictions and those remaining fallback surfaces require source-bound High review and, where needed, more targeted tests. Do not present this bounded receipt as full Core qualification.
- No production promotion, release, API approval, rollback mechanism or performance result is supplied.

## Preserved failed attempts

All runs remain under `data-tests-v2/runs/`. Initial author errors are visible: `find` returns a range index, not an Item; a plain public Data value cannot be an arbitrary object; and one intermediate driver had a syntax error. Corrected tests use actual range storage, put flat JSON sharing on the engine-owned-copy control, and use real shared collections for public reopen.

The first FIND probe expected the SET probe's value 1. Actual baseline FIND dispatch occurs on a different temporary and leaves value **2** on rejection. The raw failure is preserved. The accepted oracle fixes that baseline fact before any candidate execution. No candidate failure was relaxed or converted to PASS.

Ownership: only `data-tests-v2/**`, this report and `data-tests-v2.final.md` were written. V1 output, live source, candidate V2, protocol, real tests, docs and benchmarks were not edited. No agent was spawned.
