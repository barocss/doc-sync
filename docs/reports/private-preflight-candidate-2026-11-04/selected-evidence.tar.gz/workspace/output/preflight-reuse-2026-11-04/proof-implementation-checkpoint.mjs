import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
const out=import.meta.dirname,initial=JSON.parse(await readFile(join(out,'proof-implementation-source-initial.json'),'utf8'));
const hash=async file=>createHash('sha256').update(await readFile(file)).digest('hex');
async function files(dir,prefix=''){const result=[];for(const e of await readdir(dir,{withFileTypes:true})){const name=prefix+e.name;if(e.isDirectory())result.push(...await files(join(dir,e.name),name+'/'));else result.push(name);}return result.sort();}
assert.deepEqual(await files(initial.live),Object.keys(initial.hashes).sort());
assert.deepEqual((await files(initial.candidate)).filter(p=>p!=='package.json'),Object.keys(initial.hashes).sort());
const rows=[];for(const [name,sha]of Object.entries(initial.hashes)){const live=await hash(join(initial.live,name)),candidate=await hash(join(initial.candidate,name));rows.push({name,initial:sha,live,candidate,liveUnchanged:live===sha,candidateUnchanged:candidate===sha});}
const final={count:rows.length,liveUnchanged:rows.every(r=>r.liveUnchanged),candidateUnchanged:rows.every(r=>r.candidateUnchanged),rows};
await writeFile(join(out,'proof-implementation-source-final.json'),JSON.stringify(final,null,2)+'\n');assert.ok(final.liveUnchanged);assert.ok(final.candidateUnchanged);
const excluded=new Set(['proof-implementation.events.jsonl','proof-implementation.prompt.md','proof-implementation.stderr.log','proof-implementation-artifacts.sha256.json']);
const hashes={};for(const name of await readdir(out)){if((name.startsWith('proof-implementation-')||name==='proof-implementation.report.md'||name==='proof-implementation.final.md'||name==='protocol.md')&&!excluded.has(name))hashes[name]=await hash(join(out,name));}
for(const name of await files(initial.candidate))hashes[`candidate-src/${name}`]=await hash(join(initial.candidate,name));
const tree=createHash('sha256').update(JSON.stringify(Object.entries(initial.hashes).sort(([a],[b])=>a.localeCompare(b)))).digest('hex');
await writeFile(join(out,'proof-implementation-artifacts.sha256.json'),JSON.stringify({node:process.version,decision:'HOLD',coreCount:final.count,liveUnchanged:final.liveUnchanged,candidateUnchanged:final.candidateUnchanged,coreTreeDigest:tree,hashes},null,2)+'\n');
const receipt=JSON.parse(await readFile(join(out,'proof-implementation-receipt.json'),'utf8'));assert.equal(receipt.cases.length,10);assert.ok(receipt.controlPass);
console.log(JSON.stringify({decision:'HOLD',coreCount:final.count,liveUnchanged:true,candidateUnchanged:true,smallMatchedRunnerCases:receipt.cases.length,optimizedFactoryInstalled:false,pairs:'3 retained; 3→2 NOT_PROVEN',coreTreeDigest:tree,artifactManifestHash:await hash(join(out,'proof-implementation-artifacts.sha256.json'))},null,2));
