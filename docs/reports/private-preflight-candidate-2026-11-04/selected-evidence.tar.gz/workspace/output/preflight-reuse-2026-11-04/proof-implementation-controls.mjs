// Owned small differential control runner. One whole Core tree per child. No timing.
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const core=resolve(process.env.DOC_SYNC_CORE_ROOT);
const load=p=>import(pathToFileURL(`${core}/${p}`).href);
import assert from 'node:assert/strict';
const {Doc}=await load('crdt/doc.ts');
const {KeyIndex}=await load('crdt/key-index.ts');
const {encodeFieldKey}=await load('crdt/fields.ts');
const {compileEdits}=await load('crdt/edit.ts');
const {createDataSchema}=await load('data/schema.ts');
const {typescriptClientEngineFactory}=await load('engine/typescript-client.ts');
const actor='preflight-proof', id={lamport:1,actor};
const key=`1@${actor}`;
function seed(){const e=typescriptClientEngineFactory.create(actor,createDataSchema()); const d=e.typescriptDocument(); d.apply({t:'node',id,origin:{lamport:0,actor:'~root'},type:'entry',attrs:{id:'data:proof',key:'proof',value:{scalar:1}}}); return {e,d};}
const value=d=>d.get(key).attrs.get('value').value.scalar;
const update=n=>({op:'update',at:[0],attrs:{value:{scalar:n}}});
function failure(fn){try{fn();assert.fail('expected rejection');}catch(error){if(error?.code==='ERR_ASSERTION')throw error;return error;}}
const out={node:process.version,core,scope:'small whole-tree differential controls; no optimization installed; no speed measurement'};
{
 const {e,d}=seed(), counts={snapshot:0,restore:0,emit:0,check:0};
 const saved=[];
 function wrap(target,name,counter){const desc=Object.getOwnPropertyDescriptor(target,name); saved.push([target,name,desc]);Object.defineProperty(target,name,{...desc,value:function(...args){counts[counter]++;return desc.value.apply(this,args);}});}
 wrap(Doc.prototype,'snapshot','snapshot');wrap(Doc,'fromSnapshot','restore');wrap(Doc.prototype,'emit','emit');wrap(Doc.prototype,'check','check');
 try{const ops=e.apply([update(2)]);assert.equal(ops.length,1);assert.equal(value(d),2);}finally{for(const [obj,name,desc]of saved.reverse())Object.defineProperty(obj,name,desc);}
 assert.deepEqual(counts,{snapshot:3,restore:3,emit:4,check:4});
 out.stockGraphicPointPasses=counts;
}
{
 const sentinel={proof:'model sentinel'},original=Doc.prototype.toJSON;
 Doc.prototype.toJSON=function(){throw sentinel;};
 try{
  const {e,d}=seed();const err=failure(()=>e.apply([{op:'update',at:[99],attrs:{value:{scalar:2}}}],{normalize:true}));
  assert.notEqual(err,sentinel);assert.equal(value(d),1);
  const naive=failure(()=>{const copy=Doc.fromSnapshot(actor,d.snapshot(),d.schema);copy.toJSON();compileEdits(copy,[{op:'update',at:[99],attrs:{value:{scalar:2}}}]);});
  assert.equal(naive,sentinel);
  out.compilerBeforeBeforeModel={stockFirstError:err.message,naiveFirstError:'model sentinel',stockLiveValue:value(d)};
 }finally{Doc.prototype.toJSON=original;}
}
{
 const {e,d}=seed(),edits=[{op:'update',at:[0],attrs:{key:'changed',type:'missing'}}];
 const before=d.snapshot(),clock=d.clock.lamport;
 const compilerDoc=Doc.fromSnapshot(actor,before,d.schema),ops=compileEdits(compilerDoc,edits);
 assert.equal(ops.length,1);assert.equal(compilerDoc.get(key).attrs.get('key').value,'changed');
 const err=failure(()=>e.apply(edits,{normalize:true}));
 assert.deepEqual(d.snapshot(),before);assert.equal(d.clock.lamport,clock);
 const direct=Doc.fromSnapshot(actor,before,d.schema),directError=failure(()=>direct.edit(edits,{normalize:true}));
 assert.equal(directError.message,err.message);assert.equal(direct.get(key).attrs.get('key').value,'changed');assert.ok(direct.clock.lamport>clock);
 out.normalizationProofIsNecessary={compilerAccepts:true,engineError:err.message,engineLiveUnchanged:true,directGraphicDocMutatesBeforeNormalizationError:true};
}
{
 // A public snapshot route can arm an override DURING restore, after any entry check.
 // It leaks one restored Item and restores the original setter before return.
 // This is not a KeyIndex optimization/census.
 function run(mode,single=false){
  const {e,d}=seed(),originalSet=KeyIndex.prototype.set,originalSnapshot=Doc.prototype.snapshot;
  const publicItems=d.snapshot().lines[0].items;let armed=false,escaped;
  publicItems[1]=new Proxy(publicItems[1],{get(target,prop,receiver){
   if(prop==='i'&&!armed){armed=true;KeyIndex.prototype.set=function(k,item){
    const result=originalSet.call(this,k,item);
    if(k===key){escaped=item;KeyIndex.prototype.set=originalSet;}
    return result;
   };}
   return Reflect.get(target,prop,receiver);
  }});
  Object.defineProperty(d.items,'map',{configurable:true,value(){return publicItems;}});
  const edits=single?[{op:'update',at:[0],attrs:{value:{scalar:2},unknown:true}}]:[update(2),{op:'update',at:[99],attrs:{value:{scalar:3}}}];let err;
  try{
   if(mode==='stock')err=failure(()=>e.apply(edits,{normalize:true}));
   else{const fresh=Doc.fromSnapshot(actor,d.snapshot(),d.schema);assert.equal(KeyIndex.prototype.set,originalSet);err=failure(()=>compileEdits(fresh,edits));}
   assert.ok(escaped);assert.notEqual(escaped,d.get(key));assert.equal(KeyIndex.prototype.set,originalSet);assert.equal(Doc.prototype.snapshot,originalSnapshot);assert.equal(value(d),1);
   return {error:err.message,escapedValue:escaped.attrs.get('value').value.scalar,liveValue:value(d),setterOriginalAgain:true};
  }finally{KeyIndex.prototype.set=originalSet;}
 }
 const stock=run('stock'),unstaged=run('unstaged fresh-copy abstraction');
 assert.equal(stock.error,unstaged.error);assert.equal(stock.escapedValue,1);assert.equal(unstaged.escapedValue,2);
 const singleStock=run('stock',true),singleUnstaged=run('unstaged',true);assert.equal(singleStock.error,singleUnstaged.error);assert.equal(singleStock.escapedValue,1);assert.equal(singleUnstaged.escapedValue,2);
 function runPublicCheck(mode){
  const schema=createDataSchema();schema.nodes.entry.attrs.meta={default:{n:0},fields:{n:{default:0}}};
  const e=typescriptClientEngineFactory.create(actor,schema),d=e.typescriptDocument();
  d.apply({t:'node',id,origin:{lamport:0,actor:'~root'},type:'entry',attrs:{id:'data:proof',key:'proof',value:{scalar:1}}});
  d.apply({t:'set',at:{lamport:2,actor},ids:[id],key:encodeFieldKey('meta',['n']),value:0});
  const originalCheck=Doc.prototype.check,items=d.snapshot().lines[0].items;let armed=false,escaped;
  items[1]=new Proxy(items[1],{get(target,prop,receiver){if(prop==='i'&&!armed){armed=true;Doc.prototype.check=function(...args){escaped=this;Doc.prototype.check=originalCheck;return originalCheck.apply(this,args);};}return Reflect.get(target,prop,receiver);}});
  Object.defineProperty(d.items,'map',{configurable:true,value(){return items;}});
  const edits=[{op:'update',at:[0],attrs:{value:{scalar:2},unknown:true}}];let err;
  try{
   if(mode==='stock')err=failure(()=>e.apply(edits));
   else{const fresh=Doc.fromSnapshot(actor,d.snapshot(),d.schema);assert.equal(Doc.prototype.check,originalCheck);err=failure(()=>compileEdits(fresh,edits));}
   assert.ok(escaped);assert.notEqual(escaped,d);assert.equal(Doc.prototype.check,originalCheck);assert.equal(value(d),1);
   return {error:err.message,escapedValue:value(escaped),escapedClock:escaped.clock.lamport,liveValue:value(d),liveClock:d.clock.lamport,checkOriginalAgain:true};
  }finally{Doc.prototype.check=originalCheck;}
 }
 const publicDocCheckStock=runPublicCheck('stock'),publicDocCheckUnstaged=runPublicCheck('unstaged');
 assert.equal(publicDocCheckStock.error,publicDocCheckUnstaged.error);assert.equal(publicDocCheckStock.escapedValue,1);assert.equal(publicDocCheckUnstaged.escapedValue,2);assert.equal(publicDocCheckStock.escapedClock,2);assert.equal(publicDocCheckUnstaged.escapedClock,4);
 out.transientRestoreEscape={stock,unstaged,singleStock,singleUnstaged,publicDocCheckStock,publicDocCheckUnstaged,conclusion:'fresh allocation and post-restore surface equality do not prove non-observability'};
}
{
 const {e,d}=seed(),input=[update(2)];let copies=0,seen,guards=0;const clone=globalThis.structuredClone;
 globalThis.structuredClone=function(v,...rest){if(v===input)copies++;return clone(v,...rest);};
 e.setEditHooks({guard(){guards++;input[0].attrs.value.scalar=999;},listener(edits){seen=edits;}});
 try{e.apply(input);assert.equal(copies,1);assert.notEqual(seen,input);assert.notEqual(seen[0].attrs,input[0].attrs);assert.equal(value(d),2);}finally{globalThis.structuredClone=clone;}
 let getters=0;const bad={op:'update',at:[0],attrs:{}};Object.defineProperty(bad.attrs,'value',{enumerable:true,get(){getters++;return {scalar:3};}});
 const err=failure(()=>e.apply([bad]));assert.equal(getters,0);
 out.engineInputCopy={originalInputCloneCalls:copies,guardCalls:guards,detachedValue:value(d),accessorReads:getters,accessorError:err.message};
}
{
 const {e,d}=seed(),before=d.snapshot(),ops=e.apply([update(2)]),op=ops[0];
 assert.deepEqual(d.priorOf(op),[{id:op.ids[0],value:{scalar:1},at:id}]);
 const raw=Doc.fromSnapshot(actor,before,d.schema);raw.apply(op);assert.deepEqual(raw.priorOf(op),[]);
 const emitted=Doc.fromSnapshot(actor,before,d.schema);emitted.emit([op]);assert.deepEqual(emitted.priorOf(op),d.priorOf(op));
 out.priorOwnership={enginePrior:d.priorOf(op),rawApplyPrior:raw.priorOf(op),emitPrior:emitted.priorOf(op)};
}
{
 const {e,d}=seed(),sentinel={proof:'guard'},snapshot=d.snapshot();let snapshots=0;const original=d.snapshot;
 d.snapshot=function(){snapshots++;return original.call(this);};d.editGuard=()=>{throw sentinel;};
 const err=failure(()=>e.apply([update(2)]));assert.equal(err,sentinel);assert.equal(snapshots,0);assert.deepEqual(original.call(d),snapshot);
 out.initialDocGuard={exactSentinel:true,snapshotCallsBeforeGuardError:snapshots};
}
{
 const controls=[];
 for(const mode of ['engine proxy','borrowed engine']){
  const {e,d}=seed(),trace=[];
  const receiver=mode==='engine proxy'?new Proxy(e,{get(target,prop,receiver){trace.push(String(prop));return Reflect.get(target,prop,receiver);}}):Object.create(e);
  e.apply.call(receiver,[update(2)]);assert.equal(value(d),2);controls.push({mode,value:value(d),getCount:trace.length,firstGets:trace.slice(0,9)});
 }
 const {d}=seed(),trace=[],proxy=new Proxy(d,{get(target,prop,receiver){trace.push(String(prop));return Reflect.get(target,prop,receiver);}});
 Doc.prototype.edit.call(proxy,[update(2)]);assert.equal(value(d),2);
 controls.push({mode:'Doc proxy',value:value(d),getCount:trace.length,firstGets:trace.slice(0,9)});
 out.receiverControls=controls;
}
{
 const {e,d}=seed();let hooks=0,prior=0;
 e.setEditHooks({guard(){hooks++;},listener:null});d.editGuard=()=>{prior++;};const original=d.editGuard;
 e.apply([update(2)],{accepted:true});assert.equal(prior,0);assert.equal(hooks,3);assert.equal(d.editGuard,original);
 const error=failure(()=>e.apply([{op:'update',at:[99],attrs:{value:{scalar:3}}}],{accepted:true}));
 assert.equal(d.editGuard,original);assert.equal(value(d),2);
 out.acceptedGuardControl={successfulHookCalls:3,priorGuardCalls:prior,restoredOnSuccessAndError:true,error:error.message};
}
console.log(JSON.stringify(out,null,2));
