# Output-only private preflight construction and ordering proof

Status: HOLD. Concrete storage-ordering and transitive-capability counterexamples are recorded in proof-implementation.report.md. No stage-removal factory was installed. This is not production approval.

## Ownership
Owned: candidate-src/** (69 current Core files and required local package context), protocol.md, proof-implementation.report.md, proof-implementation.final.md, and proof-implementation-* runners, logs, manifests and receipts. Other output files belong to the parent/design/review lanes. Production source must remain byte-identical. No tests outside these owned runners, builds, timing, browser/mobile, commits, pushes or subagents.

## Proposed private operation
The engine selects the public restore function before reading actor; calls the selected source snapshot with its original receiver; reads schema once; restores once. A module-private immediate operation receives the actual source Doc, not a caller snapshot token. Public fromSnapshot retains all legacy copies and checks. Schema provenance can originate only in the actual engine validate/copy/freeze path. There is no public trusted flag, Doc flag, registrar, package export, or prepared-op replay.

## Proof table
| Obligation | Acceptance | Current state |
| --- | --- | --- |
| Source preservation | All 69 live hashes unchanged at end | PASS: exact inventory and hashes |
| Construction | Local monotonic audit before actual dispatch receiving private objects/capabilities; unsafe routes use unchanged legacy path | Not closed; staged path retained |
| Defining-module captures | Doc, KeyIndex and Clock originals captured before engine import; no foreign probing | Not closed; staged path retained |
| Clone evaluation | Selection/actor/snapshot receiver/schema/restore order unchanged; no extra unknown-receiver traps | Not closed; staged path retained |
| Eligibility | One copied update, one ordinary nonreserved attribute, existing atom, engine-owned all-container/atom schema; explicitly account for placements | Not closed; staged path retained |
| Normalizer ordering | Private before-model read cannot change compiler semantics/cache result; defer model errors until compiler succeeds; no callbacks/escape | Not closed; staged path retained |
| Admission/copies | Keep constructor, schema, snapshot validation, capability/ID/span/head/reserved/move checks; zero accessor reads; one original input clone | Not closed; staged path retained |
| Live integration | Keep live atomic stage, emit/run/priors, clocks/tickets, guard order, identity, notification/history | Not closed; staged path retained |
| Small controls | Separate process whole-tree selection; root/nested/list and counterexamples; exact errors/state/counts | PASS: 10 matched baseline-copy cases; NOT optimized proof |

## Stop rule
If the proof needs broad reflective trust machinery or cannot establish a bounded actual-dispatch audit and normalizer ordering in Doc/engine/a small helper plus strictly necessary KeyIndex/Clock captures, retain the staged path and report HOLD with concrete evidence. A failed proof is not permission to weaken copies or promote a candidate. No timing claims.

## Final private API disposition
Conceptual only: engine-private `preflightOwnedPoint(sourceDoc, copiedEdits): void`, closed over actual ownSchema validate/copy/freeze provenance. It selects restore before actor, snapshots with the source receiver, reads schema once, restores once, and immediately consumes a local monotonic construction/operation audit. Unsafe means same restored copy uses unchanged staged edit; never retry or resnapshot. It returns no Doc/ops/witness and adds no Doc flag/public argument/register. No implementation was installed because the narrower state-neutrality and callback-boundary proof is not closed.

Actual Data smoke: retained moves root/nested/List = 1/3/3. Excluding moves excludes those fixtures. Counts remain 3 pairs / 4 compilers. Node 24 native strip-only, no timing.
