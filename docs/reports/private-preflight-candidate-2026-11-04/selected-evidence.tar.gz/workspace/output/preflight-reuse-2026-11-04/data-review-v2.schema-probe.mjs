// Read-only reviewer case. This does not alter the independent test or its gate.
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {seed, update, value, state} from './proof-tests/fixtures.mjs';
assert.equal(process.version, 'v24.22.1');
if (process.argv[2] === '--child') {
  const base = pathToFileURL(path.resolve(process.argv[3])+'/').href;
  const {typescriptClientEngineFactory:factory} = await import(base+'engine/typescript-client.ts');
  const {createDataSchema} = await import(base+'data/schema.ts');
  const input = structuredClone(createDataSchema());
  if (process.argv[4] === 'altered') input.nodes.entry.attrs.note = {default:''};
  const {e,d} = seed(factory, () => input);
  let snapshots = 0, restores = 0;
  const clone = structuredClone;
  globalThis.structuredClone = function(v,...args) {
    if (v && typeof v === 'object' && Object.hasOwn(v,'scalar')) {
      const stack = new Error().stack;
      if (stack.includes('at itemToJSON ')) snapshots++;
      if (stack.includes('at itemFromJSON ')) restores++;
    }
    return clone(v,...args);
  };
  let ops;
  try { ops = e.apply([update(2)], {normalize:true}); }
  finally { globalThis.structuredClone = clone; }
  assert.equal(value(d),2);
  console.log(JSON.stringify({mode:process.argv[4],snapshots,restores,ops,prior:d.priorOf(ops[0]),state:state(d)}));
} else {
  const baseline = path.resolve(import.meta.dirname,'../refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src');
  const candidate = path.resolve(import.meta.dirname,'candidate-v2/packages/doc-sync/src');
  const rows = [];
  for (const mode of ['clone-default','altered']) {
    const results = [baseline,candidate].map(tree => {
      const child = spawnSync(process.execPath,[import.meta.filename,'--child',tree,mode],{encoding:'utf8',timeout:2000});
      assert.equal(child.status,0,child.stderr);
      return JSON.parse(child.stdout);
    });
    assert.deepEqual([results[0].snapshots,results[0].restores],[3,3]);
    assert.deepEqual([results[1].snapshots,results[1].restores],mode==='altered'?[3,3]:[2,2]);
    rows.push({mode,baseline:[results[0].snapshots,results[0].restores],candidate:[results[1].snapshots,results[1].restores],semantics:'PASS'});
    for (const result of results) { delete result.snapshots; delete result.restores; }
    assert.deepEqual(results[0],results[1]);
  }
  console.log(JSON.stringify({node:process.version,rows},null,2));
}
