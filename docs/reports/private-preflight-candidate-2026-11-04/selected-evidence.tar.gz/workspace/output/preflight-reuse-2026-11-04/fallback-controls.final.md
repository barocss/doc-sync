Disposition: PREPARED; smoke/counts/CLI PASS; timing NOT_RUN.

No independent proof or performance approval.

Report: fallback-controls.report.md

Report SHA-256: b669112054de55560d9073e107ae97102af10744d3940522a5ac793965cfe6e9

Manifest: fallback-controls/final-manifest.json

Driver SHA-256: 2fb6ded590abdd81aaec001aa27d3b9ddc2fc49ecc576c92eee382b45c4b1fb3

Check runner SHA-256: c6e057d28d64d827c970a8762e5651364882d71095b112b437fde675bb0f1ede

Final receipt SHA-256: 547bace96464ad3b1e2afad7065c74c0ac92e0505cff1b611de9cef930c4d45f

Fixture SHA-256: 2e4e050d630e667317e31cdbc001feccf8947cfb8c4e54ceedd01efda908ad8e

Baseline closure: 8b532beb32d4ef0e7d69e54ac9a989d269d0c590e11d6ef8f3f0545b362c4a51

Candidate closure: d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab

Four control semantic hashes and untimed factory/domain guard match across both source lanes.

Only final checks-final evidence binds final harness bytes. Earlier attempts are preserved.
