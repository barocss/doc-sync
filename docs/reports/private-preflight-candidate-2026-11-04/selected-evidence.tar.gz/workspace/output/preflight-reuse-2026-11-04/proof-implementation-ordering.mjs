import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const core=resolve(process.env.DOC_SYNC_CORE_ROOT ?? `${import.meta.dirname}/candidate-src`);
const load=p=>import(pathToFileURL(`${core}/${p}`).href);
const {Doc}=await load('crdt/doc.ts');
const {compileEdits}=await load('crdt/edit.ts');
const {createDataSchema}=await load('data/schema.ts');
const {typescriptClientEngineFactory}=await load('engine/typescript-client.ts');
const actor='ordering-proof';
function seed(){const e=typescriptClientEngineFactory.create(actor,createDataSchema()),d=e.typescriptDocument();
 d.apply({t:'node',id:{lamport:1,actor},origin:{lamport:0,actor:'~root'},type:'entry',attrs:{id:'data:proof',key:'proof',value:{scalar:1}}});
 d.apply({t:'node',id:{lamport:2,actor},origin:{lamport:1,actor},type:'map',attrs:{id:'data:empty'}});return {e,d};}
function storage(d){return {snapshot:d.snapshot(),version:d.version,clock:d.clock.lamport,tokens:d.storedTokenCount(),lines:d.lines().map(l=>l.key),cache:{model:!!d.modelCache,blocks:d.blockCache.size,logical:d.logicalBlocks.size,projection:!!d.projectionCache}};}
const {d}=seed(),p=Doc.fromSnapshot(actor,d.snapshot(),d.schema),before=storage(p);
p.toJSON();const after=storage(p);
assert.ok(after.lines.length>before.lines.length);assert.ok(after.tokens>before.tokens);assert.equal(after.clock,before.clock);assert.equal(after.version,before.version);
const edits=[{op:'update',at:[0],attrs:{value:{scalar:2}}}];
const first=Doc.fromSnapshot(actor,d.snapshot(),d.schema),second=Doc.fromSnapshot(actor,d.snapshot(),d.schema);
const firstOps=compileEdits(first,edits);second.toJSON();const secondOps=compileEdits(second,edits);
assert.deepEqual(firstOps,secondOps);assert.notDeepEqual(first.snapshot(),second.snapshot());
const compilerFirst=storage(first),modelFirst=storage(second);
assert.deepEqual(first.toJSON(),second.toJSON());assert.deepEqual(first.snapshot(),second.snapshot());
console.log(JSON.stringify({core,node:process.version,scope:'ordering obligation, not optimized implementation',allContainerAtomReadMutatesStorage:{before,after},matchedOneKeyCompilerResult:{ops:firstOps,compilerFirst,modelFirst,logicalResultSameAfterModelRead:true,storageBeforeCompilerDifferent:true},verdict:'Narrow schema shape alone does not establish storage-neutral before-read. Existing empty sibling container creates a body head. Compiler equivalence holds for this fixture only.'},null,2));
