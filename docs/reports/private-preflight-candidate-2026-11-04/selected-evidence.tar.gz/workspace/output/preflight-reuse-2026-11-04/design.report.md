# Private preflight stage reuse: architecture and proof review

## Decision: HOLD

Do not remove the fresh preflight Doc's graphic atomic stage yet. Do not skip the engine preflight on the strength of the live Doc's graphic stage.

**New evidence:** a restore callback can expose an Item or the entire fresh preflight Doc, then restore the original method before restoration returns. An unstaged compiler changes that exposed Item before a late rejection. The current staged compiler does not. The live Doc, final method identities, error text, owned frozen schema, and defensive payload copies can all remain unchanged. Thus “fresh allocation + final surface equality” is not a sufficient private-copy proof.

This is a bounded HOLD, not a claim that a private factory cannot solve the problem. A factory can establish construction provenance. It must establish it during construction, not infer it after callbacks have run. It must also solve the compiler-before-model error order. Section 6 gives the smallest next proof step. No production candidate or timing is approved by this report.

### Evidence boundary

- **PASS:** all 69 Core source files equal `output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src`, byte for byte. Checked before report writing and again at final capture.
- **PASS:** nine small baseline functional probe groups in `baseline-probe.mjs` and `baseline-probe.json`. Node **v24.22.1** at `/Users/user/.nvm/versions/node/v24.22.1/bin/node`. Normal strip-only execution. No execution flags.
- **NOT_RUN:** candidate implementation, candidate tests, full tests, build, dist/package checks, browser, mobile, profiles, performance timing, commit, push, and further agents.
- The reported full Core result, **2081 PASS / 2 SKIP**, is supplied context. It was not rerun here. It is not performance qualification.
- The COW rejection and private attribute-adoption HOLD remain in effect. No COW, trace, payload-transfer, or original-surface production helper was installed. No KeyIndex optimization census was repeated.
- Owned files here: this report, `final.md`, `baseline-probe.mjs`, and `baseline-probe.json`. Existing event/prompt/log artifacts and all other workers' files were left unchanged.

## 1. Exact current call graph

All paths below are under `packages/doc-sync/src/`.

### Engine admission and guard order

1. `engine/typescript-client.ts:217-223`: `compile` validates and clones the EditOp input with `copy`, then checks operation kinds, paths, and delete counts.
2. `224-226`: `withPathMemo(doc, ...)` calls `doc.edit` with a preflight closure. `crdt/edit.ts:101-107` reads schema/frozen state, version, and token count before entering that closure. It restores a prior path memo in `finally`.
3. `crdt/doc.ts:2243-2247`: `Doc.edit` calls the current `editGuard`, then the engine preflight. This is before its graphic snapshot and before its normalization model read. It is **not** before engine DTO admission or path-memo setup.
4. `engine/typescript-client.ts:225`: `fastText` runs first. Only if false does `fastStructure` run. Only if both are false does `this.clone(doc).edit(input, {normalize:true})` run. Keep this short circuit and all its errors.
5. `127-174`: fast text proves physical-text placement and allocation/clock bounds. It has schema attribute checks. It is not a graphic-domain admission shortcut.
6. `176-215`: fast structure handles bounded plain-root split/merge. It excludes moves/cardinality and proves schema, placement, and clock conditions.

The engine clone is exactly `Doc.fromSnapshot(this.actor, doc.snapshot(), doc.schema)` at `121`. Its selection/evaluation order matters: select `Doc.fromSnapshot`, read engine actor, call the selected source snapshot method with its receiver, read source schema, then call the selected restore function. Do not retry the snapshot on fallback. Do not read actor/schema from an unknown receiver for a new eligibility test.

### Graphic point edit: three pairs, four compiler runs

Let L be live, P be the outer preflight copy, V be P's atomic validation copy, and A be L's atomic validation copy.

| Order | Work | Source |
| --- | --- | --- |
| 1 | snapshot L; restore P | engine clone, `typescript-client.ts:121,225` |
| 2 | snapshot P; restore V; compile into V | `doc.ts:2248-2252` |
| 3 | read P's before model; compile into P; run `applyEdits` and normalization | `doc.ts:2253-2265` |
| 4 | discard preflight result; snapshot L; restore A; compile into A | `doc.ts:2248-2252` |
| 5 | read L's before model if requested/listened; compile into L; normalize; notify | `doc.ts:2253-2270` |

The one-entry probe confirms **3 snapshots, 3 restores, 4 checked compiler emissions, 4 emits, and 4 applies**. The four compiler count is specific to this one-set fixture. It is not a general one-emission-per-edit claim. The engine preflight always asks for normalization. The live call may not need it.

Removing pair 2 is a material structural target in principle. Removing one of three pairs is **not** proof of a one-third total speedup. No speed was measured.

## 2. New counterexample: a fresh copy can escape transiently

### Executed mechanism

The probe uses an engine-created, copied/frozen **default Data schema**. It does not modify a Doc method, a source Item, or a payload-copy helper.

1. `Doc.items` exposes the actual item array (`doc.ts:361-364`). Give only that public array an own `map` returning retained valid ItemJSON data. The original `Doc.snapshot` remains selected. This is an unsafe C1 route and must fall back in a correct future design.
2. One returned ItemJSON is a Proxy over a normal plain object. The JSON visitor checks descriptors and keys (`annotations.ts:41-57`); it does not read its `i` property through ordinary get. The Proxy passes this baseline admission.
3. On the first ordinary `j.i` read in `itemFromJSON` (`doc.ts:2715-2719`), arm a temporary `KeyIndex.prototype.set` wrapper.
4. The actual restore insertion (`doc.ts:2609`) calls that wrapper. It calls the original setter, retains the restored Item, and immediately restores the original setter.
5. At return from `Doc.fromSnapshot`, all inspected setter and Doc snapshot method identities are original again. The retained Item belongs to P, not L. Each payload was still defensively copied.

This is about **construction escape**, not KeyIndex parsing or performance.

### Executed differential

| Input | Current engine preflight | Unstaged fresh-copy abstraction |
| --- | --- | --- |
| valid value update, then bad path `[99]` | rejects; exposed P Item remains scalar **1** | same rejection text; exposed P Item is scalar **2** |
| one update with `{value:{scalar:2}, unknown:true}` | rejects unknown attribute; exposed P Item remains **1** | same rejection text; exposed P Item is **2** |

In all four cases L remains scalar 1 and the setter is original again. The second case also defeats an eligibility rule based only on “one point-update EditOp.” One EditOp can emit and apply several sets in order (`edit.ts:1141`).

**Evidence:** the values above are asserted in the output-only probe. **Inference, high confidence:** a factory that merely returns the existing public restore result and then checks final descriptors is insufficient. Entry and exit descriptor checks both miss a callback armed during DTO consumption. A correct factory must fall back on this route, or prevent target exposure by construction without changing the public trace.

### Same escape through public `Doc.check`, including the clock

A second executed variant does not replace KeyIndex or a global intrinsic. It adds one valid nested-field attribute to a Data-shaped schema, then creates the engine normally. The engine owns/copies/freezes that schema. The ItemJSON Proxy arms a temporary **public `Doc.prototype.check`** wrapper during `j.i` consumption. The reserved-field restore check at `doc.ts:2661` calls it with P as receiver. The wrapper retains P, restores the original check method, and runs the original validation. Before and after outer restoration, all Doc methods are original.

For one update containing a valid value set followed by an unknown attribute:

- Current engine: exposed P remains value **1**, clock **2**.
- Unstaged fresh-copy abstraction: exposed P becomes value **2**, clock **4**.
- Both reject with the same unknown-attribute message. Both leave L at value **1**, clock **2**. Both end with the original public check method.

This directly exercises the public override boundary named in the task. It also shows why a leaked disposable copy's clock cannot be ignored. A correct narrowed Data-only factory can decline the field schema and this C1/Proxy route. The counterexample is not a reason to decline that narrower factory after it has a complete proof.

This does not prove that a factory with a proper construction audit is unsafe. It identifies a required fallback and the exact place where a post-hoc proof fails. Fewer validation calls are not automatically a security defect. Here the differing observation is an exposed intermediate Item after rejection.

## 3. Error order and normalization are independent obligations

### F1. Naive unstaged `Doc.edit` changes the first error

`doc.ts:2251` compiles V **before** P's `textEditScope`/before-model read at `2254-2255`.

With a throwing `Doc.prototype.toJSON` sentinel and an invalid path:

- Current engine: first error is `경로 [99]: 99 번째 자식이 없다`. Live value stays 1.
- Naive before-model-first abstraction: first error is the exact model sentinel.

The probe asserts this. Capturing only the `edit` descriptor at engine import is not a fix. Original descriptors must be captured in each defining module, before later imports can replace them. Any affected override must retain its old call/receiver/error trace.

### F2. The live graphic compiler stage does not prove normalization

A default Data update with `{key:'changed', type:'missing'}` produces a valid key set in `compileEdits`. For a non-text block, the compiler ignores the `type` key (`edit.ts:1141`). Model application handles `type` (`model.ts:716-724`) and canonicalization rejects a child not admitted by its container (`312-318`).

Executed results:

- A detached `compileEdits` accepts and emits one set.
- The current engine rejects with `Node missing is not allowed in data` before L changes.
- Direct `Doc.edit(..., {normalize:true})` has its own graphic compiler stage, yet throws that same normalization error **after changing its own key and clock**.

Thus the engine's normalized preflight cannot be replaced by “the live graphic stage already validates.” This does not assert that public `Doc.edit` promises rollback for normalization failures today. It demonstrates why the engine has a stronger pre-live proof.

### What must remain

Keep public DTO admission, snapshot admission, defensive copies, all restore identity/capability/reserved-register/movement checks, compiler path/schema/field/clock checks, normalized preflight, guard precedence, and notification order. In particular:

- `doc.ts:2575-2673`: public restore performs JSON, clock, feature, identity/span/head, reserved storage, register, and move validation. Constructor schema validation is at `335-349`. Do not turn a private-stage optimization into public restore validation reuse.
- `edit.ts:299-337`: field expansion can allocate additional tickets; graphic checks occur on expanded operations before `doc.emit`.
- `doc.ts:2274-2276,2528-2549`: `emit` invokes its guard, then `run` captures attribute and movement priors before `apply`.
- `doc.ts:800-908`: `apply` invokes its guard, invalidates model/cache state, advances revision, copies stored values, and observes clocks.

## 4. Input copies, operations, and integration identity

### Input-copy semantics: verified, not assumed

The engine's `copy` (`typescript-client.ts:28-49`) first checks plain JSON using descriptors, then calls `structuredClone` once. A getter-valued edit attribute is **rejected without invoking its getter**. It is not copied by reading that getter once.

The probe confirms one structured clone of the original valid EditOp input. A live guard then changes the original scalar to 999. The copied batch still writes 2. The listener receives a detached input graph. The observed guard count is 3 for this single live set: edit entry, emit, apply. The copy and semantic admission still precede the first Doc guard.

`Client.edit` forwards through LocalClient or host (`client/index.ts:232-235`); LocalClient forwards to `engine.apply` (`local/client.ts:138,155-156`). Do not add another EditOp copy in a new private preflight helper. Session/history/event copies elsewhere are different ownership boundaries.

### Do not adopt a prepared Doc or replay raw applies

The baseline stage discards its ops. There is no existing prepared-op commit API at `Doc.edit`.

The probe confirms that the real engine result has `priorOf(op) = [{id, value:{scalar:1}, at:oldTicket}]`. Raw `apply(op)` on an equivalent Doc gives `priorOf(op) = []`. `emit([op])` captures the correct prior. `History.record` consumes these weak-map entries (`history.ts:439-448`). Identical JSON or identical op contents alone do not prove History equivalence.

Any future prepared commit needs a separate proof of expanded op identity, target ownership/version, single use, exact priors, ticket allocation, clock floor, and one live emission. This report does not recommend that larger design. Keep live Doc/Line/Item identities and the current live compiler for the first revision.

### Integration constraints

- Engine guard wrapper and attachment: `typescript-client.ts:105-120`. Keep previous guard behavior and listener binding when replacing/restoring documents.
- `accepted:true`: `228-231` temporarily substitutes the guard and restores it in `finally`. The probe confirms the prior guard is bypassed as today, the hook runs three times on success, and the old guard returns on success and error.
- Local hooks/commit: `local/client.ts:98-100,119-156`. Do not consume pending operations or notify during detached proof.
- Sync hooks: `sync/client.ts:262-272`. Conditional reproduction compares full ops before accepted application (`570-579`). Preserve this path, including installingConditional and record order.
- Sessions: `typescript-client.ts:373-391`. Keep draft/live clock reservation, pending op copies, publish and cancel. Do not strengthen rollback claims for existing callback failures or for `begin`, which assigns its draft before cloning.
- Prepared state/checkpoint/schema transitions: `315-340`. No public restore/admission or defensive-copy bypass. No whole-snapshot adoption.

## 5. Required fallback table for a later design

These are proof requirements, not currently implemented eligibility.

| Public situation | Required behavior |
| --- | --- |
| Unknown, Proxy, borrowed, or subclass engine receiver | Run the unchanged legacy path. A WeakSet membership check is safe; extra actor/schema/Doc reads on an unknown receiver are not. No new private-brand TypeError. |
| Unknown/Proxy/subclass/borrowed Doc; changed own descriptor or prototype/static method/accessor | Unchanged legacy path, before eligible-only reads. Capture originals at their defining module, not when Client is imported. |
| Own `items.map`, own map getter, foreign array, own constructor/species, element/field getter, Proxy DTO, transient loader dispatch | Preserve original calls and reads once. No post-hoc non-escape inference. The new transient-escape probe must remain baseline-equivalent. |
| Override selected before source snapshot; snapshot/schema callback changes later surfaces | Keep the selected restore function, receiver, and evaluation order. Restore the same snapshot once. Do not retry or select a replacement after callbacks. |
| Raw or externally frozen schema | Legacy. Frozen is not provenance. Only a real validate/copy/freeze factory can mint private schema provenance. Keep its current error order. |
| Public snapshot/fromSnapshot, import, recovery, checkpoint, schema preview/upgrade | Existing copies and validation. No trust token, new public argument, or new package capability. |
| Any callback during a purported private interval | Never carry a reusable trusted-Doc flag across it. Either establish a local no-exposure proof at the actual dispatch or fall back. Final descriptor equality is insufficient. |
| Late compiler, normalization, clock, or guard failure | Preserve first error, callback trace, and existing target-state boundary. Do not catch and retry on another Doc. |

Baseline controls prove that transparent engine Proxy, borrowed engine receiver, and transparent Doc Proxy can all edit successfully today. For this fixture, the engine Proxy makes 8 get traps and the Doc Proxy makes 232. These are not performance figures or universal API counts. A future fallback must compare the full trace for its matched fixture, not merely succeed.

## 6. Minimal next safe step

**Do one output-only construction/ordering proof before writing a production candidate.** Keep the 69-file baseline frozen. Do not time it.

The smallest useful proposed scope is one copied `update`, one non-reserved ordinary attribute on an existing atom, in an engine-owned all-container/atom schema. No text, groups, grids, fields, cardinality, annotations, moves, reserved/derived storage, type changes, or multi-key patches. Default Data value updates in the root/nested Map/List cases fit the intended schema/input shape, but fixture eligibility must be checked rather than assumed.

The private factory is conceptually feasible:

1. Own schema provenance at the actual validate/copy/freeze factory. There is no exported registration function and no `isFrozen` authority.
2. Factor the existing restore body without changing its algorithm, public signatures, copies, or errors. A private invocation owns a **local construction audit**, not an on-Doc flag. Record exposure risk when the actual selected dispatch receives a newly built Doc/Item/Line/register or a closure that can later mutate it. Compare dispatches to defining-module originals **before calling them**. A mismatch remains unsafe even if the callback restores the original. Include KeyIndex/Map/Set/array dispatch and retained iteration callbacks, not only `doc.check`. Unknown snapshot traps must not be probed a second time for eligibility.
3. Keep the exact public clone evaluation and fallback observations. A custom selected restore function still runs as selected and cannot mint a witness. A Proxy returned in place of a fresh Doc is not a real allocation witness. Never accept a caller-supplied snapshot/Doc/token as private authority.
4. Consume a construction witness only inside the same immediate private operation. Do not return the preflight Doc, ops, witness, or ownership authority to public callbacks. Keep every defensive copy. If the witness cannot be established cheaply within the allowed few-file scope, stop this option; do not enlarge it into a reflected original-surface or whole-snapshot helper.
5. Separately prove the normalization schedule. A new factory alone does **not** solve it. A before-model-first variant must prove that the read cannot change tokens, lines, clocks, or subsequent compiler behavior for the narrowed shape. It must hold any before-read error until the full compiler result is known, so compiler errors retain precedence. It must also prove that no callback can observe that reordered read. Compare all cache/storage effects, not just final JSON. Otherwise retain the current stage; do not approve naive unstaged `Doc.edit`.

This is a discriminating proof task, not an approved implementation plan. The present report has **not** closed steps 2 or 5. A bare `new Doc` registry, a post-restore scan, or a “trusted data schema” boolean does not close them. A single-key restriction avoids the executed multi-key failure, but is not itself a no-exposure or read-order proof.

Do not use a private rollback/rewind of the disposable compiler as a shortcut without a separate state proof. `apply` changes revision, model state, caches, clocks, and weak-map priors as well as the visible register. That is more work than an attribute swap. No such rollback helper was implemented here.

## 7. Functional acceptance before timing

A later approved candidate must use separate baseline/candidate processes and normal Node 24 strip-only imports. Do not load two candidates into one mutated prototype realm.

Mandatory narrow tests:

1. New transient restore escape: both the two-op bad-path case and one-op multi-key late error. Include self-restoring setters and retained iteration closures. Compare exposed intermediate state, exact first error, live clock/version/snapshot, and callbacks.
2. Existing C1/C2: own map/getter, species that retains Array or Proxy, throwing getter/constructor, and earlier callbacks changing later lines. All unsafe routes must preserve legacy reads and defensive copies.
3. R4 preload: import defining modules, override valid/invalid/throwing/getter Doc/Clock/restore surfaces, then import Client. Also test replacement during source snapshot/restore and restoration to originals before return. No late original capture.
4. Error order: invalid first/last path, valid first set plus invalid second key/op, model-read sentinel, applyEdits-only failure from section 3, clock exhaustion at allocation/field/movement bounds, and initial readonly guard. Compare exact sentinel identity where applicable.
5. Input ownership: one engine copy of the original input, rejected getters with zero getter reads, guard mutation of original input, deep aliases, and no extra public arguments/flags/exports.
6. Full state/History: exact ops and tickets, snapshots, version/clock, `priorOf` and movement priors; undo/redo with foreign writes; live Item/Line/Doc identity; notification sequence. Normalize only pre-agreed History wall-clock timestamps.
7. Direct public Doc, public restoration twice, sessions begin/publish/cancel/failure, accepted conditional intent, checkpoint/reopen/recovery, prepared state, and schema preview/upgrade. Keep guards, listener bindings, and defaults.
8. Receiver controls: real, Proxy, borrowed, subclass, custom engine factory. Compare trap/getter traces; no new brand error. Construction-witness authority must not escape through any callback or returned object.

These tests are a proposal. The nine baseline probes are narrower evidence and are not candidate qualification.

## 8. Performance/control proposal: approve before any timing

Context only: root supplied the earlier COW results: first-read reductions of 27-36%, but 20k total nested Map 3.55% and List 2.91%, and 2k nested regression 5.4%. They were rejected. The supplied large setter/read figures, about 800 ms plus 100 ms, were not measured in this task.

If construction and error-order proof passes, use this prespecified gate:

- Same frozen post-refactor 69-file baseline. Record driver/source hashes, deterministic fixture identity, full-state oracle and Node v24.22.1. Do not benchmark against HEAD alone, COW, or attribute adoption.
- Primary endpoint: public setter **plus first relevant public read**. Also report each component. Include root Map, nested Map, and List, at both 20k and 2k. Include any setup/model work moved into the setter.
- Require **at least 5% total median reduction in each of all three 20k cases in every accepted serialized ABBA cycle**. Also require no setter regression over 3%. Require **at most 3% total regression for each 2k case**. A pass in only root Map is not acceptance.
- Prespecify three cycles with early stop on the first mandatory failure. No favorable reruns after a failed/noisy mandatory cycle without a new approved protocol. Root serializes timing, tests and other qualification jobs. Record host load; do not stop unrelated work.
- Untimed controls first: direct public `Doc.edit` with graphic schema; direct text Doc and default-engine fastText/fastStructure; public snapshot/fromSnapshot copies; SyncClient with default engine; SyncClient with a custom factory whose engine methods/receivers are observable; raw/replaced Docs and custom schemas. Direct Doc/public restore/custom fallback paths must retain the same work and trace. SyncClient/default engine may benefit only in the same eligible internal preflight path.
- For tiny unchanged timing controls, propose an absolute noise tolerance of **0.25 ms per operation median**, declared before timing. For non-tiny controls use 3%. This allowance does not weaken the 20k benefit or 2k regression gates. First reject any control whose functional trace or copy count changes, regardless of speed.
- Separate counts from timing. A candidate may claim removal of exactly one *private preflight* pair only when its fixture is eligible. Both L snapshots and their public observations must remain. Never describe a removed compiler-only validation pass as removal of all admission/normalization checks.

Performance status remains **NOT_RUN**. The opportunity may exceed 5% because it targets one full restoration and compiler pass; that is an unmeasured hypothesis, not a projected or qualified speedup.

## 9. Source identity and confidence

HEAD: `ec9622571a04a7d7ea3f967bb3e6423b17ce5194`. This review uses the frozen **post-refactor WIP**, not that HEAD tree.

| Source under `packages/doc-sync/src/` | SHA-256 |
| --- | --- |
| `crdt/doc.ts` | `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` |
| `crdt/edit.ts` | `243365d1edf36d2de8d450143743db4e59b52fa0a9f8d2a92a0ca99dae608553` |
| `crdt/model.ts` | `2c7870499350dd5fc9657853e1b4cb8462dbf40efe9cf469254fd6bd5cc257e1` |
| `crdt/ticket.ts` | `70f8b71bac19b6f9039056570256ac41890f99fdc46da1675e91bd875aed8298` |
| `crdt/annotations.ts` | `cc2257ad38afdb18a803eedda7968af05ab2be434b8ccfd064b0b04c64f0cac3` |
| `crdt/key-index.ts` | `ff447129ce1d006ae1cb24430b21d448fbb41dc043098145b07a3bcee126a1dd` |
| `crdt/history.ts` | `d6e4efe3aa54bde4212f12b46e394aac2b898a690ccf95f7b85b806d4a08273b` |
| `engine/typescript-client.ts` | `dbfedab406844f1e79c4d77656787ae0c438e09212c84f30efc06ad109b0d421` |
| `client/index.ts` | `2c1d49322f2bf56d47b650b0917da647e87004c1028ef7d5ff3393ddb1b6290d` |
| `local/client.ts` | `44dea53c95da539adcf52fba406d42d8d1ef41b702d035d5f27ad46eab1e5964` |
| `sync/client.ts` | `738c490910374c8b2ab73dc808a5de7e4d66143ff4a66e717840eb4d8f900c8c` |
| `data/schema.ts` | `3462f7d365c8ab496cc1e99d8bcf6a3da05df8055d7ffd5ff08f2d675a752192` |

| Conclusion | Classification | Confidence |
| --- | --- | --- |
| Baseline has three pairs and four compiler passes in this fixture | Source and probe evidence | High |
| Fresh copy plus final original descriptors is insufficient | Executed counterexample | High |
| Compiler-only live staging cannot replace normalized engine preflight | Executed counterexample | High |
| A private factory with construction proof can be a solution component | Architecture inference; not implementation proof | Medium |
| Narrow before-read reordering can preserve all errors/state | Unresolved proof obligation | Unknown |
| Avoiding the stage meets whole-operation performance gates | Not measured | Unknown |

Root chooses the next implementation after this report. Until the construction and ordering proof is closed, keep the current stages and public APIs unchanged.
