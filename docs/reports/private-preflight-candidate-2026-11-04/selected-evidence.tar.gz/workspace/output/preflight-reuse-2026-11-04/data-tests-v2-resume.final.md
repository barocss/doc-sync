Disposition: HOLD_FUNCTIONAL_FAILURE

Independent Node v24.22.1 run: 90 baseline PASS, 90 candidate PASS, 90 full-output equivalence PASS. First failed gate: custom-schema mandatory legacy counts. Baseline compiler/snapshot/restore/live: 4/3/3/2. Candidate: 3/2/2/2. No observed public output or error difference. Scope ambiguity for an exact clone of the default schema awaits independent High interpretation. The gate is unchanged.

16 positive count scenarios reduce 3 pairs to 2 and 4 compiler entries to 3, with 2 live snapshots. Mandatory normal Data reductions: 9/9. Source, harness, protocol and producer were stable. Production 69 files are byte-identical to archive. Candidate 70 files JSON digest before/after: fd49e2f3c695cfa40b3c16c28a72624158becb71a3788bf7d1bd6223c70a5862.

Report: data-tests-v2-resume.report.md
Report SHA-256: 751bd3b8f63bcc84d38aa4f09fdd19d328d6ef5b42db44dc721f483cc4b2aaec
Receipt: data-tests-v2/runs/2026-11-03T19-56-31-358Z/receipt.json
Receipt SHA-256: 20452cd10dfd5712a050572e159007180984e41d3a1e24455034a89fab2b749c

Performance harness preparation is complete. Four small baseline-only smoke/counts runs and CLI rejection controls PASS. Next-read root clone count is 1. Retained moves are 0/0/0 and 1/3/3. Timing: NOT_RUN. Independent tsc: NOT_RUN because functional qualification is HOLD. No production promotion, build, dist, package, browser, mobile, Git or release approval. Prior reports and evidence are preserved.
