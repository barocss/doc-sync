# Independent V2 clarified tests

Disposition: APPROVE_FUNCTIONAL_ONLY. Exact-source High safety approval remains a separate gate.

The new version passed **94 baseline executions, 94 candidate executions, 94 complete-output equivalence checks and all count gates**. First failure: none. Candidate-only TypeScript noEmit passed with exit 0. Timing was not run.

## Scope correction and preserved evidence

Before this execution, parent recorded `scope-clarification-v2.md` and adopted the explicit High interpretation in `data-review-v2.report.md`. The exact default fingerprint must be on the actual factory's validated, copied and deeply frozen output. Caller identity and external freezing confer no authority. An exact default clone passed through that factory remains eligible. A different schema fingerprint must use legacy staging. Direct public Doc construction/restore cannot mint authority.

The earlier `custom-schema` probe only cloned the default schema. Its initial legacy-count assertion failed. That HOLD receipt, runner, driver, resume report and final remain unchanged. This report does not relabel that run. New files `run-clarified.mjs` and `extra-clarified-child.mjs` implement the scope correction. The new run copies the parent clarification and checks it remains unchanged.

The actual custom fixture adds valid `entry.attrs.probe = {default: ''}` and asserts schemaVersion differs from default. Clone/raw/frozen-default fixtures assert fingerprint equality, factory output identity differs from input, and recursive engine schema freezing. Existing semantic output, error, history, escape and first-error oracles are unchanged.

Counts below are compiler entries / scalar snapshot copies / scalar restore copies / live snapshots:

| Scenario | Baseline | Candidate | Required gate |
|---|---|---|---|
| Altered custom schema | 4/3/3/2 | 4/3/3/2 | Exact legacy fallback PASS |
| Clone of default through factory | 4/3/3/2 | 3/2/2/2 | Exact reduction PASS |
| Raw default through factory | 4/3/3/2 | 3/2/2/2 | Exact reduction PASS |
| Externally frozen default through factory | 4/3/3/2 | 3/2/2/2 | Exact reduction PASS |
| Direct public Doc.fromSnapshot with raw default, then Doc.edit | 2/1/1/1 | 2/1/1/1 | Exact legacy work PASS |

The public restore negative is an explicit new case. Existing public-alias and public-register-alias cases also retain defensive copy/register isolation checks. The own TypeScript runner independently asserts the three new factory cases are REDUCED_PRIVATE_PAIR and both custom/public negative cases are LEGACY_FALLBACK before it can run. Thus unchanged fallback on a positive case cannot qualify.

All **19 positive count scenarios** reduce three snapshot/restore pairs to two and four compiler entries to three, with both live snapshots retained. The mandatory normal root/nested Map/List, authored Data and empty-sibling count remains **9/9**. This is count evidence; private-mode binding and invisible private state require the independent High review.

## Receipts and source identity

Functional receipt: `data-tests-v2/clarified-runs/2026-11-03T20-00-53-686Z/receipt.json`.

The exact 64 old controls and all 26 prior additions remain. Four explicit cases were added. Every baseline/candidate child runs one whole source tree in its own process. Before/after manifests retain source and JavaScript harness hashes. Raw stdout/stderr, protocol, producer and clarification inputs are preserved in the run directory. Harness, archive, live, candidate, protocol, producer and clarification stability all PASS. Production **69/69 files remain byte-identical to the frozen archive**.

- Archive JSON manifest SHA-256: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`.
- Candidate 70-file JSON manifest SHA-256, before/after: `fd49e2f3c695cfa40b3c16c28a72624158becb71a3788bf7d1bd6223c70a5862`.
- Producer's equivalent sorted-line closure: `d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab`.

TypeScript receipt: `data-tests-v2/clarified-typecheck-runs/2026-11-03T20-01-26-573Z/receipt.json`. Candidate PASS, exit 0; stdout/stderr empty. The check uses pinned Node v24.22.1 and repository TypeScript, includes only the candidate 70-file source closure, and inherits the exact repository base config: ES2022, NodeNext, strict, noEmit, allowImportingTsExtensions, verbatimModuleSyntax, erasableSyntaxOnly, skipLibCheck, node types and ES2022/DOM/DOM.Iterable libraries. Base config SHA-256: `e2309ff28fca2a4564a174c43671b08bae7c45687b8ed68f3afa71b14731ff6a`. Source matched the functional receipt and remained unchanged. Baseline tsc was not needed because candidate passed. This is source type checking, not package/build acceptance.

## Limits

The prior performance harness preparation remains available. No timing, candidate performance census, 2k/20k census, direct public Doc 100k control, custom-schema/structural fallback timing, heap, package, build, dist, browser, mobile, Git, release or production promotion was performed in this continuation. The bounded functional result does not replace full Core qualification or independent High safety review.

Writes were limited to new files under `data-tests-v2/**` and this clarified report/final. Candidate, production, protocol, old reports and old evidence were not edited. No agent was spawned.
