# V2 private Data preflight producer

Disposition: PROOF_READY

This is an output-only producer handoff. Independent execution and High review remain required. It is not production, performance, package, browser, mobile, or release approval. The prior worker stopped at model capacity. This worker resumed its actual implementation and preserved earlier evidence.

## Exact implementation

Candidate root: `candidate-v2/packages/doc-sync/src`. It contains the 69 copied Core files plus `crdt/private-data.ts`. Five copied modules differ: Doc, engine, KeyIndex, Placements, and Clock. No production source, real tests, documentation, package export, or benchmark was changed.

- The actual engine schema factory performs its existing schema-version validation, plain-JSON validation, copy, and recursive freeze. Its private WeakSet records only owned copies with the exact default Data schema fingerprint. External freezing does not grant authority. Public restore does not register a schema or Doc as trusted.
- Real engine and Doc allocation registries reject unknown, borrowed, Proxy, subclass, and changed-prototype receivers before inspecting foreign internals. The registries record allocation identity, not document validity.
- The original snapshot builder supplies a scoped certificate for its real fresh wrappers. Known Line/items-array identities, native array/default-species behavior, actual source Map/Clock/Placements allocations, primitive wrapper metadata, and host-cloned payloads are required. Unknown map/species/DTO routes make that invocation unsafe before callbacks receive its mapper. Returned foreign DTOs are not reflected over to gain authority.
- The defining KeyIndex, Placements, and Clock modules capture their own dispatch surfaces before importers can replace them. KeyIndex capture includes nested `find` and `join`. Doc checks these surfaces, Doc instance/static surfaces, empty sentinel instances/prototypes, actual Placement records Map, and ROOT own-data primitives. An accessor ROOT is rejected without a guard read of the accessor.
- The private helper selects restore, reads actor, calls source snapshot once, reads schema once, and invokes the selected restore once. The certificate is checked before restore receives its input. The restore retains all original admission checks and per-register defensive copies. If later eligibility fails, the same restored P executes the full old staged edit. The source sequence is not retried.
- A storage-only guard verifies fixed Data types, canonical token keys, ordinary clock/register bounds, canonical heads, collision-free implicit bodies, shallow physical Data topology, retained valid placements, the exact projected atom path, unique nonempty record IDs, and canonical old/new Data value metadata. References must name `$root` or a retained collection of the stated kind. Mixed metadata, uncertain states, invalid paths/values, and unsupported shapes use legacy staging.
- Only one copied `update` containing the ordinary `value` key can use the immediate operation. The scoped context is consumed once at P's `edit` entry and cleared in `finally`. It removes only P's inner atomic validation snapshot/restore/compiler. It keeps P's before-model read, compiler, emit/run/priors, `applyEdits` normalization, and after-model read. Both live snapshots and the live atomic validation stage remain. No P adoption, raw replay, rewind, rollback, public trust bit, or reusable token was added.
- New immutable membership arrays and the capture-free schema freeze helper are module scoped. Required per-operation state and closures retain their captures.

## Private construction and ordering argument

The authority boundary is the actual source builder plus original transitive construction dispatch. It is not an entry/exit descriptor comparison alone. A foreign map, species object, DTO iterator, or snapshot override cannot receive a positive builder certificate. The callback-capable source work finishes before the restore witness is decided. Certified wrappers contain only fresh native containers, primitive metadata, and host-cloned payloads. The original restore call graph then has no external callback that can retain P, an Item, a Line, a KeyIndex range, or a loader/owner closure. Defining-module surface checks include the transitive dispatch that prior counterexamples replaced. Unsafe observations cannot be erased by a self-restoring source override. No public restore result retains construction authority.

Let H be model/head/cache materialization, U the one ordinary value update, and V the removed inner validation on a separate clone. In the bounded shape, every materializable head is the canonical body head of a main-line Map/List and cannot collide with an existing token. H allocates no clock ticket, changes no visible type/parent/order, and has no callback or failure route after the guard. U changes no topology; its only operation gets `clock + 1` and targets the guarded existing entry. Head IDs use the reserved body actor, while U uses a guarded ordinary actor. Thus H cannot change U's path, ticket, target, prior value, or error. Fixed Data schemas have no text, fields, grouping, grid, cardinality, annotation, or type-change behavior. Original retained-placement projection is pure for this storage shape. Empty siblings are included, rather than excluded.

V changes only its own disposable clone. Both retained schedules still perform H, U, `applyEdits`, and the after-model read on P in their original order. The guard proves the compiler work formerly checked by V has one valid target and ordinary AttrSpec, valid new metadata, and one available ticket. Therefore moving past V introduces no earlier private model error and removes no relevant first compiler error. Unknown or invalid states keep V. No literal storage-neutrality claim is made: H can create empty collection heads and caches.

The source argument applies only to this bound. The tests below also compare actual private P graphs and priors on representative placed/no-move paths. They are not a proof of all JavaScript programs or all CRDT operations.

## Tests on final source bytes

Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`, version `v24.22.1`.

| Check | Result | Evidence boundary |
| --- | --- | --- |
| Paired public controls | 90 baseline PASS; 90 candidate PASS; 90 exact semantic comparisons PASS | Unchanged independent child drivers, executed by the owned resume orchestrator |
| Positive census | 16 scenarios reduce the private pair | Three pairs to two; four compiler entries to three; two live snapshots stay |
| Required negative census | PASS | `bad-value`, `bad-path`, `bad-meta`, `clock-overflow`, `bodyhead-collision` retain exact baseline compiler/snapshot/restore counts |
| Actual private P comparison | 6/6 PASS | Root/nested Map/List, authored placements or no-move restore, with empty Map/List siblings |
| Extra dispatch/error controls | 4/4 PASS | Non-callable map on public snapshot and engine apply; Line.items accessor trace; pre-Doc ROOT accessor trace |
| Candidate TypeScript | PASS, exit 0 | `node node_modules/typescript/bin/tsc -p output/preflight-reuse-2026-11-04/candidate-v2/tsconfig.json`; no emit/build |
| Production preservation | PASS | All 69 production files equal the frozen archive and initial inventory |
| Legacy candidate preservation | PASS for all 69 Core files | V1 copied Core still equals the archive |

The 90 cases use `proof-tests/child.mjs`, `legacy-child.mjs`, `projection-child.mjs`, and `data-tests-v2/extra-child.mjs` unchanged. The owned `candidate-v2/proof/resume-run.mjs` reuses their exact 64 + 26 inventory and applies their negative fallback count rule. No candidate prototype wrapper is used for positive counts. Source hooks enter the compiler and count live snapshots before original capture; the scalar structuredClone census counts copy events only.

The positive census includes stock; real root/nested Map/List created and no-move bulk fixtures; the one-entry normal fixtures with authored move counts 1/3/3; and created/bulk fixtures with empty Map/List siblings. Seven values per larger fixture include negative zero, Korean, emoji, boolean, null, and a shared collection reference. The independent bodies assert ops/tickets/priors, snapshots, clocks, versions, History, live Doc/Item/Line identity, notifications, undo/redo, foreign overwrite/delete, input-copy/guard behavior, sessions/checkpoint, public aliases, admission errors, and adversarial fallback traces. Only History grouping wall time is normalized.

The extra private test source-hooks the actual detached P at its completed `edit` return. It compares all enumerable storage and cache fields as a complete object graph, preserving aliases, plus actual ops, normalization and `priorOf` results. Capture happens only after the operation; it does not grant the implementation authority. WeakMaps are opaque. This Data shape creates no text-cache keys; restored placement application and the single set do not create movement-prior keys. Set priors are checked using the real emitted op. Thus this check has an explicit WeakMap observation limit.

Final paired receipt: `candidate-v2/proof/resume-runs/2026-11-03T19-53-10-823Z/receipt.json`.

Final private/edge receipt: `candidate-v2/proof/resume-detail-2026-11-03T19-53-35-964Z/receipt.json`.

Both receipts use candidate JSON-manifest digest `fd49e2f3c695cfa40b3c16c28a72624158becb71a3788bf7d1bd6223c70a5862` and confirm stable source during execution. Final `resume-source-final.json` binds that same source closure.

## Corrected attempts retained

All earlier logs remain. The resumed snapshot rewrite originally used Reflect.apply and could change the non-callable map TypeError; the final code retains literal `line.items.map(...)`. An early 90-case producer run compared semantic outputs but omitted the required negative count rule. It therefore missed optimized work on mixed old scalar/reference metadata. The final metadata gate and explicit negative census close that case. A candidate typecheck found an implicit `owner` type; an explicit `Item | null` annotation fixed it. The first extra private-state fixture incorrectly supplied a plain object to the public finite-scalar/shared-collection API; the baseline rejected it. The fixture now uses a valid scalar string. These attempts are not counted as final passes and were not deleted.

## Hashes and limits

Digest format for the source closures below: SHA-256 of ASCII-path-sorted UTF-8 `file_sha256 + two spaces + relative_path + LF` entries.

| Closure | Files | SHA-256 |
| --- | ---: | --- |
| Production = archive = initial Core | 69 | `8b532beb32d4ef0e7d69e54ac9a989d269d0c590e11d6ef8f3f0545b362c4a51` |
| Actual V2 candidate source | 70 | `d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab` |

| Changed candidate file | SHA-256 |
| --- | --- |
| `crdt/doc.ts` | `b3c58361a1ea38a35b50dd4da8e322052e03bb8c7b4879f7db2ebbdeb469273f` |
| `crdt/key-index.ts` | `da13a10c0201288e5bcc0be1d3824e5e37307c609ff353b7864859d94ac3ed6b` |
| `crdt/placement.ts` | `cde6bb0c52229d4c564425aab9f80efe49d56150a008df9e03692702047ac2a0` |
| `crdt/private-data.ts` | `b5cf84fdcbb96609a11d3f83a98c9d4ba10b4bc7214ee03216faaa33b3f33ad0` |
| `crdt/ticket.ts` | `86fdf09218f5b11de91b698b5bf0b4e5d66a6f677f430d1205f132aec8ce39d5` |
| `engine/typescript-client.ts` | `10083260d162ae0a7746ca12f0a6c1466700458019f599269ffb174abc61ceaa` |

Full file and runner/receipt hashes: `candidate-v2/proof/resume-source-final.json`.

Intrinsic/global replacement (including Map/Set/Array/Object and host structuredClone semantics) remains outside the contract. Exposed module prototypes and empty sentinels are checked; they are not assumed original. Only exact factory-owned default Data schemas and the guarded shallow point operation qualify. General schemas, unsupported operations, unusual state, and uncertain receivers remain on legacy staging. The broad prior production qualification is not rerun or enlarged here. No speed, heap, package, release, original MCP restart fix, browser, mobile, or production-promotion claim is made. No further agent, Git action, sibling search, or performance run was used. Parent controls independent qualification and any later phase.
