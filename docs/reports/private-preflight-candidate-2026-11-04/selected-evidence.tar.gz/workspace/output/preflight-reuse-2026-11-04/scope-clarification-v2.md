# Default-schema ownership clarification

Parent decision recorded before any V2 timing: 2026-11-03T20:00:02.809744+00:00.

The mandatory scope is an exact DEFAULT Data fingerprint on a schema that the
actual engine factory has validated, copied and recursively frozen itself.
Authority belongs to that owned output. It does not belong to a caller object,
its identity, or Object.isFrozen. The existing createDataSchema API has no
source-origin brand; a structurally identical clone does not become a different
schema. Adding a redundant source-origin brand is not justified here.

The old protocol table's statement that custom/raw/frozen schemas do not qualify
was imprecise. It means that arbitrary caller objects, even if frozen, cannot
serve as authority at the private boundary. An altered schema fingerprint stays
on the legacy route. A clone of the exact default schema that passes the same
actual factory copy/freeze/fingerprint path qualifies, just as its default input
does. No copies or validation are removed by this clarification. Direct public
Doc/raw snapshot input does not mint the private schema authority.

Independent High review reached this interpretation in data-review-v2.report.md.
The initial independent90-case receipt remains HOLD: its custom-schema fixture
only structuredClone'd the default schema. Exact outputs90/90 passed; its
mandated legacy count assertion failed. Do not erase or relabel that receipt.

Before any new qualification, retain clone-default as a separate positive
fixture and make the true custom-schema fixture actually alter a valid optional
AttrSpec (and verify its fingerprint differs). Keep exact legacy counts for that
altered schema. Add explicit external-freeze/factory-copy coverage. Record the
new harness hashes, exact candidate source hashes and all results separately.
This is a transparent correction of fixture classification BEFORE timing,
not a relaxation of any semantic-equivalence or actual custom-schema gate.

Frozen candidate source is unchanged:70-file closure
 d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab.
Old protocol, producer reports and failed receipts remain historical and intact.
This decision is not independent code approval, performance acceptance, library
promotion, or a resolution of the known intermittent MCP restart failure.
