# Private preflight construction/ordering proof attempt

## Decision: HOLD — concrete STOP before installing a stage-removal factory

No production change. No optimized factory was installed in the candidate. The candidate is an exact copy of the 69 current live Core files, with a local `type: module` package context. Both trees retain all three snapshot/restore pairs and all four compiler runs. **3→2 is NOT_PROVEN, not a reported success.**

This stop is not based on the absence of an existing private API. The new factory remains feasible in principle. Two executed obligations prevent treating construction provenance plus the proposed schema/input restriction as sufficient:

1. The proposed before-model read changes private storage even with the actual engine-owned Data schema and one ordinary-key atom update.
2. Even without authored moves, the immediate private operation invokes another defining module with a retained Doc-mutation closure. Capturing originals only in Doc/engine/KeyIndex/Clock cannot cover a preload that replaces that module before Doc imports it.

Rather than introduce a broad reflective surface registry or extend trust across more modules without a closed proof, this attempt retains the stages. It does not claim that all narrower alternatives are impossible.

## Ownership and execution boundary

Owned files: `candidate-src/**`, `protocol.md`, this report, `proof-implementation.final.md`, and the explicitly named `proof-implementation-*` runners, receipts, fixtures, manifests and logs created by this attempt. Existing prompt/event/stderr artifacts from the parent and all design/review files were not edited. In particular, the design lane's `final.md` was not overwritten.

Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`, v24.22.1, native strip-only; no execution flags. Each child imports exactly one whole Core tree. No mixed Doc/Item/Clock class realms. The smoke runner uses synchronous Node source hooks only for snapshot/restore/compiler counters and compiler-output copies. It does not instrument Doc.apply, replace public methods for those counts, or write instrumented source to either tree. The hostile controls intentionally replace public surfaces in their own child process.

NOT_RUN: real repository tests, docs/types checks, benchmarks, global build, dist/package generation, CPU timing, browser/mobile, commit, push, additional agents. No unrelated cleanup or process control. The parent's 2084 cases (2082 PASS / 2 SKIP), types/docs PASS, and unresolved original MCP second-restart diagnostic are supplied context, not rerun or changed here.

## 1. Ordering counterexample: schema shape does not make the before-read storage-neutral

Runner: `proof-implementation-ordering.mjs`. Receipts: `proof-implementation-ordering.{baseline,candidate}.json`.

Fixture: actual factory-owned/frozen `createDataSchema()`, one existing root entry and one empty sibling Map. No authored moves, text, groups, grids, fields, cardinality, or annotations. The copied edit is exactly one `update` with exactly one ordinary `value` key.

| Private state | Before `toJSON()` | After `toJSON()` |
| --- | --- | --- |
| Tokens | 3 | 4 |
| Lines | 1 | 2 |
| Clock | 2 | 2 |
| Version | 0 | 0 |
| Model cache present | false | true |
| Block-cache entries | 0 | 2 |
| Logical-cache entries | 0 | 2 |
| Placement projection cache present | false | true |

The added head is `0@2@ordering-proof/body`. `Doc.rawBlock` → `rawFlow` → `blocks` → `get` creates the empty Map body. Source: `crdt/doc.ts:395-433,1799-1815,2084-2088,2123-2127,2187-2188`. A semantic model read is not just a cache-free JSON read.

Compiling before versus after that read emits the same full set op in this fixture, but produces different immediate snapshots: only the model-first copy contains that body head. Later model reads converge both snapshots and JSON. This is **not** an observed compiler-result divergence; it is an executed refutation of the stronger tokens/lines-neutrality premise. Logical equivalence and all cache effects for every eligible state remain unproved.

The first probe incorrectly expected immediate snapshots to match. Its raw AssertionError, including the extra body line, is preserved in `proof-implementation-ordering.first-failure.stderr.log`. The corrected test explicitly asserts the difference; it does not silently convert it into a positive proof. A separate harness-authoring error (`SharedList.ids` does not exist) is preserved in `proof-implementation-smoke.first-failure.stderr.log`; the runner now uses `at(0).id`.

Any narrower eligibility would need to prove all relevant lazy heads already exist, without first changing the state under proof or probing foreign DTOs again. A deferred model error alone does not establish that storage/cache proof. No rollback/attribute rewind was attempted.

## 2. Defining-module counterexample outside a restore-only witness

Runner: `proof-implementation-projection-capability.mjs`.

1. Import only `crdt/placement.ts`.
2. Replace `Placements.prototype.project`, then import Doc and engine. This is a public/direct-module method replacement, not a standard global-intrinsic replacement.
3. Create the engine normally. Its actual schema factory owns and freezes Data's schema.
4. Restore a fresh private-copy abstraction, with no authored moves. Compile one ordinary `value` update.
5. The override receives `ownerOf`, retains it, restores the original project method, and calls the original implementation.
6. After the compiler returns, all selected project identities are original again. Calling the retained closure with the empty sibling's body key changes that private copy from 3 tokens / 1 line to 4 tokens / 2 lines. Its clock stays 3. The source stays unchanged.

`Doc.placementProjection` passes `line => this.get(line)?.line.owner?.key ?? null` at `crdt/doc.ts:1770`. This is a mutation capability, even though it normally returns only a string. Graphic projection is active before the first authored move (`1693`).

**Concrete construction boundary:** a loader-only witness can be valid when restoration ends and still become invalid during the immediately following model/compiler read. A defining-module capture made in Doc or engine is already late for this preload. Closing this route requires a defining-module original/provenance check in Placement as well, or declining it with a correctly rooted proof. Restricting authored moves does not remove this dispatch. This attempt did not enlarge the allowed few-file construction into a transitive reflective trust architecture.

This test uses an explicitly labeled test-local unstaged abstraction. It is not an installed candidate factory and is not a claim that a proper local dispatch audit cannot reject this route.

## 3. Construction dispatch and retained loader capability

Runner: `proof-implementation-construction.mjs`.

- A restore-time ItemJSON Proxy arms a self-restoring **KeyIndex.find**, while **KeyIndex.set stays original throughout**. The nested dispatch exposes P's index. A one-key update at clock exhaustion rejects and leaves the exposed value 1. An outer-set equality check cannot establish no exposure. This test does not claim a clock-failure differential.
- A Proxy item-array `forEach` retains the actual restoration callback. It also arms the self-restoring nested find to observe the restored line. On the matched late-path failure, legacy staging leaves exposed P at value 1; the test-local unstaged abstraction leaves it at 2. Both leave live at 1 and report the same path error.
- Re-entering the retained loader callback after rejection pushes an Item into P's retained Line **before** duplicate-token validation throws. Its line grows from 2 to 3 Items. This is asserted through the exposed private index, not inferred from final method descriptors.

Thus any common restorer must mark unsafe before a foreign selected iteration callback receives its loader closure, and before the nested index dispatch receives private references. Monotonic unsafe state must survive self-restoration. No end descriptor scan, allocation WeakSet, or public Doc flag was substituted for that requirement here.

## 4. Small controls and actual Data eligibility

`proof-implementation-receipt.json`: **10 runner cases**, each in separate baseline and candidate child processes, exit 0 with matching results. The `controls` case includes the nine inherited small probe groups, adapted into an owned whole-tree runner. This is a baseline-copy control result, not optimized qualification.

Covered:

- C1 transient setter/Doc.check exposure; one-op multi-key late rejection.
- Retained loader closure and indirect KeyIndex dispatch above.
- Array constructor/species callback control.
- Defining-module model and Clock preload; invalid-path compiler error before model sentinel; valid-path exact model sentinel; exact clock sentinel.
- Selected restore getter before actor, source snapshot receiver, one source-schema read in the outer clone sequence, then selected restore call. Both live source-snapshot observations remain.
- Engine input getter rejection with **zero getter reads**; **one structuredClone of the original valid input** before the guard; guard mutation cannot alter the admitted payload.
- Normalized applyEdits-only rejection before live mutation; exact guard sentinel; accepted guard wrappers; transparent/borrowed receivers and matched trap traces.
- `priorOf` versus raw apply control.
- Actual Client/Data root, nested Map and List point updates: full forward ops/tickets, snapshots and History snapshot; undo/redo values and snapshots; reopen; same live Doc/Line/Item identities.

Only History group's numeric wall-clock `at` fields are normalized in cross-process comparisons. Ticket fields, attribute data, paths, operations, models and snapshots are not normalized. Fixtures are captured once with the real Data facade and reopened identically in each child.

| Actual Data fixture | Retained authored moves before point update | Snapshot/restore pairs | Compiler runs |
| --- | --- | --- | --- |
| Root Map | 1 | 3 | 4 |
| Nested Map | 3 | 3 | 4 |
| List | 3 | 3 | 4 |

**Eligibility consequence:** a first proof that excludes existing placements excludes all three actual facade fixtures here, including root Map after its normal initial insertion. It must not be advertised as universal normal Data eligibility. A hand-seeded no-move legacy fixture is only a narrower fixture. Supporting actual facade updates requires proving the retained-placement restore and projection paths too; those validations were not removed.

Not separately qualified: full selective undo with foreign writes, sessions, synchronization/conditional intent, notifications under all callbacks, schema upgrades, custom engine factories, recovery beyond local reopen, every C2 species/line-mutation variant. Production source is unchanged; this is not new broad integration evidence.

## 5. Private API/proof disposition

The proposed operation remains conceptual and is recorded in `protocol.md`: an engine-private immediate `preflightOwnedPoint(sourceDoc, copiedEdits): void`, closed over actual factory-owned schema provenance. It selects public restoration in legacy order, restores once with a local construction audit, and either performs the complete private normalized preflight or calls the unchanged staged edit on that same restored copy. It never returns a Doc, ops, witness, or reusable authority to public callbacks. Public fromSnapshot always retains legacy admission/copies.

Not implemented: schema provenance minting, common-restorer factoring, complete actual-dispatch audit, defining-module original captures, safe compiler-before-model deferral, and stage removal. No hidden public argument, capability flag, barrel export, registrar, staged-Doc adoption, prepared-op replay, or output dependency was added.

Reason to stop: the executed state-neutrality premise fails; the private-operation callback boundary extends into Placement even for no moves; and excluding placements would miss every ordinary Data fixture measured by this smoke. A correct next candidate needs a revised, explicitly bounded eligibility and a transitive dispatch proof, not a boolean trust assertion. Reflection cost has **not been measured**. High reflective cost is a concern, not a performance result.

## 6. Hashable checkpoint

- Exact inventory: **69 live Core files**, no extra source files, all SHA-256 values unchanged from the initial checkpoint. Candidate's corresponding 69 files are also unchanged.
- Initial per-file hashes: `proof-implementation-source-initial.json`.
- Final per-file live/candidate comparisons: `proof-implementation-source-final.json`.
- Core tree digest: `326c2a8955c9122e127619c771a9c0334e1b062e08c0dff36694c854e8e90dd7`.
- Digest algorithm: SHA-256 of UTF-8 `JSON.stringify(Object.entries(hashes).sort(([a],[b]) => a.localeCompare(b)))`.
- Runner/report/receipt hashes: `proof-implementation-artifacts.sha256.json`. The artifact manifest excludes itself and the parent's inherited process artifacts.

Reproduce the bounded controls with Node 24:

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/proof-implementation-run.mjs
```

The setup runner refuses to overwrite an existing candidate checkpoint. Do not rerun setup to discard WIP. No promotion, release, speedup, or 3→2 claim is approved.
