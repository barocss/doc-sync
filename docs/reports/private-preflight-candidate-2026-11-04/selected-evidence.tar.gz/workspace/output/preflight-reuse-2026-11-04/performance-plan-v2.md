# Prospective V2 private-preflight performance gate

Recorded before any V2 timing, 2026-11-03T19:49:20.223838+00:00.

This plan does not approve the producer or authorize timing before independent
functional equivalence and exact-source High proof approval. Production remains
unchanged. If proof fails, timings are NOT_RUN, not a missing performance pass.

## Scope

Use pinned Node 24.22.1 in separate single-source child processes. Baseline is
the qualified post-refactor archive, not HEAD. Candidate is the independently
reviewed stable output-only source. Record all source and harness hashes before
and after each process. No source hooks or prototype/structuredClone counters in
timed runs. Run copy-count censuses separately. Preserve previous attempts.

Measure complete public setter, first following public point read and their
sum for root Map, nested Map and List, with 2,000 and 20,000 total stored entries.
Include both bulk no-move fixtures and bounded real authored placement fixtures.
Seed, warmup, assertions, snapshots, serialization and independent model/History
oracles stay outside timers. Retained COW is absent: next-read root-clone count
remains one in both lanes. Positive proof census must separately establish
three-to-two private snapshot/restore pairs and four-to-three compiler entries,
with both live snapshots unchanged.

## Run order and acceptance

Three prospective cycles, each A-B-B-A for every selected fixture/size. Keep the
same five measured samples and two warmups per process; compare pooled lane
medians within each cycle. Stop at the first mandatory failure. Do not repeat a
failed cycle until it passes, pool it away, or relabel the baseline. Later cycles
then remain NOT_RUN. Report every process and exact first failed cell.

For EVERY cycle and each root/nested/list fixture at 20k, complete setter plus
first read must improve by at least 5%. Every main setter must regress by no
more than 3%; every 2k complete total must regress by no more than 3%. These are
conjunctive gates; a fast point-read cell alone does not establish usefulness.

Run independent direct public Doc local/remote 100k text controls, plus legacy
custom-schema and structural/fallback controls. Maximum median regression is
3%, with a predeclared 0.25 ms absolute allowance only for sub-millisecond
control cells. No such allowance applies to main Data cells. No full test,
build, writer, review or browser run may overlap timing. Preserve other users'
processes; record host load and do not claim an idle or causally isolated host.

## Limits and follow-through

No retained-heap, network, Chrome end-to-end or Rust/WASM claim follows from Node
medians. Any retained registries require a separate memory check before promotion.
A useful output-only result is still not library acceptance. Production promotion
requires focused/full/type/package checks and desktop Chrome regression after
source integration. A failed safety/performance gate keeps qualified source.
