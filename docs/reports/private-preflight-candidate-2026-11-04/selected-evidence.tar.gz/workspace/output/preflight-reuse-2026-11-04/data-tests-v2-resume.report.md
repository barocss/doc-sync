# Independent V2 resume — output only

Disposition: HOLD_FUNCTIONAL_FAILURE

The actual producer terminal `data-proof-v2-resume.final.md` was PROOF_READY before execution. The independent run used pinned Node v24.22.1 and separate whole-source child processes. It passed **90 baseline executions, 90 candidate executions, and 90 full-output equivalence checks**. One mandatory fallback count gate failed: `custom-schema`. This is a count/scope failure; no observed public output or error differed.

Receipt: `data-tests-v2/runs/2026-11-03T19-56-31-358Z/receipt.json`. Raw stdout/stderr, before/after source and harness hashes, protocol and producer inputs remain in the same run directory. Earlier reports and runs are preserved.

The probe in `data-tests-v2/extra-child.mjs` uses `schema = structuredClone(createDataSchema())`, then `factory.create(actor, schema)`, creates one entry and updates its ordinary value. The expected legacy fallback counts are compiler **4**, scalar snapshot **3**, scalar restore **3**, live snapshot **2**. Actual candidate counts are **3 / 2 / 2 / 2**. The runner now applies the protocol's custom-schema fallback count rule to this existing probe. It does not change its fixture or output oracle. The gate was added before candidate execution and was not relaxed after failure. Parent and producer received the exact failure immediately.

Normal root Map, nested Map and List, plus the authored Data and empty-sibling controls, supply **9 mandatory positive scenario reductions**. All 16 count-bearing positive scenarios reduce private snapshot/restore pairs **3 to 2**, compiler entries **4 to 3**, while retaining **2 live snapshots**. This count evidence does not identify the removed pair without separate exact-source High review.

All run stability checks passed: harness, archive, live source, candidate source, protocol and terminal producer. Live production has **69 files, byte-identical to the archive**. Candidate has 70 source files. Archive JSON manifest digest: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`. Candidate before and after: `fd49e2f3c695cfa40b3c16c28a72624158becb71a3788bf7d1bd6223c70a5862`.

Independent TypeScript check: **NOT_RUN**, because its required functional qualification is HOLD. `data-tests-v2/typecheck.mjs` is prepared to inherit exact repository compiler flags, check only the selected whole source with noEmit, bind hashes to the accepted functional receipt, and run archive control only if candidate fails. Native strip-only functional execution does not prove TypeScript acceptance.

## Performance harness preparation

Owned `performance-driver.mjs`, `performance-cli-tests.mjs` and `performance-README.md` derive from the existing source-only Data benchmark. No production or repository benchmark source was edited. The driver freezes parsed options, refuses overwrite, pins Node, bounds imports to the selected source closure, and checks source/driver hashes. The linear bulk fixture has bounded public placement setup. It verifies retained move counts **0/0/0** or **1/3/3**, with setup outside intervals. Base and authored fixture hashes are recorded separately and must match between source lanes.

Accepted baseline-only CLI controls: `data-tests-v2/performance-cli-runs/2026-11-03T19-50-51-993Z`. Four 20-entry smoke/counts processes passed for both fixture modes, with next-read root clone **1**, setter root clone **0**, full model/arrays/checkpoint/History/undo-redo/foreign-write/deletion oracles, overwrite refusal, and five invalid-option controls. Smoke/counts never read performance.now. An initial oracle error used Doc.items instead of all snapshot Lines; it was corrected before accepted CLI controls. The earlier standalone smoke result is preserved but has an older driver hash.

Timing, 2k/20k counts, candidate performance smoke/counts, direct public Doc 100k controls, custom-schema/structural fallback timing, heap checks, build/dist/package/browser/mobile/Git/release: **NOT_RUN**. The README supplies commands for later serial count censuses. Root's preregistered performance plan was read. Timing requires functional qualification plus exact-source High approval and must not overlap other work.

Ownership: only `data-tests-v2/**` and new resume report/final are writable by this worker. Production, candidate, protocol, old reports, V1 and repository tests/docs/benchmarks were not edited. No agent was spawned.
