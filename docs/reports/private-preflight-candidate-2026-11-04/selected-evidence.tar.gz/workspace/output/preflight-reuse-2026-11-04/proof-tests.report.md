# Independent proof tests — output only

## Decision: HOLD — optimized private qualification PENDING

The test driver and baseline oracles are ready. The producer has now issued **HOLD** and did not install an optimized private factory. `protocol.md` and `proof-implementation.final.md` confirm that disposition. There is no concrete private helper or internal observation protocol to qualify. Therefore no candidate GREEN, construction witness, normalization-order proof, eligibility claim, or performance claim is issued. Two new ordering/capability counterexamples were independently reproduced by this test lane.

No blind wait was used. The lane built and ran the baseline suite, preserved failed attempts, and reports the absent optimized producer as a blocker. Run the driver again after the producer supplies its actual private protocol and final source. Do not turn unchanged candidate files into a positive proof.

## Evidence boundary

| Category | Result | Meaning |
| --- | --- | --- |
| CONTRACT | PARTIAL / candidate PENDING | Public oracles cover the listed cases. Private producer authority and the full design section 7 remain open. |
| CODE | baseline PASS; candidate NOT_REVIEWED | 69 live Core files match the frozen archive. No production edits. No private algorithm was invented by this lane. |
| FUNCTIONAL | baseline 64 PASS / 0 FAIL / 0 SKIP | 64 isolated process scenarios. Two scenarios reuse the supplied multi-probe files. This is not 64 independent private-witness proofs and not the normal Core suite. |
| CANDIDATE | PENDING / 0 executions | `--candidate` was requested, but the readiness gate did not pass. |
| PERFORMANCE | NOT_RUN | Clone and compiler counts only. No timing, heap, allocation-size, or speed result. |
| Full suite/build/browser/mobile/remote | NOT_RUN | No root test dependency, build, browser, mobile, commit, or push. |

Node: `/Users/user/.nvm/versions/node/v24.22.1/bin/node`, exact `v24.22.1`. No runtime feature or skip flags. Native Node strip-only execution.

## Reproduce

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/proof-tests/run.mjs --candidate
```

The readiness check requires the producer's terminal `PROOF_READY` receipt and a protocol that is neither `IN_PROGRESS` nor `HOLD`. This is a scheduling gate, not proof of the implementation. Even after that gate, the driver cannot issue full private qualification: `candidateQualification` remains `NOT_YET_PRIVATE_WITNESS_QUALIFIED` until the missing private protocol tests and independent review are supplied.

Latest accepted baseline run:

- `proof-tests/runs/2026-11-03T19-03-49-118Z/receipt.json`
- `proof-tests/latest-run.json`
- Live Core: **69 files**; archive comparison **69/69 identical**.
- Baseline manifest digest: `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271`.
- Candidate full-tree manifest before/after: `99378f0edb272bb3a8e0b147e8e6aa2102eb023cdb899f7dbd87f366c20b97fb`. This includes the candidate package context; it is not evidence that a private producer exists.
- Live source, archive, candidate tree, driver, and protocol were stable during this run.

Each run has before/end SHA-256 manifests and separate stdout/stderr for every process. Results are not reusable if the selected Core/helper tree changes during execution. The driver records all candidate files, not only changed Doc/engine files. No imported baseline and candidate classes share a realm.

## Positive fixtures and independent oracles

The default factory and public `Client.data` setters are imported from one selected complete Core tree per child. Public fixtures use N=20. They cover root Map, nested Map, and List, with both:

1. Normal public creation, including actual placement records.
2. Public state capture and restore with empty movement records. The restored public collection is explicitly checked before updates; it is not an artificial raw one-entry seed presented as normal public creation.

Each fixture updates one existing entry through `attrs.value`: finite scalar, `-0`, Hangul, emoji, boolean, null, and a same-client collection reference. The public read is checked against the caller's value. The stored `-0` is serialized with an explicit negative-zero marker for cross-process comparisons. Legacy History serializes values through JSON and redo changes `-0` to `0`; this baseline behavior is explicit in the oracle, not a candidate relaxation.

The suite records full returned ops and tickets, `priorOf`, snapshots, clock/version, default History snapshots, notification sequence, and live Doc/Item/Line identities. It performs undo/redo after each update. Foreign overwrite followed by undo/redo must retain the foreign value; a later foreign delete must remain deleted. Only History group wall-clock timestamps are normalized to zero. No CRDT clocks, tickets, operation payloads, or notification metadata are normalized away.

UUID generation is deterministic only during fixture setup. The original UUID function is restored before qualification updates. No Doc, engine, KeyIndex, or restore method wrapper is installed in positive count cases. The public Client edit wrapper records actual returned ops only.

### Structural counts, separate from timing

A source-load hook increments a counter at the actual `compileEdits` entry. Another increments the original snapshot body for the exact live Doc. These do not change the public method descriptors. The global `structuredClone` census classifies scalar payload copies by actual `itemToJSON` / `itemFromJSON` call stacks. It does not wrap `Doc.prototype.snapshot`, `Doc.fromSnapshot`, `Doc.edit`, or `Doc.emit` and therefore does not disable original-surface eligibility by those wrappers.

Verified baseline formula:

| Fixture | Snapshot scalar payload copies | Restore scalar payload copies | Compiler entries | Live snapshot calls |
| --- | ---: | ---: | ---: | ---: |
| One-entry engine update | 3 | 3 | 4 | 2 |
| N=20 first public update, each of six public fixtures | 60 | 60 | 4 | 2 |

The source call graph from the supplied design explains the three pairs: engine outer preflight, preflight Doc atomic stage, live Doc atomic stage. The count hook confirms it. Other scalar clones are recorded separately and are not mislabelled snapshot/restore work.

Candidate count gates accept only exact removal of one pair and one compiler, with both live snapshots retained, or an exact legacy-count fallback. A future real positive must show actual reduction on public Data fixtures. A synthetic one-entry reduction alone does not qualify it. `realDataReduced` is currently **0**, because no candidate ran. A fallback result alone is not success.

## Negative and fallback cases exercised on baseline

- Reuses the exact supplied `baseline-probe.mjs` and the owned-snapshot C1/C2 probe via a whole-tree import resolver. No rewrite of their expected results.
- Source own `items.map`, own map getter, throwing map getter, throwing constructor, native map species returning retained Array or Proxy.
- Earlier source map getter changes the later Line's map; full trace and resulting storage are recorded.
- Transient KeyIndex setter armed by ItemJSON `i` access, then self-restored before return: two-op bad path and one-op multi-key late unknown attribute. Both reject with escaped preflight value exactly **1**, unchanged live state, and original setter restored.
- Public Doc.check self-restoring construction escape from the supplied baseline probe, including exposed clock.
- Proxy iteration retains the actual loader closure while exposing a restored Item; rejected late path leaves the exposed value at 1. Re-entering that closure pushes another Item into the exposed private Line before duplicate-ID rejection, while live remains unchanged. It is a public fallback counterexample, not private witness instrumentation.
- A self-restoring source snapshot callback arms the same escape. Final source method equality does not make it eligible.
- Invalid-path compiler error wins over the model-read sentinel. The normalization-only `Node missing is not allowed in data` error precedes all live changes.
- Guard sentinel identity and no snapshot before the first rejecting guard. Clock exhaustion preserves the live snapshot/version/clock.
- Original input structured clone exactly once; original batch mutation in the live guard does not change the owned edit; accessor-valued attrs rejected with zero getter invocations.
- Engine Proxy, borrowed engine, engine subclass-like receiver, Doc Proxy, borrowed Doc, and Doc subclass. Full traces are retained, not only success booleans.
- SyncClient with an observable custom factory/engine Proxy. Method receivers and full get/call trace are checked.
- Original defining Doc/Clock modules loaded before engine/Client: snapshot/restore valid, invalid, throwing, getter overrides; Clock.next valid, throwing, getter overrides. Exact local sentinel identity is checked before serializable comparison.
- Restore selection/actor/snapshot-get/snapshot-call/schema/restore ordering. A source snapshot replaces static restore after the outer selection; the already selected outer restore must construct before the new inner-stage restore throws.
- Public `fromSnapshot` restores twice with foreign aliases: source/restore/live separation and per-register alias separation remain independent.
- JSON getter, duplicate token, missing head, capability, format, invalid span, register identity, invalid movement validation reject.
- Out-of-shape input controls: empty batch, two keys, two operations, reserved/unknown key, insert, delete.
- Session begin/apply/collect/cancel, then publish, and checkpoint prepare/install. Accepted guard restoration and prior ownership are also covered by the supplied baseline probe.

All negative cases have an asserted baseline result. They are not written as “pass or throw either accepted.” Error identity is checked with a local sentinel where applicable; process comparison uses serializable traces and state. Candidate fallback counts and traces must remain baseline-equivalent.

## Independent STOP evidence added after producer HOLD

These tests use the real factory-owned Data schema, one ordinary `value` key, no authored moves, and a sibling empty Map. They do not call an invented private helper.

- **`lazy-head-ordering` PASS:** a model read on the restored public abstraction adds one token and one Line without changing its clock/version. Compiling before versus after the model read produces equal ops but unequal immediate snapshots. Later model reads converge. Thus this is a storage-ordering counterexample, not an observed emitted-op divergence. The proposed storage-neutrality premise does not hold for the stated shape restriction.
- **`projection-preload` PASS:** import only the defining Placement module; override `Placements.project`; then import Doc/engine. The override receives and retains the real `ownerOf` closure and restores itself. After compilation, invoking that closure creates a private body head, adding one token/Line with unchanged clock/version and unchanged source. No-move eligibility and final method equality are insufficient to close this transitive callback capability.

Both raw process receipts and observations are in the latest run. These independent results support HOLD; they do not prove that every possible narrower implementation is impossible.

## Open obligations — do not promote

1. **No optimized private helper was installed; producer is HOLD.** No private construction witness, selected-dispatch audit, owned-schema provenance, non-forgeability, or single-use authority was observed. No generic external token recorder substitutes for it.
2. **No candidate execution or equivalence yet.** Stable unchanged copied files do not prove a new producer. Eligibility of placed vs no-move public fixtures is PENDING.
3. **Normalization-order proof is not closed.** The independent lazy-head test refutes storage neutrality, and the Placement preload demonstrates a retained mutation capability. Public error/state oracles alone do not close these private obligations.
4. Full design section 7 is broader than this bounded driver: schema preview/upgrade, all recovery/reopen permutations, conditional intent installation, all sessions failure points, additional reserved storage/head rules, custom raw schemas, and every field/movement clock bound still require dedicated coverage or valid supplied receipts. The default/public paths tested here are not approval of those untested paths.
5. The source hooks require their exact anchor strings. If the producer changes those declarations, update instrumentation against the actual source and retain the failed run. Do not silently omit counters.
6. Root and independent High review gates remain required. No production or performance approval follows from this report.

## Preserved failed attempts

All attempted runs remain under `proof-tests/runs/`; no failed log was deleted. Initial setup errors included treating undo's caret return as a boolean, expecting JSON-backed History redo to preserve negative zero, looking for nested Items only on the main Line, using the wrong session method name, and placing a function directly on a JSON array (correctly rejected by snapshot admission). One early malformed span fixture used an unbounded span and hit a runtime Set limit; it was replaced with immediate invalid span 0. These are test-author corrections, not candidate regressions or hidden accepted failures. The final bounded suite is 64/64 baseline PASS.

Ownership honored: only `proof-tests/**`, this report, and `proof-tests.final.md` were written. Other WIP and the producer's files were not changed. No agents were spawned.
