import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
const base=join(import.meta.dirname,'candidate-v2/packages/doc-sync/src');
async function edit(path,fn){const p=join(base,path);await writeFile(p,fn(await readFile(p,'utf8')));}
await edit('crdt/key-index.ts',s=>'import {captureSurface} from "./private-data.ts";\n'+s+'\n// Defining-module capture includes transitive private find/join dispatch.\nexport const originalKeyIndexSurface = captureSurface(KeyIndex.prototype);\n');
await edit('crdt/ticket.ts',s=>'import {captureSurface} from "./private-data.ts";\n'+s+'\nexport const originalClockSurface = captureSurface(Clock.prototype);\n');
await edit('crdt/placement.ts',s=>'import {captureSurface} from "./private-data.ts";\n'+s+'\nexport const originalPlacementSurface = captureSurface(Placements.prototype);\n');
await edit('engine/typescript-client.ts',s=>{
 s=s.replace('import {Doc, MAIN}', 'import {captureSurface, ownEngineSchema} from "../crdt/private-data.ts";\nimport {preflightOwnedDataPoint} from "../crdt/doc.ts";\nimport {Doc, MAIN}');
 const a=s.indexOf('/** Own public factory input once;'),b=s.indexOf('\nconst replaceAll',a);
 s=s.slice(0,a)+'const ownSchema = ownEngineSchema;\nconst realEngines = new WeakSet<object>();\n'+s.slice(b);
 s=s.replace('this.definition = ownSchema(schema); this.doc = new Doc(actor, this.definition);','this.definition = ownSchema(schema); this.doc = new Doc(actor, this.definition);\n        if (new.target === TypeScriptClientEngine) realEngines.add(this);');
 s=s.replace('if (!this.fastText(doc, input) && !this.fastStructure(doc, input)) this.clone(doc).edit(input, {normalize: true});','if (!this.fastText(doc, input) && !this.fastStructure(doc, input)) {\n                if (dataEngineReceiver(this) && preflightOwnedDataPoint(doc, input, () => this.actor)) return;\n                this.clone(doc).edit(input, {normalize: true});\n            }');
 const i=s.indexOf('export const typescriptClientEngineFactory:');
 s=s.slice(0,i)+`const originalEngineSurface = captureSurface(TypeScriptClientEngine.prototype);
function dataEngineReceiver(value: object): boolean {
    if (!realEngines.has(value) || Object.getPrototypeOf(value) !== TypeScriptClientEngine.prototype || !originalEngineSurface()) return false;
    for (const key of Reflect.ownKeys(TypeScriptClientEngine.prototype)) if (Object.hasOwn(value, key)) return false;
    const actor = Object.getOwnPropertyDescriptor(value, "actor");
    return !!actor && "value" in actor && typeof actor.value === "string";
}
`+s.slice(i);
 return s;
});
