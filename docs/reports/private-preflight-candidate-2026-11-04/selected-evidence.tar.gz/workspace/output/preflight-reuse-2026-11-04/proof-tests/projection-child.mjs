import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {actor,ticket,root,update} from './fixtures.mjs';
assert.equal(process.version,'v24.22.1');
const [tree]=process.argv.slice(2),base=pathToFileURL(resolve(tree)+'/').href,load=p=>import(base+p);
// Import this defining module before any class that can capture it.
const {Placements}=await load('crdt/placement.ts'),original=Placements.prototype.project;let closure,dispatches=0;
Placements.prototype.project=function(records,ownerOf,gaps){dispatches++;closure=ownerOf;Placements.prototype.project=original;return original.call(this,records,ownerOf,gaps);};
const {Doc}=await load('crdt/doc.ts'),{compileEdits}=await load('crdt/edit.ts'),{createDataSchema}=await load('data/schema.ts'),{typescriptClientEngineFactory:factory}=await load('engine/typescript-client.ts');
const e=factory.create(actor,createDataSchema()),source=e.typescriptDocument();
source.apply({t:'node',id:ticket(1),origin:root,type:'entry',attrs:{id:'data:entry',key:'proof',value:{scalar:1}}});
source.apply({t:'node',id:ticket(2),origin:ticket(1),type:'map',attrs:{id:'data:empty'}});
const beforeSource=source.snapshot(),p=Doc.fromSnapshot(actor,beforeSource,source.schema);
assert.equal(p.hasMoves,false);assert.equal(dispatches,0);
// Explicit public unstaged abstraction. This is NOT a candidate producer.
compileEdits(p,[update(2)]);assert.equal(dispatches,1);assert.equal(Placements.prototype.project,original);assert.equal(typeof closure,'function');
const measure=()=>({tokens:p.storedTokenCount(),snapshot:p.snapshot(),clock:p.clock.lamport,version:p.version});
const before=measure(),owner=closure(`0@2@${actor}/body`),after=measure();
assert.equal(owner,`2@${actor}`);assert.equal(after.tokens,before.tokens+1);assert.equal(after.snapshot.lines.length,before.snapshot.lines.length+1);assert.equal(after.clock,before.clock);assert.equal(after.version,before.version);assert.deepEqual(source.snapshot(),beforeSource);
console.log(JSON.stringify({scenario:'projection-preload',observation:{scope:'unstaged public abstraction; not a private optimized factory',dispatches,owner,before,after,sourceUnchanged:true,originalRestored:true}}));
