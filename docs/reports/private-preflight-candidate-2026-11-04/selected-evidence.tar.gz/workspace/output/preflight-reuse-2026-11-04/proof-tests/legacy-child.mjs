import {registerHooks} from 'node:module';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
assert.equal(process.version,'v24.22.1');
const [tree,which]=process.argv.slice(2),url=pathToFileURL(resolve(tree)+'/').href;
const path=which==='legacy-preflight'?resolve(import.meta.dirname,'../baseline-probe.mjs'):resolve(import.meta.dirname,'../../owned-snapshot-2026-11-04/baseline-probe.mjs');
const entry=pathToFileURL(path).href;
// Reuse the exact provided probes. Resolve all Core imports to one selected
// whole tree; never import both trees into this realm.
registerHooks({resolve(specifier,context,next){if(context.parentURL===entry&&specifier.startsWith('../../packages/doc-sync/src/'))return next(url+specifier.slice('../../packages/doc-sync/src/'.length),context);return next(specifier,context);}});
await import(entry);
