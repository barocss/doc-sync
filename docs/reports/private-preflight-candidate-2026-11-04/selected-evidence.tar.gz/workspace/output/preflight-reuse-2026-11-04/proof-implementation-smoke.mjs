import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {registerHooks} from 'node:module';
const core=resolve(process.env.DOC_SYNC_CORE_ROOT),base=pathToFileURL(`${core}/`).href;
const counts={snapshot:0,restore:0,compiler:0};globalThis.__proofImplementationCounters=counts;
const compilerOps=[];globalThis.__proofImplementationCompilerOps=compilerOps;
registerHooks({load(url,context,next){const result=next(url,context);if(!url.startsWith(base))return result;
 let source=typeof result.source==='string'?result.source:result.source?.toString();if(!source)return result;
 const patterns=url===`${base}crdt/doc.ts`?[
  ['    snapshot(): Snapshot {','    snapshot(): Snapshot {\n        globalThis.__proofImplementationCounters.snapshot++;'],
  ['    static fromSnapshot(actor: string, snapshot: Snapshot, schema: Schema | null = null): Doc {','    static fromSnapshot(actor: string, snapshot: Snapshot, schema: Schema | null = null): Doc {\n        globalThis.__proofImplementationCounters.restore++;']
 ]:url===`${base}crdt/edit.ts`?[
  ['export const compileEdits = (doc: Doc, ops: EditOp[]): Op[] => {','export const compileEdits = (doc: Doc, ops: EditOp[]): Op[] => {\n    globalThis.__proofImplementationCounters.compiler++;'],
  ['    return compiler.out;', '    globalThis.__proofImplementationCompilerOps.push(structuredClone(compiler.out));\n    return compiler.out;']
 ]:[];
 for(const [from,to]of patterns){assert.equal(source.split(from).length,2,`unique source hook ${from}`);source=source.replace(from,to);}return {...result,source};}});
const load=p=>import(`${base}${p}`);
const {Client,clientOwner}=await load('client/index.ts');
const {createDataSchema}=await load('data/schema.ts');
const fixturePath=resolve(import.meta.dirname,'proof-implementation-data-fixtures.json');
if(process.argv.includes('--fixtures')){
 const fixtures=[];
 for(const kind of ['root','nested','list']){
  const c=new Client({actor:`smoke-${kind}`,schema:createDataSchema()});let target;
  if(kind==='root'){target=c.data.root;target.set('point',1);}
  else if(kind==='nested'){target=c.data.createMap();c.data.root.set('nested',target);target.set('point',1);}
  else {target=c.data.createList();c.data.root.set('list',target);target.insert(0,1);}
  c.clearHistory();fixtures.push({kind,state:c.captureState()});c.dispose();
 }
 await writeFile(fixturePath,JSON.stringify(fixtures,null,2)+'\n');console.log(JSON.stringify({fixtures:fixtures.length,source:core}));
}else{
 const results=[];
 for(const fixture of JSON.parse(await readFile(fixturePath,'utf8'))){
  const c=Client.fromState(fixture.state,{schema:createDataSchema()}),owner=clientOwner(c),e=owner.engine,d=e.typescriptDocument();
  const target=fixture.kind==='root'?c.data.root:c.data.root.get(fixture.kind==='nested'?'nested':'list');
  // Settle the facade's ordinary read work before the point update under count.
  const before=c.snapshot(),doc=d,items=d.lines().flatMap(l=>l.items),lines=d.lines();
  const initialHistory=c.historyStatus();Object.keys(counts).forEach(k=>counts[k]=0);compilerOps.length=0;
  if(fixture.kind==='list')target.set(target.at(0).id,2);else target.set('point',2);
  const updateCounts={...counts},ops=structuredClone(compilerOps.at(-1));assert.equal(ops.length,1);assert.deepEqual(updateCounts,{snapshot:3,restore:3,compiler:4});
  assert.equal(e.typescriptDocument(),doc);assert.equal(d.lines().length,lines.length);assert.ok(d.lines().every((line,i)=>line===lines[i]));assert.ok(items.every(item=>d.get(item.key)===item));
  const after=c.snapshot(),model=c.model(),history=e.typescriptHistory().snapshot();
  const value=()=>fixture.kind==='list'?target.get(target.at(0).id):target.get('point');assert.equal(value(),2);
  const undo=c.undo();assert.equal(value(),1);const undoSnapshot=c.snapshot();
  const redo=c.redo();assert.equal(value(),2);const redoSnapshot=c.snapshot();
  const reopened=Client.fromState(c.captureState(),{schema:createDataSchema()});assert.deepEqual(reopened.snapshot(),redoSnapshot);assert.deepEqual(reopened.model(),c.model());
  const moves=before.moves?.length??0;
  results.push({kind:fixture.kind,ops,counts:updateCounts,proposedPairReduction:false,actualDataCreateHasMoves:moves>0,moves,initialHistory,after,model,history,undo,undoSnapshot,redo,redoSnapshot,liveIdentitiesPreserved:true,reopen:true});
  reopened.dispose();c.dispose();
 }
 console.log(JSON.stringify({node:process.version,core,status:'CONTROL_PASS; unchanged candidate, not optimized proof',results},null,2));
}
