import {registerHooks} from 'node:module';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {actor,ticket,root,update,rejection,errorRecord,seed,value,state,stableHistory,deterministicIds} from './fixtures.mjs';
assert.equal(process.version,'v24.22.1','Node 24 pin');
const [tree,scenario]=process.argv.slice(2),treeURL=pathToFileURL(resolve(tree)+'/').href;
// Only compiler entry is source-instrumented. No Doc/Clock/restore surface wrapper
// is installed in positive count cases. Entire dependency graph stays in one tree.
globalThis.__proofCompilerCount=0;
let compilerHooks=0;
globalThis.__proofLiveSnapshots=0;
registerHooks({load(url,context,next){const result=next(url,context);if(url===treeURL+'crdt/edit.ts'){
 const source=String(result.source),needle='export const compileEdits = (doc: Doc, ops: EditOp[]): Op[] => {';
 assert.equal(source.split(needle).length,2,'compiler source hook anchor');compilerHooks++;
 return {...result,source:source.replace(needle,needle+'\n globalThis.__proofCompilerCount++;')};
}if(url===treeURL+'crdt/doc.ts'){const source=String(result.source),needle='    snapshot(): Snapshot {';assert.equal(source.split(needle).length,2,'snapshot hook anchor');return {...result,source:source.replace(needle,needle+'\n if(this===globalThis.__proofLiveDoc)globalThis.__proofLiveSnapshots++;')};}return result;}});
const load=path=>import(treeURL+path);
const {Doc}=await load('crdt/doc.ts');
const {KeyIndex}=await load('crdt/key-index.ts');
const {Clock}=await load('crdt/ticket.ts');
const {createDataSchema}=await load('data/schema.ts');
let factory,Client,clientOwner;
const result={scenario};
const trace=[];
// R4: overrides are installed AFTER defining-module import, BEFORE engine/Client.
let preloadCleanup=()=>{};
if(scenario.startsWith('preload:')){
 const mode=scenario.slice(8),sentinel={local:'R4'},name=mode.startsWith('restore')?'fromSnapshot':mode.startsWith('clock')?'next':'snapshot';
 const target=name==='fromSnapshot'?Doc:name==='next'?Clock.prototype:Doc.prototype;
 const desc=Object.getOwnPropertyDescriptor(target,name);
 const original=desc.value;
 if(mode.endsWith('getter'))Object.defineProperty(target,name,{configurable:true,get(){trace.push('get '+name);return function(...args){trace.push('call '+name);return original.apply(this,args);};}});
 else Object.defineProperty(target,name,{...desc,value:function(...args){trace.push('call '+name);if(mode.endsWith('throw'))throw sentinel;if(mode.endsWith('invalid')&&name==='snapshot')return {lamport:-1,lines:[]};if(mode.endsWith('invalid')&&name==='fromSnapshot')return null;return original.apply(this,args);}});
 preloadCleanup=()=>Object.defineProperty(target,name,desc);
 result.preloadSentinel=sentinel;
}
({typescriptClientEngineFactory:factory}=await load('engine/typescript-client.ts'));
({Client,clientOwner}=await load('client/index.ts'));
function census(fn){const clone=globalThis.structuredClone;let scalars=0,snapshotScalars=0,restoreScalars=0;const before=globalThis.__proofCompilerCount,liveBefore=globalThis.__proofLiveSnapshots;
 globalThis.structuredClone=function(v,...args){if(v&&typeof v==='object'&&Object.hasOwn(v,'scalar')){scalars++;const stack=new Error().stack;if(stack.includes('at itemToJSON '))snapshotScalars++;if(stack.includes('at itemFromJSON '))restoreScalars++;}return clone(v,...args);};
 try{const output=fn();return {output,scalarCopies:scalars,compilerCalls:globalThis.__proofCompilerCount-before,snapshotScalars,restoreScalars,liveSnapshots:globalThis.__proofLiveSnapshots-liveBefore};}finally{globalThis.structuredClone=clone;}}
function runSeed(fn){const s=seed(factory,createDataSchema);return fn(s);}
if(scenario==='stock-count'){
 result.observation=runSeed(({e,d})=>{globalThis.__proofLiveDoc=d;const before=state(d),item=d.get(`1@${actor}`),line=item.line;const count=census(()=>e.apply([update(2)],{normalize:true}));assert.equal(value(d),2);assert.equal(d.get(item.key),item);assert.equal(item.line,line);return {before,after:state(d),ops:count.output,prior:d.priorOf(count.output[0]),scalarCopies:count.scalarCopies,compilerCalls:count.compilerCalls,snapshotScalars:count.snapshotScalars,restoreScalars:count.restoreScalars,liveSnapshots:count.liveSnapshots};});
}else if(scenario.startsWith('data:')){
 const [,kind,construction]=scenario.split(':'),restoreIds=deterministicIds();
 let c,map,list,id,target;
 try{
  c=new Client({actor,schema:createDataSchema()});const data=c.data;map=kind==='root'?data.root:data.createMap();list=kind==='list'?data.createList():null;
  if(kind==='nested')data.root.set('nested',map);if(list)data.root.set('list',list);
  for(let n=0;n<20;n++)if(list){const next=list.push(n);if(n===0)id=next;}else map.set(n===0?'proof':`k${n}`,n);
  target=data.createMap();
 }finally{restoreIds();}
 if(construction==='bulk'){
  // Restore the real public-created snapshot without movement records. This is
  // not assumed model-equivalent: assert the public target remains addressable.
  const captured=c.captureState();captured.engine.document.moves=[];
  c=Client.fromState(captured,{schema:createDataSchema()});const data=c.data;
  map=kind==='root'?data.root:data.getMap(map.id);list=list?data.getList(list.id):null;target=data.getMap(target.id);
 }
 const backend=clientOwner(c),e=backend.engine,d=e.typescriptDocument(),live=d,items=d.snapshot().lines.flatMap(l=>d.get(l.key).line.items),lines=items.map(i=>i.line);
 const read=()=>list?list.get(id):map.get('proof');const set=v=>list?list.set(id,v):map.set('proof',v);
 assert.equal(read(),0);c.clearHistory();
 let lastOps;const originalEdit=c.edit;c.edit=function(...args){lastOps=originalEdit.apply(this,args);return lastOps;};
 const notifications=[];const stop=c.subscribe({modelEvents(edits,info){notifications.push({phase:'model',edits,info});},update(){notifications.push({phase:'update'});}});
 globalThis.__proofLiveDoc=d;const trials=[];
 for(const next of [2,-0,'한글','🙂',true,null,target]){
  const before=c.snapshot(),priorValue=read();const count=census(()=>set(next));assert.equal(read(),next);
  assert.equal(e.typescriptDocument(),live);items.forEach((item,n)=>{assert.equal(d.get(item.key),item);assert.equal(item.line,lines[n]);});
  trials.push({ops:lastOps,priors:lastOps.map(op=>op.t==='set'?d.priorOf(op):null),value:next===target?{reference:target.id}:Object.is(next,-0)?'-0':next,snapshot:c.snapshot(),clock:d.clock.lamport,version:d.version,history:stableHistory(e.typescriptHistory()),compilerCalls:count.compilerCalls,scalarCopies:count.scalarCopies,snapshotScalars:count.snapshotScalars,restoreScalars:count.restoreScalars,liveSnapshots:count.liveSnapshots});
  assert.notEqual(c.undo(),null);assert.equal(read(),priorValue);assert.notEqual(c.redo(),null);assert.equal(read(),Object.is(next,-0)?0:next);
 }
 const currentItem=items.find(i=>i.attrs.get('id')?.value===(list?id:map.candidates('proof').at(-1).id));assert.ok(currentItem);
 const foreign={t:'set',at:ticket(d.clock.lamport+100,'foreign'),ids:[currentItem.id],key:'value',value:{scalar:'foreign'}};e.receive('foreign',[foreign]);
 c.undo();assert.equal(read(),'foreign');c.redo();assert.equal(read(),'foreign');
 const deletion={t:'del',at:ticket(d.clock.lamport+1,'foreign'),ids:[currentItem.id]};e.receive('foreign',[deletion]);c.undo();c.redo();assert.equal(read(),undefined);
 stop();result.observation={kind,construction,hasMoves:d.hasMoves,trialCount:trials.length,trials,notifications,foreignFinal:state(d),history:stableHistory(e.typescriptHistory()),identity:true};
}else if(scenario==='input-copy'){
 result.observation=runSeed(({e,d})=>{const edits=[update(2)],clone=globalThis.structuredClone;let clones=0,guards=0,seen;globalThis.structuredClone=function(v,...args){if(v===edits)clones++;return clone(v,...args);};e.setEditHooks({guard(){guards++;edits[0].attrs.value.scalar=999;},listener(input){seen=input;}});try{e.apply(edits);assert.equal(clones,1);assert.equal(value(d),2);assert.notEqual(seen,edits);}finally{globalThis.structuredClone=clone;}let reads=0;const attrs={};Object.defineProperty(attrs,'value',{enumerable:true,get(){reads++;return {scalar:3};}});const error=rejection(()=>e.apply([{op:'update',at:[0],attrs}]));assert.equal(reads,0);return {clones,guards,reads,error:errorRecord(error),value:value(d),detached:seen!==edits};});
}else if(scenario.startsWith('escape:')){
 const mode=scenario.slice(7);result.observation=runSeed(({e,d})=>{const items=d.snapshot().lines[0].items,original=KeyIndex.prototype.set;let armed=false,exposed;
 items[1]=new Proxy(items[1],{get(t,p,r){if(p==='i'&&!armed){armed=true;KeyIndex.prototype.set=function(k,item){const output=original.call(this,k,item);if(k===`1@${actor}`){exposed=item;KeyIndex.prototype.set=original;}return output;};}return Reflect.get(t,p,r);}});
 Object.defineProperty(d.items,'map',{configurable:true,value(){trace.push('source-map');return items;}});
 const input=mode==='two'?[update(2),update(3,[99])]:[{op:'update',at:[0],attrs:{value:{scalar:2},unknown:true}}];const before=state(d);let error;
 try{error=rejection(()=>e.apply(input,{normalize:true}));assert.ok(exposed);assert.equal(exposed.attrs.get('value').value.scalar,1);assert.equal(KeyIndex.prototype.set,original);assert.deepEqual(state(d),before);return {error:errorRecord(error),exposedValue:exposed.attrs.get('value').value.scalar,before,after:state(d),trace};}finally{KeyIndex.prototype.set=original;}});
}else if(scenario==='model-order'){
 result.observation=runSeed(({e,d})=>{const original=Doc.prototype.toJSON,sentinel={local:'beforeModel'};Doc.prototype.toJSON=function(){trace.push('model');throw sentinel;};try{const error=rejection(()=>e.apply([update(2,[99])],{normalize:true}));assert.notEqual(error,sentinel);assert.equal(value(d),1);return {error:errorRecord(error),sentinelWon:false,trace,state:state(d)};}finally{Doc.prototype.toJSON=original;}});
}else if(scenario==='normalization-error'){
 result.observation=runSeed(({e,d})=>{const before=state(d),error=rejection(()=>e.apply([{op:'update',at:[0],attrs:{key:'changed',type:'missing'}}],{normalize:true}));assert.equal(error.message,'Node missing is not allowed in data');assert.deepEqual(state(d),before);return {error:errorRecord(error),before,after:state(d)};});
}else if(scenario==='guard-first'||scenario==='clock-exhaustion'){
 result.observation=runSeed(({e,d})=>{const sentinel={local:'readonly'},original=d.snapshot;let snapshots=0;d.snapshot=function(){snapshots++;return original.call(this);};if(scenario==='guard-first')d.editGuard=()=>{throw sentinel;};else d.clock.lamport=Number.MAX_SAFE_INTEGER;const before=state(d);snapshots=0;const error=rejection(()=>e.apply([update(2)]));if(scenario==='guard-first'){assert.equal(error,sentinel);assert.equal(snapshots,0);}assert.deepEqual(state(d),before);return {error:errorRecord(error),sameSentinel:error===sentinel,snapshots:snapshots-1,before,after:state(d)};});
}else if(scenario.startsWith('receiver:')){
 const mode=scenario.slice(9);result.observation=runSeed(({e,d})=>{let receiver=e;if(mode==='engine-proxy')receiver=new Proxy(e,{get(t,p,r){trace.push(String(p));return Reflect.get(t,p,r);}});if(mode==='engine-borrowed')receiver=Object.create(e);if(mode==='engine-subclass')receiver=Object.assign(Object.create(Object.create(Object.getPrototypeOf(e))),e);
 if(mode==='doc-proxy'){const proxy=new Proxy(d,{get(t,p,r){trace.push(String(p));return Reflect.get(t,p,r);}});Doc.prototype.edit.call(proxy,[update(2)]);}else if(mode==='doc-subclass'){class Sub extends Doc{};Object.setPrototypeOf(d,Sub.prototype);e.apply([update(2)]);}else if(mode==='doc-borrowed'){const receiver=Object.create(d);Doc.prototype.edit.call(receiver,[update(2)]);}else e.apply.call(receiver,[update(2)]);
 assert.equal(value(d),2);return {trace,state:state(d)};});
}else if(scenario.startsWith('source:')){
 const mode=scenario.slice(7);result.observation=runSeed(({e,d})=>{const retained=d.snapshot().lines[0].items,sentinel={local:mode};let escaped;
 if(mode==='map')Object.defineProperty(d.items,'map',{value(){trace.push('map');return retained;}});
 if(mode==='map-getter')Object.defineProperty(d.items,'map',{get(){trace.push('get map');return function(){trace.push('map');return retained;};}});
 if(mode==='map-throw')Object.defineProperty(d.items,'map',{get(){trace.push('get map');throw sentinel;}});
 if(mode==='constructor-throw')Object.defineProperty(d.items,'constructor',{get(){trace.push('constructor');throw sentinel;}});
 if(mode==='species-array'||mode==='species-proxy')Object.defineProperty(d.items,'constructor',{value:{get [Symbol.species](){trace.push('species');return function(n){escaped=new Array(n);if(mode==='species-proxy')escaped=new Proxy(escaped,{defineProperty(t,p,desc){trace.push('define '+String(p));return Reflect.defineProperty(t,p,desc);}});return escaped;};}}});
 let ops,error;try{ops=e.apply([update(2)]);}catch(err){error=err;}
 if(mode.endsWith('throw')){assert.equal(error,sentinel);assert.equal(value(d),1);}else {if(error)throw error;assert.equal(value(d),2);if(escaped)assert.ok(escaped.length>0);}
 return {trace,error:error?errorRecord(error):null,sameSentinel:error===sentinel,value:value(d),ops,escapedLength:escaped?.length};});
}else if(scenario==='public-alias'){
 result.observation=runSeed(({d})=>{const snapshot=d.snapshot(),entry=snapshot.lines[0].items[1],shared=entry.a.find(([k])=>k==='value')[1];entry.a.push(['other',shared,`1@${actor}`]);const a=Doc.fromSnapshot(actor,snapshot,d.schema),b=Doc.fromSnapshot(actor,snapshot,d.schema),get=x=>x.get(`1@${actor}`).attrs;assert.notEqual(get(a).get('value').value,get(a).get('other').value);assert.notEqual(get(a).get('value').value,shared);assert.notEqual(get(a).get('value').value,get(b).get('value').value);shared.scalar=90;get(a).get('other').value.scalar=80;assert.equal(value(a),1);assert.equal(value(b),1);assert.equal(value(d),1);return {a:a.snapshot(),b:b.snapshot(),live:d.snapshot(),detached:true,registersSeparate:true};});
}else if(scenario==='clone-selected-once'){
 result.observation=runSeed(({e,d})=>{const originalRestore=Doc.fromSnapshot,originalSnapshot=d.snapshot,sentinel={local:'replacement must not run'};let reads=0;const before=originalSnapshot.call(d);
 Object.defineProperty(d,'snapshot',{configurable:true,get(){reads++;trace.push('get snapshot');return function(){trace.push('call snapshot');Doc.fromSnapshot=function(){trace.push('replacement restore');throw sentinel;};return originalSnapshot.call(this);};}});
 // The outer restore was selected before source.snapshot replaced the static.
 // Its inner staged restore selects the replacement and must throw that exact
 // sentinel; selecting replacement early would omit the first real restore.
 const originalSet=KeyIndex.prototype.set;KeyIndex.prototype.set=function(...args){trace.push('restore insertion');return originalSet.apply(this,args);};let error;
 try{error=rejection(()=>e.apply([update(2)]));assert.equal(error,sentinel);assert.equal(reads,1);assert.ok(trace.indexOf('restore insertion')<trace.indexOf('replacement restore'));assert.equal(value(d),1);return {trace,reads,sameSentinel:true,value:value(d),unchanged:JSON.stringify(originalSnapshot.call(d))===JSON.stringify(before)};}finally{Doc.fromSnapshot=originalRestore;KeyIndex.prototype.set=originalSet;}});
}else if(scenario==='self-restore-snapshot'){
 result.observation=runSeed(({e,d})=>{const original=Doc.prototype.snapshot,originalSet=KeyIndex.prototype.set;let captured;d.snapshot=function(){trace.push('custom snapshot');delete this.snapshot;const items=original.call(this).lines[0].items;items[1]=new Proxy(items[1],{get(t,p,r){if(p==='i')KeyIndex.prototype.set=function(k,item){const result=originalSet.call(this,k,item);if(k===`1@${actor}`){captured=item;KeyIndex.prototype.set=originalSet;}return result;};return Reflect.get(t,p,r);}});const snap=original.call(this);snap.lines[0].items=items;return snap;};
 try{const error=rejection(()=>e.apply([update(2),update(3,[99])]));assert.ok(captured);assert.equal(d.snapshot,original);assert.equal(captured.attrs.get('value').value.scalar,1);assert.equal(value(d),1);return {trace,error:errorRecord(error),exposedValue:1,live:state(d)};}finally{KeyIndex.prototype.set=originalSet;}});
}else if(scenario==='clone-order'){
 result.observation=runSeed(({e,d})=>{const original=Doc.fromSnapshot,restoreDesc=Object.getOwnPropertyDescriptor(Doc,'fromSnapshot'),snapshot=d.snapshot(),schema=d.schema;
 Object.defineProperty(Doc,'fromSnapshot',{configurable:true,get(){trace.push('select restore');return function(...args){trace.push('restore');return original.apply(this,args);};}});
 Object.defineProperty(e,'actor',{get(){trace.push('actor');return actor;}});
 Object.defineProperty(d,'snapshot',{get(){trace.push('get snapshot');return function(){assert.equal(this,d);trace.push('call snapshot');return snapshot;};}});
 Object.defineProperty(d,'schema',{get(){trace.push('schema');return schema;}});
 try{e.apply([update(2)]);const start=trace.indexOf('select restore');assert.deepEqual(trace.slice(start,start+6),['select restore','actor','get snapshot','call snapshot','schema','restore']);return {trace,value:value(d)};}finally{Object.defineProperty(Doc,'fromSnapshot',restoreDesc);}});
}else if(scenario.startsWith('preload:')){
 // Seeding a raw node uses Clock.observe but not next. Clear setup trace.
 const {e,d}=seed(factory,createDataSchema);trace.length=0;let ops,error;try{ops=e.apply([update(2)]);}catch(err){error=err;}
 const mode=scenario.slice(8),sentinel=result.preloadSentinel;if(mode.endsWith('throw'))assert.equal(error,sentinel);else if(mode.endsWith('invalid'))assert.ok(error);else {if(error)throw error;assert.equal(value(d),2);}
 result.observation={trace,error:error?errorRecord(error):null,sameSentinel:error===sentinel,value:value(d),ops};delete result.preloadSentinel;preloadCleanup();
}else if(scenario==='retained-iteration'){
 result.observation=runSeed(({e,d})=>{const snapshot=d.snapshot(),items=snapshot.lines[0].items;let captured,retainedCallback,retainedReceiver;
 const proxyItems=new Proxy(items,{get(t,p,r){if(p==='forEach')return function(callback,thisArg){trace.push('forEach');retainedCallback=callback;retainedReceiver=thisArg;return Array.prototype.forEach.call(this,(item,n)=>{callback.call(thisArg,item,n,this);});};return Reflect.get(t,p,r);}});
 Object.defineProperty(d.items,'map',{value(){return proxyItems;}});
 // A custom DTO iteration can retain the loader closure. It must never mint
 // private authority, even when its function restores itself before returning.
 const original=KeyIndex.prototype.set;items[1]=new Proxy(items[1],{get(t,p,r){if(p==='i')KeyIndex.prototype.set=function(k,item){const out=original.call(this,k,item);if(k===`1@${actor}`){captured=item;KeyIndex.prototype.set=original;}return out;};return Reflect.get(t,p,r);}});
 try{const error=rejection(()=>e.apply([update(2),update(3,[99])],{normalize:true}));assert.ok(retainedCallback);assert.ok(captured);assert.equal(captured.attrs.get('value').value.scalar,1);assert.equal(value(d),1);const retainedLine=captured.line,priorLength=retainedLine.items.length;const reentry=rejection(()=>retainedCallback.call(retainedReceiver,items[1],1,proxyItems));assert.equal(reentry.message,'Duplicate snapshot token identity');assert.equal(retainedLine.items.length,priorLength+1);assert.equal(value(d),1);return {trace,error:errorRecord(error),exposedValue:captured.attrs.get('value').value.scalar,retainedClosure:true,reentry:errorRecord(reentry),retainedLineGrowth:1,live:state(d)};}finally{KeyIndex.prototype.set=original;}});
}else if(scenario==='earlier-later-line'){
 const e=factory.create(actor,createDataSchema()),d=e.typescriptDocument();e.apply([{op:'insert',at:[0],content:[{type:'map',attrs:{id:'data:00000000-0000-4000-8000-000000000001'},children:[{type:'entry',attrs:{id:'data:00000000-0000-4000-8000-000000000002',key:'proof',value:{scalar:1}}}]}]}]);
 const snapshots=d.snapshot(),later=d.get(snapshots.lines[1].key).line,first=d.items,originalMap=Array.prototype.map;let retained;
 Object.defineProperty(first,'map',{get(){trace.push('first map getter');Object.defineProperty(later.items,'map',{configurable:true,value(...args){trace.push('later map');retained=originalMap.apply(this,args);return retained;}});return originalMap;}});
 const ops=e.apply([update(2,[0,0])]);assert.ok(retained);const target=d.get(ops[0].ids[0].lamport+'@'+actor);assert.equal(target.attrs.get('value').value.scalar,2);result.observation={trace,ops,snapshot:d.snapshot(),retained:true};
}else if(scenario.startsWith('fallback:')){
 const mode=scenario.slice(9);result.observation=runSeed(({e,d})=>{const input=mode==='empty'?[]:mode==='multi-key'?[{op:'update',at:[0],attrs:{key:'next',value:{scalar:2}}}]:mode==='two-op'?[update(2),update(3)]:mode==='reserved'?[{op:'update',at:[0],attrs:{$type:'entry'}}]:mode==='unknown'?[{op:'update',at:[0],attrs:{unknown:true}}]:mode==='delete'?[{op:'delete',at:[0],count:1}]:[{op:'insert',at:[1],content:[{type:'entry',attrs:{id:'data:00000000-0000-4000-8000-000000000002',key:'other',value:{scalar:2}}}]}];let ops,error;const count=census(()=>{try{ops=e.apply(input,{normalize:true});}catch(err){error=err;}});if(mode==='unknown'||mode==='reserved')assert.ok(error);return {ops,error:error?errorRecord(error):null,state:state(d),compilerCalls:count.compilerCalls,snapshotScalars:count.snapshotScalars,restoreScalars:count.restoreScalars};});
}else if(scenario.startsWith('admission:')){
 const mode=scenario.slice(10);result.observation=runSeed(({d})=>{const snapshot=d.snapshot(),entry=snapshot.lines[0].items[1];let expected;
 if(mode==='json-getter'){let reads=0;Object.defineProperty(snapshot,'lamport',{enumerable:true,get(){reads++;throw new Error('must not invoke');}});const error=rejection(()=>Doc.fromSnapshot(actor,snapshot,d.schema));assert.equal(reads,0);return {error:errorRecord(error),reads};}
 if(mode==='duplicate-id')snapshot.lines[0].items.push({...entry,i:`1@${actor}`});
 if(mode==='missing-head')snapshot.lines[0].items.shift();
 if(mode==='capability')snapshot.capabilities.push('invented');
 if(mode==='format')snapshot.format=99;
 if(mode==='span')entry.s=0;
 if(mode==='register')entry.a[0][2]=`-1@${actor}`;
 if(mode==='move')snapshot.moves.push({t:'move',at:ticket(2),target:ticket(99),parent:root,after:null});
 const error=rejection(()=>Doc.fromSnapshot(actor,snapshot,d.schema));return {error:errorRecord(error),live:state(d)};});
}else if(scenario==='custom-factory'){
 const {SyncClient}=await load('sync/client.ts');const listeners=new Set(),transport={subscribe(fn){listeners.add(fn);return ()=>listeners.delete(fn);},send(){},sendPresence(){}};
 const custom={...factory,create(...args){trace.push('factory create');const engine=factory.create(...args);return new Proxy(engine,{get(t,p,r){trace.push('get '+String(p));const value=Reflect.get(t,p,r);return typeof value==='function'?function(...a){assert.equal(this,r);trace.push('call '+String(p));return value.apply(t,a);}:value;}});}};
 const client=new SyncClient(actor,transport,{schema:createDataSchema(),engineFactory:custom}),e=client.engine,d=e.typescriptDocument();d.apply({t:'node',id:ticket(1),origin:root,type:'entry',attrs:{id:'data:00000000-0000-4000-8000-000000000001',key:'proof',value:{scalar:1}}});trace.length=0;const ops=e.apply([update(2)]);assert.equal(value(d),2);result.observation={trace,ops,state:state(d)};
}else if(scenario==='lazy-head-ordering'){
 result.observation=runSeed(({e,d})=>{d.apply({t:'node',id:ticket(2),origin:ticket(1),type:'map',attrs:{id:'data:empty'}});const snapshot=d.snapshot(),a=Doc.fromSnapshot(actor,snapshot,d.schema),b=Doc.fromSnapshot(actor,snapshot,d.schema),measure=x=>({tokens:x.storedTokenCount(),snapshot:x.snapshot(),clock:x.clock.lamport,version:x.version});const before=measure(a);a.toJSON();const after=measure(a);assert.equal(after.tokens,before.tokens+1);assert.equal(after.snapshot.lines.length,before.snapshot.lines.length+1);assert.equal(after.clock,before.clock);assert.equal(after.version,before.version);return load('crdt/edit.ts').then(({compileEdits})=>{const readFirst=compileEdits(a,[update(2)]),compileFirst=compileEdits(b,[update(2)]);assert.deepEqual(readFirst,compileFirst);assert.notDeepEqual(a.snapshot(),b.snapshot());const immediate={readFirst:a.snapshot(),compileFirst:b.snapshot()};a.toJSON();b.toJSON();assert.deepEqual(a.snapshot(),b.snapshot());return {scope:'ordering counterexample, not candidate private proof',before,after,ops:readFirst,immediate,converged:true};});});
}else if(scenario==='sessions-checkpoint'){
 result.observation=runSeed(({e,d})=>{const session=e.createSession(),initial=state(d);session.begin();let ops=session.apply([update(2)]);session.collect(ops);assert.equal(value(d),1);session.cancel();assert.equal(value(d),1);session.begin();ops=session.apply([update(3)]);session.collect(ops);const published=session.publish();assert.equal(value(d),3);const checkpoint=e.checkpoint(),copy=factory.create(actor,createDataSchema());copy.installCheckpoint(copy.prepareCheckpoint(checkpoint));assert.deepEqual(copy.snapshot(),e.snapshot());return {initial,ops:published.ops,after:state(d),checkpoint};});
}else throw new Error('Unknown scenario '+scenario);
if(result.observation instanceof Promise)result.observation=await result.observation;
assert.equal(compilerHooks,1);console.log(JSON.stringify(result,(_,v)=>Object.is(v,-0)?{$negativeZero:true}:v));
