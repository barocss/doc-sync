import {spawnSync} from 'node:child_process';
import {writeFileSync,mkdirSync,readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,join,relative} from 'node:path';
import assert from 'node:assert/strict';
assert.equal(process.version,'v24.22.1');
const out=resolve(import.meta.dirname,'../..'),proof=import.meta.dirname;
const repo=resolve(out,'../..'),archive=join(repo,'output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src');
const candidate=join(out,'candidate-v2/packages/doc-sync/src');
const hash=x=>createHash('sha256').update(x).digest('hex');
function manifest(tree){const entries={};function walk(p){for(const e of readdirSync(p,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const q=join(p,e.name);if(e.isDirectory())walk(q);else entries[relative(tree,q)]=hash(readFileSync(q));}}walk(tree);return entries;}
const dir=join(proof,'resume-detail-'+new Date().toISOString().replaceAll(/[:.]/g,'-'));mkdirSync(dir);
const before={candidate:manifest(candidate),archive:manifest(archive)};
const rows=[];
for(const [name,args] of [...['root','nested','list'].flatMap(k=>['created','bulk'].map(c=>['private',[k,c]])),...['noncallable-snapshot','noncallable-apply','items-accessor','root-accessor'].map(x=>['edge',[x]])]){
 const row={name,args};
 for(const [label,tree] of [['baseline',archive],['candidate',candidate]]){
  const r=spawnSync(process.execPath,[join(proof,'resume-'+name+'-child.mjs'),tree,...args],{encoding:'utf8',timeout:30000,maxBuffer:32*1024*1024});
  writeFileSync(join(dir,label+'-'+name+'-'+args.join('-')+'.stdout.json'),r.stdout??'');
  writeFileSync(join(dir,label+'-'+name+'-'+args.join('-')+'.stderr.log'),r.stderr??'');
  row[label]={exit:r.status};if(r.status===0)row[label].result=JSON.parse(r.stdout.trim());else row[label].stderr=r.stderr;
 }
 try{assert.equal(row.baseline.exit,0);assert.equal(row.candidate.exit,0);assert.deepEqual(row.candidate.result,row.baseline.result);row.status='PASS';}catch(e){row.status='FAIL';row.error=String(e);}
 rows.push(row);
}
const after={candidate:manifest(candidate),archive:manifest(archive)};
const summary={dir,node:process.version,pass:rows.filter(r=>r.status==='PASS').length,fail:rows.filter(r=>r.status==='FAIL').length,candidateDigest:hash(JSON.stringify(before.candidate)),stable:JSON.stringify(before)===JSON.stringify(after)};
writeFileSync(join(dir,'receipt.json'),JSON.stringify({...summary,before,after,rows},null,2));
writeFileSync(join(proof,'resume-detail-latest.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
