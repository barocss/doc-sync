import assert from 'node:assert/strict';
export const actor='proof-tests';
export const ticket=(lamport,who=actor)=>({lamport,actor:who});
export const root=ticket(0,'~root');
export const update=(value,at=[0])=>({op:'update',at,attrs:{value:{scalar:value}}});
export function rejection(fn){try{fn();}catch(error){return error;}assert.fail('expected rejection');}
export function errorRecord(error){return {name:error?.name??typeof error,message:error?.message??null};}
export function seed(factory,createDataSchema){const e=factory.create(actor,createDataSchema()),d=e.typescriptDocument();d.apply({t:'node',id:ticket(1),origin:root,type:'entry',attrs:{id:'data:00000000-0000-4000-8000-000000000001',key:'proof',value:{scalar:1}}});return {e,d};}
export const value=d=>d.get(`1@${actor}`).attrs.get('value').value.scalar;
export const state=d=>({snapshot:d.snapshot(),clock:d.clock.lamport,version:d.version});
export function stableHistory(h){const s=h.snapshot();for(const stack of [s.undo,s.redo])for(const group of stack)group.at=0;return s;}
export function deterministicIds(){const prior=globalThis.crypto.randomUUID;let n=0;globalThis.crypto.randomUUID=()=>`00000000-0000-4000-8000-${String(++n).padStart(12,'0')}`;return ()=>{globalThis.crypto.randomUUID=prior;};}
