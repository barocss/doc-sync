import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {resolve,join,relative} from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
assert.equal(process.version,'v24.22.1');
const repo=resolve(import.meta.dirname,'../../../..'),out=join(repo,'output/preflight-reuse-2026-11-04');
const archive=join(repo,'output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src');
const candidate=join(out,'candidate-v2/packages/doc-sync/src');
const old=join(out,'proof-tests'),extra=join(out,'data-tests-v2');
const hash=x=>createHash('sha256').update(x).digest('hex');
function manifest(tree){const entries={};function walk(p){for(const e of readdirSync(p,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const q=join(p,e.name);if(e.isDirectory())walk(q);else entries[relative(tree,q)]=hash(readFileSync(q));}}walk(tree);return entries;}
const runner=readFileSync(join(old,'run.mjs'),'utf8');
const controls=Function('return '+runner.slice(runner.indexOf('const scenarios=')+16,runner.indexOf(';\nasync function hashes')))();
assert.equal(controls.length,64);
const extras=['normal:root','normal:nested','normal:list','empty:root:created','empty:nested:created','empty:list:created','empty:root:bulk','empty:nested:bulk','empty:list:bulk','flat-shared','commutation','bad-value','bad-path','bad-meta','clock-final','clock-overflow','custom-schema','saved-reopen','escape-find:two','escape-find:multi','projection-engine','public-register-alias','canonical-alias','bodyhead-collision','compiler-before-model:value','compiler-before-model:path'];
const runDir=join(import.meta.dirname,'resume-runs',new Date().toISOString().replaceAll(/[:.]/g,'-'));mkdirSync(runDir,{recursive:true});
const before={archive:manifest(archive),live:manifest(join(repo,'packages/doc-sync/src')),candidate:manifest(candidate)};
writeFileSync(join(runDir,'before.json'),JSON.stringify(before,null,2));
const rows=[];
function clean(x){x=structuredClone(x);for(const o of [x.observation,...(x.observation?.trials??[])])if(o)for(const k of ['compilerCalls','snapshotScalars','restoreScalars','liveSnapshots','scalarCopies'])delete o[k];return x;}
for(const scenario of [...controls,...extras]){
 const file=extras.includes(scenario)?join(extra,'extra-child.mjs'):join(old,scenario.startsWith('legacy-')?'legacy-child.mjs':scenario==='projection-preload'?'projection-child.mjs':'child.mjs');
 const row={scenario};
 for(const [name,tree] of [['baseline',archive],['candidate',candidate]]){
  const r=spawnSync(process.execPath,[file,tree,scenario],{encoding:'utf8',timeout:30000,maxBuffer:24*1024*1024});
  const slug=scenario.replaceAll(':','-');writeFileSync(join(runDir,`${name}-${slug}.stdout.log`),r.stdout??'');writeFileSync(join(runDir,`${name}-${slug}.stderr.log`),r.stderr??'');
  row[name]={status:r.status===0?'PASS':'FAIL',exit:r.status,error:r.error?.message};
  if(r.status===0)try{row[name].value=JSON.parse(r.stdout.trim());}catch(e){row[name].status='FAIL';row[name].error=String(e);}
 }
 try{assert.equal(row.baseline.status,'PASS');assert.equal(row.candidate.status,'PASS');assert.deepEqual(clean(row.candidate.value),clean(row.baseline.value));row.equivalence='PASS';}catch(e){row.equivalence='FAIL';row.error=String(e);}
 const b=row.baseline.value?.observation,c=row.candidate.value?.observation;
 if(b&&c&&(scenario.startsWith('data:')||scenario.startsWith('empty:')||scenario.startsWith('normal:')||scenario==='stock-count')){
  const bs=b.trials??[b],cs=c.trials??[c];
  row.count=cs.every((t,i)=>t.compilerCalls===3&&t.liveSnapshots===2&&t.snapshotScalars===bs[i].snapshotScalars*2/3&&t.restoreScalars===bs[i].restoreScalars*2/3)?'REDUCED_PRIVATE_PAIR':cs.every((t,i)=>['compilerCalls','liveSnapshots','snapshotScalars','restoreScalars'].every(k=>t[k]===bs[i][k]))?'LEGACY_FALLBACK':'FAIL';
 }
 if(b&&c&&['bad-value','bad-path','bad-meta','clock-overflow','bodyhead-collision'].includes(scenario))row.count=['compilerCalls','liveSnapshots','snapshotScalars','restoreScalars'].every(k=>c[k]===b[k])?'LEGACY_FALLBACK':'FAIL';
 rows.push(row);
 if(row.equivalence==='FAIL'||row.count==='FAIL')console.log(JSON.stringify({scenario,equivalence:row.equivalence,count:row.count,error:row.error}));
}
const after={archive:manifest(archive),live:manifest(join(repo,'packages/doc-sync/src')),candidate:manifest(candidate)};
writeFileSync(join(runDir,'after.json'),JSON.stringify(after,null,2));
const stable=Object.fromEntries(['archive','live','candidate'].map(k=>[k,JSON.stringify(before[k])===JSON.stringify(after[k])]));
stable.production69MatchesArchive=Object.keys(after.live).length===69&&JSON.stringify(after.live)===JSON.stringify(after.archive);
const summary={runDir,node:process.version,stable,baselinePASS:rows.filter(r=>r.baseline.status==='PASS').length,candidatePASS:rows.filter(r=>r.candidate.status==='PASS').length,equivalencePASS:rows.filter(r=>r.equivalence==='PASS').length,reduced:rows.filter(r=>r.count==='REDUCED_PRIVATE_PAIR').map(r=>r.scenario),firstFailure:rows.find(r=>r.equivalence==='FAIL'||r.count==='FAIL')?.scenario??null,candidateDigest:hash(JSON.stringify(before.candidate))};
writeFileSync(join(runDir,'receipt.json'),JSON.stringify({...summary,rows},null,2));writeFileSync(join(import.meta.dirname,'resume-latest.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
