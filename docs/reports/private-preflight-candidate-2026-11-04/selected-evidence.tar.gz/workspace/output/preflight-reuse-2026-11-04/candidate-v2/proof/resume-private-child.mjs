import {registerHooks} from 'node:module';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {actor,deterministicIds} from './fixtures.mjs';
assert.equal(process.version,'v24.22.1');
const [tree,kind,construction]=process.argv.slice(2),base=pathToFileURL(resolve(tree)+'/').href;
globalThis.__privateReturns=[];
registerHooks({load(url,context,next){const result=next(url,context);if(url!==base+'crdt/doc.ts')return result;const source=String(result.source),needle='        return {ops, normalize};';assert.equal(source.split(needle).length,2);return {...result,source:source.replace(needle,'        if(this!==globalThis.__privateLive)globalThis.__privateReturns.push({doc:this,ops,normalize});\n'+needle)};}});
const {Client,clientOwner}=await import(base+'client/index.ts'),{createDataSchema}=await import(base+'data/schema.ts');
const reset=deterministicIds();let c,map,list,id;
try{
 c=new Client({actor,schema:createDataSchema()});const data=c.data;
 if(kind==='root')map=data.root;
 else if(kind==='nested'){map=data.createMap();data.root.set('nested',map);}
 else{list=data.createList();data.root.set('list',list);}
 if(list){id=list.push(1);list.push(3);}else{map.set('proof',1);map.set('other',3);}
 data.root.set('empty-map',data.createMap());data.root.set('empty-list',data.createList());
}finally{reset();}
if(construction==='bulk'){const saved=c.captureState();saved.engine.document.moves=[];c=Client.fromState(saved,{schema:createDataSchema()});map=map?(kind==='root'?c.data.root:c.data.getMap(map.id)):null;list=list?c.data.getList(list.id):null;}
const d=clientOwner(c).engine.typescriptDocument();globalThis.__privateLive=d;globalThis.__privateReturns=[];
if(list)list.set(id,'한글🙂');else map.set('proof','한글🙂');
assert.equal(globalThis.__privateReturns.length,1,'exact actual detached preflight P');
const {doc:p,ops,normalize}=globalThis.__privateReturns[0];assert.notEqual(p,d);assert.equal(ops.length,1);assert.deepEqual(normalize,[]);
// Compare every enumerable storage/cache field and graph alias, not just a model.
// WeakMaps cannot be enumerated. Data creates no text-cache keys; movement priors
// are empty on restore and on this set; set priors are asserted via actual ops.
function graph(root){const ids=new Map(),nodes=[];function ref(v){if(v===null||typeof v!=='object')return typeof v==='function'?{function:v.name}:Object.is(v,-0)?{negativeZero:true}:v;const old=ids.get(v);if(old!==undefined)return {$ref:old};const id=nodes.length;ids.set(v,id);nodes.push(null);let value;if(v instanceof WeakMap)value={kind:'WeakMap',opaque:true};else if(v instanceof Map)value={kind:'Map',entries:[...v].map(([k,x])=>[ref(k),ref(x)])};else if(v instanceof Set)value={kind:'Set',entries:[...v].map(ref)};else value={kind:v.constructor?.name??null,properties:Object.keys(v).map(k=>[k,ref(v[k])])};nodes[id]=value;return {$ref:id};}const rootRef=ref(root);return {root:rootRef,nodes};}
const result={kind,construction,ops,normalize,priors:ops.map(op=>p.priorOf(op)),privateGraph:graph(p)};
assert.deepEqual(p.toJSON(),d.toJSON());assert.deepEqual(p.snapshot(),d.snapshot());
console.log(JSON.stringify(result));
