// Internal implementation only. No package/barrel export or caller trust registrar.
import {schemaVersion} from "./schema-version.ts";
import type {Schema} from "./schema.ts";
import {createDataSchema} from "../data/schema.ts";

/** Capture only the named defining-module surface, before importers can replace it. */
export function captureSurface(target: object): () => boolean {
    const proto = Object.getPrototypeOf(target), keys = Reflect.ownKeys(target);
    const descriptors = keys.map(key => Object.getOwnPropertyDescriptor(target, key)!);
    return () => {
        if (Object.getPrototypeOf(target) !== proto) return false;
        const current = Reflect.ownKeys(target);
        if (current.length !== keys.length || current.some((key, i) => key !== keys[i])) return false;
        return keys.every((key, i) => {
            const a = descriptors[i], b = Object.getOwnPropertyDescriptor(target, key)!;
            return a.value === b.value && a.get === b.get && a.set === b.set &&
                a.enumerable === b.enumerable && a.configurable === b.configurable && a.writable === b.writable;
        });
    };
}

const ownedDefaultData = new WeakSet<object>();
const fingerprint = JSON.stringify(createDataSchema());
function freezeSchemaValue(value: unknown): void {
    if (value && typeof value === "object" && !Object.isFrozen(value)) {
        Object.values(value).forEach(freezeSchemaValue);
        Object.freeze(value);
    }
}

/** This is the actual engine validate/copy/freeze factory, not registration. */
export function ownEngineSchema(input: Schema): Schema {
    schemaVersion(input);
    const active = new Set<object>();
    const visit = (v: unknown): void => {
        if (v === null || typeof v === "string" || typeof v === "boolean") return;
        if (typeof v === "number" && Number.isFinite(v)) return;
        if (typeof v !== "object" || active.has(v)) throw new Error("Engine DTO must be finite plain JSON");
        const proto = Object.getPrototypeOf(v);
        if (Array.isArray(v) ? proto !== Array.prototype : proto !== Object.prototype && proto !== null) throw new Error("Engine DTO must be plain JSON");
        const keys = Reflect.ownKeys(v);
        if (Array.isArray(v) && (keys.length !== v.length + 1 || Object.keys(v).some((key, i) => key !== String(i)))) throw new Error("Engine DTO arrays must be dense");
        active.add(v);
        for (const key of keys) {
            if (Array.isArray(v) && key === "length") continue;
            const descriptor = Object.getOwnPropertyDescriptor(v, key)!;
            if (typeof key !== "string" || !descriptor.enumerable || !("value" in descriptor)) throw new Error("Engine DTO must contain plain values");
            visit(descriptor.value);
        }
        active.delete(v);
    };
    visit(input);
    const schema = structuredClone(input);
    freezeSchemaValue(schema);
    if (JSON.stringify(schema) === fingerprint) ownedDefaultData.add(schema);
    return schema;
}
export const isOwnedDefaultData = (schema: unknown): schema is Schema =>
    typeof schema === "object" && schema !== null && ownedDefaultData.has(schema);
