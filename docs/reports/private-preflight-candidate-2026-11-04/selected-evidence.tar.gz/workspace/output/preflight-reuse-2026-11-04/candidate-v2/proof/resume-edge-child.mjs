import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {actor,seed,update,errorRecord} from './fixtures.mjs';
assert.equal(process.version,'v24.22.1');
const [tree,mode]=process.argv.slice(2),base=pathToFileURL(resolve(tree)+'/').href;
const trace=[];
let ROOT,rootDescriptor;
if(mode==='root-accessor'){
 ({ROOT}=await import(base+'crdt/ticket.ts'));rootDescriptor=Object.getOwnPropertyDescriptor(ROOT,'lamport');
}
// ROOT getter setup must precede Doc import, while preserving valid descriptor syntax.
if(mode==='root-accessor'){Object.defineProperty(ROOT,'lamport',{configurable:true,enumerable:true,get(){trace.push('ROOT.lamport');return 0;}});}
const {typescriptClientEngineFactory:factory}=await import(base+'engine/typescript-client.ts'),{createDataSchema}=await import(base+'data/schema.ts');
const {e,d}=seed(factory,createDataSchema);trace.length=0;
if(mode==='noncallable-snapshot'||mode==='noncallable-apply')Object.defineProperty(d.items,'map',{value:7});
if(mode==='items-accessor'){
 const line=d.get('0@~root').line,items=line.items;
 Object.defineProperty(line,'items',{configurable:true,get(){trace.push('line.items');return items;}});
}
let error,ops;
try{if(mode==='noncallable-snapshot')d.snapshot();else ops=e.apply([update(2)],{normalize:true});}catch(err){error=err;}
if(mode.startsWith('noncallable'))assert.equal(error?.name,'TypeError');else if(error)throw error;
console.log(JSON.stringify({mode,trace,error:error?errorRecord(error):null,ops,clock:d.clock.lamport,version:d.version}));
