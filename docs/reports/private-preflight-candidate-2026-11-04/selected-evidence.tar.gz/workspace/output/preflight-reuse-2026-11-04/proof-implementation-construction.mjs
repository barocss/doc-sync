// Negative construction proofs. Deliberately unsafe abstractions are test-local, not candidate code.
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const core=resolve(process.env.DOC_SYNC_CORE_ROOT),load=p=>import(pathToFileURL(`${core}/${p}`).href);
const {Doc}=await load('crdt/doc.ts');
const {KeyIndex}=await load('crdt/key-index.ts');
const {compileEdits}=await load('crdt/edit.ts');
const {createDataSchema}=await load('data/schema.ts');
// Import defining modules before installing the public preload override.
const originalSet=KeyIndex.prototype.set, originalFind=KeyIndex.prototype.find;
const originalToJSON=Doc.prototype.toJSON;
const {typescriptClientEngineFactory}=await load('engine/typescript-client.ts');
const actor='construct-proof',key=`1@${actor}`,id={lamport:1,actor};
const update={op:'update',at:[0],attrs:{value:{scalar:2}}};
function seed(){const e=typescriptClientEngineFactory.create(actor,createDataSchema()),d=e.typescriptDocument();d.apply({t:'node',id,origin:{lamport:0,actor:'~root'},type:'entry',attrs:{id:'data:proof',key:'proof',value:{scalar:1}}});return {e,d};}
function failure(f){let err;try{f();}catch(e){err=e;}assert.ok(err,'expected rejection');return err;}
function indirectDispatch(mode){
 const {e,d}=seed(),items=d.snapshot().lines[0].items;let armed=false,escapedIndex;
 items[1]=new Proxy(items[1],{get(target,prop,receiver){
  if(prop==='i'&&!armed){armed=true;KeyIndex.prototype.find=function(...args){escapedIndex=this;KeyIndex.prototype.find=originalFind;return originalFind.apply(this,args);};}
  return Reflect.get(target,prop,receiver);
 }});
 Object.defineProperty(d.items,'map',{configurable:true,value(){return items;}});
 let error;
 try{
  // One op and ONE ordinary key, failing only at allocation: no multi-key authority loophole.
  // Use an overflowing snapshot Lamport clock without touching the selected restore method.
  d.clock.lamport=Number.MAX_SAFE_INTEGER;
  if(mode==='legacy') error=failure(()=>e.apply([update]));
  else { const p=Doc.fromSnapshot(actor,d.snapshot(),d.schema);assert.equal(KeyIndex.prototype.set,originalSet);assert.equal(KeyIndex.prototype.find,originalFind);error=failure(()=>compileEdits(p,[update])); }
  assert.ok(escapedIndex);assert.notEqual(escapedIndex,d.byKey);
  assert.equal(KeyIndex.prototype.set,originalSet);assert.equal(KeyIndex.prototype.find,originalFind);
  const exposed=escapedIndex.get(key);assert.ok(exposed);assert.equal(exposed.attrs.get('value').value.scalar,1);
  return {error:error.message,exposedValue:exposed.attrs.get('value').value.scalar,outerSetOriginalThroughout:true,innerFindOriginalAtReturn:true,liveValue:d.get(key).attrs.get('value').value.scalar};
 } finally {KeyIndex.prototype.find=originalFind;}
}
function retainedClosure(mode){
 const {e,d}=seed(),items=d.snapshot().lines[0].items;let retained,escapedIndex,callbacks=0;
 const proxy=new Proxy(items,{get(target,prop,receiver){
  if(prop==='forEach')return function(callback,thisArg){callbacks++;retained=callback;KeyIndex.prototype.find=function(...args){escapedIndex=this;KeyIndex.prototype.find=originalFind;return originalFind.apply(this,args);};return Array.prototype.forEach.call(target,callback,thisArg);};
  return Reflect.get(target,prop,receiver);
 }});
 Object.defineProperty(d.items,'map',{configurable:true,value(){return proxy;}});
 let error;
 // The retained loader callback is a capability even though it receives no fresh Item argument.
 try{
  const edits=[update,{op:'update',at:[99],attrs:{value:{scalar:3}}}];
  if(mode==='legacy')error=failure(()=>e.apply(edits));
  else {const p=Doc.fromSnapshot(actor,d.snapshot(),d.schema);error=failure(()=>compileEdits(p,edits));}
  assert.equal(typeof retained,'function');
  // Re-enter after restoration: duplicate identity is rejected only AFTER the callback pushes
  // a freshly built Item into the retained Line. This demonstrates lasting mutation authority.
  const duplicate={i:`1@${actor}`,k:'n',b:'entry',a:[['value',{scalar:7},`1@${actor}`]]};
  assert.ok(escapedIndex);assert.equal(KeyIndex.prototype.set,originalSet);assert.equal(KeyIndex.prototype.find,originalFind);
  const exposed=escapedIndex.get(key),beforeLength=exposed.line.items.length;
  const exposedValue=exposed.attrs.get('value').value.scalar;assert.equal(exposedValue,mode==='legacy'?1:2);
  const replayError=failure(()=>retained(duplicate));
  const afterLength=exposed.line.items.length;assert.equal(afterLength,beforeLength+1);
  assert.match(replayError.message,/Duplicate snapshot token identity/);
  assert.equal(d.get(key).attrs.get('value').value.scalar,1);
  return {error:error.message,retainedCallbacks:callbacks,replayError:replayError.message,retainedMutationAuthority:true,exposedValue,beforeLength,afterLength,liveValue:1};
 }finally{KeyIndex.prototype.find=originalFind;}
}
const indirectLegacy=indirectDispatch('legacy'),indirectUnstaged=indirectDispatch('unstaged');
assert.deepEqual(indirectLegacy,indirectUnstaged);
const closureLegacy=retainedClosure('legacy'),closureUnstaged=retainedClosure('unstaged');
assert.equal(closureLegacy.error,closureUnstaged.error);assert.equal(closureLegacy.exposedValue,1);assert.equal(closureUnstaged.exposedValue,2);
// An outer selected-method check alone cannot establish construction safety.
assert.equal(Doc.prototype.toJSON,originalToJSON);
console.log(JSON.stringify({node:process.version,core,indirectLegacy,indirectUnstaged,closureLegacy,closureUnstaged,verdict:'Construction witness must include internal KeyIndex dispatch and retained loader callbacks. Neither equality at return nor outer-set identity closes the proof. No optimization installed.'},null,2));
