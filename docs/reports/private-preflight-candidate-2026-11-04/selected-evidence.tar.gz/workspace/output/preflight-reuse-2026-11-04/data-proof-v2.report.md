# Coordinator pointers for the resumed V2 proof

The original CLI producer stopped for model capacity before writing this path.
The resumed High producer's actual terminal/report are
`data-proof-v2-resume.final.md` and `data-proof-v2-resume.report.md`.
The source remains frozen at70-file closure
d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab.

Read scope-clarification-v2.md for the parent decision, supported by independent
High interpretation in data-review-v2.report.md. The initial90-case custom-schema
count failure remains recorded. It cloned the exact default schema rather than
altering it. No producer source was changed or input-origin brand added.

The independent new94-case run now passes baseline94/candidate94/equivalence94,
strict count gates and source stability. Its actual receipt is
`data-tests-v2/clarified-runs/2026-11-03T20-00-53-686Z/receipt.json`.
Final test/typecheck handoff will be in `data-tests-v2-clarified.final.md` and
`data-tests-v2-clarified.report.md`, not the preserved earlier HOLD file.
The test lane is currently finishing its own candidate noEmit TypeScript check.

This pointer is from the parent coordinator, not a new producer, independent
approval or performance receipt. All timing remains NOT_RUN pending exact-source
High proof decision and final independent qualification.
