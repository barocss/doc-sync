# Independent V2 private-preflight proof review

Disposition: APPROVE_PROOF

**Approve only the bounded source proof for the exact V2 source closure below.** This is not functional-gate, production, performance, package, workspace, or release approval.

The independent functional receipt remains **HOLD_FUNCTIONAL_FAILURE** because its `custom-schema` count gate uses an exact clone of the default schema. Section 5 gives the High scope interpretation and the minimal test repair. Do not erase that receipt, report the whole functional gate as PASS, or start performance work from this proof verdict alone.

Review: 2026-11-03T19:34Z through 20:03:32.938Z; local date 2026-11-04. Node v24.22.1 was pinned throughout. The writer delivered an actual private producer, not the old baseline copy. I waited for its terminal delivery before the final verdict and reviewer executions.

## 1. Exact scope and evidence

Candidate source: `candidate-v2/packages/doc-sync/src`.

- Only an actual engine-factory-owned schema with the exact default Data fingerprint can qualify.
- Only one already-copied update with exactly the ordinary `value` attribute, targeting a guarded existing entry atom, can qualify.
- The fixed physical topology is the Data main line plus Map/List body lines. Normal authored placements and absent empty body heads are supported.
- Other schemas, operations, attributes, type changes, text, fields, groups, grids, cardinality, annotations, uncertain state, and unknown receivers retain staging.
- Both live snapshot observations, the live atomic compiler stage, all restore admission/copies, engine pre-live normalization, emit/run/priors, accepted guards, notifications, and live object identities remain.

| Evidence | Result and limit |
| --- | --- |
| Exact source/contract review | APPROVE_PROOF for this closure and bound only |
| Independent Medium execution | 90 baseline PASS; 90 candidate PASS; 90 output-equivalence PASS; one failed count/scope gate, preserved |
| Independent positive census | 16 reduced scenarios; all 9 mandatory normal reductions; two live snapshots remain |
| Reviewer tiny normal probe | Three paired cases PASS; authored moves 1/3/3; exact output equality; pairs 3→2 and compilers 4→3 |
| Reviewer schema probe | Default clone qualifies; actually altered schema falls back; full ops/priors/state match baseline |
| Producer private-P/edge probes | Six paired private graphs and four paired edge controls PASS; reviewed bodies and receipt, not independently rerun here |
| Production preservation | 69/69 files equal frozen archive; V1's corresponding 69 Core files also equal archive |
| Production 2084-case qualification | Supplied parent context, not rerun or enlarged by this review |
| Timing, speed, heap, global tests/build/dist, browser/mobile, Git | NOT_RUN in this lane |

The prior round's 64 baseline passes and HOLD were read as controls and proof-obligation history. They are not evidence of an optimized V2 pass.

## 2. Construction authority is closed within the stated source contract

References in this section are relative to candidate source.

### Schema provenance and receivers

`crdt/private-data.ts:22-59` performs the actual schema-version validation, descriptor-based plain-JSON validation, host copy, and recursive deep freeze. Only its newly owned exact-fingerprint result enters the private WeakSet. `isFrozen` and caller registration do not grant authority. The factory cannot admit a caller schema object directly as its owned result.

`engine/typescript-client.ts:56,88,393-400` records real engine allocation identity and checks its prototype surface and primitive own actor descriptor. Unknown, Proxy, borrowed, subclass and changed-surface receivers fail this check without extra reads of their actor/schema/Doc internals. The original fallback expression remains at `219-223`. There is no new private-brand field or brand error.

The Doc/Line registries at `crdt/doc.ts:2770-2774` establish actual non-Proxy allocation identity, not validity or permission to skip validation. Their role is limited to safely recognizing the builder's native allocations. A public restored Doc does not retain a private-operation witness.

### Actual builder, then callback-free restore

`crdt/doc.ts:2568-2597,2796-2833` couples the certificate to the actual source snapshot builder. It requires the registered Line/items-array identities and native dense array/default-constructor path before passing the mapper. Unknown arrays, map overrides, constructor/species routes and accessor-backed Line arrays make that local audit unsafe. No returned foreign DTO is inspected for authority. Unsafe is monotonic.

The literal `line.items.map(...)` call remains. This preserves its receiver, evaluation and non-callable-map TypeError. Metadata checks concern the builder's own new wrapper/tuple arrays. Payload objects are host-cloned and still pass the full public snapshot admission before construction. Metadata retained in certified wrappers is primitive. The actual fresh output graph, not an arbitrary plain-looking caller graph, supplies the purity premise.

Source callbacks finish before the witness decision at `2859-2875`. They can mutate public source surfaces, but cannot yet hold the not-created P. A foreign source route cannot recover certificate authority merely by restoring descriptors. Original source functions alone are not the proof: real builder output, owned pure schema, and the closed construction call graph are all required together.

### Transitive and sentinel boundaries

- `crdt/key-index.ts:139` captures the defining-module prototype, including nested `find` and `join`, not just outer `set`.
- `crdt/placement.ts:70-79` captures its defining-module surface and verifies the actual registered native records Map. The owner closure dispatch is therefore covered even without authored moves.
- `crdt/ticket.ts:59` captures Clock in its own module.
- `crdt/doc.ts:2777-2795` checks Doc static/prototype surfaces, EmptyMap/EmptySet prototypes, exposed empty instances, and their empty contents. These are not waved away as global intrinsics.
- ROOT is checked through exact own-data primitive descriptors. A pre-Doc accessor does not get accepted by a late descriptor capture or invoked by the new guard.

With certified fresh pure restore input and pure owned schema, the unchanged original restore body cannot run a caller callback that receives P, Items, Lines, ranges, or loader closures. All JSON/schema/identity/span/head/reserved/capability/register/move validation and defensive copies still execute. This closes the prior transient FIND/SET, retained `forEach`, and Placement `ownerOf` counterexamples for positive authority. Those unsafe public routes instead retain their original staged work and observations.

### Immediate single use

`crdt/doc.ts:2876-2884` sets a local immediate context only after witnessed construction and storage eligibility. `2255-2257` consumes it once for that exact P and admitted edit identity, before any model/compiler work. The surrounding `finally` restores prior scope. P has its original null guard/listener and callback-free fields. There is no callback between granting and consuming this context, no public snapshot/token input, no persistent Doc-validity flag, and no witness returned through P, ops, or public nested restore calls. The helper returns only whether it completed the preflight path.

The internal helper exports are not package/barrel exports. Authority rests on the executed producer, not on possession of an exported registration function.

## 3. Ordering, no-throw admission and private state

`crdt/doc.ts:2834-2852,2888-2971` implements the positive proof before early model reading. It checks canonical token IDs and heads, fixed birth/current types, allowed registers, ordinary clock actors and bounds, collision-free generated body heads, shallow physical topology, unique nonempty record IDs, canonical old/new DataMeta, reference/kind consistency, retained movement topology, and the exact projected visible entry path. Generic AttrSpec acceptance alone is no longer the metadata proof. Bad or uncertain cases keep V on the same already-restored P; source snapshot/restore is not repeated.

The pure Data projection mirrors original container placement projection: non-head nodes in physical order, original retained movement handling, and actual collection ownership. It cannot introduce text, required children, grouping or derived gap semantics in this admitted topology. It runs the verified original Placement dispatch. Its owner callback is local and is not retained by that implementation.

For positive states:

1. Every H-created head is the canonical body head of a known main-line Map/List. Occupied or noncanonical aliases do not qualify. H creates no Lamport ticket and changes no visible parent, order, type, or path.
2. U is exactly one ordinary value set on the selected live entry. Its AttrSpec and new value are valid, no field expansion occurs, and `clock + 1` is safe. H cannot change its target, allocation, old register prior, or compiler result. Body-head actors cannot collide with the guarded ordinary U actor.
3. The deleted V compiles only a separate disposable clone. In the old P schedule, before-model H still preceded actual U. The new P retains that same H→U→expected-model/after-model order. It does not move U ahead of H or alter the live schedule.
4. Within the positive bound, the compiler success formerly tested by V and the model-read conditions are established before early H. There is no new early private model failure competing with a compiler failure. Invalid path/value/clock/metadata states retain the old first-error checks. No deferred error, rollback, clock rewind, prepared-Doc swap, or raw apply replay is used.

Thus literal storage neutrality is not required or claimed. Empty sibling bodies can be materialized. The private ordering/commutation argument concerns paths, ops/tickets, clocks, priors, normalized expected model, final P storage/caches, and errors, not just public JSON equality.

The producer's `resume-private-child.mjs` captures the actual detached P only after its completed edit return, using a source observation hook before original capture. It compares enumerable storage/cache graph aliases plus actual ops, normalization and priors across root/nested/List, with placements or no-move restoration and empty Map/List siblings. WeakMaps are opaque; this shape creates no text-cache keys or movement-prior keys, and the real emitted set's prior is explicitly checked. This is representative executed evidence with a stated observation limit, not a claim that opaque WeakMaps were exhaustively enumerated.

## 4. Integration and test assessment

`crdt/doc.ts:2255-2257` skips only P's atomic validation branch. The engine still discards P after its normalized proof and runs the original live edit. The public `Doc.edit` and `fromSnapshot` routes cannot consume the context accidentally. No live Doc/Line/Item replacement, staged-op adoption or prior reconstruction occurs.

I reviewed the independent driver bodies, including the resumed readiness/count gate and extra controls. Separate whole-tree child processes avoid mixed mutable prototype realms. Counts use pre-capture source observations and scalar copy censuses, not prototype wrappers that disable eligibility. Source binding establishes which private pair is removed; global structuredClone counts alone do not.

The independent 90-case receipt covers normal authored moves 1/3/3, empty siblings and legacy no-move cases, input getter rejection/one-copy admission, guard and accepted behavior, full operations/priors/snapshots/History/notifications, live identities, undo/redo with foreign overwrite/deletion, saved reopen, sessions/checkpoint, public alias separation, admission errors, R4 preloads, C1/C2/species, transient FIND/SET, retained iteration and Placement closures, unknown/borrowed/Proxy receivers, readonly/high-clock/model-error/normalization fallback. Only agreed History wall time is normalized. All 90 baseline/candidate public-output comparisons pass.

This is bounded coverage. It is not all-session-failure, all-schema-transition, all-CRDT-state, full Core, product or remote proof. Those broader paths retain legacy source behavior and remain outside this approval.

## 5. The custom-schema gate: preserve failure, correct the fixture

Independent receipt first failure: `custom-schema`. Expected compiler/snapshot/restore/live counts: `4/3/3/2`; observed candidate: `3/2/2/2`. Public outputs and errors match. Its fixture is exactly `structuredClone(createDataSchema())`, then the actual engine factory.

**High interpretation:** this fixture is not an altered custom schema. The revised boundary is the exact engine-owned default Data schema **fingerprint**, with authority minted by actual validate/copy/deep-freeze. An exact caller clone still becomes a new factory-owned default-fingerprint schema. Caller clone identity and caller freezing do not supply authority. Requiring the original `createDataSchema()` input identity would be a different protocol and is not the stated bound.

This failed count assertion therefore does not establish unsafe construction, a public semantic regression, or a source-scope violation. It also must not be relabeled a passed functional gate. The Medium report correctly preserves it.

Minimum repair, owned by the test lane: retain the failed receipt; make the custom-schema fixture actually differ from the fingerprint, such as adding one allowed optional entry AttrSpec; keep its exact legacy count assertion; retain a separate exact-default-clone eligible case; then rerun and bind the amended functional receipt before advancing. This reviewer did not edit that driver or assertion.

The independent reviewer schema probe separately tests the real public factory with both inputs. Exact cloned default: baseline/candidate scalar snapshot-restore pairs `3/3` versus `2/2`. Actually altered schema (`entry.attrs.note = {default: ''}`): `3/3` versus `3/3`. Full returned ops, prior and final state match in both cases. This supports the source interpretation; it does not silently repair the existing failed gate.

## 6. Exact final hashes

Final read-only capture: **2026-11-03T20:03:32.938Z**. Digest: SHA-256 of ASCII-path-sorted UTF-8 `file_sha256 + two spaces + relative_path + LF` entries.

| Source closure | Files | SHA-256 |
| --- | ---: | --- |
| Actual V2 source | 70 | `d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab` |
| Production = archive = V1 corresponding Core | 69 | `8b532beb32d4ef0e7d69e54ac9a989d269d0c590e11d6ef8f3f0545b362c4a51` |

Candidate JSON-manifest digest in the independent receipt: `fd49e2f3c695cfa40b3c16c28a72624158becb71a3788bf7d1bd6223c70a5862`. Source, harness, archive, production, protocol and producer were stable during that execution. My normal probe also verified stable source and archive equality. Five copied source modules differ; one private helper is added; the other 64 original source files match the archive.

| Changed candidate source | SHA-256 |
| --- | --- |
| `crdt/doc.ts` | `b3c58361a1ea38a35b50dd4da8e322052e03bb8c7b4879f7db2ebbdeb469273f` |
| `crdt/key-index.ts` | `da13a10c0201288e5bcc0be1d3824e5e37307c609ff353b7864859d94ac3ed6b` |
| `crdt/placement.ts` | `cde6bb0c52229d4c564425aab9f80efe49d56150a008df9e03692702047ac2a0` |
| `crdt/private-data.ts` | `b5cf84fdcbb96609a11d3f83a98c9d4ba10b4bc7214ee03216faaa33b3f33ad0` |
| `crdt/ticket.ts` | `86fdf09218f5b11de91b698b5bf0b4e5d66a6f677f430d1205f132aec8ce39d5` |
| `engine/typescript-client.ts` | `10083260d162ae0a7746ca12f0a6c1466700458019f599269ffb174abc61ceaa` |

| Bound artifact | SHA-256 |
| --- | --- |
| `data-protocol-v2.md` | `2777b9977b40020e01f1be88baadc3f53057012475e23a391044afdca0f65afe` |
| `data-proof-v2-resume.report.md` | `e523b162a6f305d84546e27be8cef4e786389f559c5b5c228edf520c61abbf88` |
| `data-proof-v2-resume.final.md` | `567be2295c80899f58f255d5ab423193100c1ae2faa25efd0a476fa4fda37555` |
| Independent `data-tests-v2/runs/2026-11-03T19-56-31-358Z/receipt.json` | `20452cd10dfd5712a050572e159007180984e41d3a1e24455034a89fab2b749c` |
| `data-tests-v2-resume.report.md` | `751bd3b8f63bcc84d38aa4f09fdd19d328d6ef5b42db44dc721f483cc4b2aaec` |
| Producer `candidate-v2/proof/resume-detail-2026-11-03T19-53-35-964Z/receipt.json` | `8b87be9ac4eafbb5f866ba6d18b46b398abe01422cbb134b9232ed956b9c4436` |
| `candidate-v2/proof/resume-source-final.json` | `742ef55c6a3301236fb34dcb47a1be1e5a1dc0a5b03c131900e62235d55737bf` |
| Candidate package context `candidate-v2/packages/doc-sync/package.json` | `619a2e12f68032a250ad9080b4c92f160bd8bdd01d2afb7d63ac5d3789eda5f8` |
| Reviewer `data-review-v2.probe.mjs` | `3370db202e377a87af37cb7d4dd77c0859d55b0eb400e59ad6276a16a3554d48` |
| Reviewer `data-review-v2.schema-probe.mjs` | `0acd1805ea25d3dcdd0c55b5403d19998f8d09625c875979e13da0340f5d1e03` |

## 7. Assumptions, preserved concerns and handoff

The approval uses the explicit contract that standard global intrinsics and host structuredClone semantics are unchanged. Controlled scalar copy censuses and pre-capture observation hooks are test instrumentation, not production capabilities. Public module prototypes, ROOT and exposed private empty sentinels are actual checked boundaries, not part of that intrinsic exclusion. Arbitrary custom source graphs do not gain authority from final descriptor equality.

During active review I recorded three concrete candidate concerns in this report's progress versions: late ROOT-accessor capture, changed non-callable-map TypeError, and mixed DataMeta eligibility. The terminal producer repaired each. I verified the final code and corresponding edge/negative receipts. These are resolved findings, not reasons to HOLD unchanged final bytes. No reviewer fix was applied to candidate or tests.

Owned writes: this report, `data-review-v2.final.md`, and two tiny read-only probe drivers under this output directory. No other files were written by this lane. Probes execute isolated children and print results only. No production/candidate/real-test/docs/benchmark mutation, AGENT/sibling/memory scan, further agent, global test/build/dist, timing, browser/mobile, Git or cleanup was performed.

Root retains control of the amended functional gate, any further regression/type/package/Chrome checks, promotion, and the later serialized 5% performance protocol. The supplied 2084-case production baseline remains unchanged. Nothing has been promoted. Do not infer any speed or heap benefit from the pair census.
