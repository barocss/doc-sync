# Fallback control harness preparation

Disposition: PREPARED. Small smoke and CLI checks PASS. Timing NOT_RUN. No independent proof or performance approval is asserted.

Owned output: fallback-controls/**, this report and fallback-controls.final.md. No production, candidate, real test, documentation, build, dist, Git, browser or mobile changes were made. No further agent was used.

Final runner: fallback-controls/driver.mjs. Instructions: fallback-controls/README.md. Final small-check receipt: fallback-controls/checks-final/smoke-checks.json. The complete per-lane source inventories before/after are in the final smoke/count outputs.

Four public Client.edit control cells cover exact default Data structural insert/delete/move and a genuinely different validated schema for equivalent value update. Default fixtures have 200 entries, five measured samples and two untimed warmups. The unused custom atom includes a valid tag AttrSpec; the validated custom fingerprint differs from default before any timer. Labels and root path names never imply eligibility.

All four full semantic SHA values match baseline and candidate. The full ops and captured normalized History/snapshot state feed each digest. Independent expected models, snapshot/History roundtrips, undo/redo and foreign set/delete preservation pass for every sample. The exact live revision remains in semantic hashes. Restore reconstructs revision, so the roundtrip compares snapshots, identity and History rather than demanding revision equality.

The separate untimed custom factory guard verifies factory receiver, proxied engine receivers and omitted-domain document behavior. Both lanes produce the same guard transcript/checkpoint and pass undo/redo. No private allocation/count or fallback census claim follows from semantic counts mode.

The final check runner passed 14 recorded checks: both lane smoke runs; both lane clock-free semantic counts runs; both existing-output rejections; exact semantic/guard equivalence; unknown option, invalid mode, zero samples, duplicate label, excessive smoke size, missing option value and missing source-root rejections. It used Node v24.22.1. Each smoke used five samples plus two untimed warmups per cell. Each counts check used one sample and zero warmups. No harness timing clock was called.

The source closures before and after match the frozen reference hashes: baseline 69 files, 8b532beb32d4ef0e7d69e54ac9a989d269d0c590e11d6ef8f3f0545b362c4a51; candidate 70 files, d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab. The deterministic fixture SHA is 2e4e050d630e667317e31cdbc001feccf8947cfb8c4e54ceedd01efda908ad8e.

Initial baseline fixture checks caught overly strict restored-revision equality, a missing flow default, the existing empty paragraph after block insertion and protected sync-fixture disposal. The harness now uses correct roundtrip boundaries, a valid default-domain schema, a text insertion into its default paragraph and explicit isolated-engine cleanup. Attempts 02–04 retain stderr; earlier passing preparation artifacts remain superseded. Only checks-final binds the final harness bytes. The initial attempt 01 failed before output creation; its error is described here. No source was adjusted to make these harness checks pass.

The parent retains the proof approval and serial ABBA gate. The gate remains maximum 3% median regression, with 0.25 ms absolute allowance only for sub-millisecond control cells. There is no such allowance for main Data cells. Direct public Doc 100k text controls reuse benchmarks/doc-trace-control.mjs separately. No performance test was run in this preparation task.
