import {readdir,readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join,relative} from 'node:path';
const root=resolve(import.meta.dirname,'../..'),out=import.meta.dirname,live=join(root,'packages/doc-sync/src'),candidate=join(out,'candidate-src');
async function files(dir){const result=[];for(const entry of await readdir(dir,{withFileTypes:true})){const p=join(dir,entry.name);if(entry.isDirectory())result.push(...await files(p));else result.push(p);}return result.sort();}
try {await readFile(join(out,'proof-implementation-source-initial.json'));throw new Error('Refuse to overwrite an existing candidate checkpoint');} catch(error) {if(error.code!=='ENOENT')throw error;}
const originals=await files(live);if(originals.length!==69)throw new Error(`Expected 69 Core files, got ${originals.length}`);
await mkdir(candidate,{recursive:true});const hashes={};
for(const file of originals){const name=relative(live,file),dest=join(candidate,name);await mkdir(resolve(dest,'..'),{recursive:true});await copyFile(file,dest);hashes[name]=createHash('sha256').update(await readFile(file)).digest('hex');}
// Context belongs beside the copied source root. Keep the original exact package metadata.
await copyFile(join(root,'packages/doc-sync/package.json'),join(out,'proof-implementation-package-context.json'));
await writeFile(join(candidate,'package.json'),JSON.stringify({type:'module'})+'\n');
await writeFile(join(out,'proof-implementation-source-initial.json'),JSON.stringify({node:process.version,live,candidate,count:originals.length,hashes},null,2)+'\n');
console.log(JSON.stringify({node:process.version,copied:originals.length,packageType:'module',source:'current live Core',candidate}));
