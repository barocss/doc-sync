import {readFile,writeFile} from 'node:fs/promises';
const p=new URL('./candidate-v2/packages/doc-sync/src/crdt/doc.ts',import.meta.url);let s=await readFile(p,'utf8');
s='import {captureSurface, isOwnedDefaultData} from "./private-data.ts";\n'+s;
s=s.replace('import {Placements}', 'import {originalPlacementSurface, Placements}').replace('import {KeyIndex}', 'import {originalKeyIndexSurface, KeyIndex}').replace('import {Clock, ROOT,', 'import {originalClockSurface, Clock, ROOT,');
s=s.replace('        const main: Line = {key: MAIN, owner: null, slot: "", items: [], inserted: 0};','        docAllocations.set(this, {lineMap: this.lineMap, byKey: this.byKey, placements: this.placements, clock: this.clock});\n        const main: Line = rememberLine({key: MAIN, owner: null, slot: "", items: [], inserted: 0});');
s=s.replaceAll(/const line: Line = (\{[^\n]+items: \[\], inserted: 0\});/g,'const line: Line = rememberLine($1);');
s=s.replace(/line = (\{[^\n]+items: \[\], inserted: 0\});/g,'line = rememberLine($1);');
s=s.replace('        if (this.schema?.domain === "graphic") {\n            // Validate the complete batch', '        const privatePoint = activePrivatePoint?.doc === this && activePrivatePoint.edits === edits;\n        if (privatePoint) activePrivatePoint = null; // one immediate use, not Doc validity\n        if (this.schema?.domain === "graphic" && !privatePoint) {\n            // Validate the complete batch');
s=s.replace('    snapshot(): Snapshot {\n        const fields', '    snapshot(): Snapshot {\n        const audit = activeSnapshot?.source === this ? activeSnapshot : null;\n        if (audit && !snapshotSource(this)) audit.safe = false;\n        const fields');
s=s.replace('        return {\n            ...(capabilities.length ? {format: 2 as const, capabilities, moves: copyStoredValue(this.placements.values())} : {}),','        const snapshot: Snapshot = {\n            ...(capabilities.length ? {format: 2 as const, capabilities, moves: copyStoredValue(this.placements.values())} : {}),');
// Literal string matching with backtick string avoids generator syntax ambiguity.
if(!s.includes('const result = map.call(items,')) {
 const a=s.indexOf('            lines: [...this.lineMap.values()].map(line => ({',s.indexOf('    snapshot(): Snapshot'));
 const b=s.indexOf('\n    static fromSnapshot',a);
 if(a<0||b<0)throw Error('snapshot anchor');
 s=s.slice(0,a)+`            lines: [...this.lineMap.values()].map(line => {
                const key = line.key, owner = line.owner?.key ?? null, slot = line.slot;
                const items = line.items, map = items.map;
                if (audit?.safe && (!lineArrays.has(line) || lineArrays.get(line) !== items ||
                    !nativeItemsArray(items, map) || typeof key !== "string" ||
                    owner !== null && typeof owner !== "string" || typeof slot !== "string")) audit.safe = false;
                const result = map.call(items, (item: Item, i: number) => {
                    const previous = line.items[i - 1];
                    const json = itemToJSON(item, previous);
                    if (audit?.safe && !pureItemWrapper(json)) audit.safe = false;
                    return json;
                });
                return {key, owner, slot, items: result};
            }),
        };
        if (audit?.safe && (typeof snapshot.lamport !== "number" || !snapshotSource(this))) audit.safe = false;
        if (audit) audit.snapshot = snapshot;
        return snapshot;
    }
`+s.slice(b);
}
await writeFile(p,s);
