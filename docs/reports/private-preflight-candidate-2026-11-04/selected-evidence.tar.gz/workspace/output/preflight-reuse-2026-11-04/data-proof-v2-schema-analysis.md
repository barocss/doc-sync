# V2 schema provenance boundary

Analysis disposition: HOLD pending the parent's contract decision. Read-only analysis of the frozen candidate. No candidate, terminal, protocol, report, or independent test was changed.

The independent count failure is real. Its `custom-schema` case uses `structuredClone(createDataSchema())`, passes that result to `typescriptClientEngineFactory.create`, seeds an entry, then applies one value update. Public outputs match. Baseline executes four compiler entries and three pairs; candidate executes three entries and two pairs. Therefore the frozen candidate does not satisfy a rule that this exact input must use legacy counts. The prior producer pass did not include this newly explicit custom-schema count requirement in its own negative census. The independent receipt is authoritative for that additional gate.

## Actual API call graph

1. `data/schema.ts:createDataSchema` returns a new plain schema object. It does not brand, freeze, register, or retain the returned identity.
2. Both `factory.create(actor, createDataSchema())` and `factory.create(actor, structuredClone(createDataSchema()))` call the same `TypeScriptClientEngine` constructor in `engine/typescript-client.ts`.
3. The constructor invokes `ownSchema`, an alias of `ownEngineSchema` in `crdt/private-data.ts`.
4. `ownEngineSchema` runs schema-version validation, finite plain-JSON validation, a new host structuredClone, and recursive freeze. It registers only that new owned output if its JSON fingerprint equals the default fingerprint. The caller's input identity is never registered.
5. The resulting owned schema becomes both the engine definition and Doc schema. `isOwnedDefaultData` later requires that exact output identity. A raw default-looking object passed directly to Doc, a public restore with an unowned schema, or an externally frozen object passed directly to Doc does not qualify.

Consequently, the custom-schema test's cloned input has exactly the same factory-output provenance as the direct positive input. Both are validated and copied again. A clone cannot bypass validation, retain caller aliases, or install callbacks in the owned schema. This test exposes a scope/count mismatch, not a demonstrated construction escape or changed public semantic result.

## Conflicting readings of the stated bound

The protocol prose says that the engine owns schema input through its existing validate/copy/freeze factory and records the exact default fingerprint. The producer prompt likewise says: "Schema provenance minted actual engine validate/copy/deepfreeze factory only". Under this **factory-output ownership** rule, the cloned default is eligible. Any finite plain input with that exact fingerprint becomes owned only after the real factory succeeds. A value-different custom schema remains ineligible. External freezing is not authority; the actual factory is authority.

The same protocol's proof table says: "Factory-owned exact default fingerprint; custom/raw/frozen schemas do not qualify". The independent count gate interprets **input-origin ownership**: a cloned default passed to the factory remains custom and must retain legacy staging. The current implementation has no means to distinguish those input origins. The default schema factory currently leaves no non-forgeable identity record. Fingerprinting and validation cannot recover that history after cloning.

These readings must not be merged silently. The existing safety argument is sufficient only for the explicitly implemented factory-output rule. It does not implement input-origin identity exclusion. If the literal independent gate is the accepted contract, the frozen producer is HOLD for scope even though its public equivalence and private construction evidence still hold on this case. If the parent instead confirms the factory-output rule, that must be an explicit contract decision and the protocol/test conflict must be resolved by their owners. The producer must not relax the independent gate itself.

## Minimal repair if input-origin exclusion is required

Extend the copied `data/schema.ts` defining factory, as the seventh affected module. Keep a private WeakSet of its actual returned schema identities. Only `createDataSchema` can add an identity. Export an internal predicate for the private factory; do not add a public package/barrel export or a callable registrar.

`ownEngineSchema` can then remember whether its input is an actual recorded factory result (or an already engine-owned schema when an existing internal flow legitimately recopies it). It must still run the existing full validation, defensive copy, and recursive freeze. It may register the owned output only when that input-origin condition and the exact copied fingerprint both hold. Clones, lookalikes, Proxies, and unrelated raw schemas fail the origin condition. Mutation of a genuine source still fails the copied fingerprint when it changes the default shape.

This repair preserves the direct positive call path and makes `structuredClone(createDataSchema())` use legacy staging without changing its public results or bypassing any copies. It needs renewed source hashes, producer tests including the exact custom negative count rule, independent tests, and High review. No code was changed in this analysis.

The phrase "frozen schemas" also needs the same precise meaning. A frozen caller object never gains authority from freezing. A genuine `createDataSchema` result that the caller freezes still retains its true origin under the proposed brand. If the contract intends even that genuine object to fall back, it needs an explicit additional input condition; it does not follow from provenance or safety. Do not add an arbitrary freeze rejection without that decision.

Do not use the test's non-UUID `id: 'data:entry'`, fixture name, actor, or any unrelated shape difference to force this one case to fall back. Such a change would hide the schema-origin defect and leave cloned schemas eligible elsewhere.

Frozen source closure remains `d6106051dccaac969849fac5ef24199690ccddf7a452cdeccdcc94606149d3ab` (70 source files; sorted per-file SHA-256 entry digest). Independent receipt: `data-tests-v2/runs/2026-11-03T19-56-31-358Z/receipt.json`. No timing, promotion, or broader approval follows from this analysis.
