import {readdir,readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join,relative,dirname} from 'node:path';
const out=import.meta.dirname,root=resolve(out,'../..'),dest=join(out,'candidate-v2'),src=join(root,'packages/doc-sync/src');
const hash=b=>createHash('sha256').update(b).digest('hex');
async function inventory(dir,base=dir){const result={};for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())Object.assign(result,await inventory(p,base));else result[relative(base,p)]=hash(await readFile(p));}return result;}
try{await readFile(join(dest,'initial.json'));throw Error('Existing V2 checkpoint; refuse overwrite');}catch(e){if(e.code!=='ENOENT')throw e;}
const files=await inventory(src);if(Object.keys(files).length!==69)throw Error('69-file boundary');
const old={};for(const e of await readdir(out,{withFileTypes:true})){if(e.name.startsWith('data-')||e.name==='candidate-v2')continue;const p=join(out,e.name);if(e.isDirectory())Object.assign(old,Object.fromEntries(Object.entries(await inventory(p)).map(([k,v])=>[e.name+'/'+k,v])));else old[e.name]=hash(await readFile(p));}
for(const f of Object.keys(files)){const p=join(dest,'packages/doc-sync/src',f);await mkdir(dirname(p),{recursive:true});await copyFile(join(src,f),p);}
await copyFile(join(root,'packages/doc-sync/package.json'),join(dest,'packages/doc-sync/package.json'));
await writeFile(join(dest,'initial.json'),JSON.stringify({node:process.version,files,old},null,2)+'\n');
console.log(JSON.stringify({node:process.version,copied:69,oldPreserved:Object.keys(old).length}));
