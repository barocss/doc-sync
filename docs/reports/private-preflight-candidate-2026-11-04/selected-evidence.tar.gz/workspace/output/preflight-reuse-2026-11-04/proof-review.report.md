# Independent private preflight proof review

## Disposition: HOLD — actual optimized producer not delivered

Started: 2026-11-03T18:56:33Z. Terminal producer and independent test reports read by 2026-11-03T19:04:26Z. Final source capture: 2026-11-03T19:05:06.932957Z (2026-11-04 Asia/Seoul).

**Do not issue APPROVE_PROOF.** The exact candidate Core bytes are unchanged baseline bytes. They contain no new private factory, construction audit, schema provenance, ordering deferral, or stage removal. Counts remain three snapshot/restore pairs and four compiler entries. There is no bounded eligible optimized path to approve.

This is a delivery gap, not an executed failure of an implemented factory. The writer stopped after concrete output-only probes and issued HOLD. The probes refute proposed proof premises. They do not prove that a properly bounded factory is impossible. The authorized actual construction/ordering implementation remains unfinished. A parent follow-up must supply that producer before an implementation-safety verdict is possible. This review did not stop early while the writer was building.

No production promotion, performance approval, workspace approval, or release approval is given.

## Evidence boundary

| Category | Result | Exact boundary |
| --- | --- | --- |
| CONTRACT | NOT_CLOSED | Private non-escape, single-use authority, schema provenance, and compiler-before-model proof have no implemented producer. |
| CODE | Preservation PASS; optimization NOT_IMPLEMENTED | Live 69 files equal archive, initial inventory, and candidate Core. Candidate adds only local package context. |
| FUNCTIONAL | Baseline 64 PASS / 0 FAIL / 0 SKIP | Independent lane receipt; not rerun by this reviewer. Candidate executions 0; equivalence executions 0; real Data reductions 0. |
| Reviewer tiny probe | PASS, one source case | Retained Placement closure mutates the unchanged candidate's private-copy abstraction. Not an installed factory. |
| PERFORMANCE | NOT_RUN | Structural counts only. No speed, timing, heap, or allocation-size claim. |

The writer separately reports ten matched runner groups on baseline and the identical copy. Those are not optimized proof passes. The parent's production qualification, 2084 cases / 2082 PASS / 2 SKIP, is supplied context. This lane did not rerun or extend it.

## 1. Actual code and integration

Paths below are relative to `candidate-src/`. These files equal live Core byte for byte.

- `engine/typescript-client.ts:121,217-226` retains original clone selection and engine preflight. There is no alternate private factory branch.
- `crdt/doc.ts:2243-2270` retains initial guard, engine preflight, graphic validation copy/compiler, before-model read, own compiler, and normalized semantic proof.
- `crdt/doc.ts:2575-2673,2715-2745` retains constructor/schema/snapshot admission, per-register copies, identity/span/head/capability/reserved/move checks.
- `crdt/doc.ts:2274-2276,2528-2549` retains emit/run and weak-map priors. There is no staged-Doc adoption, prepared-op replay, raw-apply commit, public flag, or output dependency.

No new regression is established in the retained staged implementation. Unchanged code also cannot prove the optimization. Passing public fallback tests does not establish private authority.

## 2. Findings, triggers, and minimum remedies

### F1 — the proposed shape restriction does not prove storage-neutral model reading

**Trigger:** actual engine-owned Data schema; existing root entry; empty sibling Map; no authored moves; one ordinary `value` update. Reading the restored copy's model creates the sibling's body head.

**Locations:** `crdt/doc.ts:395-433` creates implicit slot storage through `get`. Model/block reads reach it. `proof-implementation-ordering.mjs:15-26` tests the two schedules. Independent `proof-tests/child.mjs`, scenario `lazy-head-ordering`, reproduces it.

**Observed:** tokens 3→4; Lines 1→2; unchanged clock/version. The writer also records model/block/logical/projection cache changes. Compiling before versus after the read produces equal ops but unequal immediate snapshots. Later model reads converge.

**Limit:** this refutes storage neutrality. It is not an emitted-op divergence, a changed first error, or proof that every narrower schedule fails.

**Minimum remedy:** retain staging for unproved implicit storage, or prove narrower eligibility and compiler/cache equivalence without changing the source or probing foreign DTOs again. Preserve compiler-first errors separately. Deferring a model error alone is insufficient. Do not substitute rollback, clock rewind, or an attribute swap.

### F2 — Placement receives a retained Doc-mutation capability during the operation

**Trigger:** import only `crdt/placement.ts`; replace `Placements.prototype.project`; then import Doc/engine. The override retains `ownerOf`, restores itself, and calls the original. Restore and compile one ordinary-key update without authored moves.

**Actual dispatch:** `crdt/doc.ts:1766` passes `line => this.get(line)?.line.owner?.key ?? null` to `this.placements.project`; `crdt/placement.ts:20` receives it. This does not replace a standard global intrinsic. Capturing Placement originals only after its import is too late for this preload.

**Observed:** the method is original again after compilation. Calling the retained closure with the empty sibling's body key adds one private token/Line. Clock/version and source remain unchanged. See independent `proof-tests/projection-child.mjs:7-21` and writer `proof-implementation-projection-capability.mjs:5-22`.

I read both bodies and ran one tiny read-only candidate source case. `proof-review.projection-probe.json` records exit 0, empty stderr, Node v24.22.1, and stable runner hash. It explicitly uses an unstaged public abstraction, not a private factory.

**Minimum remedy:** root the relevant original in the Placement defining module. Audit the actual selected dispatch before passing private objects or closures. A mismatch must invalidate the local invocation permanently, including self-restoration. Keep the selected legacy call/receiver/error trace on fallback. If this exceeds the approved few-file scope, obtain a bounded revision or retain staging. No-move admission and restore-only witnessing do not close it.

### F3 — nested KeyIndex calls and retained loader closures are audit boundaries

**Locations:** `crdt/doc.ts:2598-2609` gives an item iteration its loader callback and inserts fresh Items. `crdt/key-index.ts:61` calls `this.find` while outer `set` can remain original. Writer `proof-implementation-construction.mjs:18-68` tests a self-restoring nested find and retained callback.

The clock-exhaustion case proves exposure, not a changed rejection result. The late-bad-path case leaves the exposed value 1 under staging and 2 under the explicitly unstaged abstraction. Re-entering the retained loader pushes an Item before duplicate-identity rejection. The latest body asserts this through the exposed index/Line, not final descriptor equality.

**Minimum remedy:** audit each selected iteration/nested dispatch before it gets fresh references or callback authority. Keep unsafe state monotonic. A bare allocation registry, final descriptor scan, public registrar, or reusable Doc flag is insufficient. The actual candidate installs none of these shortcuts; it installs no witness at all.

### F4 — future test scheduling must not parse readiness by substring

**Location:** `proof-tests/run.mjs:19` uses `/PROOF_READY/.test(final)` and excludes only an IN_PROGRESS protocol.

**Trigger:** `NOT_PROOF_READY` or `HOLD: not PROOF_READY` in terminal text, with a HOLD protocol, opens this scheduling gate. Current terminal text contains HOLD without that substring. Thus this did **not** cause a candidate execution or false PASS here. The driver also explicitly stops short of private qualification.

**Minimum remedy before automated reuse:** require a structured terminal disposition exactly equal to `PROOF_READY`, reject HOLD, and bind the receipt to the candidate closure. Independent contract/source review remains mandatory. This reviewer did not edit the test lane.

## 3. Independent test-body assessment

Read the actual `proof-tests/child.mjs`, `fixtures.mjs`, `legacy-child.mjs`, `projection-child.mjs`, and `run.mjs`, not just writer smoke or summary counts.

- Whole-tree imports and isolated child processes avoid mixed class realms. Before/end manifests cover all candidate files. Core/candidate/driver bytes still match the accepted run.
- Real N=20 public-created root/nested Map/List fixtures and separate no-move restores test returned ops/tickets/priors, snapshot/clock/version, History, values, Doc/Item/Line identity, notifications, undo/redo, and foreign overwrite/delete. Only History wall-clock grouping times are normalized. Existing JSON-backed negative-zero redo behavior is explicit.
- Input tests require one clone of original valid input, guard mutation isolation, and zero rejected-accessor reads.
- Negative bodies assert specific outcomes for C1/C2 map/species/getter routes, transient escape, compiler/model error order, normalization-only failure, guard/clock rejection, receiver traces, selected restore order/late replacement, alias separation, admission, and sessions/checkpoint. They do not allow either success or error indiscriminately.
- Positive counters do not replace Doc snapshot/restore/edit/emit descriptors. The scalar structuredClone census counts payload-copy events, not bytes or heap. Source/stack anchors must be checked against a changed producer.
- Baseline one-entry counts are 3/3 snapshot/restore scalar copies, four compiler entries, two live snapshot calls. Count gates distinguish exact private-pair reduction from unchanged fallback. No candidate ran, so no reduction gate passed.

Normal Data creation retains placements. Writer fixtures retain moves 1/3/3 for root/nested/List. Excluding placements excludes these ordinary fixtures. A legacy no-move positive cannot be generalized to normal Data eligibility.

Open coverage includes private authority/non-forgeability itself, all session failures, conditional intent installation, schema preview/upgrade, broader recovery, raw/owned schema controls, and all field/movement bounds. The custom factory case constructs SyncClient and invokes its observable engine; it is not full conditional/recovery product evidence. Baseline PASS does not close these obligations.

## 4. Exact checkpoint and source closure

Capture: **2026-11-03T19:05:06.932957Z**.

Digest algorithm: SHA-256 of concatenated UTF-8 lines `file_sha256 + two spaces + relative_path + LF`, ordered by relative path. This differs from the writer's JSON-entry digest algorithm. Both bind the same 69 Core bytes.

| Closure | Files | SHA-256 |
| --- | ---: | --- |
| Live Core = frozen archive = initial inventory = candidate Core | 69 | `8b532beb32d4ef0e7d69e54ac9a989d269d0c590e11d6ef8f3f0545b362c4a51` |
| Entire candidate tree, including package.json | 70 | `4e22242aa376ee5a39e9f8c21c28e0c1f88048f3d47ef7be0e776c1a1dd89c2d` |
| Independent executable drivers below | 5 | `15d9289440808b89d4d735720e3f43c9a55225aefe99c920b6f696a5362bc98b` |

Per-file Core manifests: `proof-implementation-source-initial.json`, `proof-implementation-source-final.json`, and accepted independent run `source-before.json` / `source-after.json`. All 69 production files still match the archive. No rejected COW helper was introduced.

| Reviewed source/artifact | SHA-256 |
| --- | --- |
| candidate-src/crdt/doc.ts | `dc7b89dd1c18a05268ad0b238e04627c640135ba0619264a5aa6fd501e6e294d` |
| candidate-src/crdt/key-index.ts | `ff447129ce1d006ae1cb24430b21d448fbb41dc043098145b07a3bcee126a1dd` |
| candidate-src/crdt/placement.ts | `ad27804d11d719f95a6e138e3eabcf904cec515df84108a3e264471d41845e1d` |
| candidate-src/crdt/ticket.ts | `70f8b71bac19b6f9039056570256ac41890f99fdc46da1675e91bd875aed8298` |
| candidate-src/engine/typescript-client.ts | `dbfedab406844f1e79c4d77656787ae0c438e09212c84f30efc06ad109b0d421` |
| protocol.md | `8db008e06aead260eb1e53d800df68cd80869f51817f8ea76b1b42c44a777da9` |
| proof-implementation.report.md | `fffed687b18028126c69da7b2868324918e6449426c4e671d2bdda99960f9952` |
| proof-implementation.final.md | `7b6a7c04a47a0cbe306b4416705003471117a7e52914cc3c3cf3da053617ecae` |
| proof-tests/child.mjs | `21ec064927de2d921e457ae8b4e5c52e0b94b358ee4c882b9c2d3bf306b84a73` |
| proof-tests/fixtures.mjs | `566b92de2c7fb6f7b6bd8e3803638eca793d76fec68667449dbb1cffafefab3e` |
| proof-tests/legacy-child.mjs | `7df2b6d0c858fe14a0e9ec744195b4754288df7ce19e2ba0a10d9514d9380786` |
| proof-tests/projection-child.mjs | `04643d4f2d572487b8dcf373de3634abf2e60ccc781b169a589d0b837e226ea3` |
| proof-tests/run.mjs | `26d61bb4ae8bab32e1e03a72a5803940650e80291f62af6a041d757eaee74159` |

Independent receipt: `proof-tests/runs/2026-11-03T19-03-49-118Z/receipt.json`, SHA-256 `d93acfa82a61ce3af52d30604b4e3b4fce4c6e100a7047d56722870d94fc8d2d`. It records 64 baseline PASS, zero candidate/equivalence executions, zero count failures, and zero real Data reductions. Source, archive, candidate, protocol, and driver were stable during that run. Core/candidate/driver bytes still match at review capture.

Reviewer probe: `proof-review.projection-probe.json`, executed 2026-11-03T19:01:49Z. Its runner hash before/after is `1f0933daf8d6c1bcd84fbca82d6e352d1e7dc3a3870d99751274d1b368615742`.

Final read-only verification at 2026-11-03T19:07:17Z confirmed the same live/candidate closure digests and all listed source/artifact file hashes.

## 5. Handoff and ownership

Keep production and its qualification unchanged. Do not promote this tree or describe it as a successful optimized private POC. The next implementation must close the concrete dispatch/storage obligations and demonstrate an actual eligible reduction on exact bytes. Then independent candidate tests and a new review can judge it. Parent controls later promotion, full regression, packaging, Chrome proof, and serialized performance gates.

Owned writes: this report, `proof-review.final.md`, and one tiny probe receipt. No production/candidate/test/docs/benchmark mutations; no broad AGENT/sibling/memory scan; no global build/dist/package/CI effects; no timing/browser/mobile/commit/push; no further agents. A read-only hash-summary command had an absolute/relative path formatting error, then succeeded after correction. An initial report patch was rejected before any write; only owned report files were then written.
