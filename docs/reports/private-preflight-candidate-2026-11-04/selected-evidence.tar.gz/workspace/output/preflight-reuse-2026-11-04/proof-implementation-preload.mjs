import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const core=resolve(process.env.DOC_SYNC_CORE_ROOT),load=p=>import(pathToFileURL(`${core}/${p}`).href);
const {Doc}=await load('crdt/doc.ts');const {Clock}=await load('crdt/ticket.ts');const {createDataSchema}=await load('data/schema.ts');
const originalModel=Doc.prototype.toJSON,originalNext=Clock.prototype.next,originalRestore=Object.getOwnPropertyDescriptor(Doc,'fromSnapshot');
const mode=process.argv[2],sentinel={mode},trace=[];
if(mode==='model'||mode==='model-valid')Doc.prototype.toJSON=function(){trace.push('model');throw sentinel;};
if(mode==='clock')Clock.prototype.next=function(){trace.push(`clock:${this.actor}:${this.lamport}`);throw sentinel;};
if(mode==='clone-order')Object.defineProperty(Doc,'fromSnapshot',{configurable:true,get(){trace.push('restoreSelect');return function(...args){trace.push('restoreCall');assert.equal(this,Doc);return originalRestore.value.apply(this,args);};}});
// The implementation module is imported AFTER the defining-module overrides above.
const {typescriptClientEngineFactory}=await load('engine/typescript-client.ts');
const actor='preload-proof',e=typescriptClientEngineFactory.create(actor,createDataSchema()),d=e.typescriptDocument();
d.apply({t:'node',id:{lamport:1,actor},origin:{lamport:0,actor:'~root'},type:'entry',attrs:{id:'data:proof',key:'proof',value:{scalar:1}}});
const before=d.snapshot(),value=()=>d.get(`1@${actor}`).attrs.get('value').value.scalar;
let error;
if(mode==='clone-order'){
 Object.defineProperty(e,'actor',{configurable:true,get(){trace.push('actor');return actor;}});
 const schema=d.schema;Object.defineProperty(d,'schema',{configurable:true,get(){trace.push('schema');return schema;}});
 d.snapshot=function(){trace.push('snapshot');assert.equal(this,d);return before;};
 e.apply([{op:'update',at:[0],attrs:{value:{scalar:2}}}]);assert.equal(value(),2);
 const start=trace.indexOf('restoreSelect');assert.ok(start>=0);assert.deepEqual(trace.slice(start,start+5),['restoreSelect','actor','snapshot','schema','restoreCall']);
 assert.equal(trace.filter(x=>x==='snapshot').length,2); // outer P clone and live atomic clone, both preserved
 error=null;
}else if(mode==='species'){
 const items=d.items;let allocated;
 const species=function(length){trace.push(`species:${length}`);allocated=new Array(length);return allocated;};
 Object.defineProperty(items,'constructor',{configurable:true,get(){trace.push('constructor');return {[Symbol.species]:species};}});
 e.apply([{op:'update',at:[0],attrs:{value:{scalar:2}}}]);assert.equal(value(),2);assert.ok(allocated);assert.ok(trace.length>0);
 error=null;
}else{
 try{e.apply([{op:'update',at:mode==='model'?[99]:[0],attrs:{value:{scalar:2}}}],{normalize:true});}catch(err){error=err;}
 assert.ok(error);assert.deepEqual(d.snapshot(),before);assert.equal(value(),1);
 if(mode==='model'){assert.notEqual(error,sentinel);assert.equal(trace.length,0);}
 if(mode==='model-valid'){assert.equal(error,sentinel);assert.deepEqual(trace,['model']);}
 if(mode==='clock'){assert.equal(error,sentinel);assert.equal(trace.length,1);}
}
Doc.prototype.toJSON=originalModel;Clock.prototype.next=originalNext;Object.defineProperty(Doc,'fromSnapshot',originalRestore);
console.log(JSON.stringify({core,node:process.version,mode,trace,error:error===sentinel?'EXACT_SENTINEL':error?.message??null,liveValue:value(),unchanged:mode==='species'||mode==='clone-order'?null:true},null,2));
