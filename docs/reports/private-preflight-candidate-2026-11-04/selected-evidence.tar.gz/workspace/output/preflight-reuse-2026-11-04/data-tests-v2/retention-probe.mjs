import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,readdirSync,writeFileSync,mkdirSync,realpathSync} from 'node:fs';
import {registerHooks} from 'node:module';
import {spawnSync} from 'node:child_process';
import {resolve,join,sep} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
assert.equal(process.version,'v24.22.1');
const own=import.meta.dirname,repo=resolve(own,'../../..');
const sha=x=>createHash('sha256').update(x).digest('hex');
const manifest=tree=>Object.fromEntries(readdirSync(tree,{recursive:true}).filter(p=>p.endsWith('.ts')).sort().map(p=>[p,sha(readFileSync(join(tree,p)))]));
const driverSHA=sha(readFileSync(fileURLToPath(import.meta.url)));
if(process.argv[2]==='--child'){
 assert.equal(typeof globalThis.gc,'function','Requires explicit --expose-gc');
 const source=realpathSync(process.argv[3]),before=manifest(source),loaded=new Set();
 registerHooks({resolve(specifier,context,next){const r=next(specifier,context);if(r.url.startsWith('file:')){const p=realpathSync(fileURLToPath(r.url));assert(p.startsWith(source+sep)&&p.endsWith('.ts'),'Import outside selected source: '+p);loaded.add(p.slice(source.length+1));}else assert(r.url.startsWith('node:'));return r;}});
 const load=p=>import(pathToFileURL(join(source,p)).href);
 const {Client,clientOwner}=await load('client/index.ts'),{createDataSchema}=await load('data/schema.ts');
 const turn=()=>new Promise(resolve=>setImmediate(resolve));
 // Fixed schedule, never conditional on collection results. Every deref occurs
 // only AFTER a completed schedule, and another turn precedes subsequent GC.
 const collect=async()=>{await turn();for(let i=0;i<8;i++){globalThis.gc();await turn();}};
 const frozen=x=>!x||typeof x!=='object'||Object.isFrozen(x)&&Object.values(x).every(frozen);
 const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
 function makeClient(actor){const c=new Client({actor,schema:createDataSchema()}),data=c.data,map=data.createMap(),list=data.createList();data.root.set('nested',map);data.root.set('list',list);data.root.set('root',1);map.set('nested',2);const id=list.push(3);data.root.set('root',11);map.set('nested',12);list.set(id,13);return {c,map,list,id};}
 function references(c){const engine=clientOwner(c).engine,doc=engine.typescriptDocument(),lines=doc.snapshot().lines.map(l=>doc.get(l.key).line);return {client:new WeakRef(c),engine:new WeakRef(engine),doc:new WeakRef(doc),schema:new WeakRef(doc.schema),lines:lines.map(l=>new WeakRef(l)),arrays:lines.map(l=>new WeakRef(l.items))};}
 const alive=refs=>({client:!!refs.client.deref(),engine:!!refs.engine.deref(),doc:!!refs.doc.deref(),schema:!!refs.schema.deref(),lines:refs.lines.filter(w=>w.deref()).length,arrays:refs.arrays.filter(w=>w.deref()).length});
 const snapshotEntries=[],weak=[];let snapshotsInitiallyFrozen=0;
 function createDisposable(i){const {c,map,list,id}=makeClient('retention-'+i),snapshot=c.snapshot(),entry=c.data.root.candidates('root').at(-1);assert(frozen(entry));if(frozen(snapshot))snapshotsInitiallyFrozen++;const saved=structuredClone(snapshot);freeze(snapshot);assert(frozen(snapshot));weak.push(references(c));snapshotEntries.push({snapshot,saved,entry,entrySaved:structuredClone(entry),id});c.dispose();}
 for(let i=0;i<12;i++)createDisposable(i);
 // A separate live client supplies mutation isolation and a strong-root control.
 const other=makeClient('retention-other'),otherBefore=other.c.snapshot();
 function createHeld(){const f=makeClient('retention-held'),refs=references(f.c);f.c.dispose();return {client:f.c,refs};}
 let holder=createHeld();const heldRefs=holder.refs;
 await collect();
 const disposedObservations=weak.map(alive),heldWhileRooted=alive(heldRefs);
 assert(heldWhileRooted.client&&heldWhileRooted.engine&&heldWhileRooted.doc,'Held Client control must retain engine/Doc');
 assert.deepEqual(other.c.snapshot(),otherBefore);
 for(const s of snapshotEntries){assert.deepEqual(s.snapshot,s.saved);assert(frozen(s.snapshot));assert.deepEqual(s.entry,s.entrySaved);assert(frozen(s.entry));}
 // No dereferenced object is stored across turns; observations contain only
 // primitives. Release the holder after the first observation, then cross a turn.
 function releaseHeld(){holder=null;}
 releaseHeld();
 await collect();
 const heldAfterRelease=alive(heldRefs);
 assert.deepEqual(other.c.snapshot(),otherBefore);
 // Mutating another client cannot change held detached public artifacts.
 other.c.data.root.set('root',99);
 for(const s of snapshotEntries){assert.deepEqual(s.snapshot,s.saved);assert.deepEqual(s.entry,s.entrySaved);}
 other.c.dispose();
 assert.deepEqual(manifest(source),before,'Source changed');
 const clear=o=>!o.client&&!o.engine&&!o.doc&&!o.schema&&o.lines===0&&o.arrays===0;
 const report={status:disposedObservations.every(clear)&&clear(heldAfterRelease)?'OBSERVED_RECLAIMED':'NOT_COLLECTED',source,sourceSHA:sha(JSON.stringify(before)),sourceFiles:before,sourceUnchanged:true,driverSHA,loadedSourceFiles:[...loaded].sort(),node:process.version,execArgv:process.execArgv,disposedCount:12,disposedObservations,heldWhileRooted,heldAfterRelease,snapshotControl:{retainedSnapshots:snapshotEntries.length,snapshotsInitiallyDeepFrozen:snapshotsInitiallyFrozen,harnessDeepFreezesSnapshots:true,detachedFrozenFacadeEntries:true,retainedArtifactsUnchanged:true,otherClientUnmodifiedUntilExplicitWrite:true},schedule:'Two fixed schedules: 8 explicit GC calls with setImmediate turns; no conditional retries and no timers',limits:'WeakRef observation only. No general GC guarantee, private-P enumeration, leak-free/heap-size/performance claim.'};
 console.log(JSON.stringify(report));
}else{
 assert.equal(process.argv.length,2,'No arguments accepted in coordinator mode');
 const runDir=join(own,'retention-runs',new Date().toISOString().replace(/[:.]/g,'-'));mkdirSync(runDir,{recursive:true});
 const sources={baseline:join(repo,'output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src'),candidate:join(own,'../candidate-v2/packages/doc-sync/src')};
 const before=Object.fromEntries(Object.entries(sources).map(([k,v])=>[k,manifest(v)])),results={};
 assert.equal(sha(JSON.stringify(before.candidate)),'fd49e2f3c695cfa40b3c16c28a72624158becb71a3788bf7d1bd6223c70a5862');
 for(const [lane,source] of Object.entries(sources)){const r=spawnSync(process.execPath,['--expose-gc',fileURLToPath(import.meta.url),'--child',source],{encoding:'utf8',timeout:30000});writeFileSync(join(runDir,lane+'.stdout.log'),r.stdout??'',{flag:'wx'});writeFileSync(join(runDir,lane+'.stderr.log'),r.stderr??'',{flag:'wx'});results[lane]={exit:r.status,signal:r.signal,error:r.error?.message};try{results[lane].observation=JSON.parse(r.stdout);}catch{};}
 const after=Object.fromEntries(Object.entries(sources).map(([k,v])=>[k,manifest(v)]));assert.deepEqual(after,before,'Selected source changed');assert.equal(sha(readFileSync(fileURLToPath(import.meta.url))),driverSHA);
 const receipt={node:process.version,driverSHA,before,after,sourceUnchanged:true,results,timing:'NOT_RUN',scope:'Bounded weak ownership observation only'};writeFileSync(join(runDir,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({runDir,driverSHA,results:Object.fromEntries(Object.entries(results).map(([k,r])=>[k,{exit:r.exit,status:r.observation?.status??'INCONCLUSIVE',heldAfterRelease:r.observation?.heldAfterRelease}]))},null,2));
}
