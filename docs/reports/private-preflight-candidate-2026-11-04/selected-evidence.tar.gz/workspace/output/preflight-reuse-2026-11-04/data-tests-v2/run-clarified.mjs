import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {join,resolve,relative} from 'node:path';
import assert from 'node:assert/strict';
assert.equal(process.version,'v24.22.1');
const dir=import.meta.dirname,out=resolve(dir,'..'),repo=resolve(dir,'../../..'),old=join(out,'proof-tests');
const archive=join(repo,'output/refactor-2026-11-03/post-refactor-baseline/packages/doc-sync/src'),live=join(repo,'packages/doc-sync/src');
const hash=b=>createHash('sha256').update(b).digest('hex');
async function manifest(tree){const r={};async function visit(d){for(const e of (await readdir(d,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const p=join(d,e.name);if(e.isDirectory())await visit(p);else r[relative(tree,p)]=hash(await readFile(p));}}await visit(tree);return r;}
async function maybe(p){try{return await readFile(p,'utf8');}catch{return null;}}
// Reuse the exact old case inventory and drivers. Do not rerun their orchestrator:
// it writes outside this worker's ownership and selects the live tree as baseline.
const oldRunner=await readFile(join(old,'run.mjs'),'utf8');
const inventory=oldRunner.slice(oldRunner.indexOf('const scenarios=')+'const scenarios='.length,oldRunner.indexOf(';\nasync function hashes'));
const controls=Function('return '+inventory)();assert.equal(controls.length,64);
const extra=['normal:root','normal:nested','normal:list','empty:root:created','empty:nested:created','empty:list:created','empty:root:bulk','empty:nested:bulk','empty:list:bulk','flat-shared','commutation','bad-value','bad-path','bad-meta','clock-final','clock-overflow','custom-schema','saved-reopen','escape-find:two','escape-find:multi','projection-engine','public-register-alias','canonical-alias','bodyhead-collision','compiler-before-model:value','compiler-before-model:path','clone-default','raw-default','frozen-default','public-raw-default-stage'];
const clarificationPath=join(out,'scope-clarification-v2.md'),clarification=await readFile(clarificationPath,'utf8');
const runId=new Date().toISOString().replace(/[:.]/g,'-'),runDir=join(dir,'clarified-runs',runId);await mkdir(runDir,{recursive:true});
const producerPath=process.env.DATA_V2_PRODUCER?resolve(process.env.DATA_V2_PRODUCER):join(out,'data-proof-v2.final.md');
const protocol=await maybe(join(out,'data-protocol-v2.md')),producer=await maybe(producerPath);
await writeFile(join(runDir,'clarification-before.txt'),clarification);
await writeFile(join(runDir,'protocol-before.txt'),protocol??'ABSENT');await writeFile(join(runDir,'producer-before.txt'),producer??'ABSENT');
// Actual producer readiness, not a copied baseline, is required for execution.
const ready=!!protocol&&!!producer&&/(?:^(?:\*\*)?PROOF_READY(?:\*\*)?\s*$|(?:Disposition|Decision|Status):\s*(?:\*\*)?PROOF_READY\b)/mi.test(producer);
let candidate=process.env.DATA_V2_TREE?resolve(process.env.DATA_V2_TREE):join(out,'candidate-v2/packages/doc-sync/src');
const harness=async()=>{const all={};for(const d of [dir,old])for(const e of await readdir(d))if(e.endsWith('.mjs'))all[relative(out,join(d,e))]=hash(await readFile(join(d,e)));return all;};
const before={harness:await harness(),archive:await manifest(archive),live:await manifest(live),candidate:await manifest(candidate).catch(()=>null)};
await writeFile(join(runDir,'before.json'),JSON.stringify(before,null,2));
const rows=[];
for(const scenario of [...controls,...extra]){
 const row={scenario,reused:controls.includes(scenario)};
 for(const [name,tree] of [['baseline',archive],...(ready?[['candidate',candidate]]:[])]){
  const file=extra.includes(scenario)?join(dir,'extra-clarified-child.mjs'):join(old,scenario.startsWith('legacy-')?'legacy-child.mjs':scenario==='projection-preload'?'projection-child.mjs':'child.mjs');
  const r=spawnSync(process.execPath,[file,tree,scenario],{encoding:'utf8',timeout:30000,maxBuffer:24*1024*1024});
  const slug=scenario.replaceAll(':','-');await writeFile(join(runDir,`${name}-${slug}.stdout.log`),r.stdout??'');await writeFile(join(runDir,`${name}-${slug}.stderr.log`),r.stderr??'');
  row[name]={status:r.status===0?'PASS':'FAIL',exit:r.status,signal:r.signal,error:r.error?.message};
  if(r.status===0)try{row[name].value=JSON.parse(r.stdout.trim());}catch(e){row[name].status='FAIL';row[name].error=String(e);}
 }
 if(row.candidate){try{assert.equal(row.baseline.status,'PASS');assert.equal(row.candidate.status,'PASS');assert.deepEqual(clean(row.candidate.value),clean(row.baseline.value));row.equivalence='PASS';}catch(e){row.equivalence='FAIL';row.difference=String(e);}}
 try{countGate(row);}catch(e){row.countGate='FAIL';row.countError=String(e);}
 rows.push(row);
}
function clean(value){const x=structuredClone(value),keys=['compilerCalls','snapshotScalars','restoreScalars','liveSnapshots','scalarCopies'];for(const o of [x.observation,...(x.observation?.trials??[])])if(o)for(const k of keys)delete o[k];return x;}
function countGate(row){const b=row.baseline.value?.observation,c=row.candidate?.value?.observation;if(!b)return;const trials=b.trials??[b];if(row.scenario.startsWith('data:')||row.scenario.startsWith('empty:')||row.scenario.startsWith('normal:')||['stock-count','clone-default','raw-default','frozen-default'].includes(row.scenario)){
 for(const t of trials){assert.equal(t.compilerCalls,4);assert.equal(t.liveSnapshots,2);assert.equal(t.snapshotScalars,t.restoreScalars);assert.equal(t.snapshotScalars%3,0);}
 if(c){const ct=c.trials??[c];const reduced=ct.every((t,i)=>t.compilerCalls===3&&t.liveSnapshots===2&&t.snapshotScalars===trials[i].snapshotScalars*2/3&&t.restoreScalars===trials[i].restoreScalars*2/3);const legacy=ct.every((t,i)=>['compilerCalls','liveSnapshots','snapshotScalars','restoreScalars'].every(k=>t[k]===trials[i][k]));row.countGate=reduced?'REDUCED_PRIVATE_PAIR':legacy?'LEGACY_FALLBACK':'FAIL';}}
 else if(c&&['bad-value','bad-path','bad-meta','clock-overflow','bodyhead-collision','custom-schema','public-raw-default-stage'].includes(row.scenario)){for(const k of ['compilerCalls','liveSnapshots','snapshotScalars','restoreScalars'])assert.equal(c[k],b[k],'legacy fallback count '+k);row.countGate='LEGACY_FALLBACK';}
}
const after={harness:await harness(),archive:await manifest(archive),live:await manifest(live),candidate:await manifest(candidate).catch(()=>null)};await writeFile(join(runDir,'after.json'),JSON.stringify(after,null,2));
const digest=x=>hash(JSON.stringify(x));
const stable={harness:digest(before.harness)===digest(after.harness),archive:digest(before.archive)===digest(after.archive),live:digest(before.live)===digest(after.live),production69MatchesArchive:Object.keys(after.live).length===69&&digest(after.live)===digest(after.archive),candidate:before.candidate!==null&&digest(before.candidate)===digest(after.candidate),protocol:protocol===await maybe(join(out,'data-protocol-v2.md')),producer:producer===await maybe(producerPath),clarification:clarification===await maybe(clarificationPath)};
const counts={baselinePASS:rows.filter(r=>r.baseline.status==='PASS').length,baselineFAIL:rows.filter(r=>r.baseline.status==='FAIL').length,candidatePASS:rows.filter(r=>r.candidate?.status==='PASS').length,candidateFAIL:rows.filter(r=>r.candidate?.status==='FAIL').length,equivalenceFAIL:rows.filter(r=>r.equivalence==='FAIL').length,countFAIL:rows.filter(r=>r.countGate==='FAIL').length,normalDataReduced:rows.filter(r=>(r.scenario.startsWith('normal:')||(r.scenario.startsWith('data:')||r.scenario.startsWith('empty:'))&&r.scenario.endsWith('created'))&&r.countGate==='REDUCED_PRIVATE_PAIR').length};
const firstFailure=rows.find(r=>r.baseline.status==='FAIL'||r.candidate?.status==='FAIL'||r.equivalence==='FAIL'||r.countGate==='FAIL')?.scenario??null;
const receipt={firstFailure,runId,node:process.version,baselineRoot:archive,candidateRoot:candidate,producerPath,ready,qualification:!ready?'PENDING_PRODUCER':!stable.candidate||!stable.protocol||!stable.producer||!stable.harness||!stable.clarification?'INVALID_WRITER_CHANGED':firstFailure?'HOLD_FUNCTIONAL_FAILURE':counts.normalDataReduced<9?'NOT_USEFUL_POSITIVE_CENSUS_INCOMPLETE':'PENDING_PRIVATE_HIGH_REVIEW',stable,counts,digests:{archive:digest(before.archive),candidateBefore:digest(before.candidate),candidateAfter:digest(after.candidate)},rows};
await writeFile(join(runDir,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');await writeFile(join(dir,'latest-clarified-run.json'),JSON.stringify({runDir,...receipt,rows:undefined},null,2)+'\n');console.log(JSON.stringify({runDir,ready,qualification:receipt.qualification,counts,stable},null,2));
