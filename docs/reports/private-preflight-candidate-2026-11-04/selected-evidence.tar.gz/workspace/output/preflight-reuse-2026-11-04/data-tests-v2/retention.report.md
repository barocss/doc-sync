# Bounded weak ownership observation

Result: **OBSERVED_RECLAIMED in both source lanes**. Both child processes ended with exit 0. Timing was not run.

Receipt: `retention-runs/2026-11-03T20-14-36-757Z/receipt.json`. Separate raw stdout/stderr are retained for each child. Driver: `retention-probe.mjs`, SHA-256 `0aaac20751f72aca95320e4cf87fc0374da625a472c9d1415009fd4666228c2c`.

The probe ran pinned Node v24.22.1 with `--expose-gc`, sequentially in separate baseline/candidate child processes. Each loaded only its chosen source closure. Each created and disposed 12 actual Clients using default Data, root Map, nested Map and List writes, then dropped Client, engine, Doc, schema, Line and items-array strong references. It retained public snapshots and frozen facade entries. All 12 sets of weak references cleared in each lane: Client/engine/Doc/schema absent, Lines 0, arrays 0.

A separately retained disposed Client was the strong-root control. Before release, both lanes observed its Client, engine, Doc and schema reachable, with three Lines and three items arrays. After release and the second fixed schedule, all of those weak references cleared in both lanes.

Each schedule used exactly eight explicit GC calls separated by setImmediate event-loop turns. There were two schedules per child. WeakRef observations stored only primitive booleans/counts. A new turn preceded the second schedule, so earlier deref keep-alive semantics did not intentionally keep the released objects alive. The schedule was fixed before execution; collection results did not trigger retries. No clock or performance timer was read.

All 12 retained snapshots and facade entries remained unchanged after collection and after a separate live Client was edited. The separate live Client's snapshot remained unchanged until its explicit write. Facade entries were already deeply frozen. Public snapshots were **not** initially deeply frozen (0/12 in either lane); the harness recursively froze its detached copies. The result does not claim the public API freezes snapshots.

Source hashes before and after matched, as did the driver hash:

| Lane | Files | JSON source manifest SHA-256 |
|---|---:|---|
| Frozen baseline | 69 | `e2a96f7b3617705affb08c4754d2c3760e15ef1ce1803af158387d3b691ff271` |
| Candidate | 70 | `fd49e2f3c695cfa40b3c16c28a72624158becb71a3788bf7d1bd6223c70a5862` |

Source inspection identified new `docAllocations` and `lineArrays` WeakMaps, plus `realEngines` and `ownedDefaultData` WeakSets. The observed Docs/Lines/arrays are accessible through existing engine and Doc views. No private registry was exposed or instrumented. Private preflight Docs and lexical scopes were not directly enumerated.

This is a small weak ownership observation on one Node runtime and one fixed schedule. It does not establish a general GC guarantee, absence of all leaks, bounded retained memory, heap savings, allocation savings or performance. No production, candidate, test, benchmark, build, dist, browser, mobile or Git source was changed. Only the new probe and its output receipts/report were written.
