import {registerHooks} from 'node:module';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {actor,ticket,root,update,rejection,errorRecord,seed,value,state,deterministicIds,stableHistory} from '../proof-tests/fixtures.mjs';
assert.equal(process.version,'v24.22.1');
const [tree,scenario]=process.argv.slice(2),base=pathToFileURL(resolve(tree)+'/').href,load=p=>import(base+p);
// Extend the established public Data fixture in memory. Files and source trees
// remain unchanged. Original driver still supplies its exact public oracles.
if(scenario.startsWith('empty:')){
 const old=pathToFileURL(resolve(import.meta.dirname,'../proof-tests/child.mjs')).href;
 registerHooks({load(url,ctx,next){const r=next(url,ctx);if(url!==old)return r;let s=String(r.source);const needle='  target=data.createMap();';assert.equal(s.split(needle).length,2);s=s.replace(needle,needle+'\n  data.root.set("empty-map",data.createMap());data.root.set("empty-list",data.createList());');return {...r,source:s};}});
 process.argv[3]=scenario.replace('empty:','data:');await import(old);
}else{
 globalThis.__v2compilers=0;globalThis.__v2liveSnapshots=0;
 registerHooks({load(url,ctx,next){const r=next(url,ctx);let s=String(r.source);if(url===base+'crdt/edit.ts'){const n='export const compileEdits = (doc: Doc, ops: EditOp[]): Op[] => {';assert.equal(s.split(n).length,2);return {...r,source:s.replace(n,n+'\n globalThis.__v2compilers++;')};}if(url===base+'crdt/doc.ts'){const n='    snapshot(): Snapshot {';assert.equal(s.split(n).length,2);return {...r,source:s.replace(n,n+'\n if(this===globalThis.__v2live)globalThis.__v2liveSnapshots++;')};}return r;}});
 function census(doc,fn){globalThis.__v2live=doc;const bc=globalThis.__v2compilers,bs=globalThis.__v2liveSnapshots,clone=globalThis.structuredClone;let snapshotScalars=0,restoreScalars=0;globalThis.structuredClone=function(v,...args){if(v&&typeof v==='object'&&Object.hasOwn(v,'scalar')){const stack=new Error().stack;if(stack.includes('at itemToJSON '))snapshotScalars++;if(stack.includes('at itemFromJSON '))restoreScalars++;}return clone(v,...args);};try{return {output:fn(),compilerCalls:globalThis.__v2compilers-bc,liveSnapshots:globalThis.__v2liveSnapshots-bs,snapshotScalars,restoreScalars};}finally{globalThis.structuredClone=clone;}}
 let retainedOwner,projectionCalls=0;
 if(scenario==='projection-engine'){
  const {Placements}=await load('crdt/placement.ts'),original=Placements.prototype.project;
  Placements.prototype.project=function(records,ownerOf,gaps){projectionCalls++;retainedOwner=ownerOf;Placements.prototype.project=original;return original.call(this,records,ownerOf,gaps);};
 }
 const {Doc}=await load('crdt/doc.ts'),{KeyIndex}=await load('crdt/key-index.ts'),{createDataSchema}=await load('data/schema.ts'),{typescriptClientEngineFactory:factory}=await load('engine/typescript-client.ts');
 const result={scenario};
 if(scenario.startsWith('normal:')){
  const kind=scenario.split(':')[1],{Client,clientOwner}=await load('client/index.ts'),restore=deterministicIds();let c,map,list,id;
  try{c=new Client({actor,schema:createDataSchema()});const data=c.data;if(kind==='root')map=data.root;else if(kind==='nested'){map=data.createMap();data.root.set('nested',map);}else{list=data.createList();data.root.set('list',list);}if(list)id=list.push(1);else map.set('proof',1);}finally{restore();}
  const e=clientOwner(c).engine,d=e.typescriptDocument(),before=state(d),moves=before.snapshot.moves.length;assert.equal(moves,kind==='root'?1:3);const identities=before.snapshot.lines.flatMap(line=>d.get(line.key).line.items),lines=identities.map(item=>item.line);c.clearHistory();
  const notifications=[],stop=c.subscribe({modelEvents(edits,info){notifications.push({phase:'model',edits,info});},update(){notifications.push({phase:'update'});}});let ops;const original=c.edit;c.edit=function(...args){ops=original.apply(this,args);return ops;};
  const counts=census(d,()=>list?list.set(id,2):map.set('proof',2));assert.equal(list?list.get(id):map.get('proof'),2);assert.equal(e.typescriptDocument(),d);identities.forEach((item,n)=>{assert.equal(d.get(item.key),item);assert.equal(item.line,lines[n]);});const priors=ops.map(op=>op.t==='set'?d.priorOf(op):null),after=state(d),history=stableHistory(e.typescriptHistory());c.undo();assert.equal(list?list.get(id):map.get('proof'),1);c.redo();assert.equal(list?list.get(id):map.get('proof'),2);stop();result.observation={kind,retainedMoves:moves,before,after,ops,priors,history,notifications,identity:true,...counts,output:undefined};
 }else if(scenario==='public-register-alias'){
  const {d}=seed(factory,createDataSchema),snapshot=d.snapshot(),entry=snapshot.lines[0].items[1],shared=entry.a.find(([k])=>k==='value')[1];entry.a.push(['other',shared,`1@${actor}`]);const a=Doc.fromSnapshot(actor,snapshot,d.schema),b=Doc.fromSnapshot(actor,snapshot,d.schema),get=x=>x.get(`1@${actor}`).attrs;
  const av=get(a).get('value').value,ao=get(a).get('other').value,bv=get(b).get('value').value,bo=get(b).get('other').value,lv=get(d).get('value').value;assert.notEqual(av,ao);assert.notEqual(bv,bo);assert.notEqual(av,bv);assert.notEqual(av,shared);assert.notEqual(lv,av);
  shared.scalar=11;assert.deepEqual([av.scalar,ao.scalar,bv.scalar,bo.scalar,lv.scalar],[1,1,1,1,1]);av.scalar=22;assert.deepEqual([shared.scalar,ao.scalar,bv.scalar,bo.scalar,lv.scalar],[11,1,1,1,1]);lv.scalar=33;assert.deepEqual([shared.scalar,av.scalar,ao.scalar,bv.scalar,bo.scalar],[11,22,1,1,1]);ao.scalar=44;assert.deepEqual([av.scalar,bv.scalar,bo.scalar,lv.scalar],[22,1,1,33]);const publicSnapshot=b.snapshot();publicSnapshot.lines[0].items[1].a.find(([k])=>k==='value')[1].scalar=55;assert.equal(bv.scalar,1);
  result.observation={source:snapshot,a:a.snapshot(),b:b.snapshot(),live:d.snapshot(),publicSnapshot,independentMutations:true};
 }else if(scenario==='canonical-alias'){
  const {d}=seed(factory,createDataSchema),snapshot=d.snapshot(),entry=snapshot.lines[0].items[1];snapshot.lines[0].items.push({...entry,i:`01@${actor}`});const error=rejection(()=>Doc.fromSnapshot(actor,snapshot,d.schema));assert.equal(error.message,'Duplicate snapshot token identity');result.observation={error:errorRecord(error),live:state(d)};
 }else if(scenario==='bodyhead-collision'){
  const {e,d}=seed(factory,createDataSchema);d.apply({t:'node',id:ticket(2),origin:ticket(1),type:'map',attrs:{id:'data:empty'}});d.apply({t:'node',id:ticket(0,`2@${actor}/body`),origin:ticket(2),type:'entry',attrs:{id:'data:collision',key:'collision',value:{scalar:0}}});
  const before=state(d);let ops,error;const counts=census(d,()=>{try{ops=e.apply([update(2)],{normalize:true});}catch(err){error=err;}});if(error)assert.deepEqual(state(d),before);result.observation={before,ops,error:error?errorRecord(error):null,after:state(d),...counts};
 }else if(scenario==='compiler-before-model:value'||scenario==='compiler-before-model:path'){
  const {e,d}=seed(factory,createDataSchema),original=Doc.prototype.toJSON,sentinel={local:'model must lose'},trace=[];const before=state(d);Doc.prototype.toJSON=function(){trace.push('model');throw sentinel;};
  try{const input=scenario.endsWith(':value')?[{op:'update',at:[0],attrs:{value:2}}]:[update(2,[999])],error=rejection(()=>e.apply(input,{normalize:true}));assert.notEqual(error,sentinel);assert.deepEqual(trace,[]);assert.deepEqual(state(d),before);result.observation={error:errorRecord(error),modelReads:0,live:state(d)};}finally{Doc.prototype.toJSON=original;}
 }else if(scenario==='commutation'){
  const {e,d}=seed(factory,createDataSchema);d.apply({t:'node',id:ticket(2),origin:ticket(1),type:'map',attrs:{id:'data:empty-map'}});d.apply({t:'node',id:ticket(3),origin:ticket(2),type:'list',attrs:{id:'data:empty-list'}});
  const {compileEdits}=await load('crdt/edit.ts'),snap=d.snapshot(),p=Doc.fromSnapshot(actor,snap,d.schema),q=Doc.fromSnapshot(actor,snap,d.schema),before=state(p);
  const modelBefore=p.toJSON();const heads=state(p);assert.equal(heads.clock,before.clock);assert.equal(heads.version,before.version);assert.equal(heads.snapshot.lines.length,before.snapshot.lines.length+2);
  const a=compileEdits(p,[update(2)]),b=compileEdits(q,[update(2)]);assert.deepEqual(a,b);assert.equal(a.length,1);
  const pm=p.toJSON(),qm=q.toJSON(),{applyEdits}=await load('crdt/model.ts'),expected=applyEdits(d.schema,modelBefore,[update(2)]);assert.deepEqual(pm,expected);assert.deepEqual(pm,qm);assert.deepEqual(state(p),state(q));assert.deepEqual(p.priorOf(a[0]),q.priorOf(b[0]));
  result.observation={scope:'public algebra control, not a private construction witness',before,heads,ops:a,prior:p.priorOf(a[0]),final:state(p),model:pm,expected,normalize:[]};
 }else if(scenario.startsWith('escape-find:')){
  const {e,d}=seed(factory,createDataSchema),mode=scenario.split(':')[1],snapshot=d.snapshot(),items=snapshot.lines[0].items,original=KeyIndex.prototype.find;let captured,armed=false,calls=0;
  items[1]=new Proxy(items[1],{get(t,p,r){if(p==='i'&&!armed){armed=true;KeyIndex.prototype.find=function(...args){calls++;const output=original.apply(this,args);const found=args[0].flatMap(range=>range.values??[range.value]).find(item=>item?.key===`1@${actor}`);if(found){captured=found;KeyIndex.prototype.find=original;}return output;};}return Reflect.get(t,p,r);}});
  Object.defineProperty(d.items,'map',{configurable:true,value(){return items;}});
  const before=state(d),input=mode==='two'?[update(2),update(3,[99])]:[{op:'update',at:[0],attrs:{value:{scalar:2},unknown:true}}];
  try{const error=rejection(()=>e.apply(input,{normalize:true}));assert.ok(captured,'actual find must expose Item');assert.equal(captured.attrs.get('value').value.scalar,2);assert.equal(KeyIndex.prototype.find,original);assert.deepEqual(state(d),before);result.observation={error:errorRecord(error),calls,exposedValue:2,live:state(d),selfRestored:true};}finally{KeyIndex.prototype.find=original;}
 }else if(scenario==='projection-engine'){
  const {e,d}=seed(factory,createDataSchema);d.apply({t:'node',id:ticket(2),origin:ticket(1),type:'map',attrs:{id:'data:empty'}});
  const ops=e.apply([update(2)],{normalize:true});assert.equal(value(d),2);const before=state(d);assert.equal(typeof retainedOwner,'function');assert.ok(projectionCalls>=1);
  const owner=retainedOwner(`0@2@${actor}/body`);assert.equal(owner,`2@${actor}`);assert.deepEqual(state(d),before);
  result.observation={ops,projectionCalls,owner,liveUnchangedAfterClosure:true,live:state(d)};
 }else if(scenario==='flat-shared'){
  const {e,d}=seed(factory,createDataSchema),shared={label:'한글🙂'},payload={left:shared,right:shared},input=[{op:'update',at:[0],attrs:{value:payload}}];
  const ops=e.apply(input,{normalize:true}),stored=d.get(`1@${actor}`).attrs.get('value').value;
  assert.deepEqual(stored,payload);assert.notEqual(stored,payload);assert.equal(stored.left,stored.right);shared.label='mutated';assert.equal(stored.left.label,'한글🙂');
  result.observation={ops,after:state(d),inputDetached:true,sharedWithinRegister:true};
 }else if(scenario==='saved-reopen'){
  const {Client,clientOwner}=await load('client/index.ts'),restore=deterministicIds();let c,shared;try{c=new Client({actor,schema:createDataSchema()});shared=c.data.createMap();shared.set('label','한글🙂');c.data.root.set('proof',shared);}finally{restore();}
  const saved=c.captureState(),reopened=Client.fromState(saved,{schema:createDataSchema()}),e=clientOwner(reopened).engine,d=e.typescriptDocument(),initial=state(d);reopened.data.root.set('proof','reopened');assert.equal(reopened.data.root.get('proof'),'reopened');reopened.undo();assert.equal(reopened.data.root.get('proof').get('label'),'한글🙂');reopened.redo();assert.equal(reopened.data.root.get('proof'),'reopened');result.observation={initial,final:state(d),history:stableHistory(e.typescriptHistory()),original:c.data.root.get('proof').get('label')};
 }else if(scenario==='public-raw-default-stage'){
  const rawSchema=createDataSchema(),source=seed(factory,createDataSchema).d;
  const d=Doc.fromSnapshot(actor,source.snapshot(),rawSchema),before=state(d);
  const counts=census(d,()=>d.edit([update(2)],{normalize:true}));
  assert.equal(value(d),2);result.observation={before,after:state(d),...counts};
 }else{
  let e,d;if(['custom-schema','clone-default','raw-default','frozen-default'].includes(scenario)){
   const {schemaVersion}=await load('crdt/schema-version.ts');
   const schema=scenario==='raw-default'?createDataSchema():structuredClone(createDataSchema());
   if(scenario==='custom-schema')schema.nodes.entry.attrs.probe={default:''};
   if(scenario==='frozen-default'){const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}};freeze(schema);}
   assert.equal(schemaVersion(schema)===schemaVersion(createDataSchema()),scenario!=='custom-schema');
   e=factory.create(actor,schema);d=e.typescriptDocument();assert.notEqual(d.schema,schema);
   const frozen=x=>{if(x&&typeof x==='object'){assert(Object.isFrozen(x));Object.values(x).forEach(frozen);}};frozen(d.schema);
   d.apply({t:'node',id:ticket(1),origin:root,type:'entry',attrs:{id:'data:entry',key:'proof',value:{scalar:1}}});}else({e,d}=seed(factory,createDataSchema));
  if(scenario==='bad-meta')d.get(`1@${actor}`).attrs.get('value').value={scalar:1,reference:'data:unknown'};
  if(scenario==='clock-final')d.clock.lamport=Number.MAX_SAFE_INTEGER-1;
  if(scenario==='clock-overflow')d.clock.lamport=Number.MAX_SAFE_INTEGER;
  const before=state(d);let ops,error;
  const input=scenario==='bad-value'?[{op:'update',at:[0],attrs:{value:2}}]:scenario==='bad-path'?[update(2,[999])]:[update(2)];
  const counts=census(d,()=>{try{ops=e.apply(input,{normalize:true});}catch(err){error=err;}});
  if(scenario==='bad-path'||scenario==='clock-overflow'||scenario==='bad-value'){assert.ok(error);assert.deepEqual(state(d),before);}
  if(scenario==='clock-final'){if(error)throw error;assert.equal(d.clock.lamport,Number.MAX_SAFE_INTEGER);assert.equal(value(d),2);}
  if(['custom-schema','clone-default','raw-default','frozen-default'].includes(scenario)){if(error)throw error;assert.equal(value(d),2);}
  result.observation={before,ops,error:error?errorRecord(error):null,after:state(d),...counts};
 }
 console.log(JSON.stringify(result,(_,v)=>Object.is(v,-0)?{$negativeZero:true}:v));
}
