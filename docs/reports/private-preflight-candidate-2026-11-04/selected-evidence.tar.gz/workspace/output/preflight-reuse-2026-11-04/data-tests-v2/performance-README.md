# Output-only source performance driver

Preparation only. Timing has **NOT_RUN**. Root must approve the actual candidate and register serial ABBA gates before timing.

`performance-driver.mjs` derives from `benchmarks/data-point-cache.mjs`. It loads one explicit whole source closure with stock Node v24.22.1. It refuses duplicate or unknown options, output overwrite, code/dist output, source imports outside the selected closure, NODE_OPTIONS and execArgv. Options are frozen after parsing. Source and driver SHA-256 are checked before and after each run. Each scenario records the authored checkpoint hash, retained move count and final checkpoint hash.

Pass the directory that contains `packages/doc-sync/src` to `--source-root`. Use explicit labels; labels and paths do not imply baseline identity or candidate eligibility. The original bulk checkpoint remains linear. `--fixture legacy-no-moves` preserves zero movement records. `--fixture normal` performs bounded public moves outside intervals and asserts retained movement counts **1 / 3 / 3** for root Map / nested Map / List. Map has no move method: root/nested moves use public Client.edit; the List target uses SharedList.move. These moves preserve model order and target paths. History is cleared after setup. The base and actual authored fixture hashes are separate.

All modes check full public model and arrays, IDs/order/values, full snapshot and captured checkpoint against raw-edit controls, History, undo/redo, frozen held entries, repeated writes without reads, negative zero, references, and foreign-write/deletion behavior after undo/redo. Only wall-clock History group timestamps are normalized in comparisons. Assertions and setup are outside timing intervals.

Smoke and counts do not read performance.now. Counts replace only host structuredClone and assert **zero setter root-model clones, one next-read root-model clone** for both source trees. They do not infer copy-on-write eligibility from a source path. Compiler/private-pair counts remain in the independent 90-case functional harness. Timing installs no clone counter. Timing supports only 2,000 or 20,000 total entries and measures setter, first read and their total, including normal History. This is not heap evidence or full Core qualification.

Run CLI controls with:

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/data-tests-v2/performance-cli-tests.mjs
```

The controls use only 20-entry frozen-baseline smoke/counts runs. They check both fixture modes, one next-read clone, no timing result, exact retained moves, overwrite refusal and invalid options. Initial preparation fixed an oracle error: Doc.items covers only its primary storage, so foreign-write targets must be found across snapshot Lines. The accepted CLI run is under `performance-cli-runs/2026-11-03T19-50-51-993Z`.

Example preparation/count command:

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/data-tests-v2/performance-driver.mjs --source-root output/refactor-2026-11-03/post-refactor-baseline --label frozen-baseline --output output/preflight-reuse-2026-11-04/data-tests-v2/NEW-counts.json --records 20 --samples 1 --warmup 0 --mode counts --fixture normal --expect-root-clones 1
```

For approved later timing, root selects the immutable source and new output, `--mode timing`, `--records 2000` or `20000`, and the fixture mode. Run serially. No timing was executed during preparation.

For the later count census, run the following command serially for each records value `2000` and `20000`, each fixture `legacy-no-moves` and `normal`, and each explicit source lane. Choose a different new output for every invocation:

```sh
/Users/user/.nvm/versions/node/v24.22.1/bin/node output/preflight-reuse-2026-11-04/data-tests-v2/performance-driver.mjs --source-root SOURCE_ROOT --label LANE --output NEW.json --records RECORDS --samples 1 --warmup 0 --mode counts --fixture FIXTURE --expect-root-clones 1
```

The baseline source root is `output/refactor-2026-11-03/post-refactor-baseline`; the candidate source root is `output/preflight-reuse-2026-11-04/candidate-v2`. Compare closure hashes against approved immutable manifests, then compare base fixtureSHA and all authoredFixtureSHA values across lanes before assessing timings. Direct public Doc 100k text controls and custom-schema/structural fallback timing controls are outside this driver and remain NOT_RUN.
