import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {mkdirSync, readFileSync} from 'node:fs';
import {join, resolve} from 'node:path';
assert.equal(process.version, 'v24.22.1');
const driver=join(import.meta.dirname,'performance-driver.mjs');
const runDir=join(import.meta.dirname,'performance-cli-runs',new Date().toISOString().replace(/[:.]/g,'-'));
mkdirSync(runDir,{recursive:true});
const root=resolve(import.meta.dirname,'../../refactor-2026-11-03/post-refactor-baseline');
const run=args=>spawnSync(process.execPath,[driver,...args],{encoding:'utf8',timeout:30000});
const common=output=>['--source-root',root,'--label','baseline-cli-control','--output',output,'--records','20','--samples','1','--warmup','0'];
const results=[];
for(const fixture of ['legacy-no-moves','normal']) for(const mode of ['smoke','counts']){
 const output=join(runDir,`${fixture}-${mode}.json`),r=run([...common(output),'--mode',mode,'--fixture',fixture]);
 assert.equal(r.status,0,r.stderr);
 const report=JSON.parse(readFileSync(output,'utf8'));
 assert.equal(report.sourceUnchangedAtEnd,true);
 assert.deepEqual(report.scenarios.map(s=>s.retainedMoves),fixture==='normal'?[1,3,3]:[0,0,0]);
 assert(report.scenarios.every(s=>s.timing===null&&s.rawEditReadControlTiming===null));
 assert.equal(report.timer,'NOT_RUN: smoke/counts do not read a clock');
 if(mode==='counts')assert(report.scenarios.every(s=>s.counts.every(c=>c.nextReadRootClones===1&&c.setterRootClones===0)));
 const overwritten=run([...common(output),'--mode',mode,'--fixture',fixture]);
 assert.notEqual(overwritten.status,0);assert.match(overwritten.stderr,/Refusing to overwrite/);
 results.push({fixture,mode,status:'PASS',output});
}
for(const tail of [['--records','20','--records','20'],['--fixture','unknown'],['--mode','counts','--expect-root-clones','0'],['--mode','timing','--records','20'],['--unknown','x']]){
 const r=run(['--source-root',root,'--label','reject','--output',join(runDir,'must-not-exist.json'),...tail]);
 assert.notEqual(r.status,0);results.push({rejected:tail,status:'PASS'});
}
console.log(JSON.stringify({status:'PASS',timing:'NOT_RUN',runDir,results},null,2));
