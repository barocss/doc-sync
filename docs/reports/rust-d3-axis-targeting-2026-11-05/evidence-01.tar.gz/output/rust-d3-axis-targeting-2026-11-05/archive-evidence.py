from pathlib import Path
import os,json,hashlib,tarfile

root=Path('/Users/user/github/doc-sync');task=root/'output/rust-d3-axis-targeting-2026-11-05'
report=root/'docs/reports/rust-d3-axis-targeting-2026-11-05';selected=set();excluded=[]
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def reject(path,reason):
    excluded.append({'path':str(path.relative_to(root)),'bytes':path.stat().st_size,'reason':reason,'sha256':sha(path)})
for base,dirs,names in os.walk(task):
    dirs[:]=[name for name in dirs if name not in {'target','native-target'}]
    for name in names:
        path=Path(base)/name
        if path.suffix=='.stdout':reject(path,'duplicate raw stdout; verified compressed copy retained');continue
        if path.suffix not in {'.json','.jsonl','.gz','.diff','.log','.rs','.mjs','.ts','.py','.toml','.lock','.md','.stderr','.patch','.txt'}:continue
        if name.endswith('.tar.gz'):
            with tarfile.open(path,'r:gz') as archive:
                binary=any(any(part in {'target','native-target'} for part in Path(member.name).parts) for member in archive.getmembers())
            if binary:reject(path,'binary-containing stage bundle; verified source-only derivative selected');continue
        if path.stat().st_size>8388608 and path.suffix in {'.json','.jsonl'}:
            reject(path,'large raw trace; verified lossless gzip selected');continue
        selected.add(path)
baseline=json.loads((task/'baseline.json').read_text())['files']
selected.update(root/name for name in baseline)
for folder in ['experiments/rust-sdk','experiments/rust-shadow']:
    for base,dirs,names in os.walk(root/folder):
        dirs[:]=[name for name in dirs if name not in {'target','native-target'}]
        for name in names:
            path=Path(base)/name
            if path.suffix in {'.rs','.toml','.lock'}:selected.add(path)
selected.update(path for path in (root/'experiments/runtime-document-axis-targeting').glob('*') if path.is_file())
selected.update([report/'README.md',report/'final-checks.json',root/'packages/doc-sync/test/moved-grid-compiler.test.ts'])
for path in selected:assert path.exists(),str(path)
groups=[];current=[];total=0
for path in sorted(selected):
    size=path.stat().st_size
    assert size<40000000,'Large uncompressed member must be losslessly compressed first: '+str(path)
    if current and total+size>40000000:groups.append(current);current=[];total=0
    current.append(path);total+=size
if current:groups.append(current)
archives=[];files=[]
for index,paths in enumerate(groups,1):
    destination=report/f'evidence-{index:02}.tar.gz';assert not destination.exists()
    with tarfile.open(destination,'w:gz',compresslevel=1) as archive:
        for path in paths:archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
    assert destination.stat().st_size<50000000
    entries=[{'path':str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':sha(path),'archive':destination.name} for path in paths]
    with tarfile.open(destination,'r:gz') as archive:
        for entry in entries:
            h=hashlib.sha256();stream=archive.extractfile(entry['path'])
            for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
            assert h.hexdigest()==entry['sha256'],entry['path']
    files.extend(entries);archives.append({'path':destination.name,'bytes':destination.stat().st_size,'sha256':sha(destination),'members':len(entries),'readback':'PASS'})
manifest={'status':'SELECTED_EVIDENCE_SEALED','archives':archives,'files':files,'excludedLocalArtifacts':excluded,
          'baseline':'main1cfb7a2 plus captured313-file opening baseline; inherited WIP retained',
          'scope':'Selected source, source-only prior-stage bundles, complete compressed traces, failures and checks; native targets/executables excluded',
          'archiveMemberByteLimit':40000000,'volumeByteLimit':50000000}
(report/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
seal_paths=[report/'README.md',report/'final-checks.json',report/'manifest.json']+[report/row['path'] for row in archives]
seal={'status':'PASS','files':{path.name:sha(path) for path in seal_paths},'archiveMembersVerified':len(files),'archiveVolumesVerified':len(archives)}
(report/'seal.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'status':'PASS','volumes':len(archives),'members':len(files),'bytes':sum(row['bytes'] for row in archives),'readback':'PASS'}))
