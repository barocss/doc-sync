from pathlib import Path
import hashlib,json,tarfile
root=Path('/Users/user/github/doc-sync');task=root/'output/rust-d3-axis-targeting-2026-11-05';report=root/'docs/reports/rust-d3-axis-targeting-2026-11-05'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
seal=read(report/'seal.json');manifest=read(report/'manifest.json')
for name,h in seal['files'].items():assert sha(report/name)==h,name
def verify_refs(value):
 if isinstance(value,dict):
  if isinstance(value.get('path'),str) and 'sha256' in value:
   p=root/value['path']
   if p.is_file():assert sha(p)==value['sha256'],value['path']
  for v in value.values():verify_refs(v)
 elif isinstance(value,list):
  for v in value:verify_refs(v)
verify_refs(read(report/'final-checks.json'))
selected={e['path'] for e in manifest['files']}
for name in ['experiments/rust-sdk/src/runtime_grid_targeting.rs','experiments/rust-sdk/tests/runtime_grid_targeting.rs','experiments/rust-sdk/examples/runtime_grid_targeting.rs','experiments/rust-sdk/examples/runtime_grid_targeting_trace.rs','packages/doc-sync/src/crdt/edit.ts','packages/doc-sync/dist/crdt/edit.js','packages/doc-sync/test/moved-grid-compiler.test.ts']:
 assert name in selected,name
summary=read(task/'compare-summary.json');inherited=read(task/'compare-inherited-summary.json')
probe=read(task/'compare-empty-cell-summary.json')
qualified=summary['completeCompressedTraces']+inherited['completeGzipArtifacts']+probe['completeGzipArtifacts']
for row in qualified:
 path=task/row['compressed'];assert str(path.relative_to(root)) in selected,row
 assert sha(path)==row['compressedSha256'],row
native=read(task/'native-final-receipt.json');maps=read(root/native['sourcesAfter'])
for name,h in maps.items():assert sha(root/name)==h,name
main=read(root/summary['receipt'])
for name,h in main['sourceHashes'].items():assert sha(root/name)==h,name
old=read(task/'earlier-seals.json')
for entry in old:
 p=root/entry['report'];assert sha(p/'seal.json')==entry['sealSha256']
 for name,h in read(p/'seal.json')['files'].items():assert sha(p/name)==h
for archive in manifest['archives']:
 entries=[e for e in manifest['files'] if e['archive']==archive['path']]
 with tarfile.open(report/archive['path'],'r:gz') as f:
  for entry in entries:assert hashlib.sha256(f.extractfile(entry['path']).read()).hexdigest()==entry['sha256'],entry['path']
result={'status':'PASS','volumes':len(manifest['archives']),'members':len(manifest['files']),'nativeMap':len(maps),'mainMap':len(main['sourceHashes']),'oldSeals':len(old),'qualifiedCompressedArtifacts':len(qualified),'gridTargetingAndTsFixSourcesIncluded':True}
p=task/'sealed-final-audit.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
