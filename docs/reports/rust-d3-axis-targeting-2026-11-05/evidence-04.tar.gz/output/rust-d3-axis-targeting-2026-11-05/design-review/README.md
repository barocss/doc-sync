---
work_id: rust-d3-axis-targeting-2026-11-05
artifact_type: design_review
status: ready_for_build
owner_role: reservation-review
source_request: Q1.3.2 typed stable grid/row/column targeting after Q1.3.1 sealing
last_updated: 2026-11-05
---

# Q1.3.2 typed row and cell targeting

Implement a first bounded slice containing row-before/after and cell-body start/end. Reuse the Q1.3.1 local base, strict current grid lookup, one evolving Compiler and one final commit. Do not add a per-row BeforeColumn/AfterColumn insertion target. Column creation needs an explicit whole-column command because one column exists across every row.

A follow-on single-column API can accept one grid, one stable column boundary and unique row-ID-to-cell payloads. One call creates exactly one column in that grid. This avoids changing the approved Q1.2 numeric column memo.

This is design only. No product, current targeting document or earlier report was changed. No Cargo, browser, mobile, native test, differential or performance execution occurred in this lane. Implementation starts only after Q1.3.1 is sealed. This design does not close all Q1.3, Q1.4, D4 or axis movement.

## First buildable API

Prefer an additive grid-focused API so existing exhaustive matches over the Q1.3.1 public enums need not change:

```rust
pub struct GridRowTarget { pub grid: Key, pub row: Key }
pub struct GridCellTarget { pub grid: Key, pub row: Key, pub column: Key }
pub enum GridModelTarget {
    BeforeRow(GridRowTarget),
    AfterRow(GridRowTarget),
    InsideCellStart(GridCellTarget),
    InsideCellEnd(GridCellTarget),
}
pub struct GridModelInsert { pub target: GridModelTarget, pub model: Value }

pub fn insert_grid_models_relative(
    &mut self,
    base: &ModelEditBase,
    commands: &[GridModelInsert],
    options: EditOptions,
    now_ms: f64,
) -> Result<ModelInsertBatchResult>;
```

These structs contain existing IDs. A cell wrapper receives no new ID. The cell body remains the existing deterministic address from grid/row/column IDs. This API does not expose zero-clock storage heads as ordinary node targets.

The separate API keeps Q1.3.1 Before(rowKey), Before(columnKey), Inside Node(text/grid) and generic wrapper targeting rejected. An alternative that adds BeforeRow/AfterRow and FlowTarget::Cell variants is shorter at call sites, but changes exhaustive-match compatibility of the existing Rust enums. The grid-focused method is the preferred minimum because the SDK is currently experimental and no cross-command-type API is required for this slice.

The command result uses the established Q1.2 format. Row insertion returns its new row axis key. Cell-body insertion returns the existing compiler result key, or None for a normalized-empty group/grid. Some(key) can be an existing zero-clock source head when the insertion fills a default paragraph. It does not prove that generic Before/After accepts that key. Use the explicit cell tuple for future body edges, or an ordinary stored primary marker when one exists. Aggregate Change and before/after clocks include preparation and reservations. Empty successful batches consume the local base conservatively and enqueue no empty pending change.

## Capability and policy matrix

| Target/state | First slice behavior |
| --- | --- |
| Stored visible grid and live row in its current rows axis | BeforeRow/AfterRow allowed |
| Stored visible grid and matching live row/column tuple | Cell-body edges allowed when the current cell is not covered |
| Visible top-left anchor of a merge | Cell-body edges allowed; anchor remains an editable current cell |
| Covered cell tuple | Reject; do not redirect to the merge anchor or neighboring cell |
| Current row axis whose cells are partly covered | Row adjacency allowed; the target is the row axis, not a cell |
| New row becomes covered by an existing span | Preserve existing RowModel normalization and retained payload behavior; do not add a result-visibility rejection |
| Missing/deleted row or column | Reject even when its old cell body and descendants remain stored/alive |
| Live row/column from another grid | Reject ownership mismatch; no type-only match or source-head inference |
| Deleted/hidden/cardinality-hidden grid, or grid inside a covered ancestor cell | Reject current grid lookup |
| Grid moved to another current parent | Fresh base follows the same grid ID and its current path; old base rejects |
| Required synthetic grid/axes or zero-clock head | Reject ordinary ID targeting under the Q1.3.1 stored-primary boundary |
| Grid with no visible model identity after its last axis is deleted | Reject; no implicit resurrection |
| Row/column Move | Unsupported; existing core rejects axis movement |
| Alias or previous placement ticket | Reject as identity; use exact current grid primary and exact axis keys |

**Current target validation and output normalization are distinct.** Q1.3.1 rejects a currently hidden target; it does not require every resulting node to remain visible. A live row axis is a valid structural target even when insertion extends a merge. Tightening the new API to forbid newly covered rows, rowspan/colspan attributes or retained hidden row payloads would change valid existing numeric row semantics without fixing a targeting bug. This design adds no such restriction.

Example: an existing span starts at R0 and ends at R1. Insert a row before R1 with cell content X. Stable endpoint projection can extend the span over the new row. X remains in the new row's retained cell model, including the covered marker. Undo/redo and peer edits must preserve that data according to the existing selective History contract. A later InsideCell command addressed directly to that covered tuple rejects until it is visible. The two operations target different objects: a row axis and a current cell body.

## Strict lookup and lowering

Capture/check the same private Q1.3.1 `{incarnation, publication revision, schema identity}` base. Do not allocate a second version counter or persist the token. Reads and acknowledgements preserve it. Successful publication, including duplicate/empty apply and clock-only work, invalidates it. Failed validation/compile/restore preserves it. Restoring even an identical checkpoint changes incarnation and invalidates an old token. The check is synchronous and local; no server revision, epoch, lease or permission follows.

Resolve each command against the current detached candidate immediately before compiling it:

1. Find the exact stored grid primary through the Q1.3.1 root-reachable walk. Require grid shape and the current canonical grid path. Do not use refreshed_grid's global projection scan alone as visibility proof.
2. Read its current row and column lists and indexed cell projection from the same state view. Require positive non-synthetic keys, alive axis tokens, expected row/column kind and membership in this exact grid. Raw global token existence is insufficient.
3. BeforeRow uses the current position of the requested row; AfterRow adds one. Lower to the existing insertion path `[...gridPath, rowIndex]` and existing schema-named RowModel compiler. Row children use the current column sequence and retain Q1.2's fixed-width normalization, including truncation of excess cells. Row insertion creates no new column.
4. InsideCell resolves the requested row and column independently from current immutable IDs, checks their pair's uncovered status, and obtains the exact cell body line. Verify its address agrees with existing RuntimeDocument::cell_head(grid,row,column). Lower to `[...gridPath, rowIndex, columnIndex, 0, childBoundary]`. The body wrapper index is exactly zero. Use the current canonical body child count for End, including the established default-prefix handling.
5. Compile on the same evolving Compiler, with the existing promotion gate, model validation, preparation, field writes and reservation accounting. Commit all commands through one stage_change/history_record only after all succeed.

A stored grid can be nested in a visible cell or flow. Its full ancestor chain must remain current and visible. Covered ancestors cannot be bypassed by looking up the inner grid's retained physical body. Never call selection_resolve/pathAt as a strict target resolver; their nearest-live fallback is a separate selection policy.

Refactor the existing private exact-block locator to return the current path plus grid projection metadata when needed. Reuse TargetView's one captured state, alive indexes, required boundaries and cell-pair map. Keep lookup read-only; do not materialize a source head before proving ownership and visibility. The new API publishes through stage_change, so the current closed mutation-gate audit remains closed.

## Sequential order, identities and guards

Each target follows its current immutable IDs after previous commands in the same batch. BeforeRow(R) twice produces the two new rows in input order before R; AfterRow(R) twice places the later new row closer to R. This matches sequential child insertion. Do not pre-resolve all row indexes against the original model.

Cell edges resolve the same row/column tuple after earlier row insertions, so a changed numeric row index cannot retarget another row's cell. The first slice adds no command that changes an existing grid's column count. RowModel cell arrays therefore retain their existing positional meaning against the current width; no new column-ID binding is claimed for those payload arrays.

Caller keys must already name existing IDs in the candidate. The first slice adds no public string aliases, predicted-ticket handles or references to future command results. Put new-row initial content in its RowModel. To target that row in a later call, use the returned row key and a fresh base. Trace fixture aliases remain test-only maps to actual IDs.

A peer row/column insert or delete delivered between read and commit invalidates the old base even when Lamport max stays unchanged. A fresh base resolves the original surviving row/column IDs in the new order. A missing/deleted anchor rejects; it never shifts to a nearest row/column. Raw owner deletion must be tested without cascading deletion so live descendants cannot mask a missing ancestor check.

Retry uses the captured Change operations and existing pending checkpoint, not rerunning the model command. A successful first call consumes its base. Recompiling with a fresh base is a new edit and can create another row. Own checkpoints preserve pending operations, clocks and History; local read bases do not survive restore. No authorization or distributed acceptance claim is added.

## Column decision: why naive cell-relative commands are wrong

The Q1.2 compiler memo is indexed by `(grid, numeric insertion index, row IDs already filled)`, not by a logical command or immutable original-column gap (`runtime_structure.rs:709-754`; TS edit.ts:997-1020).

Assume original columns `[C0,C1]` and distinct rows R0/R1:

| Two naive commands | First insertion | Second resolution | Result |
| --- | --- | --- | --- |
| Before(C1) in R0, then Before(C1) in R1 | New N at index1; C1 shifts to index2 | Index2 differs from memo index1 | Two new columns |
| After(C0) in R0, then After(C0) in R1 | New N at index1 | Index1 still matches memo; second row is new | One shared column |
| After(C0) twice in the same row | New N at index1 | Row already used in memo | Two new columns |

This direction/row-dependent behavior is correct for the existing numeric compiler but is an ambiguous user contract for a proposed whole-column ID operation. Do not silently replace the old numeric memo with a stable-column-ID memo. Do not claim that repeated cell-relative commands always create one shared column. Do not freeze all user command indexes upfront, which would reintroduce index drift across other operations.

## Follow-on single-column operation

After the first row/cell slice is qualified, the smallest coherent column API is one whole-column command per call:

```rust
pub enum ColumnBoundary { Start, End, Before(Key), After(Key) }
pub struct RowCellPayload { pub row: Key, pub model: Value }
pub struct ColumnInsert {
    pub grid: Key,
    pub boundary: ColumnBoundary,
    pub cells: Vec<RowCellPayload>,
}
pub struct ColumnInsertResult {
    pub column: Key,
    pub change: Change,
    pub clock_before: u64,
    pub clock_after: u64,
}
pub fn insert_column_relative(
    &mut self, base: &ModelEditBase, command: ColumnInsert,
    options: EditOptions, now_ms: f64,
) -> Result<ColumnInsertResult>;
```

One call creates exactly one new column in the target grid, one pending Change and one History record transaction. Default options produce one undo action; existing typing coalescence can merge it with a prior compatible group. A cell payload may itself contain a nested grid with its own axes; the invariant concerns the target grid's column-ID set, not the count of every wire Node with type col. The result returns the one global column key once, not a fictional cell ID for each row.

Validate the current grid and optional column boundary by exact ownership/live/current ancestry. Each payload row must belong to that grid and be live. Reject duplicate row IDs before compiling; repeated rows must not create a second column through the old memo rule. Preserve the provided payload order for deterministic ticket/operation ordering. Do not silently sort a row map.

Resolve the numeric column boundary **once** for this whole-column command. Start a fresh Compiler with column memo None. The first cell payload creates the column at c; later unique row payloads fill that same new column at the same c through the unchanged Q1.2 memo. They do not re-resolve Before(originalColumn) after the first creation. Outer row axes do not change during this command. A map lookup proves each payload row's current index. Assert that all internal returned column keys are identical and that the target grid gained exactly that one column.

Unspecified rows receive their normal default empty cells. For `cells=[]`, use the first current live row with the schema's empty cell/body model as the internal compiler seed; the call still creates one column. A visible grid has nonempty live rows/columns under the existing strict grid projection. This empty-payload adapter requires an explicit TS/native regression; it is a planned contract, not an execution result.

Preserve existing cell attributes, span writes, retained covered-cell data and row/column endpoint rules. Whole-column insertion targets a structural axis boundary; newly covered cell payloads follow existing model normalization. InsideCell continues to reject a currently covered tuple. There is no automatic split/unmerge or new visibility restriction on structural results.

A second public call starts a fresh compiler and creates another column, even when it uses the same original boundary and disjoint payload rows. It needs a fresh read base and forms another History action. Multi-column atomic calls are deferred. Such an API would need an explicit new-column boundary per logical command. A single TS Doc.edit array would otherwise share its existing memo across adjacent logical column commands. An adapter would need qualified memo barriers, such as the existing empty UPDATE reset at edit.ts:366, or another explicit command contract. Do not smuggle that change into the insert-only Q1.2/Q1.3.2 slice.

## Independent TS comparison

For the first slice, extend the independent TS oracle with typed grid/axis ownership checks. Find the exact visible grid using TS's own current primary-marker walk. Use its current rows/cols IDs, covered map, body path and blockPath/flowPath. Never consume a native-returned numeric path. Existing complete-prefix planning from Q1.3.1 can resolve each new typed command against a rebuilt complete TS prefix; execute the full resolved array once on the live TS document and record History once.

Compare complete pre-model intent, normalization closure, new axis IDs, complete operations where representation contracts apply, clock reservations, full History, typed pending changes, stable selections, own checkpoint recovery and both actor states. The expected structural model must retain hidden cell payloads under spans rather than project them away. The row oracle must preserve existing width/truncation semantics. Selection fallback remains independently tested and is never used for targeting.

For the later single-column API, independently resolve grid boundary c once and existing payload row IDs to current row indexes. Expand the one command to one TS insert array at `[...gridPath, rowIndex, c]` for every unique payload row, with the same c for all. Existing TS memo creates one column and fills it across rows. With no payloads, use the explicitly documented empty-cell seed. This is an oracle for the new whole-column command, not an assertion that independently repeated BeforeColumn targets have those semantics.

## Required first-slice acceptance cases

- Original Word/Presentation tables plus a renamed custom grid schema and nested grids; row-before/after and empty/nonempty cell-body start/end.
- Two grids with identical row/cell type names: crossing grid/row/column IDs rejects without model, clock, History, pending or base change.
- Peer row/column insertion between read and commit: old base rejects, fresh base retains the same ID target at its changed index. Same-Lamport foreign changes also invalidate.
- Missing/deleted axes, deleted/hidden ancestor and covered ancestor cell reject even when stored descendant tokens remain alive. Generic Q1.3.1 axis-key targets stay rejected.
- Cell body addressed by tuple succeeds when it has only a virtual default paragraph, with no invented child/node ID. A covered cell rejects; a visible merge anchor succeeds.
- Insert row within an anchored rowspan: span extent grows as in TS, new covered cell payload remains in the complete retained model, and one undo/redo restores the whole model with peer text/attribute writers preserved.
- RowModel excess cells retain the current fixed-width normalization; no accidental column is created. Row payload rowspan/colspan attributes use the existing compiler behavior.
- Repeated before/after row targets use sequential order. A later invalid typed target rejects all earlier candidate commands and leaves the original base usable, including an existing redo branch and pending changes.
- Clock-only/empty child models preserve Q1.2 pending/History behavior, while successful publication consumes the local base. Read/ack preserve it. Failed restore and rejected calls preserve it; identical successful restore invalidates it.
- Checkpoint + exact pending retry is idempotent. Model command replay with a fresh base is explicitly a new edit. Raw row/column Move remains rejected.

The column follow-on adds: two distinct row payloads share exactly one target-grid column; duplicate row keys reject; empty payload still creates one; same original Before/After boundary across separate calls creates distinct columns; fresh peer axis order binds correct IDs; hidden payload and span growth are retained; one History action preserves foreign writers on undo/redo. Nested grids must not confuse the target-grid axis-count invariant.

## Implementation steps and evidence boundary

1. After Q1.3.1 seal, add grid target structs, the new grid-focused batch method, and private strict-grid/axis/cell resolution using the existing state view. Keep current APIs and generic target rejection policies unchanged.
2. Reuse the shared model compiler and stage_change. Add no core storage, snapshot, wire, version or identity format. Retain row/cell model admission and normalization exactly; visibility checks apply to the current target.
3. Add focused Rust ownership/visibility/ordering/span/atomicity tests and an independent TS trace corpus. Run current Q1.3.1 and Q1.2 affected checks once after source freeze. Seal new evidence without rewriting old reports.
4. Only after that qualification, implement and qualify the single-column command separately. Do not add multi-column atomicity, axis Move, server revision, schema transition, ACL, retry authorization or broad D4 lifecycle as hidden dependencies of the first slice.

Source inspection establishes design feasibility and the numeric memo hazard. All proposed APIs and acceptance runs remain NOT_IMPLEMENTED/NOT_RUN in this review lane. No browser, mobile, benchmark, hosted write, production Rust/WASM or release acceptance follows.

## Source evidence

| Contract point | Current source |
| --- | --- |
| Native local base and synchronous guard | `experiments/rust-sdk/src/runtime_targeting.rs:8-108` |
| Exact root-reachable primary lookup and default-prefix policy | `experiments/rust-sdk/src/runtime_targeting.rs:196-371` |
| Indexed cell pairs, current covered status and live axes | `experiments/rust-sdk/src/runtime_targeting.rs:374-432` |
| Existing row/column/body model path transitions | `experiments/rust-sdk/src/runtime_structure.rs:316-350` |
| Existing grid/row model insertion dispatch | `experiments/rust-sdk/src/runtime_structure.rs:410-411` |
| Row insertion keeps current width and fills only current columns | `experiments/rust-sdk/src/runtime_structure.rs:678-707` |
| Numeric column memo and repeated-row policy | `experiments/rust-sdk/src/runtime_structure.rs:709-754` |
| Existing cell fill retains payload and writes anchored span endpoints | `experiments/rust-sdk/src/runtime_structure.rs:568-605` |
| Existing deterministic grid rows/columns/cell addresses | `experiments/rust-sdk/src/runtime_schema.rs:2140-2162` |
| Closed publication gates and revision checks | `experiments/rust-sdk/src/runtime_schema.rs:372-407` |
| Successful restore replaces the local instance | `experiments/rust-sdk/src/runtime_schema.rs:1314-1368` |
| Live axes and span extent from stable endpoints | `experiments/rust-shadow/src/nested.rs:773-841` |
| Current grid metadata supplies row/column pairs and covered map | `experiments/rust-shadow/src/nested.rs:1133-1147` |
| Canonical grid model retains covered cell bodies | `experiments/rust-shadow/src/nested.rs:1293-1319` |
| Axis Move is rejected | `experiments/rust-shadow/src/movement.rs:225-249` |
| TS row insertion and excess-cell handling | `packages/doc-sync/src/crdt/edit.ts:970-993`, `:932-939` |
| TS same-index/different-row shared column creation | `packages/doc-sync/src/crdt/edit.ts:997-1037` |
| TS non-insert/non-delete command clears the memo | `packages/doc-sync/src/crdt/edit.ts:353-367` |
| TS empty flow payload adds no body operations | `packages/doc-sync/src/crdt/edit.ts:875-883` |
| Existing independent exact-marker and prefix-array oracle | `experiments/runtime-document-targeting/oracle.mjs:12-59` |

`source-seal.json` records this design's source inputs. These hashes identify the inspected state and do not assert that the proposed axis APIs are implemented.

The follow-on single-column command has a separate detailed contract in `column-contract.md`. It remains unimplemented until the row/cell slice is qualified.
