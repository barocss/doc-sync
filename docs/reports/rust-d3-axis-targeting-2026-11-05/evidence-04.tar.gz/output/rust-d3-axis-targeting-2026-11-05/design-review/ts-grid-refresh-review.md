---
work_id: rust-d3-axis-targeting-2026-11-05
artifact_type: corrective_source_review
status: done
owner_role: reservation-review
source_request: Fix the observed authoritative TS moved-grid refresh defect in the current phase
last_updated: 2026-11-05
---

# TS current-grid refresh correction

Final source verdict: **APPROVED_BOUNDED_SOURCE**, zero blocking findings. The observed moved-grid row insertion defect is fixed in the frozen source and generated dist. Fresh differential execution remains separate. This is not a moved-row parity deferral. Rust product API sources remain frozen. This lane makes no product edits and runs no tests.

Recommended local helper preserves the nonprojection fast path: use marker.line.key when usesProjection is false. Otherwise first use keyOf(doc.placementOf(marker.id).parent) when an accepted placement exists, then doc.logicalLineOf(marker). Both refreshGrid and exported gridPath must use that one helper.

Doc.placementOf reads placementProjection().current (`doc.ts:1797-1800`). Placements.project replays movements in total Ticket order and accepts only cycle-safe current ancestry (`placement.ts:21-37`); this is not the latest raw movement record. A newer cyclic move can remain retained while the accepted current parent is older. The helper must follow the accepted parent.

Doc.logicalLineOf returns required.parent before placement (`doc.ts:1806-1811`). Valid required-line targets cannot be explicitly moved: Doc.check rejects any move whose target.line is parseRequired (`doc.ts:587-594`). The accepted-placement-first helper is still clearer and avoids depending on that early-return detail. No doc.ts change is required.

Exact marker identity remains the grid lookup predicate. Do not return the stale grid object or a neighbor when the marker is absent in the chosen current line. Keep the last-axis deletion behavior: refreshGrid can miss after the grid has no current projected axes, and deleteColumns intentionally returns on that undefined result (`edit.ts:1146-1150`). An unconditional throw on refresh miss would change that bounded existing behavior.

The correction must cover row insertion, column insertion/reuse, column deletion, and exported gridPath consumers used by merge/cell-property commands. Preserve nonprojection behavior, unchanged grids and the existing numeric column memo. The minimal helper also permits direct tests with a retained GridBlock captured before a move.

Focused regressions should show the original moved-row failure before the fix, then current-path row/column editing and gridPath after cross-parent moves, accepted cycle-winner behavior when a newer cyclic candidate is retained, exact marker handling among two same-type grids, and over-count/last-column delete preserving its return behavior. Parent owns broader workspace/TSC and fresh TS/native qualification. Review approval cannot substitute for those receipts.

## Frozen correction review

The final source uses one local gridLine helper exactly as recommended. refreshGrid still returns only the exact current grid-kind marker match, with no stale-object/neighbor fallback. exported gridPath uses the same selected line. Nonprojection code returns the birth line before any placement lookup. deleteColumns retains the `if (!now) return` path after a grid loses its last axis. No Doc/placement log or numeric memo behavior changes.

The baseline-to-current source diff contains only the helper, its refreshGrid/gridPath call sites and the explicit grid-kind predicate. The frozen test file adds eight tests: three each for original Word section and Presentation slide owners (moved row/shared column/full model/foreign undo/redo/checkpoint; column memo deletion/span/last-axis deletion; retained GridBlock gridPath through move undo/redo), one custom schema-valid newer cyclic move that stays retained while prior accepted placement wins, and one ordinary nonprojected grid regression. The cycle test asserts check=null, two retained moves, accepted.at unchanged, current gridPath and complete expected row model after insertion. These test bodies were inspected; this lane did not run them.

The owner reported focused58 PASS (new8 + affected50), generated-dist8 PASS and the approved single-package build. This lane separately verified all 138 before/after dist map entries against live files: only `packages/doc-sync/dist/crdt/edit.js` changed, zero additions/removals, and zero live after-map drift. The generated JS diff has exactly the same helper/call-site/grid-kind change. Archives preserve the old source/dist. `ts-dist-review.json`, both .diff files and the refreshed implementation-source-seal.json contain the exact evidence. No workspace, native, comparison or build PASS was inferred from source inspection.

The pre-fix moved-row parity limitation is resolved at source. The moved-grid row positive command is restored to the new comparison corpus along with its cell tuple command. Parent/comparer own the fresh complete execution receipt; it must include the new edit.ts/dist bytes and cannot reuse the failed pre-fix comparison.
