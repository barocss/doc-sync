---
work_id: rust-d3-column-targeting-2026-11-05-design
artifact_type: command_contract
status: draft_after_axis_qualification
owner_role: reservation-review
source_request: Q1.3.3 one explicit column command, design only while Q1.3.2 is implemented
last_updated: 2026-11-05
---

# Q1.3.3 one call creates one column

Implement this only after Q1.3.2 is qualified. One `insert_column_relative` call creates one new column in one existing visible stored grid. Its unique row-ID payloads fill that same column. Existing numeric batch memo semantics stay unchanged. Multiple public calls create multiple columns; multi-column atomic commands are outside this slice.

This is a command contract, not an implementation or test receipt. No product source or prior phase artifact was changed by this design lane.

## API and result

```rust
pub enum ColumnBoundary { Start, End, Before(Key), After(Key) }
pub struct RowCellPayload { pub row: Key, pub model: Value }
pub struct ColumnInsert {
    pub grid: Key,
    pub boundary: ColumnBoundary,
    pub cells: Vec<RowCellPayload>,
}
pub struct ColumnInsertResult {
    pub column: Key,
    pub change: Change,
    pub clock_before: u64,
    pub clock_after: u64,
}
pub fn insert_column_relative(
    &mut self,
    base: &ModelEditBase,
    command: ColumnInsert,
    options: EditOptions,
    now_ms: f64,
) -> Result<ColumnInsertResult>;
```

Reuse the existing opaque process-local base. It has no Serde/checkpoint/wire representation. The new column result is a real positive axis ID. It can form an explicit grid/row/column tuple but remains invalid as a generic Q1.3.1 Before/After block anchor. There is no cell-wrapper ID or public alias namespace.

`cells` is an ordered sequence with unique row IDs, not a map that silently changes operation order. The model for each item must be the grid's declared cell type and pass the existing model compiler's cell/body/attribute validation. Unspecified rows receive their existing default empty cells. Row payloads may contain nested grids; exactly-one-column refers to the target grid, not to all col wire births inside nested payloads.

The call produces one aggregate Change, one pending entry and one History record transaction. Default History options create one undo action. Existing typing coalescence can merge it with a preceding compatible History group; this API does not change that rule. `clock_after` includes all compiler reservations and survives own checkpoint restore.

## Precondition and target validation

Validate the local base/schema/incarnation/revision before any compilation. Reject a non-document schema or non-finite time. Find exactly one current root-reachable stored grid primary using the qualified strict locator. Reject a deleted/hidden/aliased/synthetic grid and a grid inside a covered ancestor. A moved surviving grid is valid with a fresh base and its current model path.

Resolve boundary ownership against that grid's current live column IDs. Before/After must name one exact positive live col axis owned by this grid. Do not accept another grid's same-type axis, a source head, an old placement ticket, a deleted col or a selection fallback. Start/End require no column anchor but still require the same valid current grid. A grid whose last axis was deleted has no current visible grid identity and rejects rather than being resurrected.

Every payload row must be a positive live row axis owned by this grid. Reject duplicates, wrong-grid, missing, deleted or synthetic rows. Validate all these bindings before creating the candidate column. Current row/column indexes are only derived implementation data; they are not persistent identities. Use one state view and row/column lookup maps instead of repeated full native exports for validation.

A row axis is structural. Existing covered cells in its visual band do not invalidate it. Do not apply the InsideCell covered-cell restriction to this whole-column command. New cell payloads can become covered by the existing stable span rules and remain retained, matching existing numeric model insertion. Do not auto-split, unmerge, discard hidden payloads or reject a valid structural result because some new cells are covered.

## Empty payload contract

`cells=[]` still means create one column. Choose the first current live row only as the compiler seed. Use the declared empty cell model with no attrs and no body content, for example `{type: cellType, children: []}`. This uses an existing live row ID internally; it does not invent a cell identity or mutate existing row content. A visible grid supplies at least one live row.

The existing native `fill_flow` returns immediately for empty content, and empty cell attrs produce no writes (`runtime_structure.rs:458-475,568-605`). TS `fillFlow` has the same empty return (`edit.ts:878-884`), and its `fillCell` takes absent body content as empty (`:932-939`). Therefore the planned seed should author the target-grid col birth only, with no user body-content writes. Qualification must check exact operations, clocks and checkpoint storage; source inspection alone does not prove eager/lazy head parity.

Do not silently convert an empty payload into a no-op or require a fake caller row alias. The returned column key and target-grid axis set must prove that the column exists even though no row payload was supplied.

## One evolving compiler and fixed boundary

1. Capture the existing before clock/checkpoint and restore one detached Compiler with `batch=true`, `column=None`.
2. Resolve grid and column boundary exactly once. Let c be the current insertion index. Validate unique payload row IDs and remember their current row indexes. With no payloads, install the explicit empty seed row above.
3. Reuse the existing cell-model insertion compiler at c. The first row creates a fresh col axis and the numeric memo. Each subsequent distinct row fills the same current index c. Do not resolve Before(originalColumn) again after creation.
4. Check that all internal result keys equal the one new column key, that the target grid's columns contain it at the intended current position, and that the target grid's column-ID set gained exactly that one key. Existing target-grid row IDs and prior column IDs must remain present and ordered. Nested payload tables can create their own axes.
5. Publish all compiled ops and final compiler clock with one existing stage_change/history_record. Any later invalid payload discards the candidate, preserving live model, clock, History, pending and the original base.

The unchanged memo is `(grid,numeric c,used row IDs)`. Fresh compiler state and unique rows make one-column creation explicit. There is no cross-command carryover because there is only one logical column command per call. Source: native `insert_model_cell` at `runtime_structure.rs:709-754`, TS `insertColumns` at `edit.ts:997-1020`.

A direct helper that emits one col axis then fills the selected cells could implement the same contract, but it adds another compiler path. Prefer reusing the existing qualified cell insertion and memo for the first bounded slice. If private method visibility needs to change, expose only the helper within the compiler module; do not add an unguarded public raw-column API.

## Why public per-row column targets stay out

With original `[C0,C1]`, Before(C1) in R0 first creates N at index1. Re-resolving Before(C1) in R1 gives index2, so the existing memo creates a second column. In contrast, After(C0) twice in distinct rows stays at index1 and shares one column. Repeated same-row insertion creates another column. This is existing numeric batch behavior, not a suitable whole-column command boundary.

Do not add a stable-ID memo to reinterpret existing Q1.2 commands, and do not pre-resolve every user command against an old model. The new command explicitly owns its one boundary resolution and one global column creation.

## Independent TS oracle

The TS driver independently finds the exact visible grid and current owned axes. It resolves c once for the whole command and maps unique row IDs to their current row indexes. Expand payloads to a single Doc.edit array of `{op:insert, at:[...gridPath,rowIndex,c], content:[cellModel]}`. Every row uses the same c. For an empty payload, expand the explicit first-live-row empty cell seed.

Call live TS Doc.edit once, record History once, and compare with an independently constructed full structural model. Do not use a native path or result key to plan the TS call. Compare the target grid's before/after column-ID sets rather than counting every col operation globally. Retain preexisting/new covered-cell data and stable span endpoint behavior in the expected model. Preserve the normal operation, clock, History, pending, selection and own-checkpoint checks from earlier corpora.

There is no need for a memo-reset UPDATE inside this one-command call. If a later API accepts several logical column commands in one transaction, adjacent TS inserts can share the memo across command boundaries. That API requires a separate explicit barrier contract. Existing TS empty UPDATE clears the memo at `edit.ts:366`, but adding such adapters is outside this single-command implementation and must not be hidden in its parity claim.

## Order, retry and local lifecycle

Payload row order controls operation/ticket allocation; target-grid row order is unchanged. The caller can repeat the same boundary in another call only with a fresh base, which creates a distinct column. Repeated Before(C1) calls place new columns in input order before C1; repeated After(C0) calls place the latest column nearest C0, matching sequential insertion.

Any delivered peer axis operation, including a lower-clock one, invalidates the previous base under the existing conservative publication rule. A fresh base follows surviving owned column/row IDs at their current indexes. A deleted boundary or payload row rejects without nearest-axis fallback. Identical successful restore invalidates old local bases; rejected calls/failed restore preserve them. No network lock or distributed read/commit guarantee is implied.

Retry uses the exact captured pending Change. Recompiling the whole-column request with a fresh base creates another column and is a new edit. One undo/redo action must preserve peer writers and foreign text in retained cells under the existing selective History contract. Hosted permission changes, retry authorization and server acceptance remain Q1.4/D4 work.

## Minimum qualification after axis slice

- Original Word/Presentation and renamed custom schema: one, many and zero payload rows; start/end/before/after boundaries.
- Distinct payload rows share exactly one new target-grid col ID. Duplicate row IDs reject even with identical or empty payloads.
- Wrong-grid boundary columns and payload rows, deleted axes, hidden/deleted grids, synthetic heads and covered ancestors reject atomically.
- Insertion inside an existing colspan extends stable endpoint spans, retains payload in newly covered cells and preserves foreign text/writers through one undo/redo, restore and exact retry.
- Empty payload adds the single target-grid col birth with the declared empty-cell semantics. No extra body operation or clock reservation is invented by the seed.
- A cell payload with a nested table does not cause the target-grid invariant to count nested col births as extra target columns.
- Later invalid cell payload rejects all earlier candidate work and leaves the original base usable with an existing redo branch and pending changes intact.
- Same original boundary in separate fresh-base calls creates distinct columns. Old-base replay rejects. Typed cell-body edges can use the returned col key with an owned row; generic block targets still reject it.
- Peer axis insertion/deletion before commit rejects the old base; a fresh base binds the original surviving IDs. Raw axis Move remains unsupported.
- Current Q1.3.2/Q1.3.1 and affected Q1.2 checks stay qualified after the new source freeze. Do not infer performance or production Rust/WASM acceptance.

All checks above are planned and NOT_RUN in this design lane. Source hashes are in `column-source-seal.json` and describe the reviewed implementation inputs, not implementation of this proposed API.
