---
work_id: rust-d3-axis-targeting-2026-11-05
artifact_type: implementation_source_review
status: done
owner_role: reservation-review
source_request: Read-only actual Q1.3.2 typed row/cell implementation review after owner freeze
last_updated: 2026-11-05
---

# Q1.3.2 final product source review

Verdict: **APPROVED_BOUNDED_SOURCE**, zero blocking findings. The authoritative TS moved-grid refresh correction is now included after its owner-confirmed final source freeze; see ts-grid-refresh-review.md. The final API, helper refactor, examples and nine focused test bodies were read after batch_impl confirmed final source freeze. This is source approval. This lane ran no Cargo, native, differential, browser, mobile or performance checks.

`implementation-source-seal.json` records the exact 25 product/test/example/generated-JS and stable context inputs. All 14 shadow-core source files equal the Q1.3.2 baseline. The new axis comparison harness remains under independent authoring and is deliberately outside this product-source approval; its fresh receipt must bind the executed harness bytes. Current docs and older reports were not edited by this lane.

## Typed target and ownership proof

The new `runtime_grid_targeting.rs:5-27` types are existing-key pairs/triples: GridRowTarget `{grid,row}` and GridCellTarget `{grid,row,column}`. GridModelTarget supplies only BeforeRow/AfterRow and InsideCellStart/End. They are separate from the unchanged Q1.3.1 RelativeModelTarget/FlowTarget enums. There is no model row/cell/body wrapper ID, axis Move or column-creation signature.

`grid_target_path` captures one native state and builds one TargetView (`:79-93`). It asks the extracted strict locator for exactly one current root-reachable stored primary grid, then verifies projection and effective grid shape (`:93-99`). It does not use the old broad refreshed_grid search as visibility proof. Thus a deleted/hidden/cardinality-hidden grid or one inside a covered ancestor cannot be recovered through retained physical cell lines.

The row key must pass `require_stored_kind` as a positive, alive, non-required synthetic, actual node with the grid's declared row birth kind. It must also occur in this exact current grid's rows list (`:100-109`). Global token existence or a same-type row in another grid cannot pass. BeforeRow uses its current index; AfterRow uses checked index+1. No nearest row fallback is present.

For cell targets, the column must similarly have actual col birth kind and current membership in this grid's cols (`:124-133`). The current covered map rejects covered tuples while allowing a visible merge anchor (`:134-136`). The pair-to-line map must contain the exact row/column pair, and its line must equal the existing deterministic cell_head(grid,row,column) (`:137-144`). The canonical model cell-body wrapper is selected at index0; Start/End uses the current body child count (`:145-163`). Missing/malformed body projection fails rather than selecting another cell.

The source admits a live structural row even when its cells are covered. It adds no post-insertion visibility check and no new span/spanned restrictions. Row commands lower directly to the existing schema RowModel compiler, retaining fixed width, excess-cell truncation, stable span growth and retained hidden body payload. This distinction is required: current cell targets must be visible, while valid structural row insertion may create covered cells under an existing merge.

## Atomicity and local base

`insert_grid_models_relative` checks the existing opaque base/schema/incarnation/revision before compilation (`:35-49`). It restores one detached Compiler, resolves each typed command against the evolving candidate and calls the same compile_model_insert helper (`:50-63`). It sends all ops plus final reservation clock to one stage_change/history_record only after the entire loop succeeds (`:64-75`). A later ownership, coverage, path, schema or payload failure discards all earlier candidate work.

No local-version mechanism changes. The base still contains only private incarnation/revision/schema fields, with no Serde or checkpoint representation. The live document still publishes only through apply_remote, stage_change or successful restore_checkpoint. These gates retain checked revision overflow, conservative successful no-op invalidation, read/ack preservation and restore ABA rejection. There is no new mutable-server accessor, Clone implementation or direct live apply route in the typed API.

Empty/clock-only results retain the Q1.2 Change, pending and History rules. Some(result key) is not proof of an editable stored primary. A cell insertion may fill an existing zero-clock body head; generic Before/After still rejects it. The explicit owned cell tuple remains the supported way to address that body's edges. Row results are actual new positive row-axis IDs.

## Shared locator and performance boundary

The Q1.3.1 private locator was extracted as locate_stored_block_in and now returns path, canonical node and projection. The generic target enum and its root-reachable primary walk remain unchanged. require_stored_kind uses a captured token kind/birth index instead of repeated raw token scans. Generic row/column keys still cannot appear as primary blocks in the root traversal; aliases, characters and synthetic heads still reject.

TargetView captures state once per target resolution. Current rows/cols use bounded linear position searches on that grid, token membership uses indexes, and cell_lines builds a pair map with duplicate-pair rejection. The existing strict traversal and the typed lookup share that helper. There is no per-cell scan of all cell entries and no per-flow re-export of complete native state inside the new resolver. This removes the previously identified additional quadratic lookup pattern; it is not a performance measurement. Model export, strict traversal, candidate restore and existing compiler work retain their own costs. The local base guard remains O(1) in document/journal size and retains no full snapshot per token.

## Focused test bodies inspected

`tests/runtime_grid_targeting.rs` contains nine tests:

- `:109`: repeated row IDs resolve sequentially; fixed width drops extra payload cells without adding columns; original cell tuple survives changed row index; one pending Change and one default History action.
- `:159`: same-kind wrong-grid rows/cols, wrong axis kind, synthetic/missing grid/row and later invalid command preserve exact live checkpoint and base usability. Generic axis targeting and row Move remain rejected.
- `:232`: current covered cell rejection, visible merge-anchor edit, plain-row insertion growing the old rowspan to3, retained covered cell content, and undo/redo. A later direct edit of the new covered tuple rejects.
- `:308`: peer row insertion invalidates old base, fresh tuple follows the original row ID, lower-clock column deletion leaves Lamport max unchanged but invalidates the base, and a fresh deleted-col tuple rejects.
- `:377`: visible nested-grid row insertion works; covered ancestor, raw grid-owner deletion and last-column deletion reject despite retained descendants.
- `:449`: intrinsic-head result key, exact pending retry, foreign text through undo/redo and restore, identical checkpoint rollback invalidation, successful empty call consuming its base.
- `:508`: explicit rowspan/colspan/spanned payload matches the existing numeric RowModel result, operations and complete checkpoint, including overlap/normalization behavior. This is native equivalence to the existing compiler, not independent TS proof.
- `:553`: normalized-empty cell-body insertion returns None, reserves clock without fake identity or operations, restores the exact checkpoint, and rejects old local base.
- `:584`: cardinality-hidden grid rejection and a fresh moved-grid row target following current ancestry, with exact new row content.

The implementation owner reported focused and example execution separately. This review inspects their bodies and does not turn those reports into this lane's native PASS. In particular, a root FOREIGN test alone does not prove hidden-cell peer-writer preservation; the new independent corpus is expected to carry that separate scenario and both undo orders.

## Authoritative TS refresh correction included

The failed comparison exposed a real TS defect: refreshGrid and gridPath selected the grid marker's birth line after a cross-parent move, so row insertion could receive undefined. That defect is fixed in this phase, with its failed preparation receipts retained.

Final edit.ts uses one local gridLine helper. Nonprojection keeps the original birth-line fast path. Projection first uses the accepted placementOf(id).parent from placementProjection().current, then logicalLineOf only when no accepted placement exists. Both refreshGrid and gridPath use it. refreshGrid requires the exact grid-kind marker and never falls back to the stale object or a neighbor. Last-axis deletion still returns on undefined. No Doc/placement-log/numeric-memo change was needed.

Eight new focused test bodies cover original Word/Presentation moved row/shared-column insertion, full-model intent, foreign cell text through undo/redo and own snapshot, span and column-deletion memo, last-column overdelete, gridPath through move undo/redo, a newer retained schema-valid cyclic move whose accepted parent remains older, and the nonprojection fast path. They were read after TS source freeze. This lane did not run them; parent owns focused58/dist8 and broader execution receipts.

The generated JS has the same minimal change. This lane verified the 138-file before/after dist maps against live files: exactly crdt/edit.js changed, zero additions/removals and zero after-map drift. Old source/dist bytes are preserved, and source/dist diffs plus exact hashes are in ts-grid-refresh-review.md, ts-dist-review.json and the current 25-input implementation-source-seal.json.

The new axis TS oracle independently checks current exact grid marker, physical axis owner/slot plus projected membership, covered policy and complete prefix-array lowering. Its mutable fixtures/oracle/compare files are not included in this product-source approval. The fresh corpus restores the moved-grid row positive plus cell-tuple command and must bind the corrected source/dist and actual runtime_grid_targeting_trace binary. Native product source and binary remained unchanged. Source approval does not substitute for that differential receipt.

## Bounded approval

Approve this native typed row/cell API source. Column creation remains Q1.3.3, with the separate one-call/one-target-grid-column contract in column-contract.md and unchanged numeric column memo. Typed read catalog/alias diagnostics, multi-column atomicity, axis Move, D4 lifecycle, distributed conditional acceptance, Q1.4 authorization, production Rust/WASM, browser/mobile and performance acceptance remain open.

The pre-TS-fix native source seal is preserved as `native-pre-ts-refresh-source-seal.json`. The current implementation-source-seal.json supersedes it for product source approval and includes the corrected TS source, its new regression file, accepted placement implementation and generated dist edit.js. See `ts-grid-refresh-review.md` for the final correction review and 138-file dist hash verification.
