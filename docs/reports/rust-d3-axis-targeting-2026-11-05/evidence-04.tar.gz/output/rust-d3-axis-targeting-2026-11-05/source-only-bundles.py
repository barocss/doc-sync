from pathlib import Path
import tarfile,hashlib,json,io
base=Path('output/rust-d3-axis-targeting-2026-11-05');record=base/'source-only-bundles.json';rows=json.loads(record.read_text()) if record.exists() else [];done={r['original'] for r in rows}
for p in sorted(base.rglob('*-sources.tar.gz')):
 if str(p) in done:continue
 with tarfile.open(p,'r:gz') as a:
  members=a.getmembers()
  if not any(any(q in {'target','native-target'} for q in Path(m.name).parts) for m in members):continue
  dest=p.with_name(p.name.replace('-sources.tar.gz','-source-code.tar.gz'));assert not dest.exists(),dest
  entries=[]
  with tarfile.open(dest,'w:gz',compresslevel=1) as b:
   for m in members:
    if not m.isfile() or any(q in {'target','native-target'} for q in Path(m.name).parts):continue
    data=a.extractfile(m).read();b.addfile(m,io.BytesIO(data));entries.append({'path':m.name,'sha256':hashlib.sha256(data).hexdigest()})
 with tarfile.open(dest,'r:gz') as a:
  for e in entries:assert hashlib.sha256(a.extractfile(e['path']).read()).hexdigest()==e['sha256']
 rows.append({'original':str(p),'sourceOnly':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'members':entries,'readback':'PASS'})
record.write_text(json.dumps(rows,indent=2)+'\n');print({'sourceOnlyBundles':len(rows)})
