from pathlib import Path
import hashlib,json,re,subprocess,sys

root=Path('/Users/user/github/doc-sync');task=root/'output/rust-d3-axis-targeting-2026-11-05'
cargo='/opt/homebrew/bin/cargo'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def source_map():
    paths=set()
    for folder in ['experiments/rust-sdk','experiments/rust-shadow']:
        for path in (root/folder).rglob('*'):
            if path.is_file() and not any(part in {'target','native-target'} for part in path.relative_to(root/folder).parts) and path.suffix in {'.rs','.toml','.lock'}:
                paths.add(path)
    for name in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
        paths.add(root/name)
    return {str(path.relative_to(root)):sha(path) for path in sorted(paths)}
def check(name,args):
    result=subprocess.run([sys.executable,str(task/'run-check.py'),name,*args],cwd=root)
    if result.returncode:raise RuntimeError('Check failed: '+name)
    path=task/(name+'.json');value=json.loads(path.read_text())
    return {'receipt':str(path.relative_to(root)),**value}
before=source_map();(task/'native-final-sources-before.json').write_text(json.dumps(before,indent=2)+'\n')
checks={}
checks['core']=check('native-final-core',[cargo,'test','--offline','--locked','-j1','--manifest-path','experiments/rust-shadow/Cargo.toml'])
checks['sdk']=check('native-final-sdk',[cargo,'test','--offline','--locked','-j1','--manifest-path','experiments/rust-sdk/Cargo.toml'])
checks['example']=check('native-final-example',[cargo,'run','--offline','--locked','-j1','--manifest-path','experiments/rust-sdk/Cargo.toml','--example','runtime_grid_targeting'])
for which in ['readme','guide']:
    manifest=str((task/('consumer-'+which)/'Cargo.toml').relative_to(root))
    checks[which+'-lock']=check('native-final-'+which+'-lock',[cargo,'generate-lockfile','--offline','--manifest-path',manifest])
    checks[which+'-consumer']=check('native-final-'+which+'-consumer',[cargo,'run','--offline','--locked','-j1','--manifest-path',manifest])
checks['cli']=check('native-final-cli',[cargo,'build','--offline','--locked','-j1','--manifest-path','experiments/rust-shadow/Cargo.toml'])
checks['inherited-traces']=check('native-final-inherited-traces',[cargo,'build','--offline','--locked','-j1','--manifest-path','experiments/rust-sdk/Cargo.toml','--example','runtime_targeting_trace','--example','runtime_batch_trace','--example','runtime_group_grid_trace','--example','runtime_moved_trace','--example','runtime_paragraph_trace','--example','runtime_schema_trace','--example','runtime_textfalse_trace'])
after=source_map();(task/'native-final-sources-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'native source changed during final checks'
for key,name in [('core','native-final-core.log'),('sdk','native-final-sdk.log')]:
    log=(task/name).read_text()
    checks[key]['passed']=sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',log))
    checks[key]['failed']=0
program=(root/'experiments/rust-sdk/examples/runtime_grid_targeting.rs').read_text().strip()
for name in ['experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:
    assert program in re.findall(r'```rust\n(.*?)\n```',(root/name).read_text(),re.S),name
for which in ['readme','guide']:
    assert (task/('consumer-'+which)/'src/main.rs').read_text().strip()==program
baseline=json.loads((task/'baseline.json').read_text())['files']
inherited=[name for name in baseline if name.startswith(('experiments/rust-sdk/tests/','experiments/rust-sdk/examples/','experiments/rust-shadow/tests/','experiments/rust-shadow/examples/'))]
for name in inherited:assert sha(root/name)==baseline[name],name
trace=task/'native-target/debug/examples/runtime_grid_targeting_trace'
cli=task/'native-target/debug/doc-sync-rust-shadow'
result={'status':'PASS','checks':checks,'sourceFiles':len(before),'sourceStable':True,
        'sourcesBefore':'output/rust-d3-axis-targeting-2026-11-05/native-final-sources-before.json',
        'sourcesAfter':'output/rust-d3-axis-targeting-2026-11-05/native-final-sources-after.json',
        'inheritedTestsExamples':len(inherited),'inheritedTestsExamplesPreserved':True,
        'fullExampleFencesAndConsumersExact':True,
        'trace':{'path':str(trace.relative_to(root)),'sha256':sha(trace)},
        'cli':{'path':str(cli.relative_to(root)),'sha256':sha(cli)},
        'notRun':['Chrome','mobile','performance benchmark','WASM','remote publication']}
destination=task/'native-final-receipt.json';assert not destination.exists()
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','core':checks['core']['passed'],'sdk':checks['sdk']['passed'],'sourceFiles':len(before),'inheritedTestsExamples':len(inherited)}))
