# Runtime group/inline/span verification

Source base is main1cfb7a2 plus inherited uncommitted flow+grid implementation,
captured as67files baseline. Preserve all prior sealed reports.

Core/SDK/comparison agents own disjoint files. Implement schema-driven computed
groups, inline tokens and scalar-mark-derived spans with arbitrary names,
multiple definitions, nested flow/grid-cell contexts and selective History.
Keep physical-source helpers distinct from D3 model-position compilation.

Compare independent semantic authors: ops/tickets, raw full History and
availability, typed pending/carets, normalized models, clock and material token
state. Preserve every actual failure and explain only format projections.
Negative fixtures must reach intended rejection paths, not omit required fields.
Qualify coupled checkpoint restoration within each runtime; no cross-runtime
snapshot wire, production recovery/GC, live transitions, WASM/client factory,
Chrome/mobile/performance, commit/push or registry release claim.

After frozen source, rerun affected previous flow/grid/legacy comparisons in new
output+target dirs. Run npm full workspace and docs build/check sequentially,
never rebuild dist while TS traces or npm tests are reading it. Run standalone
extracted documented Cargo example. Record current source hashes and seal a
portable selected-evidence archive with final/failure logs, no build binaries.
