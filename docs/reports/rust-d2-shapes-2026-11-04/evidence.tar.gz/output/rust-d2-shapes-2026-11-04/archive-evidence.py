from pathlib import Path
import os,json,hashlib,tarfile
root=Path('/Users/user/github/doc-sync'); task=root/'output/rust-d2-shapes-2026-11-04'; report=root/'docs/reports/rust-d2-shapes-2026-11-04'
selected=set()
for directory,dirs,files in os.walk(task):
 dirs[:]=[d for d in dirs if d!='target' and not d.endswith('-target') and not d.startswith('target-') and d not in {'before-src','baseline-source'}]
 for name in files:
  p=Path(directory)/name
  if p.suffix in {'.json','.log','.rs','.mjs','.toml','.lock','.md','.stderr','.py'} or p.name=='baseline.tar.gz':selected.add(p)
for p in (task/'sdk/before-src').glob('experiments/rust-sdk/tests/runtime_grid_before.rs'):selected.add(p)
for directory in ['experiments/rust-sdk','experiments/rust-shadow']:
 for base,dirs,files in os.walk(root/directory):
  dirs[:]=[d for d in dirs if d!='target']
  for name in files:
   p=Path(base)/name
   if p.suffix in {'.rs','.toml','.lock','.json'}:selected.add(p)
for directory in ['experiments/runtime-document-shapes','experiments/runtime-document-grid','experiments/runtime-document-nested']:
 selected.update((root/directory).glob('*.mjs'))
for name in ['experiments/runtime-schema-native/compare.mjs','README.md','HANDOFF.md','experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md','apps/docs/src/schemas/custom.md','apps/docs/src/schemas/document.md','apps/docs/src/roadmap.md','docs/rust-roadmap.md','docs/reports/rust-d2-shapes-2026-11-04/README.md','docs/reports/rust-d2-shapes-2026-11-04/final-checks.json']:
 selected.add(root/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(selected)]
archive=report/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(selected):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'status':'SELECTED_EVIDENCE_SEALED','sourceBase':'1cfb7a23611f0a98994a6716cfc2bddfc5ba89f4 plus captured uncommitted recursive-flow/grid baseline','archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},'files':files,'excluded':['Cargo targets and executables','duplicate native.stdout traces','duplicate baseline extraction sources']}
(report/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 for f in files:assert hashlib.sha256(tar.extractfile(f['path']).read()).hexdigest()==f['sha256'],f['path']
seal={'status':'PASS','files':{p.name:sha(p) for p in [report/'README.md',report/'final-checks.json',report/'manifest.json',archive]},'archiveMembersVerified':len(files)}
(report/'seal.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'members':len(files),'archiveBytes':archive.stat().st_size,'readback':'PASS'}))
