use doc_sync_native_sdk::RuntimeSchema;
use serde_json::{Value,json};
fn main(){let cases:Vec<Value>=serde_json::from_str(include_str!("../cases.json")).unwrap();let results:Vec<Value>=cases.into_iter().map(|case|{let error=RuntimeSchema::compile(case["schema"].clone()).unwrap_err();json!({"name":case["name"],"expectedBeforeRejection":true,"error":error.to_string()})}).collect();println!("{}",serde_json::to_string_pretty(&results).unwrap());}
