use doc_sync_native_sdk::*;
use serde_json::{json, Value};

fn find<'a>(value: &'a Value, kind: &str) -> Option<&'a Value> {
    if value["type"] == kind { return Some(value); }
    match value {
        Value::Object(fields) => fields.values().find_map(|v| find(v, kind)),
        Value::Array(items) => items.iter().find_map(|v| find(v, kind)),
        _ => None,
    }
}
fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({
        "root":"book", "marks":["bold"],
        "markValues":{"destination":{"default":"","inherit":false}},
        "nodes":{
            "book":{"shape":"flow","children":["line","list"],"default":"line"},
            "line":{"shape":"text","children":["badge","link"]},
            "list":{"shape":"group","children":["entry"],"by":["depth"]},
            "entry":{"shape":"text","children":["badge","link"],
                "attrs":{"depth":{"default":0}}},
            "badge":{"shape":"inline","attrs":{"label":{"default":""}}},
            "link":{"shape":"span","mark":"destination","attr":"href"}
        }
    }))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let head = RuntimeDocument::flow_head(None)?;
    let (entry, _) = a.insert_group_member_at(
        &head, "list", "entry", None, None, Attributes::new(), EditOptions::default(), 1.,
    )?;
    a.insert_text_at(
        &head, Some(&entry), "A😀", Attributes::new(), EditOptions::default(), 2.,
    )?;
    let text = a.line_token_ids(&head)?;
    assert_eq!(text.len(), 3); // UTF-16: A plus two surrogate units.
    let (badge, _) = a.insert_inline_at(
        &head, "badge", text.last(), Attributes::new(), EditOptions::default(), 3.,
    )?;
    assert_eq!(a.line_token_ids(&head)?.len(), 4); // Inline occupies one position.
    a.set_attribute(&badge, "label", json!("status"), EditOptions::default(), 4.)?;
    a.set_group_attribute(&[entry], "list", "depth", json!(1), EditOptions::default(), 5.)?;
    a.format_span(&text, "link", json!("own"), EditOptions::default(), 6.)?;
    for change in a.pending_changes() { b.apply_remote(&change.ops)?; }
    let foreign = b.format_span(&text, "link", json!("peer"), EditOptions::default(), 7.)?;
    a.apply_remote(&foreign.ops)?;
    let undo = a.undo()?;
    b.apply_remote(&undo.ops)?;
    assert_eq!(find(&a.model()?, "link").unwrap()["attrs"]["href"], "peer");
    let redo = a.redo()?;
    b.apply_remote(&redo.ops)?;
    assert_eq!(find(&a.model()?, "link").unwrap()["attrs"]["href"], "peer");
    assert_eq!(a.model()?, b.model()?);

    let pending = a.pending_changes().to_vec();
    let checkpoint = a.checkpoint()?.to_json()?;
    a = RuntimeDocument::restore(&RuntimeCheckpoint::from_json(&checkpoint)?)?;
    assert_eq!(a.pending_changes(), pending.as_slice());
    let before_retry = a.checkpoint()?.to_json()?;
    for _ in 0..2 {
        for change in &pending {
            a.apply_remote(&change.ops)?;
            b.apply_remote(&change.ops)?;
        }
    }
    assert_eq!(a.checkpoint()?.to_json()?, before_retry);
    assert_eq!(a.model()?, b.model()?);
    // A host acknowledges only a transport-accepted exact prefix.
    a.acknowledge(&pending)?;
    assert!(a.pending_changes().is_empty());
    println!("PASS: shapes, foreign value, History, checkpoint, retry, acknowledgement");
    Ok(())
}
