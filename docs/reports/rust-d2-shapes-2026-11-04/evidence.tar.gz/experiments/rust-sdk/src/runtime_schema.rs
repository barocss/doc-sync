//! User-defined native Document and Graphic schemas. Document support is the
//! recursive flow/grid/text/atom/group/inline/span subset. Unsupported rules fail
//! during compilation. Authoring addresses physical source heads and token keys.
use crate::{
    Attributes, Change, EditOptions, Error, HistoryStatus, Key, Op, Position, Result, Selection,
    Ticket, Utf16Text,
};
use doc_sync_rust_shadow as engine;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
const MAX_CLOCK: u64 = 9_007_199_254_740_991;
#[derive(Debug, Clone, PartialEq, Serialize)]
#[serde(transparent)]
pub struct RuntimeSchema {
    manifest: Value,
    #[serde(skip)]
    identity: String,
}
impl<'de> Deserialize<'de> for RuntimeSchema {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> std::result::Result<Self, D::Error> {
        let v = Value::deserialize(d)?;
        Self::compile(v).map_err(serde::de::Error::custom)
    }
}
impl RuntimeSchema {
    pub fn compile(manifest: Value) -> Result<Self> {
        let compiled =
            engine::runtime_schema::RuntimeSchema::compile(manifest.clone()).map_err(Error)?;
        let identity = compiled.identity().to_owned();
        Ok(Self { manifest, identity })
    }
    pub fn identity(&self) -> &str {
        &self.identity
    }
    pub fn manifest(&self) -> &Value {
        &self.manifest
    }
    pub fn domain(&self) -> &str {
        self.manifest["domain"].as_str().unwrap_or("document")
    }
}
/// Coupled native graphic/history checkpoint and exact unacknowledged changes.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RuntimeCheckpoint {
    version: u32,
    actor: String,
    native: Value,
    schema: RuntimeSchema,
    pending: Vec<Change>,
}
impl RuntimeCheckpoint {
    pub fn to_json(&self) -> Result<String> {
        Ok(serde_json::to_string(self)?)
    }
    pub fn from_json(input: &str) -> Result<Self> {
        let checkpoint = serde_json::from_str(input)?;
        RuntimeDocument::restore(&checkpoint)?;
        Ok(checkpoint)
    }
}
pub struct RuntimeDocument {
    server: engine::Server,
    actor: String,
    schema: RuntimeSchema,
    pending: Vec<Change>,
}
impl RuntimeDocument {
    pub fn new(actor: impl Into<String>, schema: RuntimeSchema) -> Result<Self> {
        let mut doc = Self {
            server: engine::Server::default(),
            actor: actor.into(),
            schema,
            pending: vec![],
        };
        doc.call(
            "new",
            json!({"actor":doc.actor,"runtimeSchema":doc.schema.manifest()}),
        )?;
        Ok(doc)
    }
    pub fn schema(&self) -> &RuntimeSchema {
        &self.schema
    }
    pub fn active_schema_identity(&self) -> &str {
        self.schema.identity()
    }
    pub fn actor(&self) -> &str {
        &self.actor
    }
    fn call(&mut self, command: &str, extra: Value) -> Result<Value> {
        let mut request =
            json!({"cmd":command,"replica":"graphic","schema":self.schema.identity()});
        for (key, value) in extra.as_object().expect("internal object") {
            request[key] = value.clone();
        }
        let response = self.server.request(request);
        if response["ok"] != true {
            return Err(Error(
                response["error"]
                    .as_str()
                    .unwrap_or("native graphic failure")
                    .into(),
            ));
        }
        Ok(response)
    }
    pub fn model(&mut self) -> Result<Value> {
        Ok(self.call("state", json!({}))?["state"]["model"].clone())
    }
    pub fn state(&mut self) -> Result<Value> {
        Ok(self.call("state", json!({}))?["state"].clone())
    }
    pub fn observed_clock(&mut self) -> Result<u64> {
        self.call("state", json!({}))?["state"]["clock"]
            .as_u64()
            .ok_or_else(|| Error("invalid graphic clock".into()))
    }
    pub fn next_ticket(&mut self) -> Result<Ticket> {
        let n = self
            .observed_clock()?
            .checked_add(1)
            .filter(|n| *n <= MAX_CLOCK)
            .ok_or_else(|| Error("clock exhausted".into()))?;
        Ok(Ticket {
            lamport: n,
            actor: self.actor.clone(),
        })
    }
    pub fn apply_remote(&mut self, ops: &[Op]) -> Result<()> {
        self.call("apply", json!({"ops":ops}))?;
        Ok(())
    }
    fn stage_change(&mut self, command: &str, extra: Value) -> Result<Change> {
        let checkpoint = self.call("history_export", json!({}))?["checkpoint"].clone();
        let mut candidate = Self {
            server: engine::Server::default(),
            actor: self.actor.clone(),
            schema: self.schema.clone(),
            pending: vec![],
        };
        candidate.call(
            "history_restore",
            json!({"actor":self.actor,"checkpoint":checkpoint}),
        )?;
        let response = candidate.call(command, extra)?;
        let change = Change {
            ops: serde_json::from_value(response["ops"].clone())?,
            caret: serde_json::from_value(response["caret"].clone())?,
        };
        self.server = candidate.server;
        if !change.ops.is_empty() {
            self.pending.push(change.clone());
        }
        Ok(change)
    }
    /// Fresh own wire operations. Retry previously sent operations with apply_remote.
    pub fn record(&mut self, ops: Vec<Op>, options: EditOptions, now_ms: f64) -> Result<Change> {
        if !now_ms.is_finite() {
            return Err(Error("now_ms must be finite".into()));
        }
        let mut previous = self.observed_clock()?;
        for op in &ops {
            let (at, width) = match op {
                Op::Node { id, .. } => (id, 1),
                Op::Text { id, units, .. } => (id, units.0.len().max(1) as u64),
                Op::Delete { at, .. }
                | Op::Undelete { at, .. }
                | Op::Set { at, .. }
                | Op::Move { at, .. } => (at, 1),
            };
            if at.actor != self.actor || at.lamport <= previous {
                return Err(Error(
                    "graphic record requires fresh own tickets in order".into(),
                ));
            }
            previous = at
                .lamport
                .checked_add(width - 1)
                .filter(|n| *n <= MAX_CLOCK)
                .ok_or_else(|| Error("clock exhausted".into()))?;
        }
        self.stage_change(
            "history_record",
            json!({"ops":ops,"options":options,"now":now_ms}),
        )
    }
    fn child_head(parent: Option<&Key>) -> Result<Ticket> {
        match parent {
            None => Key::root().ticket(),
            Some(key) => Key::parse(format!("0@{}/children", key.as_str()))?.ticket(),
        }
    }
    fn after_ticket(&mut self, after: Option<&Key>) -> Result<Option<Ticket>> {
        after
            .map(|key| {
                let state = self.call("state", json!({}))?;
                let value = &state["state"]["placements"][key.as_str()]["at"];
                if value.is_null() {
                    if self.schema.domain() == "document"
                        && state["state"]["lines"].as_array().is_some_and(|lines| {
                            lines.iter().any(|line| line["key"] == key.as_str())
                        })
                    {
                        return key.ticket();
                    }
                    return Err(Error("graphic order anchor missing".into()));
                }
                Ok(serde_json::from_value(value.clone())?)
            })
            .transpose()
    }
    /// Insert one object. None parent selects the canvas. None after inserts first.
    /// Declared structured attribute patches compile to independent field registers.
    pub fn insert(
        &mut self,
        kind: &str,
        parent: Option<&Key>,
        after: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        if self.schema.domain() != "graphic" {
            return Err(Error(
                "insert requires graphic schema; use insert_block for document".into(),
            ));
        }
        let id = self.next_ticket()?;
        let key = Key::from_ticket(&id);
        let parent = Self::child_head(parent)?;
        let after = self.after_ticket(after)?;
        let mut scalar = Attributes::new();
        let mut fields = vec![];
        for (name, value) in attrs {
            if self.schema.manifest()["nodes"][kind]["attrs"][&name]
                .get("fields")
                .is_some()
            {
                let values = value
                    .as_object()
                    .ok_or_else(|| Error("graphic field patch must be object".into()))?;
                for (field, value) in values {
                    fields.push((format!("$field:{}", json!([name, field])), value.clone()));
                }
            } else {
                scalar.insert(name, value);
            }
        }
        let mut clock = id.lamport;
        let mut ops = vec![Op::Node {
            id: id.clone(),
            origin: parent.clone(),
            node_type: kind.into(),
            boundary: String::new(),
            attrs: Some(scalar),
        }];
        for (field, value) in fields {
            clock += 1;
            ops.push(Op::Set {
                at: Ticket {
                    lamport: clock,
                    actor: self.actor.clone(),
                },
                ids: vec![id.clone()],
                key: field,
                value,
            });
        }
        if let Some(after) = after {
            clock += 1;
            ops.push(Op::Move {
                at: Ticket {
                    lamport: clock,
                    actor: self.actor.clone(),
                },
                target: id,
                parent,
                after: Some(after),
            });
        }
        let change = self.record(ops, options, now_ms)?;
        Ok((key, change))
    }
    /// Set one declared scalar or one encoded perfield key. Null restores its default.
    pub fn set_attribute(
        &mut self,
        id: &Key,
        key: impl Into<String>,
        value: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let at = self.next_ticket()?;
        self.record(
            vec![Op::Set {
                at,
                ids: vec![id.ticket()?],
                key: key.into(),
                value,
            }],
            options,
            now_ms,
        )
    }
    pub fn set_field(
        &mut self,
        id: &Key,
        attribute: &str,
        field: &str,
        value: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.set_attribute(
            id,
            format!("$field:{}", json!([attribute, field])),
            value,
            options,
            now_ms,
        )
    }
    pub fn delete(&mut self, ids: &[Key], options: EditOptions, now_ms: f64) -> Result<Change> {
        let at = self.next_ticket()?;
        self.record(
            vec![Op::Delete {
                at,
                ids: ids.iter().map(Key::ticket).collect::<Result<_>>()?,
            }],
            options,
            now_ms,
        )
    }
    /// Move the object with all descendants and label text. Cycles are ignored by
    /// the shared deterministic placement projection, while the op remains retained.
    pub fn reparent(
        &mut self,
        id: &Key,
        parent: Option<&Key>,
        after: Option<&Key>,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let at = self.next_ticket()?;
        let after = self.after_ticket(after)?;
        self.record(
            vec![Op::Move {
                at,
                target: id.ticket()?,
                parent: Self::child_head(parent)?,
                after,
            }],
            options,
            now_ms,
        )
    }
    pub fn insert_label_text(
        &mut self,
        label: &Key,
        after: Option<&Key>,
        text: impl Into<Utf16Text>,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.insert_label_text_with_marks(label, after, text, Attributes::new(), options, now_ms)
    }
    pub fn insert_label_text_with_marks(
        &mut self,
        label: &Key,
        after: Option<&Key>,
        text: impl Into<Utf16Text>,
        marks: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let ids = self.label_text_ids(label)?;
        if after.is_some_and(|key| !ids.contains(key)) {
            return Err(Error(
                "label anchor must be a visible token of this label".into(),
            ));
        }
        let id = self.next_ticket()?;
        let origin = match after {
            Some(key) => key.ticket()?,
            None => Key::parse(format!("0@{}/text", label.as_str()))?.ticket()?,
        };
        self.record(
            vec![Op::Text {
                id,
                origin,
                units: text.into(),
                marks,
            }],
            options,
            now_ms,
        )
    }
    /// Stable visible UTF-16 token keys for label editing. Deletion uses delete().
    pub fn label_text_ids(&mut self, label: &Key) -> Result<Vec<Key>> {
        let state = self.call("state", json!({}))?;
        let ids = &state["state"]["texts"][label.as_str()];
        if ids.is_null() {
            return Err(Error("label not found".into()));
        }
        Ok(serde_json::from_value(ids.clone())?)
    }
    pub fn undo(&mut self) -> Result<Change> {
        self.stage_change("history_undo", json!({}))
    }
    pub fn redo(&mut self) -> Result<Change> {
        self.stage_change("history_redo", json!({}))
    }
    pub fn history_status(&mut self) -> Result<HistoryStatus> {
        Ok(serde_json::from_value(
            self.call("history_state", json!({}))?["status"].clone(),
        )?)
    }
    pub fn pending_changes(&self) -> &[Change] {
        &self.pending
    }
    pub fn acknowledge(&mut self, changes: &[Change]) -> Result<()> {
        if !self.pending.starts_with(changes) {
            return Err(Error(
                "acknowledgement is not an exact pending prefix".into(),
            ));
        }
        self.pending.drain(..changes.len());
        Ok(())
    }
    pub fn checkpoint(&mut self) -> Result<RuntimeCheckpoint> {
        Ok(RuntimeCheckpoint {
            version: 1,
            actor: self.actor.clone(),
            schema: self.schema.clone(),
            native: self.call("history_export", json!({}))?["checkpoint"].clone(),
            pending: self.pending.clone(),
        })
    }
    pub fn restore(checkpoint: &RuntimeCheckpoint) -> Result<Self> {
        if checkpoint.version != 1
            || checkpoint.native["actor"] != checkpoint.actor
            || checkpoint.native["document"]["schema"] != checkpoint.schema.identity()
            || engine::runtime_schema::RuntimeSchema::compile(checkpoint.schema.manifest.clone())
                .map_err(Error)?
                .identity()
                != checkpoint.schema.identity()
        {
            return Err(Error("graphic checkpoint actor/schema mismatch".into()));
        }
        let mut doc = Self {
            server: engine::Server::default(),
            actor: checkpoint.actor.clone(),
            schema: checkpoint.schema.clone(),
            pending: vec![],
        };
        doc.call(
            "history_restore",
            json!({"actor":doc.actor,"checkpoint":checkpoint.native}),
        )?;
        let before = doc.call("history_export", json!({}))?["checkpoint"].clone();
        for change in &checkpoint.pending {
            for op in &change.ops {
                let at = match op {
                    Op::Node { id, .. } | Op::Text { id, .. } => id,
                    Op::Delete { at, .. }
                    | Op::Undelete { at, .. }
                    | Op::Set { at, .. }
                    | Op::Move { at, .. } => at,
                };
                if at.actor != doc.actor {
                    return Err(Error("graphic pending actor mismatch".into()));
                }
            }
            doc.apply_remote(&change.ops)?;
        }
        if doc.call("history_export", json!({}))?["checkpoint"] != before {
            return Err(Error(
                "graphic pending is not an exact checkpoint replay".into(),
            ));
        }
        doc.pending = checkpoint.pending.clone();
        Ok(doc)
    }
    pub fn restore_checkpoint(&mut self, checkpoint: &RuntimeCheckpoint) -> Result<()> {
        if checkpoint.actor != self.actor || checkpoint.schema.identity() != self.schema.identity()
        {
            return Err(Error("cannot replace graphic actor or schema".into()));
        }
        *self = Self::restore(checkpoint)?;
        Ok(())
    }
    /// Move a Document block and its descendants to a compatible flow.
    pub fn reparent_block(
        &mut self,
        id: &Key,
        parent: Option<&Key>,
        after: Option<&Key>,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.document_origin(parent, None)?;
        let at = self.next_ticket()?;
        let after = self.after_ticket(after)?;
        self.record(
            vec![Op::Move {
                at,
                target: id.ticket()?,
                parent: Self::flow_head(parent)?.ticket()?,
                after,
            }],
            options,
            now_ms,
        )
    }
    /// Capture a model range as stable token anchors. Nested paths use one
    /// child index per flow level and a final UTF-16 offset.
    pub fn capture_selection(
        &mut self,
        range: Option<Selection<Position>>,
    ) -> Result<Option<Selection<Key>>> {
        Ok(serde_json::from_value(
            self.call("selection_capture", json!({"range":range}))?["range"].clone(),
        )?)
    }
    pub fn resolve_selection(
        &mut self,
        range: Option<Selection<Key>>,
    ) -> Result<Option<Selection<Position>>> {
        Ok(serde_json::from_value(
            self.call("selection_resolve", json!({"range":range}))?["range"].clone(),
        )?)
    }
    /// Stable body head for a Document flow. None selects the root flow.
    pub fn flow_head(parent: Option<&Key>) -> Result<Key> {
        match parent {
            None => Ok(Key::root()),
            Some(parent) => Key::parse(format!("0@{}/body", parent.as_str())),
        }
    }
    fn document_origin(&mut self, parent: Option<&Key>, after: Option<&Key>) -> Result<Ticket> {
        if self.schema.domain() != "document" {
            return Err(Error("document flow requires document schema".into()));
        }
        let head = Self::flow_head(parent)?;
        self.document_line_origin(&head, after)
    }
    fn document_line_origin(&mut self, head: &Key, after: Option<&Key>) -> Result<Ticket> {
        let state = self.state()?;
        let items = if let Some(lines) = state["lines"].as_array() {
            lines
                .iter()
                .find(|line| line["key"] == head.as_str())
                .and_then(|line| line["items"].as_array())
                .ok_or_else(|| Error("document parent flow not found".into()))?
        } else if head == &Key::root() {
            state["items"]
                .as_array()
                .ok_or_else(|| Error("document items missing".into()))?
        } else {
            return Err(Error("document parent flow not found".into()));
        };
        let origin = after.unwrap_or(head).ticket()?;
        if !items.iter().any(|item| item["id"] == json!(origin)) {
            return Err(Error("document anchor is outside source flow".into()));
        }
        Ok(origin)
    }
    /// Visible UTF-16 token keys in the flow's physical source sequence.
    /// Moved blocks retain their source sequence; selection resolves model paths.
    pub fn flow_text_ids(&mut self, parent: Option<&Key>) -> Result<Vec<Key>> {
        self.document_origin(parent, None)?;
        let state = self.state()?;
        let head = Self::flow_head(parent)?;
        let items = if let Some(lines) = state["lines"].as_array() {
            lines
                .iter()
                .find(|line| line["key"] == head.as_str())
                .unwrap()["items"]
                .as_array()
                .unwrap()
        } else {
            state["items"].as_array().unwrap()
        };
        items
            .iter()
            .filter(|item| item["kind"] == "char" && item["visible"] == true)
            .map(|item| {
                serde_json::from_value::<Ticket>(item["id"].clone())
                    .map(|ticket| Key::from_ticket(&ticket))
                    .map_err(Error::from)
            })
            .collect()
    }
    /// Insert a text, atom or flow marker in the Document root flow.
    /// For text blocks, right is the current right boundary (None means end).
    pub fn insert_block(
        &mut self,
        kind: &str,
        after: Option<&Key>,
        right: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        self.insert_block_in(kind, None, after, right, attrs, options, now_ms)
    }
    /// Insert a marker in a parent flow's physical source sequence.
    /// None parent selects the root. After and right identify source tokens.
    /// This method does not compile model positions after block movement;
    /// a moved block retains its original source sequence.
    pub fn insert_block_in(
        &mut self,
        kind: &str,
        parent: Option<&Key>,
        after: Option<&Key>,
        right: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        self.document_origin(parent, None)?;
        self.insert_marker_in_line(
            kind,
            &Self::flow_head(parent)?,
            after,
            right,
            attrs,
            options,
            now_ms,
        )
    }
    fn insert_marker_in_line(
        &mut self,
        kind: &str,
        head: &Key,
        after: Option<&Key>,
        right: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        let origin = self.document_line_origin(head, after)?;
        if let Some(right) = right {
            self.document_line_origin(head, Some(right))?;
        }
        let id = self.next_ticket()?;
        let key = Key::from_ticket(&id);
        let shape = &self.schema.manifest()["nodes"][kind]["shape"];
        let boundary = if shape == "text" {
            format!(
                "{}|{}",
                Key::from_ticket(&origin).as_str(),
                right.map(Key::as_str).unwrap_or("end")
            )
        } else {
            String::new()
        };
        let change = self.record(
            vec![Op::Node {
                id,
                origin,
                node_type: kind.into(),
                boundary,
                attrs: Some(attrs),
            }],
            options,
            now_ms,
        )?;
        Ok((key, change))
    }
    /// Insert UTF-16 tokens at a Document token or block marker.
    pub fn insert_text(
        &mut self,
        after: Option<&Key>,
        text: impl Into<Utf16Text>,
        marks: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.insert_text_in(None, after, text, marks, options, now_ms)
    }
    /// Insert UTF-16 tokens in a parent flow's physical source sequence.
    /// After identifies a source token, not a model position. Moved blocks
    /// retain their original source sequence; use selection for model paths.
    pub fn insert_text_in(
        &mut self,
        parent: Option<&Key>,
        after: Option<&Key>,
        text: impl Into<Utf16Text>,
        marks: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let origin = self.document_origin(parent, after)?;
        let id = self.next_ticket()?;
        self.record(
            vec![Op::Text {
                id,
                origin,
                units: text.into(),
                marks,
            }],
            options,
            now_ms,
        )
    }
    /// Visible character and inline keys in a physical source line.
    /// A source line can be a root, nested flow, or grid cell head.
    pub fn line_token_ids(&mut self, head: &Key) -> Result<Vec<Key>> {
        self.document_line_origin(head, None)?;
        let state = self.state()?;
        let items = if let Some(lines) = state["lines"].as_array() {
            lines
                .iter()
                .find(|line| line["key"] == head.as_str())
                .unwrap()["items"]
                .as_array()
                .unwrap()
        } else {
            state["items"].as_array().unwrap()
        };
        items
            .iter()
            .filter(|item| {
                item["visible"] == true
                    && (item["kind"] == "char"
                        || item["kind"] == "node"
                            && self.schema.manifest()["nodes"][item["born"].as_str().unwrap_or("")]
                                ["shape"]
                                == "inline")
            })
            .map(|item| {
                serde_json::from_value::<Ticket>(item["id"].clone())
                    .map(|id| Key::from_ticket(&id))
                    .map_err(Error::from)
            })
            .collect()
    }
    // Validate all supplied attributes before omitting default-valued birth
    // registers. Parent and source-context checks remain in atomic record().
    fn insert_canonical_marker_in_line(
        &mut self,
        kind: &str,
        head: &Key,
        after: Option<&Key>,
        right: Option<&Key>,
        mut attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        let specs = &self.schema.manifest()["nodes"][kind]["attrs"];
        for (name, value) in &attrs {
            let spec = &specs[name];
            if spec.is_null()
                || spec["computed"] == true
                || !engine::runtime_schema::value_ok(spec, value)
            {
                return Err(Error(format!("invalid attribute {kind}.{name}")));
            }
        }
        attrs.retain(|name, value| {
            let default = &specs[name]["default"];
            let equal = if value.is_number() && default.is_number() {
                value.as_f64() == default.as_f64()
            } else {
                value == default
            };
            !value.is_null() && !equal
        });
        self.insert_marker_in_line(kind, head, after, right, attrs, options, now_ms)
    }
    /// Insert a schema-declared inline token. Delete it with delete(); update
    /// its attributes with set_attribute(). The anchor is a physical source key.
    pub fn insert_inline_at(
        &mut self,
        head: &Key,
        kind: &str,
        after: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        if self.schema.manifest()["nodes"][kind]["shape"] != "inline" {
            return Err(Error("inline kind required".into()));
        }
        self.insert_canonical_marker_in_line(kind, head, after, None, attrs, options, now_ms)
    }
    /// Insert a stored member of a schema-derived group. The wrapper has no
    /// stored ID. Its type and grouping attributes come from the schema.
    pub fn insert_group_member_at(
        &mut self,
        head: &Key,
        group: &str,
        kind: &str,
        after: Option<&Key>,
        right: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        let spec = &self.schema.manifest()["nodes"][group];
        if spec["shape"] != "group"
            || !spec["children"]
                .as_array()
                .is_some_and(|children| children.iter().any(|child| child == kind))
        {
            return Err(Error("member must be declared by group".into()));
        }
        self.insert_canonical_marker_in_line(kind, head, after, right, attrs, options, now_ms)
    }
    /// Insert explicit marks at a stable physical source address.
    pub fn insert_text_at(
        &mut self,
        head: &Key,
        after: Option<&Key>,
        text: impl Into<Utf16Text>,
        marks: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let origin = self.document_line_origin(head, after)?;
        let id = self.next_ticket()?;
        self.record(
            vec![Op::Text {
                id,
                origin,
                units: text.into(),
                marks,
            }],
            options,
            now_ms,
        )
    }
    /// Insert plain text with the left character's inheritable marks. Inline
    /// tokens and block markers do not supply inherited marks.
    pub fn insert_inherited_text_at(
        &mut self,
        head: &Key,
        after: Option<&Key>,
        text: impl Into<Utf16Text>,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.document_line_origin(head, after)?;
        let mut marks = Attributes::new();
        if let Some(after) = after {
            let state = self.state()?;
            let items = if let Some(lines) = state["lines"].as_array() {
                lines
                    .iter()
                    .find(|line| line["key"] == head.as_str())
                    .unwrap()["items"]
                    .as_array()
                    .unwrap()
            } else {
                state["items"].as_array().unwrap()
            };
            if let Some(item) = items
                .iter()
                .find(|item| item["id"] == json!(after.ticket().unwrap()) && item["kind"] == "char")
            {
                if let Some(attrs) = item["attrs"].as_object() {
                    for (name, register) in attrs {
                        let value = &register["value"];
                        let boolean = self.schema.manifest()["marks"]
                            .as_array()
                            .is_some_and(|keys| keys.iter().any(|key| key == name));
                        let spec = &self.schema.manifest()["markValues"][name];
                        if boolean && value == true
                            || !spec.is_null()
                                && spec["inherit"] == true
                                && !value.is_null()
                                && value != &spec["default"]
                        {
                            marks.insert(name.clone(), value.clone());
                        }
                    }
                }
            }
        }
        self.insert_text_at(head, after, text, marks, options, now_ms)
    }
    /// Set a boolean or scalar value mark on explicit character/inline tokens.
    /// Null clears a value mark. Schema and token validation occurs before commit.
    pub fn format_tokens(
        &mut self,
        ids: &[Key],
        mark: &str,
        value: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        if !self.schema.manifest()["marks"]
            .as_array()
            .is_some_and(|marks| marks.iter().any(|m| m == mark))
            && self.schema.manifest()["markValues"].get(mark).is_none()
        {
            return Err(Error("declared mark required".into()));
        }
        let at = self.next_ticket()?;
        self.record(
            vec![Op::Set {
                at,
                ids: ids.iter().map(Key::ticket).collect::<Result<_>>()?,
                key: mark.into(),
                value,
            }],
            options,
            now_ms,
        )
    }
    /// Format a span by its schema type. The wrapper is projected from its
    /// value mark; it does not create or store a wrapper token.
    pub fn format_span(
        &mut self,
        ids: &[Key],
        kind: &str,
        value: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let spec = &self.schema.manifest()["nodes"][kind];
        if spec["shape"] != "span" {
            return Err(Error("span kind required".into()));
        }
        let mark = spec["mark"]
            .as_str()
            .ok_or_else(|| Error("span mark missing".into()))?
            .to_owned();
        self.format_tokens(ids, &mark, value, options, now_ms)
    }
    /// Update one declared group attribute on explicit stored members in one
    /// transaction. Callers retain member identities when group boundaries change.
    pub fn set_group_attribute(
        &mut self,
        members: &[Key],
        group: &str,
        attribute: &str,
        value: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let spec = self.schema.manifest()["nodes"][group].clone();
        if spec["shape"] != "group"
            || !spec["by"]
                .as_array()
                .is_some_and(|by| by.iter().any(|name| name == attribute))
        {
            return Err(Error("declared group attribute required".into()));
        }
        let state = self.state()?;
        let mut kinds = std::collections::BTreeMap::new();
        if let Some(lines) = state["lines"].as_array() {
            for line in lines {
                if let Some(items) = line["items"].as_array() {
                    for item in items {
                        if item["visible"] != true || item["kind"] != "node" {
                            continue;
                        }
                        if let Ok(id) = serde_json::from_value::<Ticket>(item["id"].clone()) {
                            let kind = item["attrs"]["$type"]["value"]
                                .as_str()
                                .unwrap_or_else(|| item["born"].as_str().unwrap_or(""));
                            if self.schema.manifest()["nodes"][kind]["shape"] == "text" {
                                kinds
                                    .insert(Key::from_ticket(&id).as_str().to_owned(), json!(kind));
                            }
                        }
                    }
                }
            }
        }
        if members.is_empty()
            || members.iter().any(|member| {
                !spec["children"].as_array().is_some_and(|children| {
                    kinds
                        .get(member.as_str())
                        .is_some_and(|kind| children.contains(kind))
                })
            })
        {
            return Err(Error("group member required".into()));
        }
        for member in members {
            let kind = kinds[member.as_str()].as_str().unwrap();
            let attr = &self.schema.manifest()["nodes"][kind]["attrs"][attribute];
            if attr.is_null()
                || attr["computed"] == true
                || !engine::runtime_schema::value_ok(attr, &value)
            {
                return Err(Error(format!("invalid attribute {kind}.{attribute}")));
            }
        }
        let at = self.next_ticket()?;
        self.record(
            vec![Op::Set {
                at,
                ids: members.iter().map(Key::ticket).collect::<Result<_>>()?,
                key: attribute.into(),
                value,
            }],
            options,
            now_ms,
        )
    }
    /// Insert an empty grid and all axes in one history transaction.
    /// `head` is a physical flow head from flow_head() or cell_head().
    /// The helper does not compile a model insertion position or a trailing block.
    pub fn insert_grid_at(
        &mut self,
        head: &Key,
        kind: &str,
        after: Option<&Key>,
        rows: usize,
        columns: usize,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Vec<Key>, Vec<Key>, Change)> {
        if rows == 0 || columns == 0 {
            return Err(Error("grid dimensions must be positive".into()));
        }
        let origin = self.document_line_origin(head, after)?;
        let spec = &self.schema.manifest()["nodes"][kind];
        if spec["shape"] != "grid" {
            return Err(Error("grid kind required".into()));
        }
        let row_kind = spec["children"][0]
            .as_str()
            .ok_or_else(|| Error("grid row kind missing".into()))?
            .to_owned();
        let count = rows
            .checked_add(columns)
            .and_then(|n| u64::try_from(n).ok())
            .ok_or_else(|| Error("grid dimensions overflow".into()))?;
        let first = self.next_ticket()?;
        first
            .lamport
            .checked_add(count)
            .filter(|n| *n <= MAX_CLOCK)
            .ok_or_else(|| Error("grid dimensions exceed clock capacity".into()))?;
        let grid = Key::from_ticket(&first);
        let mut ops = vec![Op::Node {
            id: first.clone(),
            origin,
            node_type: kind.into(),
            boundary: String::new(),
            attrs: Some(attrs),
        }];
        let mut axis_keys = [Vec::new(), Vec::new()];
        let mut clock = first.lamport;
        for (index, count) in [rows, columns].into_iter().enumerate() {
            let mut origin = if index == 0 {
                Self::grid_rows_head(&grid)?
            } else {
                Self::grid_columns_head(&grid)?
            }
            .ticket()?;
            for _ in 0..count {
                clock = clock
                    .checked_add(1)
                    .filter(|n| *n <= MAX_CLOCK)
                    .ok_or_else(|| Error("clock exhausted".into()))?;
                let id = Ticket {
                    lamport: clock,
                    actor: self.actor.clone(),
                };
                axis_keys[index].push(Key::from_ticket(&id));
                ops.push(Op::Node {
                    id: id.clone(),
                    origin,
                    node_type: if index == 0 {
                        row_kind.clone()
                    } else {
                        "col".into()
                    },
                    boundary: String::new(),
                    attrs: Some(Attributes::new()),
                });
                origin = id;
            }
        }
        let change = self.record(ops, options, now_ms)?;
        let [rows, columns] = axis_keys;
        Ok((grid, rows, columns, change))
    }
    /// Physical row sequence head. Rows and columns are stable token identities.
    pub fn grid_rows_head(grid: &Key) -> Result<Key> {
        Key::parse(format!("0@{}/rows", grid.as_str()))
    }
    pub fn grid_columns_head(grid: &Key) -> Result<Key> {
        Key::parse(format!("0@{}/cols", grid.as_str()))
    }
    /// Physical cell flow head. This address is stable across axis movement.
    /// It is not a model position. A moved block retains its birth sequence.
    pub fn cell_head(grid: &Key, row: &Key, col: &Key) -> Result<Key> {
        Key::parse(format!(
            "0@{}/cell:{},{}",
            grid.as_str(),
            row.as_str(),
            col.as_str()
        ))
    }
    /// Insert one schema-named row. Delete rows with delete(&[row], ...).
    pub fn insert_grid_row(
        &mut self,
        grid: &Key,
        kind: &str,
        after: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        self.insert_marker_in_line(
            kind,
            &Self::grid_rows_head(grid)?,
            after,
            None,
            attrs,
            options,
            now_ms,
        )
    }
    /// Insert one column. The wire type `col` is reserved by the native format.
    pub fn insert_grid_column(
        &mut self,
        grid: &Key,
        after: Option<&Key>,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        self.insert_marker_in_line(
            "col",
            &Self::grid_columns_head(grid)?,
            after,
            None,
            Attributes::new(),
            options,
            now_ms,
        )
    }
    pub fn insert_cell_block(
        &mut self,
        grid: &Key,
        row: &Key,
        col: &Key,
        kind: &str,
        after: Option<&Key>,
        right: Option<&Key>,
        attrs: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        self.insert_marker_in_line(
            kind,
            &Self::cell_head(grid, row, col)?,
            after,
            right,
            attrs,
            options,
            now_ms,
        )
    }
    pub fn insert_cell_text(
        &mut self,
        grid: &Key,
        row: &Key,
        col: &Key,
        after: Option<&Key>,
        text: impl Into<Utf16Text>,
        marks: Attributes,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let origin = self.document_line_origin(&Self::cell_head(grid, row, col)?, after)?;
        let id = self.next_ticket()?;
        self.record(
            vec![Op::Text {
                id,
                origin,
                units: text.into(),
                marks,
            }],
            options,
            now_ms,
        )
    }
    pub fn set_cell_attribute(
        &mut self,
        grid: &Key,
        row: &Key,
        col: &Key,
        attribute: &str,
        value: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.set_attribute(
            grid,
            format!("$cell:{},{}|{}", row.as_str(), col.as_str(), attribute),
            value,
            options,
            now_ms,
        )
    }
    /// Merge a rectangle using inclusive stable row/column endpoints.
    /// Covered cells retain their content. Split clears this span register.
    pub fn merge_cells(
        &mut self,
        grid: &Key,
        row: &Key,
        col: &Key,
        end_row: &Key,
        end_col: &Key,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.set_attribute(
            grid,
            format!("$span:{},{}", row.as_str(), col.as_str()),
            json!({"row":end_row,"col":end_col}),
            options,
            now_ms,
        )
    }
    pub fn split_cell(
        &mut self,
        grid: &Key,
        row: &Key,
        col: &Key,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        self.set_attribute(
            grid,
            format!("$span:{},{}", row.as_str(), col.as_str()),
            Value::Null,
            options,
            now_ms,
        )
    }
    /// Move a Document block into a cell, with the same physical source contract
    /// as reparent_block. The anchor uses the current placement ticket.
    pub fn reparent_block_to_cell(
        &mut self,
        id: &Key,
        grid: &Key,
        row: &Key,
        col: &Key,
        after: Option<&Key>,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<Change> {
        let head = Self::cell_head(grid, row, col)?;
        self.document_line_origin(&head, None)?;
        let at = self.next_ticket()?;
        let after = self.after_ticket(after)?;
        self.record(
            vec![Op::Move {
                at,
                target: id.ticket()?,
                parent: head.ticket()?,
                after,
            }],
            options,
            now_ms,
        )
    }
}
