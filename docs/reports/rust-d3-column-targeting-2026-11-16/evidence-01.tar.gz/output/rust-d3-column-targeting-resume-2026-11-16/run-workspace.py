from pathlib import Path
import subprocess,time,json,os
out=Path("output/rust-d3-column-targeting-resume-2026-11-16")
checks=[]
for name,cmd in [("workspace",["npm","test"]),("typecheck",["npm","run","typecheck"]),("docs-build",["npm","run","docs:build"]),("docs-check",["npm","run","docs:check"])]:
 start=time.time()
 with (out/(name+".log")).open("w") as log:
  try: code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1800).returncode
  except subprocess.TimeoutExpired: code=124
 row={"name":name,"command":cmd,"exit":code,"status":"PASS" if code==0 else "FAIL","seconds":round(time.time()-start,2),"log":str(out/(name+".log"))}
 checks.append(row);(out/"workspace-checks.json").write_text(json.dumps(checks,indent=2)+"\n");print(row,flush=True)
