from pathlib import Path
import json,hashlib,tarfile,io
root=Path('.');base=Path('output/rust-d3-column-targeting-2026-11-05');out=Path('output/rust-d3-column-targeting-resume-2026-11-16');report=Path('docs/reports/rust-d3-column-targeting-2026-11-16')
sha=lambda b:hashlib.sha256(b).hexdigest()
main=base/'compare/run-2026-11-04T17-16-37.299Z-86829'
reg=base/'compare-regressions/run-2026-11-16T02-02-24.884Z-46677'
hashes=json.loads((main/'run-source-hashes.json').read_text())
assert all(Path(p).is_file() and sha(Path(p).read_bytes())==h for p,h in hashes.items()),'Historical comparison source drift'
r=json.loads((reg/'receipt.json').read_text());assert r['hashesBefore']==r['hashesAfter']
# Verify current protected corpus independently, excluding intentional roadmap/HANDOFF additions.
drift=[p for p,h in r['hashesAfter'].items() if not Path(p).is_file() or sha(Path(p).read_bytes())!=h]
assert not drift,drift
checks=json.loads((out/'workspace-checks.json').read_text());assert len(checks)==4
final={'status':'PASS' if all(x['exit']==0 for x in checks) else 'INCOMPLETE','native':json.loads((base/'native-final-receipt.json').read_text())['status'],'historicalComparison':'PASS_SOURCE_BINDING_RECHECKED_NOT_RERUN','historicalSourcePathsVerified':len(hashes),'freshInheritedStages':len(r['results']),'freshInheritedStatus':r['status'],'inheritedPathsCurrentlyVerified':len(r['hashesAfter']),'workspace':checks,'publication':'NOT_PERFORMED','exclusions':r['exclusions']}
(report/'final-checks.json').write_text(json.dumps(final,indent=2)+'\n')
selected=set()
def add(p):
 p=Path(p)
 if p.is_file():selected.add(str(p))
for p in hashes:
 if not any(x in {'target','native-target'} for x in Path(p).parts):add(p)
for p in [base/'compare-summary.json',base/'native-final-receipt.json',base/'native-final-sources-before.json',base/'native-final-sources-after.json']:add(p)
for p in base.glob('native-final-*.log'):add(p)
for p in base.glob('native-final-*.json'):add(p)
for p in (base/'design-review').glob('*'):add(p)
for p in main.iterdir():
 if p.suffix=='.json' or p.name.endswith('trace.json.gz'):add(p)
for p in reg.iterdir():add(p)
# Archive per-stage receipts/maps, without huge duplicated inherited trace trees.
for stage in r['results']:
 artifact=stage.get('artifact',{}) or {};directory=artifact.get('out')
 if directory:
  d=Path(directory)
  for name in ['receipt.json','run-source-hashes.json']:
   q=d/name
   if q.exists():add(q.relative_to(Path.cwd()) if q.is_absolute() else q)
for p in out.glob('*.json'):add(p)
for p in out.glob('*.log'):add(p)
for p in out.glob('*.py'):add(p)
for p in ['HANDOFF.md','docs/rust-roadmap.md','apps/docs/src/roadmap.md','experiments/rust-sdk/README.md','apps/docs/src/guide/rust.md']:add(p)
files=[];archives=[];part=[];size=0;volumes=[]
for p in sorted(selected):
 n=Path(p).stat().st_size
 if part and size+n>28*1024*1024:volumes.append(part);part=[];size=0
 part.append(p);size+=n
if part:volumes.append(part)
for i,paths in enumerate(volumes,1):
 archive=report/f'evidence-{i:02}.tar.gz'
 with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
  for p in paths:
   data=Path(p).read_bytes();info=tarfile.TarInfo(p);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));files.append({'path':p,'bytes':len(data),'sha256':sha(data),'archive':archive.name})
 with tarfile.open(archive,'r:gz') as tar:
  for row in [x for x in files if x['archive']==archive.name]:assert sha(tar.extractfile(row['path']).read())==row['sha256']
 archives.append({'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(paths),'readback':'PASS'})
manifest={'status':'SELECTED_EVIDENCE_SEALED','scope':'Source snapshot, full historical column traces, fresh native/workspace logs and aggregate/per-stage inherited receipts. Inherited full trace trees and native binaries remain in original output, not duplicated in this selected archive.','archives':archives,'files':files}
(report/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
sealed={p.name:sha(p.read_bytes()) for p in report.iterdir() if p.is_file() and p.name!='seal.json'}
(report/'seal.json').write_text(json.dumps({'status':'PASS','files':sealed,'archiveMembersVerified':len(files),'archiveVolumesVerified':len(archives)},indent=2)+'\n')
print(json.dumps({'final':final,'archives':archives,'members':len(files)},indent=2))
