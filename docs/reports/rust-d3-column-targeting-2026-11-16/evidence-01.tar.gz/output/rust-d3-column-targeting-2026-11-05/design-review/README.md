---
work_id: rust-d3-column-targeting-2026-11-05
artifact_type: implementation_contract
status: ready_for_build_after_axis_seal
owner_role: reservation-review
source_request: Final Q1.3.3 one-column command contract after Q1.3.2 qualification
last_updated: 2026-11-05
---

# Q1.3.3 one explicit column command

Build one additive `insert_column_relative` method after Q1.3.2 is sealed. One successful call creates exactly one new column in one current visible stored grid. Unique row-ID payloads fill that same column in caller order. Empty payloads still create the column. Existing numeric column memo, snapshots, core storage and History semantics stay unchanged.

This is an implementation-ready contract. The proposed method is NOT_IMPLEMENTED and all new qualification is NOT_RUN in this design lane. No current product, Q1.3.2 source-review seal or previous report was changed here.

## Public API and result

```rust
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ColumnBoundary { Start, End, Before(Key), After(Key) }

#[derive(Debug, Clone, PartialEq)]
pub struct RowCellPayload { pub row: Key, pub model: Value }

#[derive(Debug, Clone, PartialEq)]
pub struct ColumnInsert {
    pub grid: Key,
    pub boundary: ColumnBoundary,
    pub cells: Vec<RowCellPayload>,
}

pub fn insert_column_relative(
    &mut self,
    base: &ModelEditBase,
    command: &ColumnInsert,
    options: EditOptions,
    now_ms: f64,
) -> Result<ModelInsertBatchResult>;
```

Use the existing `ModelInsertBatchResult`. Every success has **exactly `keys = [Some(newColumnKey)]`**, regardless of zero, one or many row payloads. There is one public structural command, so internal per-row fill results do not become repeated public result entries. `change`, `clock_before` and `clock_after` retain their existing aggregate semantics, including preparation and reservations. Failure returns an error and publishes nothing.

A new `{column, change, clock_before, clock_after}` result would express the one-key invariant in its type, but it duplicates the qualified clock/Change serialization contract and expands the public surface. A tuple `(Key, Change)` loses the reservation clocks; `(Key, ModelInsertBatchResult)` duplicates identity. Reusing BatchResult with a documented/tested one-Some-key invariant is the preferred bounded deliverable. Update its comment to include one whole-column command, without changing existing constructors or field meanings.

Borrowing the command matches the existing borrowed batch APIs and lets the caller preserve its request data without cloning all cell payloads. No new command/base checkpoint or wire serialization is required. A successful column key is a positive immutable axis ID. It can form `GridCellTarget {grid,row,column}` but is still rejected by generic Q1.3.1 Before/After block targeting. There is no cell-wrapper ID or public alias namespace.

## Target and ownership contract

- Reuse the private Q1.3.1 local `{incarnation, publication revision, schema identity}` guard. Validate it before compilation, then require document domain and finite time.
- Locate the exact current root-reachable stored primary grid through the Q1.3.2 strict locator. A live token in a hidden physical source line is insufficient. Reject missing/deleted/cardinality-hidden/synthetic grid and covered ancestors. A moved grid is valid only at its accepted current placement, using a fresh base.
- The current grid must have at least one live row and one live column. That is the existing projected-grid visibility rule. If the last axis was deleted, this API rejects rather than reviving a hidden grid. Start/End do not weaken this precondition.
- Before/After names a positive live ordinary col axis in this exact grid. A same-type column from another grid, source head, tombstone, placement ticket or nearest selection location rejects. Start gives c=0; End gives c=current column count; Before uses the anchor's current index; After uses checked index+1.
- Each payload row must be a positive live ordinary row of the grid's declared row kind and a member of this exact current rows list. Reject missing/deleted/wrong-grid/wrong-kind/synthetic rows and duplicate row IDs. A duplicate rejects even when both models are equal or empty.
- Validate all row bindings before creating a candidate column. Preserve payload Vec order; do not sort by row ID or visible row index. This order controls operation tickets and fresh span-writer priority.

Capture one current state view for ownership checks and build row/column lookup maps. Reuse TargetView, require_stored_kind, strict primary lookup and current grid metadata. No second version/identity system or repeated full snapshot export is needed for the guard.

## Cell payload and merge policy

Each model must be the grid's declared cell type and must pass the existing model compiler's cell/body/attribute validation. Use the same admitted JSON/model subset. Do not broaden scalar or schema-reference admission in this slice. Span/rowspan/colspan/spanned inputs follow the existing compiler exactly; `spanned:true` itself is output-only and creates no span writer.

Only specified rows receive the supplied new-cell bodies and noncomputed attributes. Other rows receive normal default bodies in the one new column. Their computed covered/span output may reflect existing merges. Existing cells and their writer IDs remain bound to the old column IDs as those columns shift numerically.

This is a structural column operation. A payload row is not a request to edit an existing visible cell body. Existing colspan ranges can expand over the new column; new payloads can become covered and remain retained. Do not reject output visibility, drop hidden content, split merges or redirect to another cell. A later Q1.3.2 InsideCell command still rejects a currently covered tuple and allows a visible merge anchor. This preserves the structural-axis/current-cell distinction already qualified for typed rows.

## Empty payload

`cells=[]` creates one column. Use the **first current live row** as an internal compiler seed, after checking its ordinary row identity/kind/ownership. The minimal seed is `{type: declaredCellType, children: []}` with no attrs. It does not require a caller alias and does not invent a body identity. An existing visible grid supplies a row; a zero-axis hidden grid is rejected beforehand.

The seed itself contributes no text, cell-attribute or span writes. Existing native/TS fillFlow returns for empty body content, and empty cell attrs produce no writes. However, existing compiler promotion and leading-default preparation can add operations and consume clocks elsewhere before the column birth. **The aggregate Change is not universally one operation, and aggregate clock delta is not universally1.** Compare all operations/clocks to the existing compiler. In a simple nonprojected baseline with no preparation, the expected result is the one target-grid col birth with no seed body writes.

## One candidate, one fixed c, one commit

1. After the local guard, take the normal before clock/checkpoint and restore one detached Compiler with `batch=true`, `column=None` and one `promoted=false` flag. Reuse existing staging; no new snapshot format or version field.
2. Resolve the current grid path, boundary index c and all payload row bindings **once for this whole-column command**. Use the payloads in caller order, or the explicit empty seed when there are none. Outer row axes do not change during cell filling.
3. Lower each payload to the existing cell-model insertion at `[...currentGridPath, rowIndex, c]` through the shared compile_model_insert helper. Keep the same c for every payload. The first creates one fresh col axis; later unique rows reuse the existing `(grid,c,used rows)` memo. Do not re-resolve Before(originalColumn) after the first creation.
4. Collect the internal returned keys. They must all be Some and equal one new positive column key. Read the candidate's target-grid projection and verify `after.rows == before.rows` and `after.cols == before.cols` with exactly that one key inserted at c. Count target-grid axis IDs, not every col wire Node: nested payload tables may legitimately create their own columns.
5. Only after validation and postconditions succeed, publish the full compiler ops and final compiler clock with one existing stage_change/history_record. Return BatchResult with one public key. Never assert these invariants after publishing and then return an error.

Do not implement this as multiple public insert calls: that would split History/pending and lose command granularity. Do not call a live public batch method before checking the one-column postcondition. A private compiler helper/visibility adjustment is acceptable; it must not create an unguarded public authoring route or alter the numeric memo algorithm.

One successful call gives one aggregate pending Change and one History record transaction. Default History options give one undo action. Existing typing coalescence may merge that record into a prior compatible group; the new method does not change it. Empty payload is a real structural edit, not an empty/no-op call.

## Why the legacy memo stays numeric

For original columns `[C0,C1]` and distinct rows R0/R1:

| Naive per-row targets | Current numeric indexes | Existing result |
| --- | --- | --- |
| Before(C1) in R0, then Before(C1) in R1 | 1, then2 after C1 shifts | Two columns |
| After(C0) in R0, then After(C0) in R1 | 1, then1 with a new row in memo | One shared column |
| After(C0) twice in the same row | 1, then1 but row already used | Two columns |

Those are existing numeric compiler semantics. A public whole-column API must not depend on that direction/row ambiguity. This method defines one command boundary and one fixed c. Each public call constructs a new compiler, so two successful fresh-base calls always create two distinct target-grid columns. No memo is shared between calls. Multi-column atomic calls remain out of scope; they would need an explicit memo barrier between logical column commands. This single-command API needs no hidden UPDATE barrier.

## Independent TS authoring and expected model

TS independently finds the exact current visible grid and owned live axes. It resolves c once, maps each unique payload row ID to its current row index, and builds one Doc.edit array with every cell insertion at `[...gridPath,rowIndex,c]`. An empty payload becomes the documented first-live-row empty cell seed. Execute the full array once on the live TS document, record History once and compare exact operations/clocks/keys to native. Do not use native numeric paths, result IDs or post-edit normalize output to construct the TS request or expected model.

The independent **model intent oracle is one whole-column transformation**, not a loop that inserts another rectangular column for every payload:

1. Clone the pre-edit canonical grid model. Insert one new cell at c in every row. Fill each specified row from the ID-bound payload map; use an empty default cell for other rows. Keep all previous bodies and noncomputed attrs, shifting existing cells together once.
2. Resolve existing span anchor/endpoints through the before axis IDs plus one new-column slot. Existing inclusive ranges grow only when the new axis is inside their stable endpoints. Do not author updates to those old span registers merely to explain their computed growth.
3. Add new span candidates from the cell payloads using the existing fill semantics and clipping to current dimensions. `spanned:true` adds no writer. New writers are after all old writers. Among fresh payload span writes, priority is **reverse caller payload order**, not reverse visual row order. Retained nested-table spans belong to their own grid and cannot be mixed into this grid's candidates.
4. Process span candidates in descending writer priority. Accept a nontrivial rectangle only if its entire area is disjoint from all already accepted newer rectangles. Reject the whole older rectangle on any intersection. Recompute computed rowspan/colspan/spanned output while retaining all covered body content.

A model alone does not expose latent older span writers. For overlapping/latent-span profiles, keep an independent before-state writer catalog from the TS fixture's own accepted operations/registers and stable axis IDs, not the actual after-state projection. Otherwise explicitly bound the fixture to no hidden prior candidates and fail closed outside that bound. The prior Q1.3.2 row-only overlap oracle cannot be copied unchanged: its row-major fresh-write order and per-row axis insertion are different from this command's caller-ordered one-column semantics.

Compare both complete models and complete material storage/writers/deletion ledgers, pending changes, full History, stable selections and own checkpoint/retry. A native/TS model match alone cannot prove command granularity or preservation of foreign text hidden by an undone axis.

## Local lifecycle, order and recovery

A delivered peer row/column insert/delete invalidates the old base, including a lower-clock operation that leaves Lamport max unchanged. Fresh bases bind surviving original IDs at their new numeric positions. A deleted anchor/payload row rejects; there is no nearest-axis fallback. Reads/ack preserve a base, successful publication consumes it, failed calls/restore preserve it, and successful identical checkpoint restore invalidates it by incarnation.

Repeated Before(C1) public calls place new columns in input-call order before C1. Repeated After(C0) calls place the later column nearer C0. Each needs a fresh base and each default call is one History action. A successful original base cannot be reused to create a duplicate column.

Retry the exact captured pending Change with apply_remote. Recompiling the model request with a fresh base is a new edit and creates another column. Own checkpoints preserve pending/History/clocks, not local base tokens. No server epoch/revision, acceptance receipt, lock or authorization is added.

Undo of the new column can hide cells containing peer text because their axis is undone. Preservation means those peer tokens/field writers remain alive in retained storage without manufactured own deletion stamps, and reappear with their data on redo. Do not require them to remain visually exposed when the column itself is hidden. Qualify both A-first/B-first undo orders and exact retry; keep retained storage evidence distinct from visible model evidence.

## Acceptance matrix

| Case | Required evidence |
| --- | --- |
| Start/End/Before/After, zero/one/many payloads | Target grid gains exactly one axis at c; rows/old col order unchanged; result has one Some key |
| Partial reverse-row-order payloads | Correct ID-bound content; omitted rows default; operation stamps follow caller order |
| Duplicate row IDs, equal/empty models | Error before publish; exact checkpoint and base unchanged |
| Wrong-grid row/column of identical type | Ownership error; no first-grid/type-only fallback |
| Missing/deleted/kind/head/synthetic axes or grid | Error; no hidden-grid revival or wrapper identity |
| Current grid in moved flow/nested visible cell | Exact accepted current grid path; peer moves invalidate old base |
| Grid under hidden/deleted/cardinality-hidden/covered ancestor | Reject even when descendants remain alive |
| Simple empty seed | One target col birth, no seed text/attrs/span writes; test aggregate extras separately with projection/preparation |
| Row payload spans and spanned | Existing TS/native admission and computed output; no new restrictions; spanned alone has no writer |
| Existing colspan plus new covered payload | Stable endpoint growth, complete retained body/writer parity through undo/redo |
| Two overlapping fresh spans in reversed row order | Newest caller-order writer wins rectangle conflict, not row-major priority |
| Latent older span reactivation | Independent retained writer catalog or an explicit bounded exclusion; no model-only guessing |
| Nested table payload | Target-grid exactly-one invariant ignores legitimate nested col births |
| Later invalid payload or clock exhaustion | No partial axis/body/History/pending/clock publication; old base usable; prepare nonempty redo branch |
| Two calls at same original boundary | Two distinct axis IDs; no cross-call memo reuse; old-base replay rejects |
| Result key used in GridCellTarget/generic target | Typed owned tuple works when current cell uncovered; generic Before/After(col) still rejects |
| Lower-clock peer axis change | Old token stale despite equal max; fresh surviving IDs resolve correctly |
| Restore/checkpoint/exact pending retry | Local token invalidated by restore; exact operations idempotent and foreign retained bytes/writers preserved |
| Existing Q1.2 numeric memo | Same-index different-row reuse and same-row new-column tests remain unchanged |
| Axis Move, multi-column atomicity, hosted writes | Explicitly outside this slice |

Use original Word/Presentation schemas plus a renamed custom recursive grid schema. Include custom overlap/caller-order and nested-table cases where the product schemas do not admit them. Fixed corpus acceptance remains bounded; it does not close Q2 generation/fuzzing.

## Implementation ownership and gates

After Q1.3.2 is sealed, prefer a new `runtime_column_targeting.rs` in the existing paragraph compiler module, narrow shared strict-grid helpers, additive re-exports, focused Rust tests, one example/trace and an independent column comparison harness. Reuse the unchanged local base and stage_change gates. Add no core code, identity/snapshot/wire/version format or full-snapshot token. Keep existing row/cell/generic APIs and numeric memo meaning unchanged.

The local guard remains O(1) in document/journal size. Model reads, validation maps, current-grid lookup, candidate restore, compiler preparation and payload filling have their existing/nonconstant costs. Do not add repeated full state exports solely for tuple validation or quadratic cell-pair searches. Do not infer a performance PASS from these source constraints.

Implementation/source freeze must precede focused execution and the fresh independent comparison. Preserve failed attempts and previous phase reports. This design authorizes no code before the parent seals Q1.3.2 and starts the next implementation scope. Q1.3.4 read catalog/alias diagnostics, Q1.4 host authorization, distributed conditional acceptance, general multi-command edits, axis movement, production Rust/WASM, browser/mobile and release qualification remain separate.

`source-seal.json` records current source inputs for this contract. It does not state that the proposed API or planned tests exist.
