# Q1.3.3 final native source review

Verdict: **APPROVED_BOUNDED_SOURCE**. No blocking finding remains in the frozen native SDK source. This review does not establish native or TS/native execution PASS. The original implementation contract and its source seal remain unchanged.

## Checked behavior

- `runtime_column_targeting.rs:30` checks the existing opaque local base before any document read/compilation. Domain and finite time checks precede candidate construction. There is one detached Compiler and one `stage_change` publication. Failure before publication preserves the live document, pending work, History and usable base.
- `runtime_column_targeting.rs:97` creates one before state/TargetView and resolves the exact current primary grid through the shared strict locator. The new `runtime_grid_targeting.rs:78` helper extracts the previously qualified grid/shape check without changing generic or row/cell target policy. No alias, selection, birth-line or neighbor fallback was added.
- All current row/column IDs are checked for positive ordinary live stored kind. Axis membership binds rows and Before/After columns to this grid. Empty axes reject. Every supplied row binding, duplicate and cell model is validated before lowering. Payloads borrow their input models and preserve caller order.
- The boundary index c is resolved once. Each unique row uses the same c and one existing numeric column memo. Empty input seeds the first live owned row with only `{type: declaredCell, children: []}`. Existing compiler preparation remains possible. Generic block targeting still rejects returned column IDs; typed cell tuples can use them.
- `runtime_column_targeting.rs:162` requires every internal result to be Some of the same positive key. Before publication, `:190` verifies this key was absent and after.cols equals the entire old vector with exactly that key inserted at c; after.rows equals the entire old vector. Nested payload tables cannot inflate the target-grid count unnoticed. Any memo or normalization deviation fails atomically.
- The compiler and span normalization code are unchanged. Existing colspan growth can cover new cells while preserving their body payload. This structural operation does not reuse current uncovered-cell restrictions. Fresh span writers retain caller order. No sorting or repeated dynamic Before(originalColumn) resolution changes the one-column intent.
- The public result has exactly one Some column key and the existing aggregate Change/clocks. A new candidate/memo per call gives distinct columns across fresh-base calls. Existing History typing options still control coalescence; source does not promise one distinct undo action when typing requests grouping.
- Existing publication gates and restore ABA protection are unchanged: successful authoring uses stage_change; apply_remote increments the local revision even when Lamport max stays fixed; restore creates a fresh incarnation. No snapshot token, new persistence field or public mutable engine route was added.

## Tests and proof limits

All 9 new focused test bodies were read. They cover four boundaries and partial rows, operation caller order, empty seeds including moved grids, wrong ownership/type/duplicates and nonempty redo rollback, nested tables and spanned-only input, merge growth plus opposite span orders, fresh calls and returned-key typed-cell use, lower-clock remote invalidation and hidden/deleted/last-column owners, late clock exhaustion, and foreign text through both undo orders/checkpoint/retry. The final foreign test checks raw UTF-16 token liveness, absence of A deletion stamps, and absence of those IDs in A undo deletes before recovery; final model equality alone is not used as its retention proof.

The owner focused receipt reports exit 0, no timeout, 41 passes (column9 + grid9 + generic12 + batch7 + unit4). The reviewer did not execute Cargo, browser, mobile or performance tests. Broad native checks and exact TS/native comparison are separate owner qualifications. The current comparison harness is not sealed by this approval; its final executed bytes require a later review/receipt.

## Source boundary and cost

The implementation seal records 20 reviewed inputs. All 14 core source files in the phase baseline and all 1,407 entries in the captured TypeScript workspace map remain byte-identical. SDK baseline differences are only additive exports/module inclusion, the extracted strict grid helper and the BatchResult comment; the new method lives in its own module.

Local base checks remain O(1). The command still pays existing checkpoint/restore, full state projection and compiler costs, plus one before axis index and one after invariant view. It does not perform a fresh target walk per row payload, clone each payload model for staging, or add a full-snapshot version token. This is a structural cost assessment, not a measured performance claim.

The seal does not approve distributed/server stale-base guarantees, hosted authorization, axis Move, cell wrapper IDs, multi-column atomic commands, production Rust/WASM, or new limits on the existing numeric compiler.
