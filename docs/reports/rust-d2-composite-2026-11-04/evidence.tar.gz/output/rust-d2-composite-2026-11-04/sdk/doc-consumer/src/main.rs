use doc_sync_native_sdk::*;
use serde_json::json;

fn deliver(peer: &mut RuntimeDocument, change: &Change) -> Result<()> {
    let received: Change = serde_json::from_str(&serde_json::to_string(change)?)?;
    assert_eq!(&received, change);
    peer.apply_remote(&received.ops)
}
fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({
        "root":"page", "marks":[], "nodes":{
            "page":{"shape":"flow","children":["line","section"],"default":"line"},
            "line":{"shape":"text"},
            "section":{"shape":"flow","children":["line"],"default":"line",
                "attrs":{
                    "style":{"default":{"tone":"plain"}},
                    "choice":{"default":null,"values":[{"tone":"warm"},{"tone":"warm"},["cool",2]]}
                }}
        }
    }))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema.clone())?;
    let (section, birth) = a.insert_runtime_block(
        "section", None, None,
        SchemaAttributes::from([
            ("style".into(), schema.default_value("section", "style")?),
            ("choice".into(), schema.enum_value("section", "choice", 0)?),
        ]), EditOptions::default(), 1.0,
    )?;
    deliver(&mut b, &birth)?;
    assert_eq!(a.model()?, b.model()?);

    // A distinct JSON copy is valid for DEFAULT, but fails atomic ENUM admission.
    let equal_copy = a.set_runtime_attribute(
        &section, "style", SchemaValue::json(json!({"tone":"plain"})),
        EditOptions::default(), 2.0,
    )?;
    deliver(&mut b, &equal_copy)?;
    let before = a.checkpoint()?.to_json()?;
    assert!(a.set_runtime_attribute(
        &section, "choice", SchemaValue::json(json!({"tone":"warm"})),
        EditOptions::default(), 3.0,
    ).is_err());
    assert_eq!(a.checkpoint()?.to_json()?, before);

    // B owns the last equal-value writer. A's undo must preserve that writer.
    let own = a.set_runtime_attribute(
        &section, "style", SchemaValue::json(json!({"tone":"shared"})),
        EditOptions::default(), 4.0,
    )?;
    deliver(&mut b, &own)?;
    let foreign = b.set_runtime_attribute(
        &section, "style", SchemaValue::json(json!({"tone":"shared"})),
        EditOptions::default(), 5.0,
    )?;
    deliver(&mut a, &foreign)?;
    let expected = a.model()?;
    deliver(&mut b, &a.undo()?)?;
    assert_eq!(a.model()?, expected);
    assert_eq!(a.model()?, b.model()?);

    let selected = a.set_runtime_attribute(
        &section, "choice", schema.enum_value("section", "choice", 2)?,
        EditOptions::default(), 6.0,
    )?;
    deliver(&mut b, &selected)?;
    let pending = a.pending_changes().to_vec();
    let saved = a.checkpoint()?.to_json()?;
    a = RuntimeDocument::restore(&RuntimeCheckpoint::from_json(&saved)?)?;
    assert_eq!(a.pending_changes(), pending.as_slice());
    let before_retry = a.checkpoint()?.to_json()?;
    for _ in 0..2 {
        for change in &pending {
            deliver(&mut a, change)?;
            deliver(&mut b, change)?;
        }
    }
    assert_eq!(a.checkpoint()?.to_json()?, before_retry);
    deliver(&mut b, &a.undo()?)?;
    assert_eq!(a.model()?, b.model()?);
    deliver(&mut b, &a.redo()?)?;
    assert_eq!(a.model()?, b.model()?);
    // A host acknowledges only after its transport accepts this exact prefix.
    let pending = a.pending_changes().to_vec();
    a.acknowledge(&pending)?;
    assert!(a.pending_changes().is_empty());
    println!("PASS: composite native JSON peers, foreign writer, checkpoint, retry and History");
    Ok(())
}
