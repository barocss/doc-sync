from pathlib import Path
root=Path('/Users/user/github/doc-sync')
def replace(name,a,b):
 p=root/name;s=p.read_text();assert a in s,name;p.write_text(s.replace(a,b))
replace('README.md','scalar and nullable JSON-mark spans, nested field attributes','scalar and JSON-mark spans with explicit native schema references for composite defaults/enums, nested field attributes')
replace('apps/docs/src/schemas/document.md','in one atomic register. They do not merge nested keys. Composite mark defaults,\ncomposite enums and `markValues.fields` are not supported.','in one atomic register. They do not merge nested keys. Native composite defaults\nand composite enum choices use explicit schema-reference handles; equal JSON\nobjects are not interchangeable references. Use the [Rust API guide](../guide/rust)\nfor the native protocol and its TypeScript transport boundary. A composite enum\nwith a composite default, and `markValues.fields`, remain unsupported.')
replace('apps/docs/src/schemas/custom.md','scalar and nullable JSON marks, deterministic required children','scalar and JSON marks with native composite-reference handles, deterministic required children')
replace('apps/docs/src/schemas/custom.md','Composite mark defaults/enums, markValues.fields, unsafe JSON keys','Composite enums with composite defaults, markValues.fields, unsafe JSON keys')
replace('docs/rust-roadmap.md','behavior remain. Composite mark defaults/enums, markValues.fields, text:false,','behavior remain. Native schema-reference handles now support composite defaults\nand composite enum choices separately. Composite enums with composite defaults,\nmarkValues.fields, text:false,')
replace('docs/rust-roadmap.md','clock difference. Object/array mark defaults and composite enums remain rejected\nrather than replacing JS reference identity with deep equality. A reproduced','clock difference. That checkpoint rejected composite defaults/enums; the next\nextension adds the explicit native reference protocol described below. A reproduced')
p=root/'docs/rust-roadmap.md';s=p.read_text();needle='Replace preset/type-name branches with per-document compiled schema data.'
addition='''The composite-reference extension adds object/array defaults without an enum,
and mixed composite enum choices with a null default. `SchemaValue` distinguishes
a schema default/enum handle from equal plain JSON. Operations carry an explicit
versioned reference envelope, validated against the schema and descriptor path.
Undo/redo and native JSON checkpoint/replay preserve its provenance. This is a
native protocol extension, not raw TS wire compatibility. TypeScript uses object
identity: JSON copies fail composite enum admission, and even DocHub's retained
copy rejects such edits. Native projection retains TS clone/fallback behavior.
Composite default-to-enum aliases need a schema identity format and remain open.
See the [composite-reference report](reports/rust-d2-composite-2026-11-04/README.md).

''';assert needle in s;p.write_text(s.replace(needle,addition+needle))
replace('apps/docs/src/roadmap.md','nested fields, nullable JSON marks, required-child rules','nested fields, JSON marks with explicit native composite references, required-child rules')
p=root/'apps/docs/src/roadmap.md';s=p.read_text();needle='Axis moves, model-only attributes, remaining advanced schema rules and the D3 model-position compiler remain open.';assert needle in s;s=s.replace(needle,'The following native extension adds composite defaults and enum choices through schema-reference handles, preserving JSON peer replay and selective History. Composite enums with composite defaults and TS/native wire exchange remain open. '+needle);p.write_text(s)
p=root/'apps/docs/src/guide/document-rules.md';s=p.read_text();s+='''
## Native composite references

The experimental runtime Rust API distinguishes a schema default or enum
reference from a plain JSON value. Use `RuntimeSchema::default_value` or
`enum_value` with the reference-aware edit helpers. A deeply equal JSON copy
is a different value under the TypeScript reference rules. Native operations
carry a validated reference envelope through peer JSON exchange and recovery.
Object/array defaults without enums and composite enum choices with a null
default are supported separately; combining a composite default and enum is
still unsupported. The native extension does not make raw TypeScript DocHub
accept serialized composite enum edits. See the [Rust guide](./rust).
''';p.write_text(s)
