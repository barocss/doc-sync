### 5.145 D2 composite defaults and explicit enum references

Three agents own native core, SDK/docs and independent TS/native comparison.
Baseline is main1cfb7a2 plus captured102file inherited native fields/rules WIP.
The four earlier sealed D2 reports remain byte-identical. This turn makes no
additional production TypeScript semantic changes.

Runtime atomic node attributes and value marks accept safe JSON object/array
defaults without enums. Null-default composite enums include object, array,
duplicate and mixed primitive choices. SchemaValue distinguishes plain JSON
from an explicit schema default/enum reference. Factories bind schema identity,
exact descriptor path, source and enum index. Reference-aware insert/set/format
helpers retain the usual scalar APIs and atomic foreign-writer History rules.
Field-leaf enums keep their prior structural equality.

Native doc-sync-runtime-reference-op-v1 envelopes bind references to raw op
payload paths. Admission validates schema, payload, descriptor and target;
register values stay JSON, while writer provenance reconstructs undo/redo
references and replay. Native peer Changes and checkpoints pass through real
JSON encoding/decoding. No extra per-edit schema compile or full journal replay
was added solely for validation. Fixed Graphic preset rejects this envelope.

Independent TS identity/server probes distinguish source references, equal
copies and JSON copies. Staged Doc.edit output with live schema-member refs
passes authoring check; copied enum payloads fail Doc.check. Even using DocHub's
own schema refs fails its retained-copy admission atomically with seq unchanged.
History redo may supply a cloned enum payload that Doc.check rejects but direct
Doc.apply applies. Native reference admission is an explicit extension, not a
claim that raw TS/native wire interoperability or TS composite enum transport
works. Cloned stored enum attributes still fall back to defaults in TS/native
projection; per-token mark cloning/span behavior is retained.

Review found and fixed a new reference-envelope split History defect: the
split scanner saw only raw node operations and misclassified the companion
move. It now reads the underlying operation. A raw-versus-envelope regression
compares split/undo/redo; the failing-before receipt is preserved.
Other descriptor/target, rollback and forged-checkpoint probes remain separately
classified, without dropping metadata or changing TS identity to deep equality.

Another real defect rejected reference delivery between same-identity schemas
with different object key insertion order. Four before-fail probes identify the
payload comparison mismatch. The narrow reference binding/admission/provenance
checks now use canonical JSON equivalence; raw register order and JS span/group
serialization remain unchanged. Plain equal JSON still has no enum identity.
Peer receive, History and restore cover that correction.

Ten scope probes check text-type changes, wrong shape, atomic batches and forged
restore. Same-shape text candidates follow TS admission. A different atom
descriptor's enum handle is TS-valid but native-unsupported because native
nontext validation requires the born descriptor. No complete admission parity
is claimed.

Final native core138/138 PASS (new18), SDK86/86 PASS (new8). Eight fresh lanes
pass under167 unchanged source/binary hashes: main2schemas160actions/320states,
flow162, grid180, shapes188, rules260, legacy6schemas82actions/164states, scope10
and TSidentity4graphs. Prior5positivecorpus hashes are unchanged. Schema checks
explicitly admit new support: grid7reject/5admit, shapes10reject/2admit,
rules16reject/3compile-onlyadmit. A later report-only counter correction proves
actual Doc.edit88, not86 (two deletes were omitted by the old filter). Main160/
320 reruns PASS; native/TS source and binaries are unchanged, and the other
seven lanes remain qualified. JSON author check rejects26 are observed TS
protocol limits, separate from successful material/History comparisons.
The identical documented Cargo programs compile/run with the final native61file
source guard; the example fence is unchanged through all three source seals.

Composite default-to-enum aliases remain unsupported: JSON schema descriptors
cannot express default===values[index]. A versioned schema-alias identity/DTO
is a separate gate. markValues.fields, text:false, axis moves, positive-minimum
cycles, callbacks/general computed rules, model-only stored attributes, live
transitions and complete product/compiler coverage remain open. Observed D3
empty-patch compiler-clock, postmove and empty-head authoring gaps remain open.
Native Map/List, public Rust Client factory/editor integration, CRDTWASM,
production GC/recovery and real native process/server restart and cross-runtime
network qualification are not provided by these same-process checkpoint tests.
No Chrome/mobile/performance run, commit/push, website deployment or registry
publication is included.

[Source-bound composite verification report](docs/reports/rust-d2-composite-2026-11-04/README.md).
