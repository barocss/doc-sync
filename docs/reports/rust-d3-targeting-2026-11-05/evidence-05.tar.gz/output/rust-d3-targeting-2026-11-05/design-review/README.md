---
work_id: rust-d3-targeting-2026-11-05
artifact_type: design_review
status: ready_for_build
owner_role: reservation-review
source_request: Q1.3 bounded native identity-relative insertion and local stale-base guard
last_updated: 2026-11-05
---

# Q1.3.1 native relative insertion and local stale-base guard

Recommendation: implement one additive native SDK slice after Q1.2 is sealed. Add strict before/after insertion relative to an existing stored block, insertion at the start/end of the root or a stored flow body, and an opaque local read-base token. Reuse Q1.2 batch compilation, one History commit, reservation handling and exact pending Change results. This is a proposed implementation contract, not an execution PASS or completion of all Q1.3.

This review owns only this directory. It changed no core, SDK, documentation or previous report. No Cargo, npm, browser or mobile checks were run.

## Scope and capability matrix

| Target | Existing storage/read support | Q1.3.1 contract | Later bounded slice |
| --- | --- | --- | --- |
| Stored paragraph/text-block primary marker | Immutable token ID; logical projection and model path | Before/after current model node, including stored members of derived groups | Exact alias semantics, if needed |
| Stored flow or grid primary marker | Immutable token ID; current placement | Before/after current model node | None needed for sibling targeting |
| Stored atom primary marker | Immutable token ID; projected sibling | Before/after only when represented as one current model block | Atom authoring remains its own compiler scope |
| Root flow | Existing root head | Inside start/end through explicit Root variant | Other boundaries can be added with tests |
| Stored flow body | Existing stored owner ID and derived body head | Inside start/end after exact owner lookup and shape check | None needed for this scope |
| Derived list/group wrapper | Consecutive stored members; wrapper has no ID | No wrapper target; before/after a member addresses its current group-member slot | Explicit outside-group boundary, if requested |
| Stored row axis | Immutable row token and grid rows projection | Reject as a block target | Q1.3.2: explicit grid + row + before/after |
| Stored column axis | Immutable column token shared across rows | Reject as a block target | Q1.3.2: explicit grid + row + column + before/after for cell-model insertion |
| Cell body | Existing derived address from grid/row/column IDs | No direct inside-cell variant; a stored visible block inside a cell can still be a sibling target | Q1.3.2: explicit grid/row/column + inside start/end |
| Virtual default/required/storage head | Engine-owned address; not an ordinary stored author node | Reject as a node target; Root is separately supported | Explicit required-slot addressing requires a separate contract |
| Inline item, span or text character | Stable token/selection support | Reject as a block target | Text-offset or inline targeting is separate D3 work |
| Graphic-domain object | Existing ID helpers and native graphic APIs | Reject this document API | Existing graphic contract remains separate |

Rows and columns are already stable IDs. Q1.3.2 must use them rather than invent IDs for model row, cell or body wrappers. Existing native movement rejects row/column axis targets (`rust-shadow/src/movement.rs:225-249`); this slice must not claim axis movement support.

## Proposed additive API

Illustrative names; keep current model-index APIs unchanged:

```rust
pub struct ModelEditBase { /* private incarnation, revision, schema identity */ }
pub struct ModelRead { pub model: Value, pub base: ModelEditBase }
pub enum FlowTarget { Root, Node(Key) }
pub enum RelativeModelTarget {
    Before(Key),
    After(Key),
    InsideStart(FlowTarget),
    InsideEnd(FlowTarget),
}
pub struct RelativeModelInsert { pub target: RelativeModelTarget, pub model: Value }

pub fn read_model_for_edit(&mut self) -> Result<ModelRead>;
pub fn insert_models_relative(
    &mut self,
    base: &ModelEditBase,
    commands: &[RelativeModelInsert],
    options: EditOptions,
    now_ms: f64,
) -> Result<ModelInsertBatchResult>;
```

`ModelEditBase` can be cloned but has no public constructor, Serialize/Deserialize implementation, checkpoint field or wire representation. The model and base are captured in the same synchronous read. Existing result keys or `state()` projection marker fields supply stored IDs; this slice needs no new document ID catalog. The schema component is the existing `RuntimeSchema::identity()` SHA-256 fingerprint, not a newly invented schema version.

A before/after target follows its **current** logical parent when the caller provides a fresh base. For a stored group member, its current parent is the derived group, so insertion uses the member path and inherits group attributes exactly as the existing compiler does. It does not mean before/after the entire group. A model incompatible with that current parent rejects. The root/stored-flow inside variants select that explicit flow's first or last model child. They never infer a text offset.

Commands execute in input order against one evolving candidate. Resolve each target immediately before compiling that command. Do not resolve all targets to indexes before running the batch. Repeated After(K) commands therefore have the same sequential behavior as repeated current-path inserts: later inserts can appear closer to K. Preserve Q1.2's one compiler, promotion gate and column memo. A target affected or hidden by an earlier command must be rechecked and can reject the whole batch.

## O(1) local base token

Use two private SDK fields on RuntimeDocument: a process-local instance incarnation and a checked monotonic publication revision. Allocate each incarnation once from a static AtomicU64 with checked exhaustion; never wrap or reuse an incarnation. A token contains that incarnation, revision and existing schema identity. The incarnation is a lifetime guard for an SDK handle, not a CRDT node/document identity, server generation or authorization token.

Native RuntimeDocument has no mutable public server handle or Clone implementation (`runtime_schema.rs:290-295`). Schema access is immutable. The current live-document mutation gates are closed and small:

| Gate | Current source | Token rule |
| --- | --- | --- |
| New document | runtime_schema.rs:297-308 | New incarnation and initial revision |
| apply_remote | :358-360 | Precompute next revision; after successful apply, publish revision |
| stage_change | :362-383 | Precompute next revision; publish it only with the successful server swap |
| Static restore | :1291-1335 | New incarnation; internal pending replay finishes before any read token exists |
| restore_checkpoint | :1337-1343 | Successful replacement gets the restored instance's new incarnation |
| Read/model/state/selection/checkpoint | Existing read methods | Preserve revision |
| acknowledge | :1273-1280 | Preserve document revision; it only removes an exact pending prefix |
| Failed validation/apply/compile/restore | Candidate or atomic core request | Preserve original incarnation and revision |

All existing authoring methods, raw record, undo/redo and the model compiler publish through record/stage_change. `apply_remote` is the only other direct live apply. The audit found no fourth live mutation path. `stage_change` swaps only the server, so it must preserve the original incarnation and increment the original revision; it must not copy its temporary candidate's incarnation.

For a small, safe implementation, **every successful apply_remote or stage_change publication increments revision**, including empty operations, duplicate retry operations, empty batches, clock-only reservations, and undo/redo that emits no operations. This conservative policy avoids snapshot equality on the mutation hot path. It may reject a semantically unchanged base; document that behavior. Failed calls leave a prior token usable. Acknowledgement alone remains valid because this token guards document targeting, not pending-queue ownership.

Check revision exhaustion before a live mutation or server swap. Never return an overflow error after applying to the live server. Static restore can consume unused incarnation numbers on failure; correctness does not require dense numbering. If future Clone or mutable-schema APIs are added, they must enter this mutation audit. An exact same checkpoint restored into the same variable still invalidates old tokens by changing incarnation, avoiding a rollback ABA acceptance.

On guarded insertion: validate the token's schema, incarnation and revision before compiling any command, including an empty batch. Return a distinct local stale-base/schema/foreign-instance error before publication. Compile and commit synchronously under the same mutable RuntimeDocument borrow. There are no await points, host callbacks or permission checks in this native contract. If any candidate command fails, live document, History, pending changes and revision stay unchanged. Successful insertion consumes the base under the conservative publication policy.

This makes token capture/check O(1) in document and journal size. Copying/comparing the existing fixed-size schema fingerprint is bounded. It does **not** make model reading, ID lookup, candidate restore or the existing History commit O(1). Those costs need separate measurement; this design claims no performance PASS.

### Snapshot-token alternative rejected for the hot path

An exact native snapshot + schema comparison correctly detects lower-clock remote changes and reservations. However, every read token would retain the complete operation journal and every commit check would export/compare it. That grows with document history and conflicts with the structural-performance goal. Keep exact checkpoint comparisons as a test oracle for atomic rejection. The audited incarnation/revision gates provide local stale rejection without that new per-token cost. If the mutation audit stops being closed, revisit the token design rather than silently omitting a publication gate.

## Strict ID lookup

Selection anchors are not strict object targets. TS `edit.ts:269-275` documents that pathAt falls back to nearby live content or another cell. Native `nested.rs:1735-1810` has the matching raw_position fallback for hidden/deleted/covered targets. Calling resolve_selection or pathAt directly can silently convert a missing object into a neighbor and is unsuitable here.

Build a read-only strict resolver from the current logical projection. Reuse existing `Compiler::entries`/block projections and model-path conventions (`runtime_structure.rs:256-328`), and the existing core `flow_model_path`/`block_model_path` algorithms as the reference (`rust-shadow/src/nested.rs:1820-1862`). Do not call materialize_model_head during lookup; preparation belongs to the detached compiler. A narrow SDK helper can walk the existing state projections from root and reuse the compiler's entries calculation; no new wire operation or core identity system is required. If a core read command is preferred to avoid duplicate path walking, it must be strictly read-only and expose the same exact-result contract.

Required checks before returning a path:

1. The requested key parses as an existing immutable token. Reject characters, inline nodes, zero-clock heads, required synthetic markers and axis tokens for Q1.3.1.
2. The actual stored token is alive. A tombstoned token must not pass because text projection retains its content or because selection can find a nearby position.
3. Match the exact primary marker in a current logical block. Do not match a text alias, parts array, prior placement ticket or physical source neighbor. A live ID that is only an alias after join returns not-current-model-node; alias retargeting needs separate qualification.
4. Reach that block from root through its current logical ancestor chain. A projection listed for a hidden old source line is not proof of visibility. Move winners and current ancestry determine the path, not birth origin or `placements` alone.
5. For grid ancestry, require the current grid plus matching live row/column IDs and reject covered cells. Retained covered-cell model data is not an editable visible target under this first policy. Recursively reject an ancestor hidden by deletion or cardinality max, even if the target itself remains alive.
6. Use current group entries to form `[...flow, groupIndex, memberIndex]`; no wrapper ID exists. Reject ambiguity if the same exact marker is found at more than one visible logical position.
7. For inside Node(K), require the current effective schema shape to be flow, and append the first/last child boundary to that flow path. Text, grid, atom and group are not stored-flow bodies.

Valid stored blocks inside visible cells remain supported through this same ancestry walk. Covered/deleted/missing cell axes reject. Required synthetic nodes and virtual root paragraphs remain excluded even when they are shown in the model; callers can select Root for root insertion. Ordinary stored nodes inside required lines can only be supported if exact root-reachable projection proves their current visible model position; otherwise reject with an explicit unsupported-target error.

No model-index fallback, nearest-live fallback, auto-unmerge, undelete or automatic rebase is permitted. On stale-base rejection the caller reads again and chooses whether the same stored ID still expresses its intent.

## TS/server evidence and distributed boundary

- `Doc.version` is a local mutation revision distinct from its Lamport clock (`doc.ts:355-359`; increments at :803 and :1139). It supports the local-token analogy; the native counter need not equal TS revision numbers.
- `readDocumentSlice` returns blockId null for derived groups and virtual text (`crdt/read.ts:88-90,114`). Stored members have IDs when read inside the group. This confirms the no-wrapper-ID boundary.
- `blockPath` and `flowPath` resolve current grouping, placement and cell coordinates (`edit.ts:191-235`). These support an independent TS targeting oracle after an exact marker/visibility check.
- Existing TS ConditionalBase is `{epoch, serverSeq, schemaVersion}` (`sync/client.ts:48`). The client requires online/ready/no pending state, checks that exact base, compiles a detached candidate and retains an exact conditional attempt (`:522-540`).
- `DocHub.submitConditional` checks epoch, exact retry receipt, actor sequence, schema version and authoritative serverSeq before accepting (`server/hub.ts:190-207`). This is an existing server acceptance contract, not a missing CRDT feature.
- TS conditional retry retains unknown outcomes and retries identical operations (`sync/client.ts:543-567`). The native SDK has no serverSeq, epoch, durable receipt or native host acceptance lifecycle. A local token must not be advertised as distributed conditional acceptance.

Q1.4 authorization remains separate. Schema validity, own History and a matching local base do not grant permission. No native hosted write, revocation handling or server-guaranteed conditional protocol is added by this slice.

## Implementation boundary after Q1.2 sealing

Prefer SDK-only changes: new `runtime_targeting.rs` under the existing paragraph compiler module; private local-version fields/helpers and read method in runtime_schema.rs; additive re-exports; shared compiler-loop reuse for relative commands; focused tests, example/trace and a new targeting comparison harness. Avoid changing core storage, snapshot, wire operations, reservation semantics, schema identity, History formats or previous reports. A shared compiler helper is acceptable when needed to retain one batch compiler and one commit.

Do not implement relative targeting as a sequence of calls to insert_model_at or insert_models_batch. That would split History/pending changes, lose evolving shared state and weaken atomicity. Do not pre-resolve all command paths against the original model.

Q1.3.2 can add typed axis/cell containers after this slice is qualified: grid+row for row adjacency; grid+row+column for cell insertion; grid+row+column for cell-body edges. Every tuple must prove current ownership, live axes and the explicit covered-cell policy. This first slice must not promise those signatures or unrestricted stable-target coverage.

## Required focused qualification

Use a fresh TS/native corpus for original Word and Presentation schemas, a custom renamed flow/group/grid schema, moves, derived groups and visible nested cell content. The TS driver independently finds the exact marker in current logical blocks, checks visibility/aliveness and obtains blockPath/flowPath. It then calls the existing TS model-index compiler. Do not use a native-returned path as the TS oracle. Compare complete models, requested result keys, operation payloads where representation contracts apply, clocks including reservations, pending changes, History undo/redo and own checkpoint restoration. Revision/incarnation numbers themselves are local implementation details and are not TS parity fields.

Minimum cases:

- Read, peer-insert/reorder/move/delete, then commit old base: stale rejection and complete unchanged live checkpoint; no edit at the previous model index.
- Fresh base after a move: before/after follows the same stored ID in its new logical parent; peer text survives one undo/redo and checkpoint retry.
- A foreign operation below the sender Lamport maximum changes the model but leaves that maximum unchanged: old base still rejects.
- Clock-only reservation, empty or duplicate successful apply, and no-op History publication invalidate according to the conservative policy. Failed mutation preserves base usability. Read and acknowledge preserve it.
- Cross-document token, static restore and restore_checkpoint reject previous-instance tokens, including identical checkpoint rollback. Different schema identity cannot pass.
- Repeated targets and multiple inserts resolve sequentially on the evolving candidate; later invalid target rejects the complete batch with redo/pending/clock/version intact.
- Derived-group member before/after uses the current member slot and group attributes. A group wrapper never appears as a target key. Group split/coalescence after peer attribute changes requires a fresh base.
- Missing, deleted, hidden-by-ancestor, hidden-by-cardinality, covered-cell, aliased-marker, synthetic-head, character, axis and wrong-shape targets reject without nearest-live fallback. Stored visible block targets inside visible cells succeed.
- Root and empty/nonempty stored-flow edges work. A stored flow moved elsewhere retains identity. Unsupported inside text/grid/group requests reject.
- Default options produce one History action/pending Change for nonempty operations. Empty and clock-only result semantics remain the Q1.2 contract. Retry uses the captured Change, not recompilation of the model command.
- Checked counter exhaustion fails before publication; new/restored instance IDs do not collide. Test this privately without exposing a public counter mutation API.

No performance, browser, mobile, production Rust/WASM or hosted authorization PASS follows from these planned checks. Fixed sequences do not close Q2 fuzzing or all Q1.3 axis targets.

`source-seal.json` records the exact 17 source inputs used for this design. These hashes identify this design review state; they do not claim that code implementing the proposal exists.
