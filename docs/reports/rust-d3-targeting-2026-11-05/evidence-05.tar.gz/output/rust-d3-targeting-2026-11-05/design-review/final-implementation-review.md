---
work_id: rust-d3-targeting-2026-11-05
artifact_type: implementation_source_review
status: done
owner_role: reservation-review
source_request: Q1.3.1 actual source review after final implementation freeze
last_updated: 2026-11-05
---

# Q1.3.1 final implementation source review

Verdict: **APPROVED_BOUNDED_SOURCE**, zero open blocking findings. This review read the actual implementation again after batch_impl confirmed final source freeze. It does not infer native, differential, browser, mobile or performance PASS. This lane ran none of those checks.

The original design README and design source seal remain unchanged. `implementation-source-seal.json` records 22 source/test/example/comparison inputs for this actual-code review. Every Rust shadow-core source file matches the Q1.3 phase baseline; this implementation changes SDK behavior only.

## Mutation and stale-base proof

`runtime_targeting.rs:8-13` stores only private incarnation, publication revision and existing schema fingerprint in ModelEditBase. It has Clone/Debug/Eq but no Serde implementation or public constructor. Read-model and base capture happen in the same synchronous call (`:39-49`). Guard checks schema, incarnation and revision before compilation, including empty commands (`:50-81`). No complete document snapshot or operation journal is retained in a read-base token. Guard work is O(1) in document/journal size; this is a source property, not a performance measurement.

`runtime_schema.rs:13-21` allocates incarnations with checked AtomicU64 fetch_update. There is no wrapping allocation. RuntimeDocument retains private server/schema/version fields and has no Clone or mutable-server accessor (`:300-307`). New and static restore allocate fresh incarnations (`:309-322`, `:1325-1333`). The existing schema identity is immutable through the public handle.

The closed live-document publication gates are apply_remote (`:372-376`), stage_change (`:381-407`) and successful restore_checkpoint replacement (`:1362-1368`). apply_remote and stage_change compute checked next_revision before live publication. After successful apply/server swap, they assign it. All record/authoring, model batches and undo/redo route through stage_change. Failed core requests or candidate commands preserve original version and checkpoint. Empty, duplicate, clock-only and no-op History publications conservatively consume a base. Reads and acknowledge do not publish document mutations or change revision (`:1296-1303`).

stage_change retains the original incarnation across its server swap. Its temporary private candidate does not issue external tokens. Static restore has a new incarnation; restore_checkpoint assigns only after a complete successful static restore. Therefore an exact checkpoint rollback cannot revalidate a prior instance token. Local revision/incarnation fields do not enter RuntimeCheckpoint, native snapshots, wire operations or History.

## Exact target resolution and atomic compilation

`runtime_targeting.rs:83-108` restores a detached candidate, resolves every command immediately before compiling that command, retains one Compiler and promotion/memo state, and submits one aggregate history_record with final compiler reservation clock. A later failure discards the complete candidate. `runtime_batch.rs:74-91` supplies the shared compile_model_insert helper, preserving Q1.2 validation and reservation semantics.

`relative_path` checks a real live stored node, rejects zero-clock heads and required synthetic actors, then walks from root (`:196-242`). It accepts only one exact primary marker (`:235-240`, `:344-352`). It never matches aliases/parts/characters or calls selection/pathAt. Before/After modifies the actual current model sibling slot. Inside Node requires effective flow shape (`:257-265`); Root is an explicit edge variant. Physical origin and a prior placement record are not used as a substitute for current logical ancestry.

The walk reads one TargetView built from a single current state (`:110-187`). It traverses only current root-reachable flow/grid projections. Missing/deleted, aliased, cardinality-hidden and ancestor-hidden stored nodes cannot produce one accepted primary position. Grid descent checks covered-cell status and live row/column identities (`:399-413`). Visible stored blocks inside visible cells remain eligible. Rows/columns themselves are absent from block traversal and reject. No direct cell-body/axis target API is added; those remain Q1.3.2 with explicit grid/row/column ownership tuples.

Current derived group entries are shared through the pure entries_for_projection helper (`runtime_structure.rs:257-290`). A member gets its actual group/member path and the existing compiler inherits current group attributes. No derived wrapper ID is created.

## Canonical prefix alignment

The original length-difference-only offset was a review risk. Final `empty_default_prefix` and walk checks (`runtime_targeting.rs:272-287`, `:319-332`) accept an extra canonical child only when it is the current flow's exact empty default text node or its one-member derived group, and reject that offset for a required private line. All other size/layout mismatches fail closed; each mapped member type is also checked before accepting any result.

This rule is grounded in core source, not a general index heuristic: `nested.rs:1154-1191` constructs model children from entries_nested; `:1194-1196` returns required-line models before default insertion; `:1207-1222` can insert one default only at index0. entries_nested (`:1239-1257`) discards empty virtual gaps wherever they occur. The schema compiler requires flow default to name a text child (`runtime_schema.rs:1308-1324`). Thus omitted atom-tail or middle virtual gaps do not become interior canonical children. A childRules max filtering mismatch fails the layout/type checks; it does not retarget a neighbor. Frozen tests include full-model prefix/group/atom and Word required-line cases.

## Review items corrected before freeze

1. P2 structural cost: the first DFS re-exported the complete native state/model per flow and scanned all tokens per block. TargetView now builds projection, birth, alive and boundary indexes once per target resolution and uses pure grouping helpers.
2. P2 grid cost: the first cell walk searched all cells for every coordinate. Final code builds one ordered pair-to-line map, rejects duplicate cell pairs, and performs indexed lookups (`:384-416`). This removes that additional O(C squared) search. Existing model export/candidate replay costs remain; no structural benchmark result follows.
3. Test strength: the moved-target test now checks exact new-parent text order and absence in the old parent. Empty-undo invalidation captures its base after the undo stack is exhausted. The source contains bounded concurrent incarnation-allocation and near-overflow tests using local counters, without exhausting the product-global counter.

No unresolved correctness counterexample was found in the assigned scope.

## Test and comparison source boundaries

The twelve runtime_targeting test bodies cover evolving repeated targets, same-Lamport foreign changes, read/ack preservation, failed remote/own/late-batch preservation, empty/duplicate/relative/undo/clock-only invalidation, foreign-instance/schema/restore ABA, moved-parent intent with foreign text and retry, group inheritance, forbidden target kinds, live/covered cell ancestry, aliases, cardinality hiding, default-prefix alignment, required lines, and explicit root/flow edges. Internal tests cover atomic allocation uniqueness and checked exhaustion before publication. Their execution results are owned by batch_impl.

The new TS oracle independently walks exact primary markers from root, checks aliveness/visibility/covered axes and validates the complete canonical block against the projected node (`runtime-document-targeting/oracle.mjs:12-35`). It uses TS blockPath after the exact projected marker relation, never a native-returned path. Prefix planning restores the exact original snapshot and clock, compiles the complete previous prefix array per step, and executes the final full array once on the live TS document (`:49-59`; compare.mjs author relative branch). It retains a separate pre-model insertion oracle and normalization-closure check. The native trace invokes the actual guarded SDK method and compares exact checkpoints after rejection. These source properties support the intended comparison method; final differential PASS requires its own fresh receipt.

## Bounded approval

This is Q1.3.1 synchronous native local targeting. A successful publication invalidates its prior local base even when document content is unchanged. The token is neither a server epoch/revision, a durable receipt, nor permission. TS DocHub already has a separate authoritative `{epoch, serverSeq, schemaVersion}` conditional-acceptance contract; native network acceptance and Q1.4 authorization are not qualified here. Typed axes/direct cell wrappers, derived wrappers, text offsets, alias retargeting, general edits, production Rust/WASM, renderer and performance qualification remain open.
