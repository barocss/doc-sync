import subprocess,pathlib,json,hashlib,datetime
out=pathlib.Path('output/rust-d2-shared-2026-11-04/core')
binary=out/'target/debug/doc-sync-rust-shadow'
sha=lambda data:hashlib.sha256(data).hexdigest()
canon=lambda value:json.dumps(value,sort_keys=True,separators=(',',':'))
payload={'b':{'y':2,'x':1},'a':0}
manifest={'root':'book','marks':[],'markValues':{'paint':{'default':None,'values':[payload]}},'nodes':{
'book':{'shape':'flow','children':['line','matrix','dot'],'default':'line'},'line':{'shape':'text'},'caption':{'shape':'text'},
'matrix':{'shape':'grid','children':['band']},'band':{'shape':'row','children':['entry']},
'entry':{'shape':'cell','children':['contents'],'attrs':{'shade':{'default':None,'values':[payload]}}},
'contents':{'shape':'flow','children':['caption'],'default':'caption'},'dot':{'shape':'atom','attrs':{'source':{'default':None,'values':[payload]}}}}}
slot=lambda at:{'at':at,'source':'enum','index':0}
mark=slot(['markValues','paint']);node=slot(['nodes','dot','attrs','source']);cell=slot(['nodes','entry','attrs','shade'])
dto={'format':'doc-sync-runtime-schema-shared-v2','manifest':manifest,'referenceGroups':[{'representative':node,'slots':sorted([node,mark,cell],key=canon)}]}
identity='sha256:'+sha(canon(dto).encode())
ticket=lambda n,actor:{'lamport':n,'actor':actor}
operation=lambda n,kind:{'t':'node','id':ticket(n,'A'),'origin':ticket(0,'~root' if kind=='matrix' else '1@A/'+('rows' if kind=='band' else 'cols')),'type':kind}
set_op=lambda n,source:{'t':'reference','format':'doc-sync-runtime-reference-op-v1','op':{'t':'set','at':ticket(n,'A'),'ids':[ticket(1,'A')],'key':'$cell:2@A,3@A|shade','value':payload},'references':[{'path':['value'],'schema':identity,**source}]}
process=subprocess.Popen([str(binary)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
requests=[];responses=[];labels=[]
def ask(label,request):
 request={'replica':'r','schema':identity,**request}; requests.append(request); labels.append(label)
 process.stdin.write(json.dumps(request,separators=(',',':'))+'\n');process.stdin.flush()
 response=json.loads(process.stdout.readline());responses.append(response)
 assert response['ok'],(label,response)
 return response
ask('new',{'cmd':'new','actor':'A','runtimeSchema':dto})
ask('seed',{'cmd':'apply','ops':[operation(1,'matrix'),operation(2,'band'),operation(3,'col')]})
def record(label,n,source):
 response=ask(label,{'cmd':'history_record','ops':[set_op(n,source)],'now':n,'options':{'caretBefore':'left','caretAfter':'right'}})
 items=response['state']['items'];grid=next(item for item in items if item['id']==ticket(1,'A'))
 assert grid['attrs']['$cell:2@A,3@A|shade']['value']==payload
 return response
record('mark-source-to-cell',4,mark)
u=ask('mark-undo',{'cmd':'history_undo'});assert u['ops'][0]['value'] is None
r=ask('mark-redo',{'cmd':'history_redo'});assert r['ops'][0]['references'][0]['at']==mark['at'];assert r['ops'][0]['op']['key']=='$cell:2@A,3@A|shade'
saved=ask('snapshot',{'cmd':'snapshot'})['snapshot']
state=r['state'];assert ask('json-snapshot-restore',{'cmd':'restore','actor':'A','snapshot':saved})['state']==state
checkpoint=ask('history-export',{'cmd':'history_export'})['checkpoint']
assert ask('json-history-restore',{'cmd':'history_restore','checkpoint':checkpoint})['state']==state
record('node-source-to-cell',10,node)
r=ask('node-undo',{'cmd':'history_undo'});assert r['ops'][0]['references'][0]['at']==mark['at']
r=ask('node-redo',{'cmd':'history_redo'});assert r['ops'][0]['references'][0]['at']==node['at'];assert r['ops'][0]['op']['key']=='$cell:2@A,3@A|shade'
saved=ask('final-snapshot',{'cmd':'snapshot'})['snapshot'];assert saved['manifest']==dto
assert ask('final-restore',{'cmd':'restore','actor':'A','snapshot':saved})['state']==r['state']
process.stdin.close();stderr=process.stderr.read();process.wait();assert process.returncode==0
reqpath=out/'cell-requests-01.jsonl';respath=out/'cell-responses-01.jsonl'
reqpath.write_text(''.join(json.dumps(req,separators=(',',':'))+'\n' for req in requests));respath.write_text(''.join(json.dumps(res,separators=(',',':'))+'\n' for res in responses));(out/'cell-stderr-01.log').write_text(stderr)
expected=json.loads((out/'source-current-01.json').read_text());assert all(sha(pathlib.Path(path).read_bytes())==digest for path,digest in expected.items())
receipt={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','scope':'Frozen native protocol only; mark/node source enum handles to differently named cell enum target via encoded cell Set, undo/redo, JSON snapshot and History restore; no source edits','requests':len(requests),'okResponses':len(responses),'labels':labels,'schema':identity,'binary':str(binary),'binarySha256':sha(binary.read_bytes()),'requestsArtifact':{'path':str(reqpath),'sha256':sha(reqpath.read_bytes())},'responsesArtifact':{'path':str(respath),'sha256':sha(respath.read_bytes())},'frozenSourceGuard':{'files':len(expected),'allMatch':True}}
(out/'cell-receipt-01.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
