from pathlib import Path
root=Path('/Users/user/github/doc-sync')
def rep(name,a,b):
 p=root/name;s=p.read_text();assert a in s,name;p.write_text(s.replace(a,b))
rep('README.md','explicit native schema references and declared default/enum sharing','explicit native reference groups across atomic attributes and value marks')
rep('apps/docs/src/schemas/document.md','alias schema DTO. Equal JSON alone does not declare sharing. `markValues.fields`\nand arbitrary cross-descriptor reference graphs remain unsupported.','''alias schema DTO. The v2 shared schema DTO also declares groups across stored
atomic attributes, value marks and enum-only slots. The chosen source reference
and the target property stay separate. Equal JSON alone does not declare sharing.
A representative determines factory and default-projection payload order;
`manifest()` stays raw and `effective_manifest()` exposes the resolved rules.
References inside payloads, field-branch aliases and `markValues.fields` remain
unsupported.''')
rep('apps/docs/src/schemas/custom.md','native composite-reference handles and explicit default/enum sharing','native reference handles, default/enum sharing and cross-descriptor reference groups')
rep('apps/docs/src/schemas/custom.md','Arbitrary cross-descriptor or enum-only reference aliases, markValues.fields','Nested payload identity and field-branch aliases, markValues.fields')
p=root/'apps/docs/src/guide/document-rules.md';s=p.read_text();s+='''
## Shared references across properties

The experimental Rust SDK also provides `compile_with_reference_groups` with
`ReferenceSlot` and `ReferenceGroup`. A group declares which composite defaults
and enum entries are the same object across supported atomic attributes or
value marks. It can contain enum entries without a default. A representative
must be one of at least two unique members; its payload order applies to all
members. Overlapping groups and undeclared equal JSON do not create sharing.

A source handle can target another property only through declared identity.
Birth helpers omit it only when it shares the target's default. Explicit writes
retain the source path/index and the target operation key through History and
native JSON recovery. Compiled effective rules also resolve default, null-reset
and clone-fallback models to the representative; raw manifest/DTO data remain
available. Bare and v1 schema identities and wire forms stay unchanged.

This format covers whole atomic values, not pointers inside JSON payloads or
structured field branches. A composite enum default must still share at least
one of its own enum slots in the native subset. General TypeScript/native wire
exchange and live schema migration remain separate work. See the
[Rust shared-reference example](./rust#shared-references-across-properties).
''';p.write_text(s)
rep('docs/rust-roadmap.md','Arbitrary cross-descriptor or enum-only reference graphs, markValues.fields, text:false,','Explicit atomic cross-descriptor and enum-only reference groups are supported.\nNested payload identity, field-branch aliases, markValues.fields, text:false,')
rep('docs/rust-roadmap.md','not close TS/native wire integration, cross-descriptor or enum-only alias graphs,','not close TS/native wire integration or arbitrary nested alias graphs,')
p=root/'docs/rust-roadmap.md';s=p.read_text();needle='Replace preset/type-name branches with per-document compiled schema data.';assert needle in s;s=s.replace(needle,'''The cross-property extension adds `doc-sync-runtime-schema-shared-v2` with
explicit `{representative, slots}` groups of atomic default/enum references.
Members may span node kinds, differently named attributes and value marks;
enum-only groups use the same format. The representative is a member and its
payload order is authoritative. Canonical group/member order does not erase
that representative choice from semantic identity. Bare/v1 identity and wire
stay unchanged. Raw manifest/DTO and diagnostic base identity remain separate
from compile-once effective rules and graph-bound native identity.

Target-aware admission and birth omission retain the selected source path/index
and actual target key. Per-key caches avoid cloning/scanning every group target
for each Set. Effective defaults, null resets and clone fallback match actual
TS shared-object projection. The own-enum default requirement and stricter
unshared native-handle boundary remain explicit native subset limits. Nested
payload reference graphs, field aliases, live transitions, remaining D2 and D3
compiler gates stay open. See the
[cross-property report](reports/rust-d2-shared-2026-11-04/README.md).

'''+needle);p.write_text(s)
p=root/'apps/docs/src/roadmap.md';s=p.read_text();needle='Arbitrary cross-descriptor/enum-only alias graphs and\nTS/native wire exchange remain open.';assert needle in s;s=s.replace(needle,'''The following v2 extension adds explicit cross-property and enum-only reference
groups with a representative, target-aware admission and raw/effective rule
separation. Nested payload/field reference graphs and TS/native wire exchange
remain open.''');p.write_text(s)
