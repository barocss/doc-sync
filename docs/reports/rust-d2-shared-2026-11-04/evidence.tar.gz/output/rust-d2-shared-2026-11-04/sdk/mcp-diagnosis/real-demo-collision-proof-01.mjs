import {createServer,get} from 'node:http';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {once} from 'node:events';
const data=await mkdtemp(join(tmpdir(),'doc-sync-owned-ipv4-proof-'));
const events=[];
const foreign=createServer((req,res)=>{events.push({server:'owned-foreign-ipv4',url:req.url,local:req.socket.localAddress,port:req.socket.localPort});res.writeHead(404,{'x-owned-server':'foreign-ipv4'});res.end();});
let child;
try {
 foreign.listen(0,'127.0.0.1');await once(foreign,'listening');const port=foreign.address().port;
 const env={...process.env,PORT:String(port),DATA_DIR:data};delete env.NO_SCHEMA;delete env.DOC_PROFILE;
 child=spawn(process.execPath,[resolve('apps/demo/server.ts')],{env,stdio:['ignore','pipe','pipe']});
 let stdout='',stderr='';child.stderr.on('data',c=>stderr+=c);
 await Promise.race([new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',code=>reject(new Error(`child exit ${code} ${stderr}`)));child.stdout.on('data',c=>{stdout+=c;if(stdout.includes(`http://localhost:${port}\n`))resolve();});}),new Promise((_,reject)=>setTimeout(()=>reject(new Error('startup timeout')),10000).unref())]);
 events.push({step:'actual-demo-banner-same-port',stdout,foreignAddress:foreign.address(),pid:child.pid});
 const request=host=>new Promise((resolve,reject)=>{get({host,port,path:'/api/docs/split-banner-proof/state',agent:false},res=>{let body='';res.on('data',c=>body+=c);res.on('end',()=>resolve({host,status:res.statusCode,contentType:res.headers['content-type']??null,owned:res.headers['x-owned-server']??null,body:body.slice(0,256)}));}).on('error',reject);});
 events.push(await request('127.0.0.1'));events.push(await request('::1'));
 console.log(JSON.stringify({platform:process.platform,node:process.version,events},null,2));
} finally {
 if(child&&child.exitCode===null){const exited=once(child,'exit');child.kill('SIGTERM');await exited;}
 if(foreign.listening)await new Promise(resolve=>foreign.close(resolve));
 await rm(data,{recursive:true,force:true});
}
