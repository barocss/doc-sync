# Read-only MCP test diagnosis

## Confirmed

- The two startup helpers use `PORT=0`, distinct temporary data directories and complete newline-terminated banner parsing. The split-banner prefix/control listeners use IPv4 loopback. No shared fixed full port exists in these helpers.
- `apps/demo/server.ts:1063` binds without a host, while both helpers return `127.0.0.1`. macOS reports `net.inet6.ip6.v6only=0`.
- On macOS with Node 24.22.1, an owned `127.0.0.1` HTTP server and an owned wildcard IPv6 server can bind the same numeric port. IPv4 requests reach the first server; `::1` requests reach the wildcard server. See `dualstack-collision-proof-01.json`.
- The actual unmodified demo server reproduces the same routing error when forced to the owned IPv4 listener's port. Its real banner announces port 57512; IPv4 GET returns identifiable foreign 404, no content type and an empty body; IPv6 GET returns the demo state with an epoch and JSON content type. See `real-demo-collision-proof-01.json`.
- The original banner failure used port 53060. A persistent unrelated Node 22 physics viewer process, PID 89429, started November 3, currently owns `127.0.0.1:53060`. It was inspected only and preserved. See `failed-port-owner-01.log`.
- Demo `send()` always sets content type and body. Its valid `/state` and `/leave` handlers do not produce the observed empty 404.

## Inference and limits

The banner failure is explained by a numeric-port collision across wildcard IPv6 and explicit IPv4 listeners. The automatic recovery failure has the same empty 404 signature and a 5.6-second duration. Its `userInsert` waits up to five seconds for a snapshot, then `finally` sends leave, which can replace the first error with the observed 404. Its original origin was not recorded, so that individual collision is not directly proved from the old log.

A passing isolated retry does not establish the cause. The controlled same-port routing proof establishes the operating-system mechanism independently.

## Candidate fix, not applied

Add an optional demo listener host environment variable, preserve the default wildcard behavior, and set the same IPv4 loopback host in demo-spawning test helpers. A controlled collision test should show that the IPv4 demo bind fails with EADDRINUSE rather than publishing an unreachable IPv4 origin, or that kernel-selected IPv4 port 0 chooses a different available port. Keep the split-banner incomplete-prefix gate assertions.

## Preservation

No source or dist edits. `source-dist-before.json` and `source-dist-after.json` guard 272 files. `app-test-baseline-01.tar.gz` preserves the two tests, both fixture helpers, demo server, and source/dist transport files. `source-dist-guard-01.json` records their guard and archive digest.
