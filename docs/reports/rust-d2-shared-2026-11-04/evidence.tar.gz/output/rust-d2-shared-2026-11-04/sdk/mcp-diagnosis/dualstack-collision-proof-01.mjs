import {createServer,get} from 'node:http';
import {once} from 'node:events';
const events=[];
const foreign=createServer((req,res)=>{events.push({server:'owned-foreign-ipv4',url:req.url,local:req.socket.localAddress,localPort:req.socket.localPort,remote:req.socket.remoteAddress});res.writeHead(404,{'x-owned-server':'foreign-ipv4'});res.end();});
const demo=createServer((req,res)=>{events.push({server:'owned-demo-wildcard',url:req.url,local:req.socket.localAddress,localPort:req.socket.localPort,remote:req.socket.remoteAddress});res.writeHead(200,{'x-owned-server':'demo-wildcard'});res.end('{}');});
const listen=(server,...args)=>new Promise((resolve,reject)=>{server.once('error',reject);server.listen(...args,()=>{server.removeListener('error',reject);resolve();});});
const request=host=>new Promise((resolve,reject)=>{get({host,port:foreign.address().port,path:'/api/docs/split-banner-proof/state',agent:false},res=>{let body='';res.on('data',c=>body+=c);res.on('end',()=>resolve({host,status:res.statusCode,headers:res.headers,body}));}).on('error',reject);});
try {
 await listen(foreign,0,'127.0.0.1');
 const port=foreign.address().port;
 events.push({step:'foreign-listening',address:foreign.address()});
 try {
  await listen(demo,port);
  events.push({step:'demo-listening-same-port',address:demo.address()});
  events.push(await request('127.0.0.1'));
  events.push(await request('::1'));
 } catch(error){events.push({step:'demo-bind-error',code:error.code,message:error.message});}
 console.log(JSON.stringify({platform:process.platform,node:process.version,events},null,2));
} finally {for (const server of [demo,foreign]) if(server.listening) await new Promise(resolve=>server.close(resolve));}
