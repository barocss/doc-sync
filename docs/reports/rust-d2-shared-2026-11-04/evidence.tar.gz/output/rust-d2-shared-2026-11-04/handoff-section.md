### 5.147 D2 cross-property schema references

Three agents own core, SDK/docs and independent TS/native comparison. Baseline
is main1cfb7a2 plus166 captured inherited D2 source/fixture/doc files. All six
older report capsules remain byte-identical. Production TS CRDT source stays
unchanged; a separate demo/test binding repair is described below. No commit,
push, deployment or registry publication is included.

RuntimeSchema v2 uses doc-sync-runtime-schema-shared-v2 with nonempty groups
of atomic default/enum slots. Each {representative,slots} group has at least two
unique slots and includes its representative. Members can span differently
named attrs, node kinds and value marks. Enum-only groups are supported.
Overlapping groups, malformed paths/representatives, primitive/field/computed
members and unequal/invalid payloads reject before replacement. Equal unlisted
values remain different identities; no deep-equality reference inference.

Groups share schema-owned constants, not mutable document registers. Each target
keeps an independent writer. Graph/representative identity pins handles and
checkpoints; member/group order normalization does not erase representative
choice. Raw manifest/DTO and base_identity stay available. effective_manifest
resolves shared slots once so defaults/null reset/enumclone fallback and factories
use representative payload order. Bare/v1 wire and identity remain unchanged.
The native nonnull composite enum default still requires an own enum member in
its group; TS-valid unlisted configurations can remain native-unsupported.

Target-aware admission and birth omission preserve selected SOURCE at/source/
index and actual TARGET key/path independently. Per-key caches avoid whole-
group scan/copy for each Set. History, exact conflicting-writer checks, native
JSON pending retry/ACK and own checkpoint restore retain provenance. This does
not perform live schema migration or provide a general TS/native wire bridge.

Core156PASS (prior147+new9), SDK101PASS (prior93+new8). The identical documented
program compiles/runs in an independent Cargo consumer. Baseline147PASS from40
archived matched core source inputs. A fixed6request protocol sequence has0ok
on old core (newformat unknown) and6ok on current core, including cross-key
History restore. Readonly cell-special-key probe14/14PASS covers mark/node refs
to a differently named cell attr, undo/redo and JSON document/History restore.

New shared corpus246actions/492actorstates includes138 actual staged Doc.edit
checks. It compares raw unwrappedops/IDs, full History, registerwriters/material,
clocks, pending/carets, UTF16 stable selections and exact attrs/marks JSON order.
Dedicated nonempty cross-group undo→JSONcheckpoint→redo→delivery proves recovered
source/target bindings. Raw/JSON redo admission rejection is recorded separately
from successful Doc.apply material semantics. New factory32/scope27/actualHub32
PASS. Source and hub-owned refs distinguish omitted births that pass transport
from retained payloads rejected by clone admission. Native-only extension remains.

Seven inherited corpora pass: flow162,grid180,shapes188,rules260,legacy82,
composite160,alias182 actions; all eight fixture/schema file hashes match baseline.
Final joint16driver qualification holds194 source/binary hashes unchanged.
Initial rules/alias trace writes failed ENOSPC while14drivers passed. Original
FAILreceipt is preserved. Ten owned diagnostic files were losslessly gzipped
with SHA verification; only current-task standalone Cargo caches were removed
after inventory. Seven selected standalone binaries retained exact bytes/paths;
regression targets and inherited tasks were untouched. After space recovery the
two failed lanes reran completely and passed under the original frozen maps.
The jointreceipt explicitly links14oldPASS+2retryPASS; no clean first-run claim.

Initial npm full run had2MCP404 failures. Controlled owned listeners and actual
demo reproduce this macOS IPv6wildcard/IPv4-specific same-numeric-port collision:
IPv4request reaches a different server. Failed banner port was confirmed owned
by an unrelated persistent IPv4listener, preserved unchanged. Automatic recovery
has the same inferred mechanism, but no origin in its original failure log.
Optional DOC_SYNC_HOST preserves normal default and lets tests bind127.0.0.1.
Twelve forced-IPv4 spawn helpers set that option; no transport retry/error mask,
protocol, actor ownership or CRDT rule changed. Fourteen integration files have
before sources/patch and stable guarded hashes. Real-demo regression before
1FAIL/1PASS →after2PASS; originalfailedfiles10PASS, demo147PASS, guarded12PASS.
Initial FAIL logs and collision receipts remain separate evidence. Final whole
workspace retry includes the two new demo cases; results are recorded below.

Nested payload/field identity graphs, callbacks/general computed rules, model-
only attributes, text:false, axis moves, positive-min cycles, full product/
compiler and live transitions stay open. Inherited D3 empty-patch clock, post-
move and empty-head compiler gaps stay open. Native Map/List, protected GC/
production recovery, Rust Client/editor binding and CRDTWASM remain separate.
Checkpoint proof here is not native production crash recovery. No Chrome/mobile
or performance benchmark is claimed.

[Source-bound cross-property report](docs/reports/rust-d2-shared-2026-11-04/README.md).
