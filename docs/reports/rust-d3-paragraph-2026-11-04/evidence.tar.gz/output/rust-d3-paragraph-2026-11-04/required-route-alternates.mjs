import {Doc, History} from '../../packages/doc-sync/src/index.ts';
import {textTicket} from '../../packages/doc-sync/src/crdt/text-storage.ts';
import {keyOf} from '../../packages/doc-sync/src/crdt/ticket.ts';
import {WORD_SCHEMA, PRESENTATION_SCHEMA} from '../../fixtures/product-schemas.ts';
for (const [schema,type,index] of [[WORD_SCHEMA,'section',2],[WORD_SCHEMA,'section',3],[PRESENTATION_SCHEMA,'slide',2]]) {
  for (const route of ['automatic-head','detached-node','detached-node-promote-head']) {
    const d=new Doc('A',schema), h=new History();
    d.edit([{op:'insert',at:[1],content:[{type}]}]);
    const line=d.blocks()[1].body, before=d.toJSON(), owner=d.blocks(line)[index-1], head=d.blocks(line)[0];
    let ops;
    if(route==='automatic-head') {
      const storage=d.get(keyOf(textTicket({parent:line,after:owner.marker.key})));
      d.clock.next();
      ops=[{t:'set',at:d.clock.next(),ids:[storage.id],key:'$field:["style","align"]',value:'right'}];
      ops.forEach(op=>d.apply(op));
      const text={t:'text',id:d.clock.next(),origin:storage.id,text:'P😀tail',marks:{bold:true}};d.apply(text);ops.push(text);
      const move={t:'move',at:d.clock.next(),target:storage.id,parent:d.get(line).id,after:owner.marker.id};d.apply(move);ops.push(move);
    }
    else {
      const storage=d.fragmentStorage(line,d.clock.next()), id=d.clock.next();
      ops=[{t:'node',id,origin:storage.id,type:'paragraph',boundary:`${storage.key}|end`}];d.apply(ops[0]);
      const text={t:'text',id:d.clock.next(),origin:id,text:'P😀tail',marks:{bold:true}};d.apply(text);ops.push(text);
      if(route==='detached-node-promote-head') ops.push({t:'move',at:d.clock.next(),target:head.marker.id,parent:d.get(line).id,after:null});
      ops.push({t:'move',at:d.clock.next(),target:id,parent:d.get(line).id,after:owner.marker.id});
      for(const op of ops.filter(op=>op.t==='move'))d.apply(op);
    }
    const after=d.toJSON(); h.record(ops,d,{caretBefore:'',caretAfter:''});h.undo(d);const undone=d.toJSON();h.redo(d);
    console.log(JSON.stringify({type,index,route,ops,after,undone,undoExact:JSON.stringify(before)===JSON.stringify(undone),redoExact:JSON.stringify(after)===JSON.stringify(d.toJSON())}));
  }
}
