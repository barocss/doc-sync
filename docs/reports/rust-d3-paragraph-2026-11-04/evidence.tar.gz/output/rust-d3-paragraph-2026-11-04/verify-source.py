from pathlib import Path
import json,hashlib,subprocess,re
r=Path('/Users/user/github/doc-sync');t=r/'output/rust-d3-paragraph-2026-11-04'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
b=json.loads((t/'baseline.json').read_text());changed=[];unchanged=[]
allowed={'HANDOFF.md','README.md','apps/docs/src/guide/document-rules.md','apps/docs/src/guide/rust.md','apps/docs/src/roadmap.md','apps/docs/src/schemas/custom.md','apps/docs/src/schemas/document.md','docs/rust-roadmap.md','experiments/rust-sdk/README.md','experiments/rust-sdk/src/runtime_schema.rs','experiments/rust-shadow/src/movement.rs','experiments/rust-shadow/src/nested.rs','packages/doc-sync/src/crdt/doc.ts','packages/doc-sync/src/crdt/edit.ts','packages/doc-sync/dist/crdt/doc.js','packages/doc-sync/dist/crdt/edit.js'}
for p,h in b['files'].items():
 q=r/p;current=sha(q)
 if current!=h:
  assert p in allowed,p
  changed.append({'path':p,'before':h,'after':current})
 else:unchanged.append(p)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head==b['head']
for row in json.loads((t/'earlier-seals.json').read_text()):
 p=r/row['report'];assert sha(p/'seal.json')==row['sealSha256']
 seal=json.loads((p/'seal.json').read_text())
 for name,h in seal['files'].items():assert sha(p/name)==h,(p,name)
pins=json.loads((t/'before-pins.json').read_text());assert sha(r/pins['binary'])==pins['sha256']
assert sha(r/'experiments/rust-sdk/examples/runtime_textfalse_trace.rs')==b['files']['experiments/rust-sdk/examples/runtime_textfalse_trace.rs']
assert sha(r/'packages/doc-sync/src/crdt/edit.ts')=='53aef99961c48be1d6848a6185b4c1461d062477ade353b1b33074ef0b01e31b'
assert sha(r/'packages/doc-sync/src/crdt/doc.ts')=='631dfd0aacbaa719c593c9daa2b1798919267707d65ec58e579a2b07d7f50be5'
result={'status':'PASS','head':head,'baselineFiles':len(b['files']),'unchangedBaselineFiles':len(unchanged),'changedAllowed':changed,'priorSealedReportsUnchanged':12,'beforeNativeBinaryUnchanged':True,'oldTextfalseAdapterUnchanged':True,'finalTsSourcesUnchangedSinceWholeWorkspaceTest':True,'unchangedPaths':unchanged}
(t/'source-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in {'unchangedPaths','changedAllowed'}}))
