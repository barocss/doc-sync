# Required-gap design review

Decision: use a real paragraph birth in detached fragment storage. Move only the newly created paragraph. Do not emit a placement write for the pre-existing default head.

The required-child genesis chain must ignore candidate predecessor entries stored in detached fragment storage when `automaticGap(storage)` returns null. These entries are retained physical storage stubs. They must not become the genesis predecessor of the required chain. Preserve the existing exclusions for gaps anchored after required children and unwritten root gaps.

The current same-position Move of the original head is unsafe. `Placements.project` applies explicit writes in total Ticket order. That Move can replace an unknown concurrent writer for the original head. Undo ownership checks cannot prevent the initial replacement.

TypeScript condition, inside the required-chain `base.filter`, after the parent check:

```ts
const storage = parseTextStorage(this.byKey.get(entry.target)?.line.key ?? "");
if (storage?.detached && !this.automaticGap(storage)) return false;
```

Rust equivalent, in the required-chain `base.iter().filter`, after the parent check:

```rust
if self.line_of(&entry.target)
    .and_then(|line| text_address(&line.key))
    .is_some_and(|storage| storage.detached && self.automatic_gap(storage).is_none())
{
    return false;
}
```

Read-only diagnostic command:

```sh
node --experimental-strip-types output/rust-d3-paragraph-2026-11-04/design-review/required-gap-review.mjs
```

The diagnostic replaces the projection method on individual Doc instances. It does not edit production source. It manually creates paragraph operations and allocates each next Ticket after applying the previous operation, including the full text Ticket span.

Observed results in `results.jsonl`:

- Word slots `[1,2]` and `[1,3]`: requested insertion visible; original head at index 0; exact undo and redo pass.
- Presentation slot `[1,2]`: requested insertion visible; original head at index 0; exact undo and redo pass.
- Concurrent B Move of the original head: replicas converge before and after A undo. The exact B writer Ticket and destination anchor remain. A insertion operations do not target the original head.
- Source hashes before and after the diagnostic are equal for TS Doc, TS compiler, native projection, and Rust paragraph compiler.

Proof boundary: this is a TypeScript in-memory design diagnostic. It is not production compiler verification, native verification, a test-suite result, or a cross-runtime receipt. These remain the implementation owners' work.

For insertion of multiple top-level nodes, move each new node with the correct preceding placement Ticket. A Move of the first paragraph does not transport its physical source siblings. The diagnostic covers a single inserted paragraph only.
