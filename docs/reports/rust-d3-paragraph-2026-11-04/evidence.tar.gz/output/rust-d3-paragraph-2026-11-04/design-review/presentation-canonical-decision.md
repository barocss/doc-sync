# Presentation default-head model difference

The native placement projection is not the source of this difference. After the foreign Move, TypeScript `Doc.blocks(slideBody)` returns `[notes, title]`, as native does. TypeScript `Doc.toJSON()` then applies a separate canonical model pass. That pass prepends an empty default title because the first child is not text. The title maximum of one then hides the later title from the model. Its token and B placement writer remain stored.

Source evidence:

- TS `doc.ts` `toJSON`: calls `canonicalWithTextCache` after `rawFlow`.
- TS `model.ts` `canonFlow`: line 328 adds a default text node only if the first node is not text or the array is empty, and the default child maximum is not zero. Lines 331-336 apply child maximums in model order.
- Native `nested.rs` `model_nested`: directly returns serialized entries and has no equivalent final model pass.

Proposed native change: add the two missing model stages after `model_nested` builds its grouped `Vec<Value>`. Do not change `blocks_nested`, `movement_blocks`, `entries_nested`, placement records, history, or authored operations.

1. Apply the stages only to a runtime flow with normal flow semantics. Preserve legacy shape mode and graphic/container semantics. Private required storage must not inherit its parent's child rules; `apply_child_rules` already makes this distinction.
2. If the array is empty or its first node is not a text node, and `childRules[default].max != 0`, prepend a synthetic empty default text node. If the first node is text, add nothing. This prevents a second Word leading paragraph.
3. Build the synthetic node with default attributes and empty runs. It has no stored identity. A temporary `Block` with `virtual_=true` and empty chars can use `model_block` to obtain the default type and attributes. Do not copy live text or attributes from an edited automatic gap.
4. Apply child maximums to the final grouped model nodes in array order, as TS does. The synthetic title counts first. Do not sort or move stored blocks. Existing required minimum handling remains in `apply_child_rules`.

With a foreign nonempty title, the title after notes remains in the raw block projection and retained storage. The canonical model hides it because the preceding synthetic title consumes `max: 1`. This matches the existing TS rule. No ledger entry is removed or replaced.

Read-only verification:

```sh
node --experimental-strip-types output/rust-d3-paragraph-2026-11-04/design-review/presentation-canonical-review.mjs
```

The script reproduces raw TS `[notes,title]` versus canonical `[title,notes]` and the exact retained foreign writer. It then applies the existing TS canonical function to the saved native model from every step of the failing Presentation head-writer profile. All 40 models (20 steps, A and B) match their TS model. UTF-16 run encoding is converted to text before this diagnostic model comparison. Raw checkpoints, histories, and operations are not normalized or compared by this script.

The results and stable source hashes are in `presentation-canonical-results.jsonl`. This is a source and saved-trace design proof. The native implementation and main exact comparison still need their own verification.
