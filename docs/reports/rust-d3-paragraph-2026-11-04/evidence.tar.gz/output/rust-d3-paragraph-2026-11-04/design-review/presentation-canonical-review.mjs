// Read-only: compare existing native models with the TS canonical model pass.
import {Doc} from '../../../packages/doc-sync/src/index.ts';
import {canonical} from '../../../packages/doc-sync/src/crdt/model.ts';
import {PRESENTATION_SCHEMA} from '../../../fixtures/product-schemas.ts';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
const sources=['packages/doc-sync/src/crdt/doc.ts','packages/doc-sync/src/crdt/model.ts','experiments/rust-shadow/src/nested.rs','experiments/rust-shadow/src/movement.rs','experiments/rust-shadow/src/required.rs'];
const hashes=()=>Object.fromEntries(sources.map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')]));
console.log(JSON.stringify({kind:'source-hashes-before',hashes:hashes()}));
const doc=new Doc('B',PRESENTATION_SCHEMA);doc.edit([{op:'insert',at:[1],content:[{type:'slide'}]}]);
const line=doc.blocks()[1].body,head=doc.blocks(line)[0].marker.id,notes=doc.blocks(line)[1].marker.id;
const foreign={t:'move',at:doc.clock.next(),target:head,parent:doc.get(line).id,after:notes};doc.apply(foreign);
console.log(JSON.stringify({kind:'source-reproduction',foreign,rawBlocks:doc.blocks(line).map(b=>({type:b.type,key:b.marker.key})),canonicalModel:doc.toJSON().children[1],writer:doc.placementOf(head)}));
const dir='output/rust-d3-paragraph-2026-11-04/compare/run-2026-11-04T09-40-31.604Z-17888/';
const ts=JSON.parse(readFileSync(dir+'typescript-trace.json')).documents.find(d=>d.name==='presentation-concurrent-old-head-end');
const native=JSON.parse(readFileSync(dir+'native-trace.json')).documents.find(d=>d.name===ts.name);
function clean(value){if(Array.isArray(value))return value.map(clean);if(value&&typeof value==='object'){const out=Object.fromEntries(Object.entries(value).map(([k,v])=>[k,clean(v)]));if(Array.isArray(out.units)){out.text=String.fromCharCode(...out.units);delete out.units;}return out;}return value;}
let count=0,passed=0;
for(let i=0;i<ts.trace.length;i++)for(const actor of ['A','B']){
  if(!ts.trace[i][actor]?.model||!native.trace[i][actor]?.model)continue;
  const before=clean(native.trace[i][actor].model),expected=clean(ts.trace[i][actor].model),after=canonical(PRESENTATION_SCHEMA,before);
  const canonicalMatch=isDeepStrictEqual(after,expected),rawMatch=isDeepStrictEqual(before,expected);count++;if(canonicalMatch)passed++;
  console.log(JSON.stringify({kind:'trace-model',step:i,label:ts.trace[i].label,actor,rawMatch,canonicalMatch,...(!rawMatch?{nativeSlide:before.children.find(n=>n.type==='slide')?.children.map(n=>n.type),typescriptSlide:expected.children.find(n=>n.type==='slide')?.children.map(n=>n.type),canonicalNativeSlide:after.children.find(n=>n.type==='slide')?.children.map(n=>n.type)}:{})}));
}
console.log(JSON.stringify({kind:'summary',models:count,canonicalMatches:passed,scope:'Model serialization diagnostic only; no raw blocks, placement or history normalization.'}));
console.log(JSON.stringify({kind:'source-hashes-after',hashes:hashes()}));
