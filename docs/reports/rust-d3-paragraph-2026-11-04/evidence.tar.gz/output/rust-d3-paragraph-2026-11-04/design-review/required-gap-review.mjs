// Read-only diagnostic: all projection changes occur in instance memory.
import {Doc, History} from '../../../packages/doc-sync/src/index.ts';
import {WORD_SCHEMA, PRESENTATION_SCHEMA} from '../../../fixtures/product-schemas.ts';
import {parseTextStorage} from '../../../packages/doc-sync/src/crdt/text-storage.ts';
import {parseRequired} from '../../../packages/doc-sync/src/crdt/cardinality.ts';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const paths = ['packages/doc-sync/src/crdt/doc.ts', 'packages/doc-sync/src/crdt/edit.ts', 'experiments/rust-shadow/src/movement.rs', 'experiments/rust-sdk/src/runtime_paragraph.rs'];
const hashes = () => Object.fromEntries(paths.map(path => [path, createHash('sha256').update(readFileSync(path)).digest('hex')]));
console.log(JSON.stringify({kind:'source-hashes-before', hashes: hashes()}));
function diagnosticProjection(doc) {
  const project = doc.placements.project.bind(doc.placements);
  doc.placements.project = (base, ...args) => {
    const seen = new Set();
    for (const entry of base) {
      const required = parseRequired(entry.target);
      if (!required || seen.has(required.parent)) continue;
      seen.add(required.parent);
      entry.after = base.filter(candidate => {
        if (candidate.parent !== required.parent || parseRequired(candidate.target)) return false;
        const item = doc.get(candidate.target), storage = parseTextStorage(item?.line.key ?? '');
        // Proposed new exclusion. A detached fragment is storage, not an
        // authored source-flow predecessor for the required genesis chain.
        if (storage?.detached && !doc.automaticGap(storage)) return false;
        // Preserve the existing exclusions for required-anchored text gaps
        // and unedited root gaps.
        const address = parseTextStorage(candidate.target);
        if (!address) return true;
        if (candidate.after && parseRequired(candidate.after)) return false;
        return address.after !== null || !item || item.line.items.length !== 1 || item.attrs.size > 0;
      }).at(-1)?.target ?? null;
    }
    return project(base, ...args);
  };
}
function insertDetached(doc, line, after) {
  const storage = doc.fragmentStorage(line, doc.clock.next()), id = doc.clock.next(), ops = [];
  const emit = op => { ops.push(op); doc.apply(op); };
  emit({t:'node', id, origin:storage.id, type:'paragraph', boundary:`${storage.key}|end`});
  emit({t:'text', id:doc.clock.next(), origin:id, text:'P😀tail', marks:{bold:true}});
  emit({t:'move', at:doc.clock.next(), target:id, parent:doc.get(line).id, after});
  return ops;
}
for (const [schema, type, index] of [[WORD_SCHEMA,'section',2],[WORD_SCHEMA,'section',3],[PRESENTATION_SCHEMA,'slide',2]]) {
  const doc = new Doc('A', schema), history = new History();
  doc.edit([{op:'insert', at:[1], content:[{type}]}]);
  const line = doc.blocks()[1].body, before = doc.toJSON(), head = doc.blocks(line)[0].marker.key, after = doc.blocks(line)[index-1].marker.id;
  diagnosticProjection(doc);
  const ops = insertDetached(doc, line, after), inserted = doc.toJSON();
  history.record(ops, doc, {caretBefore:'',caretAfter:''});
  const undo = history.undo(doc), undone = doc.toJSON();
  const redo = history.redo(doc), redone = doc.toJSON();
  console.log(JSON.stringify({kind:'slot',type,index,ops,inserted,undone,redone,undo:undo.ops,redo:redo.ops,undoExact:JSON.stringify(before)===JSON.stringify(undone),redoExact:JSON.stringify(inserted)===JSON.stringify(redone),originalHeadIndex:doc.blocks(line).findIndex(block=>block.marker.key===head)}));
}
{
  const a = new Doc('A',WORD_SCHEMA); a.edit([{op:'insert',at:[1],content:[{type:'section'}]}]);
  const b = Doc.fromSnapshot('B',a.snapshot(),WORD_SCHEMA); diagnosticProjection(a); diagnosticProjection(b);
  const line=a.blocks()[1].body, head=a.blocks(line)[0].marker.id, footer=a.blocks(line)[2].marker.id;
  const foreign={t:'move',at:b.clock.next(),target:head,parent:b.get(line).id,after:footer};
  const check=b.check([foreign]); b.apply(foreign);
  const history=new History(), ops=insertDetached(a,line,footer); history.record(ops,a,{caretBefore:'',caretAfter:''});
  a.apply(foreign); for(const op of ops)b.apply(op);
  const same=(left,right)=>JSON.stringify(left)===JSON.stringify(right);
  const beforeUndo={converged:same(a.toJSON(),b.toJSON()),writerRetained:same(a.placementOf(head).at,foreign.at),afterRetained:same(a.placementOf(head).after,footer)};
  const undo=history.undo(a).ops; for(const op of undo)b.apply(op);
  const afterUndo={converged:same(a.toJSON(),b.toJSON()),writerRetained:same(a.placementOf(head).at,foreign.at),afterRetained:same(a.placementOf(head).after,footer)};
  console.log(JSON.stringify({kind:'foreign-head-move',foreign,foreignCheck:check,ops,undo,insertOpsTouchOriginal:ops.some(op=>op.target&&same(op.target,head)),beforeUndo,afterUndo,modelAfterUndo:a.toJSON()}));
}
console.log(JSON.stringify({kind:'source-hashes-after', hashes: hashes()}));
