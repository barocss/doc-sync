//! Bounded model-position insertion. Physical token APIs keep their own contract.
use super::*;

struct Compiler {
    doc: RuntimeDocument,
    clock: u64,
    ops: Vec<Op>,
}

impl RuntimeDocument {
    /// Insert one text block at a model child path, such as `[1, 0]`.
    /// The final index is a child index, not a UTF-16 offset. Text, inline and
    /// span runs are supported. Group/grid parents and moved documents reject.
    /// The complete insertion commits as one atomic history transaction.
    pub fn insert_paragraph_at(
        &mut self,
        at: &[usize],
        paragraph: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        let kind = paragraph["type"].as_str().unwrap_or("");
        if self.schema.effective_manifest()["nodes"][kind]["shape"] != "text" {
            return Err(Error("paragraph insertion requires a text node".into()));
        }
        self.insert_model_at(at, paragraph, options, now_ms)
    }

    /// Insert one text block or a flow containing text/flow children at a
    /// model child path. This bounded compiler does not accept grids/groups,
    /// text-offset insertion, or documents with movement operations.
    pub fn insert_model_at(
        &mut self,
        at: &[usize],
        model: Value,
        options: EditOptions,
        now_ms: f64,
    ) -> Result<(Key, Change)> {
        if self.schema.domain() != "document" || at.is_empty() {
            return Err(Error("document model child path required".into()));
        }
        let checkpoint = self.checkpoint()?;
        let mut compiler = Compiler {
            doc: Self::restore(&checkpoint)?,
            clock: self.observed_clock()?,
            ops: vec![],
        };
        let state = compiler.doc.state()?;
        if state["moves"]
            .as_array()
            .is_some_and(|moves| !moves.is_empty())
        {
            return Err(Error(
                "model insertion after movement is unsupported".into(),
            ));
        }
        compiler.validate_node(&model, 0)?;
        let line = compiler.resolve_flow(&at[..at.len() - 1])?;
        let key = compiler.insert(&line, at[at.len() - 1], &model)?;
        if compiler.doc.observed_clock()? != compiler.clock {
            return Err(Error(
                "model insertion with trailing reserved tickets is unsupported".into(),
            ));
        }
        Ok((key, self.record(compiler.ops, options, now_ms)?))
    }
}

impl Compiler {
    fn spec(&self, kind: &str) -> &Value {
        &self.doc.schema.effective_manifest()["nodes"][kind]
    }
    fn next(&mut self) -> Result<Ticket> {
        self.clock = self
            .clock
            .checked_add(1)
            .filter(|n| *n <= MAX_CLOCK)
            .ok_or_else(|| Error("clock exhausted".into()))?;
        Ok(Ticket {
            lamport: self.clock,
            actor: self.doc.actor.clone(),
        })
    }
    fn emit(&mut self, ops: Vec<Op>) -> Result<()> {
        self.doc.apply_remote(&ops)?;
        self.ops.extend(ops);
        Ok(())
    }
    fn attrs(node: &Value) -> Result<Attributes> {
        match node.get("attrs") {
            None => Ok(Attributes::new()),
            Some(value) => serde_json::from_value(value.clone()).map_err(Error::from),
        }
    }
    fn validate_attrs(&self, kind: &str, node: &Value) -> Result<()> {
        if let Some(attrs) = node.get("attrs").and_then(Value::as_object) {
            if attrs.len() > 1
                && attrs
                    .keys()
                    .any(|key| self.spec(kind)["attrs"][key].get("fields").is_some())
            {
                return Err(Error(
                    "model insertion accepts one structured attribute branch at a time".into(),
                ));
            }
        }
        self.doc.attribute_writes(kind, Self::attrs(node)?, false)?;
        Ok(())
    }
    fn validate_node(&self, node: &Value, depth: usize) -> Result<()> {
        if depth > 64 {
            return Err(Error("model insertion exceeds maximum depth".into()));
        }
        let object = node
            .as_object()
            .ok_or_else(|| Error("model node object required".into()))?;
        if object
            .keys()
            .any(|key| !["type", "attrs", "runs", "children"].contains(&key.as_str()))
        {
            return Err(Error("unsupported model node property".into()));
        }
        let kind = node["type"]
            .as_str()
            .ok_or_else(|| Error("model type required".into()))?;
        self.validate_attrs(kind, node)?;
        match self.spec(kind)["shape"].as_str() {
            Some("text") => {
                if node.get("children").is_some() {
                    return Err(Error("text node cannot have children".into()));
                }
                self.units(
                    node.get("runs").unwrap_or(&json!([])),
                    &Attributes::new(),
                    depth,
                )?;
            }
            Some("flow") => {
                if node.get("runs").is_some() {
                    return Err(Error("flow node cannot have runs".into()));
                }
                if let Some(children) = node.get("children") {
                    for child in children
                        .as_array()
                        .ok_or_else(|| Error("children array required".into()))?
                    {
                        let child_kind = child["type"].as_str().unwrap_or("");
                        if !self.spec(kind)["children"]
                            .as_array()
                            .is_some_and(|kinds| kinds.iter().any(|value| value == child_kind))
                        {
                            return Err(Error("model child is not declared by flow".into()));
                        }
                        self.validate_node(child, depth + 1)?;
                    }
                }
            }
            _ => {
                return Err(Error(
                    "model insertion supports text and flow nodes only".into(),
                ))
            }
        }
        Ok(())
    }
    fn blocks(&mut self, line: &str) -> Result<Vec<Value>> {
        let state = self.doc.state()?;
        let blocks = state["projections"]
            .as_array()
            .and_then(|projections| {
                projections
                    .iter()
                    .find(|projection| projection["line"] == line)
            })
            .and_then(|projection| projection["blocks"].as_array())
            .ok_or_else(|| Error("model flow projection missing".into()))?;
        let visible = blocks
            .iter()
            .filter(|block| {
                !(block["virtual"] == true && block["chars"].as_array().is_some_and(Vec::is_empty))
            })
            .cloned()
            .collect::<Vec<_>>();
        for block in &visible {
            let kind = block["type"].as_str().unwrap_or("");
            if self.doc.schema.effective_manifest()["nodes"]
                .as_object()
                .is_some_and(|nodes| {
                    nodes.values().any(|spec| {
                        spec["shape"] == "group"
                            && spec["children"]
                                .as_array()
                                .is_some_and(|children| children.iter().any(|child| child == kind))
                    })
                })
            {
                return Err(Error("grouped model positions are unsupported".into()));
            }
        }
        Ok(visible)
    }
    fn resolve_flow(&mut self, path: &[usize]) -> Result<String> {
        let mut line = Key::root().as_str().to_owned();
        for index in path {
            let blocks = self.blocks(&line)?;
            let block = blocks
                .get(*index)
                .ok_or_else(|| Error("model parent index outside flow".into()))?;
            line = block["body"]
                .as_str()
                .ok_or_else(|| Error("model parent must be a flow".into()))?
                .into();
        }
        Ok(line)
    }
    fn last(block: &Value) -> Result<Ticket> {
        let key = block["chars"]
            .as_array()
            .and_then(|chars| chars.last())
            .unwrap_or(&block["marker"])
            .as_str()
            .ok_or_else(|| Error("model block marker missing".into()))?;
        Key::parse(key)?.ticket()
    }
    fn insert(&mut self, line: &str, index: usize, node: &Value) -> Result<Key> {
        let blocks = self.blocks(line)?;
        if index > blocks.len() {
            return Err(Error("model child index outside flow".into()));
        }
        if index == 0 && !blocks.is_empty() {
            let head = &blocks[0];
            if head["kind"] != "text" || head["virtual"] == true {
                return Err(Error("model start requires a stored text head".into()));
            }
            let old_right = head["chars"]
                .as_array()
                .and_then(|chars| chars.first())
                .and_then(Value::as_str)
                .or_else(|| blocks.get(1).and_then(|block| block["marker"].as_str()))
                .unwrap_or("end")
                .to_owned();
            let head_key = Key::parse(head["marker"].as_str().unwrap())?;
            let (key, last) = if self.spec(node["type"].as_str().unwrap())["shape"] == "text" {
                (head_key.clone(), self.fill_head(head, node)?)
            } else {
                let default = self.line_default(line)?;
                self.retype(head, &default, Attributes::new())?;
                self.block(line, head_key.ticket()?, &old_right, node)?
            };
            let tail = json!({"type":head["type"],"attrs":head["attrs"],"runs":[]});
            self.block_with_constraint(line, last, &old_right, &tail, false)?;
            return Ok(key);
        }
        let origin = if index == 0 {
            Key::parse(line)?.ticket()?
        } else {
            Self::last(&blocks[index - 1])?
        };
        let right = blocks
            .get(index)
            .and_then(|block| block["marker"].as_str())
            .unwrap_or("end");
        let state = self.doc.state()?;
        let required_prefix = format!(
            "0@~required:{}:",
            RuntimeDocument::encode_required_part(line)
        );
        let from_required = state["lines"].as_array().is_some_and(|lines| {
            lines.iter().any(|source| {
                source["key"]
                    .as_str()
                    .is_some_and(|key| key.starts_with(&required_prefix))
                    && source["items"]
                        .as_array()
                        .is_some_and(|items| items.iter().any(|item| item["id"] == json!(origin)))
            })
        });
        if index > 0 && from_required {
            if self.spec(node["type"].as_str().unwrap())["shape"] != "text" {
                return Err(Error(
                    "model insertion after required slots supports text only".into(),
                ));
            }
            let nonce = self.next()?;
            let storage = Key::parse(format!(
                "0@~fragment:{}:{}",
                RuntimeDocument::encode_required_part(line),
                RuntimeDocument::encode_required_part(Key::from_ticket(&nonce).as_str())
            ))?;
            let (key, _) = self.block(line, storage.ticket()?, right, node)?;
            let at = self.next()?;
            self.emit(vec![Op::Move {
                at,
                target: key.ticket()?,
                parent: Key::parse(line)?.ticket()?,
                after: Some(Key::parse(blocks[index - 1]["marker"].as_str().unwrap())?.ticket()?),
            }])?;
            return Ok(key);
        }
        Ok(self.block(line, origin, right, node)?.0)
    }
    fn line_default(&mut self, line: &str) -> Result<String> {
        let state = self.doc.state()?;
        state["lines"]
            .as_array()
            .and_then(|lines| lines.iter().find(|entry| entry["key"] == line))
            .and_then(|entry| entry["items"].as_array())
            .and_then(|items| items.first())
            .and_then(|item| item["born"].as_str())
            .map(str::to_owned)
            .ok_or_else(|| Error("flow default missing".into()))
    }
    fn birth_attrs(
        &self,
        kind: &str,
        attrs: Attributes,
    ) -> Result<(Attributes, Vec<(String, Value)>)> {
        let (mut scalar, fields) = self.doc.attribute_writes(kind, attrs, false)?;
        scalar.retain(|key, value| {
            !value.is_null()
                && (value.is_object()
                    || value.is_array()
                    || !RuntimeDocument::same_value(
                        value,
                        &self.spec(kind)["attrs"][key]["default"],
                    ))
        });
        Ok((scalar, fields))
    }
    fn block(
        &mut self,
        line: &str,
        origin: Ticket,
        right: &str,
        node: &Value,
    ) -> Result<(Key, Ticket)> {
        self.block_with_constraint(line, origin, right, node, true)
    }
    fn block_with_constraint(
        &mut self,
        line: &str,
        origin: Ticket,
        right: &str,
        node: &Value,
        constrain: bool,
    ) -> Result<(Key, Ticket)> {
        let kind = node["type"].as_str().unwrap();
        let id = self.next()?;
        let key = Key::from_ticket(&id);
        let text = self.spec(kind)["shape"] == "text";
        let constrained =
            constrain && text && self.doc.constrained_child(&Key::parse(line)?, kind)?;
        let boundary = if text {
            format!(
                "{}|{}{}",
                Key::from_ticket(&origin).as_str(),
                right,
                if constrained {
                    format!("|child:{}", key.as_str())
                } else {
                    String::new()
                }
            )
        } else {
            String::new()
        };
        let (attrs, fields) = self.birth_attrs(kind, Self::attrs(node)?)?;
        let mut ops = vec![Op::Node {
            id: id.clone(),
            origin,
            node_type: kind.into(),
            boundary,
            attrs: (!attrs.is_empty()).then_some(attrs),
        }];
        for (field, value) in fields {
            let at = self.next()?;
            ops.push(Op::Set {
                at,
                ids: vec![id.clone()],
                key: field,
                value,
            });
        }
        self.emit(ops)?;
        let last = if text {
            self.emit_runs(id, node.get("runs").unwrap_or(&json!([])))?
        } else {
            let body = RuntimeDocument::flow_head(Some(&key))?;
            let children = node
                .get("children")
                .and_then(Value::as_array)
                .cloned()
                .unwrap_or_default();
            if let Some((first, rest)) = children.split_first() {
                let blocks = self.blocks(body.as_str())?;
                let head = blocks
                    .first()
                    .ok_or_else(|| Error("new flow has no text head".into()))?;
                let mut last = if self.spec(first["type"].as_str().unwrap())["shape"] == "text" {
                    self.fill_head(head, first)?
                } else {
                    Self::last(head)?
                };
                let rest = if self.spec(first["type"].as_str().unwrap())["shape"] == "text" {
                    rest
                } else {
                    &children
                };
                for child in rest {
                    last = self.block(body.as_str(), last, "end", child)?.1;
                }
            }
            id
        };
        Ok((key, last))
    }
    fn retype(&mut self, head: &Value, kind: &str, attrs: Attributes) -> Result<()> {
        let id = Key::parse(head["marker"].as_str().unwrap())?.ticket()?;
        let mut staged = vec![];
        if head["type"] != kind {
            let at = self.next()?;
            staged.push((at, "$type".to_owned(), json!(kind)));
        }
        let specs = self.spec(kind)["attrs"]
            .as_object()
            .cloned()
            .unwrap_or_default();
        for (key, spec) in &specs {
            let value = attrs
                .get(key)
                .filter(|v| !v.is_null())
                .unwrap_or(&spec["default"]);
            if spec.get("fields").is_some() || head["attrs"][key] != *value {
                let at = self.next()?;
                staged.push((
                    at,
                    key.clone(),
                    if attrs.get(key).is_none_or(Value::is_null)
                        || !value.is_object()
                            && !value.is_array()
                            && RuntimeDocument::same_value(value, &spec["default"])
                    {
                        Value::Null
                    } else {
                        value.clone()
                    },
                ));
            }
        }
        let mut ops = vec![];
        for (at, key, value) in staged {
            if specs
                .get(&key)
                .is_some_and(|spec| spec.get("fields").is_some())
            {
                let mut writes = vec![];
                RuntimeDocument::field_writes(&specs[&key], &value, &mut vec![key], &mut writes)?;
                for (key, value, _) in writes {
                    let at = self.next()?;
                    ops.push(Op::Set {
                        at,
                        ids: vec![id.clone()],
                        key,
                        value,
                    });
                }
            } else {
                ops.push(Op::Set {
                    at,
                    ids: vec![id.clone()],
                    key,
                    value,
                });
            }
        }
        self.emit(ops)
    }
    fn fill_head(&mut self, head: &Value, node: &Value) -> Result<Ticket> {
        self.retype(head, node["type"].as_str().unwrap(), Self::attrs(node)?)?;
        self.emit_runs(
            Key::parse(head["marker"].as_str().unwrap())?.ticket()?,
            node.get("runs").unwrap_or(&json!([])),
        )
    }
    fn units(
        &self,
        runs: &Value,
        outer: &Attributes,
        depth: usize,
    ) -> Result<Vec<(Value, Attributes)>> {
        if depth > 64 {
            return Err(Error("run nesting exceeds maximum depth".into()));
        }
        let mut out = vec![];
        for run in runs
            .as_array()
            .ok_or_else(|| Error("runs array required".into()))?
        {
            if let Some(text) = run.get("text") {
                let text = text
                    .as_str()
                    .ok_or_else(|| Error("run text must be a string".into()))?;
                let mut marks: Attributes = match run.get("marks") {
                    None => Attributes::new(),
                    Some(value) => serde_json::from_value(value.clone())?,
                };
                marks.extend(outer.clone());
                let manifest = self.doc.schema.effective_manifest();
                let mut canonical = Attributes::new();
                for (name, value) in marks {
                    if manifest["marks"]
                        .as_array()
                        .is_some_and(|keys| keys.iter().any(|key| key == &name))
                    {
                        if value == true {
                            canonical.insert(name, value);
                        } else if !value.is_null() && !value.is_boolean() {
                            return Err(Error("invalid boolean mark".into()));
                        }
                    } else if let Some(spec) = manifest["markValues"].get(&name) {
                        if !value.is_null() && value != spec["default"] {
                            canonical.insert(name, value);
                        }
                    } else {
                        return Err(Error("unknown run mark".into()));
                    }
                }
                if !text.is_empty() {
                    out.push((json!(text), canonical));
                }
            } else {
                let kind = run["type"]
                    .as_str()
                    .ok_or_else(|| Error("inline or span type required".into()))?;
                match self.spec(kind)["shape"].as_str() {
                    Some("inline") => {
                        self.validate_attrs(kind, run)?;
                        out.push((run.clone(), Attributes::new()));
                    }
                    Some("span") => {
                        let mut outer = outer.clone();
                        let mark = self.spec(kind)["mark"].as_str().unwrap();
                        let attr = self.spec(kind)["attr"].as_str().unwrap();
                        outer.insert(mark.into(), run["attrs"][attr].clone());
                        out.extend(self.units(
                            run.get("runs").unwrap_or(&json!([])),
                            &outer,
                            depth + 1,
                        )?);
                    }
                    _ => return Err(Error("unsupported run node".into())),
                }
            }
        }
        Ok(out)
    }
    fn emit_runs(&mut self, mut origin: Ticket, runs: &Value) -> Result<Ticket> {
        let units = self.units(runs, &Attributes::new(), 0)?;
        let mut index = 0;
        while index < units.len() {
            let (value, marks) = &units[index];
            if let Some(text) = value.as_str() {
                let mut text = text.to_owned();
                index += 1;
                while index < units.len() && units[index].0.is_string() && units[index].1 == *marks
                {
                    text.push_str(units[index].0.as_str().unwrap());
                    index += 1;
                }
                let id = self.next()?;
                let units = Utf16Text::from(text.as_str());
                self.clock = self
                    .clock
                    .checked_add(units.0.len() as u64 - 1)
                    .filter(|n| *n <= MAX_CLOCK)
                    .ok_or_else(|| Error("clock exhausted".into()))?;
                self.emit(vec![Op::Text {
                    id: id.clone(),
                    origin,
                    units,
                    marks: marks.clone(),
                }])?;
                origin = Ticket {
                    lamport: self.clock,
                    actor: id.actor,
                };
            } else {
                let id = self.next()?;
                let kind = value["type"].as_str().unwrap();
                let (attrs, fields) = self.birth_attrs(kind, Self::attrs(value)?)?;
                let mut ops = vec![Op::Node {
                    id: id.clone(),
                    origin,
                    node_type: kind.into(),
                    boundary: String::new(),
                    attrs: (!attrs.is_empty()).then_some(attrs),
                }];
                for (key, value) in fields {
                    let at = self.next()?;
                    ops.push(Op::Set {
                        at,
                        ids: vec![id.clone()],
                        key,
                        value,
                    });
                }
                self.emit(ops)?;
                origin = id;
                index += 1;
            }
        }
        Ok(origin)
    }
}
