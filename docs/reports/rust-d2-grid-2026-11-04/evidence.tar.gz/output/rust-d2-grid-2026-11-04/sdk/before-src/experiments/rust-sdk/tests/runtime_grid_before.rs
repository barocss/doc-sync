use doc_sync_native_sdk::*;
use serde_json::{json, Value};
fn schema() -> RuntimeSchema {
    RuntimeSchema::compile(json!({"root":"book","marks":["strong"],"nodes":{
        "book":{"shape":"flow","children":["line","box","matrix"],"default":"line"},
        "box":{"shape":"flow","children":["line","box","matrix"],"default":"line"},
        "line":{"shape":"text"},
        "matrix":{"shape":"grid","children":["band"],"attrs":{"tone":{"default":"plain"}}},
        "band":{"shape":"row","children":["tile"]},
        "tile":{"shape":"cell","children":["body"],"attrs":{"shade":{"default":"white"}}},
        "body":{"shape":"flow","children":["line","box","matrix"],"default":"line"}
    }}))
    .unwrap()
}

#[test]
fn runtime_grid_schema_compiles() { let _ = schema(); }
