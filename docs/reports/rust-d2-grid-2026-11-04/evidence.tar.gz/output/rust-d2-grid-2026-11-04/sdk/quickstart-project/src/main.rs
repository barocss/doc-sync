use doc_sync_native_sdk::*;
use serde_json::json;
fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({"root":"notebook","marks":[],"nodes":{
        "notebook":{"shape":"flow","children":["line","section","matrix"],"default":"line"},
        "line":{"shape":"text"},
        "section":{"shape":"flow","children":["line","matrix"],"default":"line"},
        "matrix":{"shape":"grid","children":["band"]},
        "band":{"shape":"row","children":["tile"]},
        "tile":{"shape":"cell","children":["body"]},
        "body":{"shape":"flow","children":["line","matrix"],"default":"line"}
    }}))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let (section, _) = a.insert_block("section", None, None, Attributes::new(), EditOptions::default(), 1.)?;
    let head = RuntimeDocument::flow_head(Some(&section))?;
    let (grid, rows, cols, _) = a.insert_grid_at(&head, "matrix", None, 2, 2, Attributes::new(), EditOptions::default(), 2.)?;
    let cell = RuntimeDocument::cell_head(&grid, &rows[0], &cols[0])?;
    let (nested, nr, nc, _) = a.insert_grid_at(&cell, "matrix", None, 1, 1, Attributes::new(), EditOptions::default(), 3.)?;
    a.insert_cell_text(&nested, &nr[0], &nc[0], None, "hello😀", Attributes::new(), EditOptions::default(), 4.)?;
    for change in a.pending_changes() { b.apply_remote(&change.ops)?; }
    let peer = b.insert_cell_text(&grid, &rows[1], &cols[1], None, "peer", Attributes::new(), EditOptions::default(), 5.)?;
    a.apply_remote(&peer.ops)?;
    let merge = a.merge_cells(&grid, &rows[0], &cols[0], &rows[1], &cols[1], EditOptions::default(), 6.)?;
    b.apply_remote(&merge.ops)?;
    let undo = a.undo()?; b.apply_remote(&undo.ops)?;
    assert_eq!(a.model()?, b.model()?);
    let saved = RuntimeCheckpoint::from_json(&a.checkpoint()?.to_json()?)?;
    let mut restored = RuntimeDocument::restore(&saved)?;
    let before = restored.checkpoint()?.to_json()?;
    let pending = restored.pending_changes().to_vec();
    for change in &pending { restored.apply_remote(&change.ops)?; }
    assert_eq!(restored.checkpoint()?.to_json()?, before);
    restored.acknowledge(&pending)?;
    assert_eq!(restored.model()?, b.model()?);
    println!("PASS: nested grids, two peers, selective undo, checkpoint and exact retry");
    Ok(())
}
