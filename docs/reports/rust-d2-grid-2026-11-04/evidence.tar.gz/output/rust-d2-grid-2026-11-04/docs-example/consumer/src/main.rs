use doc_sync_native_sdk::*;
use serde_json::{json, Value};

fn has_units(node: &Value, text: &str) -> bool {
    if node["attrs"]["spanned"] == true {
        return false;
    }
    let units: Vec<u16> = text.encode_utf16().collect();
    match node {
        Value::Object(fields) => {
            fields.get("units") == Some(&json!(units))
                || fields.values().any(|value| has_units(value, text))
        }
        Value::Array(values) => values.iter().any(|value| has_units(value, text)),
        _ => false,
    }
}

fn find_type<'a>(node: &'a Value, kind: &str) -> Option<&'a Value> {
    if node["type"] == kind {
        return Some(node);
    }
    node["children"]
        .as_array()?
        .iter()
        .find_map(|child| find_type(child, kind))
}

fn main() -> Result<()> {
    let schema = RuntimeSchema::compile(json!({"root":"notebook","marks":[],"nodes":{
        "notebook":{"shape":"flow","children":["line","section"],"default":"line"},
        "line":{"shape":"text"},
        "section":{"shape":"flow","children":["line","matrix"],"default":"line"},
        "matrix":{"shape":"grid","children":["band"]},
        "band":{"shape":"row","children":["tile"]},
        "tile":{"shape":"cell","children":["body"],"attrs":{
            "shade":{"default":"white"},
            "colspan":{"default":1,"min":1,"computed":true},
            "rowspan":{"default":1,"min":1,"computed":true},
            "spanned":{"default":false,"computed":true}}},
        "body":{"shape":"flow","children":["line","detail"],"default":"line"},
        "detail":{"shape":"grid","children":["track"]},
        "track":{"shape":"row","children":["entry"]},
        "entry":{"shape":"cell","children":["content"]},
        "content":{"shape":"flow","children":["caption"],"default":"caption"},
        "caption":{"shape":"text"}
    }}))?;
    let mut a = RuntimeDocument::new("A", schema.clone())?;
    let mut b = RuntimeDocument::new("B", schema)?;
    let options = EditOptions::default();
    let (section, _) = a.insert_block(
        "section",
        None,
        None,
        Attributes::new(),
        options.clone(),
        1.,
    )?;
    let head = RuntimeDocument::flow_head(Some(&section))?;
    let (grid, rows, cols, _) = a.insert_grid_at(
        &head,
        "matrix",
        None,
        2,
        2,
        Attributes::new(),
        options.clone(),
        2.,
    )?;
    let cell = RuntimeDocument::cell_head(&grid, &rows[0], &cols[0])?;
    let (nested, nr, nc, _) = a.insert_grid_at(
        &cell,
        "detail",
        None,
        1,
        1,
        Attributes::new(),
        options.clone(),
        3.,
    )?;
    a.insert_cell_text(
        &nested,
        &nr[0],
        &nc[0],
        None,
        "own😀",
        Attributes::new(),
        options.clone(),
        4.,
    )?;
    for change in a.pending_changes() {
        b.apply_remote(&change.ops)?;
    }
    let peer = b.insert_cell_text(
        &grid,
        &rows[0],
        &cols[1],
        None,
        "peer",
        Attributes::new(),
        options.clone(),
        5.,
    )?;
    a.apply_remote(&peer.ops)?;
    let undo = a.undo()?;
    b.apply_remote(&undo.ops)?;
    assert!(!has_units(&a.model()?, "own😀"));
    assert!(has_units(&a.model()?, "peer"));
    let redo = a.redo()?;
    b.apply_remote(&redo.ops)?;
    assert!(has_units(&a.model()?, "own😀"));
    assert!(has_units(&a.model()?, "peer"));
    let merge = a.merge_cells(
        &grid,
        &rows[0],
        &cols[0],
        &rows[0],
        &cols[1],
        options.clone(),
        6.,
    )?;
    b.apply_remote(&merge.ops)?;
    let merged = a.model()?;
    let covered = &find_type(&merged, "matrix").unwrap()["children"][0]["children"][1];
    assert_eq!(covered["attrs"]["spanned"], true);
    assert!(has_units(&covered["children"], "peer"));
    assert!(!has_units(&merged, "peer"));
    let split = a.split_cell(&grid, &rows[0], &cols[0], options, 7.)?;
    b.apply_remote(&split.ops)?;
    assert!(has_units(&a.model()?, "peer"));
    assert_eq!(a.model()?, b.model()?);
    let saved = RuntimeCheckpoint::from_json(&a.checkpoint()?.to_json()?)?;
    let mut restored = RuntimeDocument::restore(&saved)?;
    let before = restored.checkpoint()?.to_json()?;
    let pending = restored.pending_changes().to_vec();
    for change in &pending {
        restored.apply_remote(&change.ops)?;
    }
    assert_eq!(restored.checkpoint()?.to_json()?, before);
    restored.acknowledge(&pending)?;
    assert!(restored.pending_changes().is_empty());
    assert_eq!(restored.model()?, b.model()?);
    println!("PASS: two grid chains, peers, foreign text, spans and checkpoint retry");
    Ok(())
}
