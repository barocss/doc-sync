# Runtime nested grid verification plan

Preserve inherited uncommitted recursive-flow source and the sealed preceding
report. Baseline archive and hash map capture the current worktree, not only
Git HEAD. Core, SDK and comparison agents own disjoint files.

Qualify renamed runtime grid -> row -> cell -> flow chains inside recursive
Document flows. Use existing TypeScript schema/grid semantics and fixed Rust
nested storage as the reference, without changing collaboration rules. Test
axis insertion/deletion, concurrent cell text/attributes, merged hidden content,
selective undo/redo, stable selection, checkpoint/pending/ACK duplicate replay,
invalid descriptors and atomic rejection where supported.

Independent traces must author operations in each engine. Compare full History
identity references and typed pending/carets, operations, clock, material state
and normalized models. Preserve first failures and any projection assumptions.
The preceding D3 post-move model-position insertion gap remains open; do not
silently alter a failing corpus or call an observed mismatch NOT_RUN.

Run Cargo suites with separate task targets and frozen hashes. Reuse earlier
qualified checks only when source maps match; otherwise rerun affected suites.
Run TS comparison before any package rebuild. Run integrated npm test and docs
build sequentially because both rebuild and remove dist. No mobile, no new
Chrome/performance or production WASM/backend qualification is requested.

Update current README/guide/custom-schema table/roadmaps/HANDOFF and add a
portable source-bound report, retaining failures. No commit/push or registry
publication is requested by this task.
